close all;
%clear all;

set_globals;

get_movie_info_for_processing  % which_movie must already be set


str_movie_processed = strcat(str_movie,'_processed')

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);

% load in cellular signals file for processing
file_signals = strcat(str_movie_processed,'\cellular_signals'); 
load(file_signals);

% load in processed data from nuclear tracking code
file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
load(file_track);


do_load_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_nucleus_structs ==1)&(exist('Cell_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
load(file_nucleus_tot_FINAL);
end;

do_load_cytosol_structs = 1;  % 1 - yes, 0 - no
if (do_load_cytosol_structs ==1)&(exist('Cell_cytosol_FILL_6')==0)
% load in the thresholded cytosol information from all frames 
file_cytosol_tot_FINAL = strcat(str_movie_processed,'\Cell_cytosol_structs_tot_FINAL');
load(file_cytosol_tot_FINAL);
end;

do_load_movie_arrays = 1;  % 1 - yes, 0 - no
if (do_load_movie_arrays == 1)&(exist('M_DAPI_total')==0)
% load in processed data from nuclear tracking code
file_movie_arrays = strcat(str_movie_processed,'\movie_arrays'); 
load(file_movie_arrays);
end;

%plot_all_nuclei_movements;  

%plot_localized_group_of_nuclei_over_time

%%%plot_specific_nucleus_and_signals(which_nucleus,M_DAPI_id_threshold,M_DAPI,M_FITC,M_CY3,box_coords);  % this has thresholding test to separare touching nuclei


 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate average nuclear signals (per pixel)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for kkk = 1:length(which_frames)
    which_frame = which_frames(kkk);
    average_nuclear_FITC_tot_time(which_frame) = 0;
    average_nuclear_CY3_tot_time(which_frame) = 0;
for which_nucleus = 1:num_nuclei_time(which_frame)
 average_nuclear_FITC_tot_time(which_frame) = average_nuclear_FITC_tot_time(which_frame) + nuclear_FITC_tot_time(which_nucleus,which_frame)*num_pixels_tot_NUCLEUS_time(which_nucleus,which_frame);
 average_nuclear_CY3_tot_time(which_frame) = average_nuclear_CY3_tot_time(which_frame) + nuclear_CY3_tot_time(which_nucleus,which_frame)*num_pixels_tot_NUCLEUS_time(which_nucleus,which_frame);
end;
 average_nuclear_FITC_tot_time(which_frame) = average_nuclear_FITC_tot_time(which_frame)/sum(num_pixels_tot_NUCLEUS_time(1:num_nuclei_time(which_frame),which_frame));
 average_nuclear_CY3_tot_time(which_frame) = average_nuclear_CY3_tot_time(which_frame)/sum(num_pixels_tot_NUCLEUS_time(1:num_nuclei_time(which_frame),which_frame));
end;

figure(2222)
subplot(2,1,1);
plot(time_sequence_movie,average_nuclear_FITC_tot_time);
xlim([0 max(time_sequence_movie)]);
title(strcat('Average Nuclear Signal per pixel MOVIE:',path_movie,')'));
ylabel('FITC');
xlabel('time (seconds)');
subplot(2,1,2);
plot(time_sequence_movie,average_nuclear_CY3_tot_time);
xlim([0 max(time_sequence_movie)]);
ylabel('CY3');
xlabel('time (seconds)');

figure(2223)
subplot(2,1,1);
plot(time_sequence_movie(2:length(time_sequence_movie)),1./dt_sequence_movie)
xlim([0 max(time_sequence_movie)]);
ylabel('sampling/bPAC impuls frequency (Hz)');
xlabel('time (seconds)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Process ERK signals if present
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (marker_from_channel(ii_Erk_marker) > 0)

  if (marker_from_channel(ii_Erk_marker)==ii_FITC)
      nuclear_Erk_tot_time_mapped_t0 = nuclear_FITC_tot_time_mapped_t0;
      cytosolic_Erk_tot_time_mapped_t0 = cytosolic_FITC_tot_time_mapped_t0;
  elseif (marker_from_channel(ii_Erk_marker)==ii_CY3)
      nuclear_Erk_tot_time_mapped_t0 = nuclear_CY3_tot_time_mapped_t0;
      cytosolic_Erk_tot_time_mapped_t0 = cytosolic_CY3_tot_time_mapped_t0;
  end;
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate mean Erks signals and plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for kkk = 1:length(which_frames)
    which_frame = which_frames(kkk);
    average_nuclear_Erk_tot_time_mapped_t0(which_frame) = 0;
    average_ratio_Erk_tot_time_mapped_t0(which_frame) = 0;
for which_nucleus = 1:num_nuclei_t0
 average_nuclear_Erk_tot_time_mapped_t0(which_frame) = average_nuclear_Erk_tot_time_mapped_t0(which_frame) + nuclear_Erk_tot_time_mapped_t0(which_nucleus,which_frame)*num_pixels_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame);
 average_ratio_Erk_tot_time_mapped_t0(which_frame) = average_ratio_Erk_tot_time_mapped_t0(which_frame) + nuclear_Erk_tot_time_mapped_t0(which_nucleus,which_frame)/...
                                                         cytosolic_Erk_tot_time_mapped_t0(which_nucleus,which_frame);
end;
 average_nuclear_Erk_tot_time_mapped_t0(which_frame) = average_nuclear_Erk_tot_time_mapped_t0(which_frame)/sum(num_pixels_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame));
 average_ratio_Erk_tot_time_mapped_t0(which_frame) = average_ratio_Erk_tot_time_mapped_t0(which_frame)/num_nuclei_t0;
end;
    
 
  index_sample_frame_Erk = [];
  for iii = 1:length(tau_sample_movie)      
    if (tau_sample_movie(iii) > 60)
       index_sample_frame_Erk = [index_sample_frame_Erk; iii];
    end;
  end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Floor and adjust signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do_floor_adjustment = 1;
if (do_floor_adjustment == 1)
block_size = ceil(3*period_burst_Erk/tau_first);
block_size = 10;
do_floor_plots = 0; 

    file_cellular_Erk_signals = strcat(str_movie_processed,'\cellular_Erk_signals');
   [nuclear_Erk_signal_adjusted ,nuclear_Erk_signal_floor,nuclear_Erk_signal,num_nuclei] = floor_and_adjust_signal(nuclear_Erk_tot_time_mapped_t0,num_nuclei_t0,numFr,block_size,do_floor_plots);
   nuclear_Erk_signal_average = sum(nuclear_Erk_signal);
     bursting_nuclear_Erk_cells_per_sample_frame = calculate_bursting_cells_per_sample_frame(nuclear_Erk_signal_adjusted,index_sample_frame_Erk,num_nuclei_t0,numFr,threshold_burst_Erk);  % to write;
%do_floor_plots = 1; 
   [cytosolic_Erk_signal_adjusted ,cytosolic_Erk_signal_floor,cytosolic_Erk_signal,num_nuclei] = floor_and_adjust_signal(cytosolic_Erk_tot_time_mapped_t0,num_nuclei_t0,numFr,block_size,do_floor_plots);
   cytosolic_Erk_signal_average = sum(cytosolic_Erk_signal);
    save(file_cellular_Erk_signals,'nuclear_Erk_signal','nuclear_Erk_signal_floor','nuclear_Erk_signal_adjusted','nuclear_Erk_signal_average','cytosolic_Erk_signal','cytosolic_Erk_signal_floor','cytosolic_Erk_signal_adjusted','cytosolic_Erk_signal_average','num_nuclei','numFr','block_size');    
elseif (do_floor_adjustment == 0)
    plot_Ca_signals_and_image
end;

  
  
figure(100)
subplot(3,1,1);
%plot(time_sequence_movie,average_nuclear_Erk_tot_time_mapped_t0);
plot(time_sequence_movie,average_ratio_Erk_tot_time_mapped_t0);
xlim([0 numFr]);
title(strcat('Average Nuclear Signal per pixel MOVIE:',path_movie,')'));
ylabel('av. nuc. Erk');
xlabel('number of frames');
xlim([0 max(time_sequence_movie)]);
xlabel('time (seconds)');
hold on;
for iii = 1:10
    which_nucleus = round(rand*(num_nuclei_t0-1)) + 1
subplot(3,1,2);
hold on;    
plot(time_sequence_movie,nuclear_Erk_tot_time_mapped_t0(which_nucleus,:)-nuclear_Erk_tot_time_mapped_t0(which_nucleus,1));
hold off
subplot(3,1,3);
hold on;    
plot(time_sequence_movie,cytosolic_Erk_tot_time_mapped_t0(which_nucleus,:)-cytosolic_Erk_tot_time_mapped_t0(which_nucleus,1));
hold off
end;
hold off;
subplot(3,1,2);
ylabel('nuclear Erk single cell');
xlim([0 max(time_sequence_movie)]);
xlabel('time (seconds)');
hold off;
subplot(3,1,3);
ylabel('cytosolic Erk single cell');
xlim([0 max(time_sequence_movie)]);
xlabel('time (seconds)');

pause
%plot_specific_nucleus_over_time
%plot_specific_nucleus_over_time_TIME
   
s_dist = ['k' 'b' 'r' 'g'];
which_frame_dist = [1 10 max(which_frames)];
for iii = 1:length(which_frame_dist)
    which_frame = which_frame_dist(iii);
    figure(10001)
    hold on;
    [NN,XX] = hist(nuclear_Erk_tot_time_mapped_t0(:,which_frame)-nuclear_Erk_tot_time_mapped_t0(:,1),20);
    h2 = plot(XX,NN/max(NN),num2str(s_dist(iii),'--'));
    set(h2,'LineWidth',2);
    xlim([-.3*max(XX) 1.1*max(XX)]);
    %ylim([0 1.2]);
end;
   legend(strcat('frame: ',num2str(which_frame_dist(1))),strcat('frame: ',num2str(which_frame_dist(2))),strcat('frame: ',num2str(which_frame_dist(3))));   
    
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate Erks signals, oscillations (to do)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    


    
end; % END OF: if (marker_from_channel(ii_Erk_marker) > 0)
    



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Process CALCIUM signals if present
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (marker_from_channel(ii_Ca_marker) > 0)

  if (marker_from_channel(ii_Ca_marker)==ii_FITC)
      nuclear_Ca_tot_time_mapped_t0 = nuclear_FITC_tot_time_mapped_t0;
      cytosolic_Ca_tot_time_mapped_t0 = cytosolic_FITC_tot_time_mapped_t0;
  elseif (marker_from_channel(ii_Ca_marker)==ii_CY3)
      nuclear_Ca_tot_time_mapped_t0 = nuclear_CY3_tot_time_mapped_t0;
      cytosolic_Ca_tot_time_mapped_t0 = cytosolic_CY3_tot_time_mapped_t0;
  end;

  
  index_sample_frame_Ca = [];
  for iii = 1:length(tau_sample_movie)      
    if (tau_sample_movie(iii) <= 30)
       index_sample_frame_Ca = [index_sample_frame_Ca; iii];
    end;
  end;

     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Floor and adjust signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do_floor_adjustment = 1;
if (do_floor_adjustment == 1)
block_size = ceil(3*period_burst_Ca/tau_first);
block_size = 10;
do_floor_plots = 0; 

    file_cellular_Ca_signals = strcat(str_movie_processed,'\cellular_Ca_signals');
   [nuclear_Ca_signal_adjusted ,nuclear_Ca_signal_floor,nuclear_Ca_signal,num_nuclei] = floor_and_adjust_signal(nuclear_Ca_tot_time_mapped_t0,num_nuclei_t0,numFr,block_size,do_floor_plots);
   nuclear_Ca_signal_average = sum(nuclear_Ca_signal);
     bursting_nuclear_Ca_cells_per_sample_frame = calculate_bursting_cells_per_sample_frame(nuclear_Ca_signal_adjusted,index_sample_frame_Ca,num_nuclei_t0,numFr,threshold_burst_Ca);  % to write;
   [cytosolic_Ca_signal_adjusted ,cytosolic_Ca_signal_floor,cytosolic_Ca_signal,num_nuclei] = floor_and_adjust_signal(cytosolic_Ca_tot_time_mapped_t0,num_nuclei_t0,numFr,block_size,do_floor_plots);
   cytosolic_Ca_signal_average = sum(cytosolic_Ca_signal);
     bursting_cytosolic_Ca_cells_per_sample_frame = calculate_bursting_cells_per_sample_frame(cytosolic_Ca_signal_adjusted,index_sample_frame_Ca,num_nuclei_t0,numFr,threshold_burst_Ca);  % to write;
    save(file_cellular_Ca_signals,'nuclear_Ca_signal','nuclear_Ca_signal_floor','nuclear_Ca_signal_adjusted','nuclear_Ca_signal_average','cytosolic_Ca_signal','cytosolic_Ca_signal_floor','cytosolic_Ca_signal_adjusted','cytosolic_Ca_signal_average','num_nuclei','numFr','block_size');    
    %load_and_plot_nucleus_Ca_signals_and_images
elseif (do_floor_adjustment == 0)
    plot_Ca_signals_and_image
end;










end;  % END OF: if (min(abs(marker_from_channel(ii_FITC)-ii_Ca_marker))==0)







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate clusters that are correlated based on some metricalculate average nuclear signals per pixel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do_generate_clusters = 1;
if (do_generate_clusters == 1)

%   get_which_metrics_to_correlate_for_movie;  % movie specific metrics
%   (still need to make this)
     
% 09/06/15: need to adjust this for localized frames such as: bursting_nuclear_Ca_cells_per_sample_frame    plot_bursting_cells_per_sequence_frame   
     
 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Unbiased xcorrelation, based on max being a thresholded factor greater than the next closet value
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 do_plot_xcorr_groups = 1;  % 0 - no, 1 - yes
 if (do_plot_xcorr_groups == 1)   
   generate_xcorr_groups_bursting_window_ppt_movies   
   %generate_xcorr_groups_ppt_movies   
 end; % end of 'if (do_plot_xcorr_groups == 1)   

end;  % END OF: if (do_generate_clusters == 1)








do_not_run = 0;
if (do_not_run == 1)


    if (which_frame == 0)
    calculate_nucleus_signals
    end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%  Average nuclear (per pixel) FITC AND CY3 signals    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

for ii = 1:xLength
 for jj = 1:yLength
    
     FITC_nuclear_average(which_frame) =  FITC_nuclear_average(which_frame) + M_FITC(ii,jj)*M_DAPI_threshold_FILL(ii,jj);
     CY3_nuclear_average(which_frame) =  CY3_nuclear_average(which_frame) + M_CY3(ii,jj)*M_DAPI_threshold_FILL(ii,jj);
     
 end;
end;

     FITC_nuclear_average(which_frame) =  FITC_nuclear_average(which_frame)/sum(sum(M_DAPI_threshold_FILL));
     CY3_nuclear_average(which_frame) =  CY3_nuclear_average(which_frame)/sum(sum(M_DAPI_threshold_FILL));


figure(2222)
subplot(2,1,1);
plot(FITC_nuclear_average);
xlim([0 numFr]);
title(strcat('Average Nuclear Signal per pixel MOVIE:',path_movie,')'));
ylabel('FITC');
xlabel('number of frames');
subplot(2,1,2);
plot(CY3_nuclear_average);
xlim([0 numFr]);
ylabel('CY3');
xlabel('number of frames');
  
  
  
  % run the calcium signaling movie
%plot_movie(M_FITC_total)


% TAKEN FROM load_and_process_multicellular_movie.m, might need to floor a
% sigan, such as Calcium

%  found_file_FITC_adjusted = fileattrib(strcat(str_processing_folder,str_movie,'_processed\FITC_adjusted.mat'))
%
%   if (found_file_FITC_adjusted == 0)
%    floor_pixel_Ca_signal
%    save(strcat(str_processing_folder,str_movie,'_processed\FITC_adjusted'),'M_FITC_total_adjusted');
%   else
%    load(strcat(str_processing_folder,str_movie,'_processed\FITC_adjusted'));
%   end;  % end of 'if (found_file_FITC_adjusted == 0)


end;  % END OF: if (do_not_run == 1)
