% %   %  For two population gap-junctin simulations
% if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(min(abs(ii_Species_to_plot_array - ii_GJ2_complex_on)) == 0)  
%   if (ii_Species_to_plot == ii_GJ_complex_on)
%    signal_average_bPAC_cluster_GJ = signal_average_bPAC_cluster
%    signal_average_non_bPAC_cluster_inner_GJ =    signal_average_non_bPAC_cluster_inner;  
%   elseif (ii_Species_to_plot == ii_GJ2_complex_on)
%    sum_signal_average_bPAC_cluster_GJ_GJ2 = signal_average_bPAC_cluster_GJ + signal_average_bPAC_cluster;
%    sum_signal_average_non_bPAC_cluster_inner_GJ_GJ2 = signal_average_non_bPAC_cluster_inner_GJ + signal_average_non_bPAC_cluster_inner;  
%    plot_two_gap_juncttion_population_results;
%   end;
% end;  



figure(jjj+600)
 subplot(3,1,1)
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster+signal_average_non_bPAC_cluster_inner,'c');                
 set(ss,'LineWidth',2);
 if (length(index_propagation_line)==4)
 ss = plot(time_bPAC/scale_factor_time,sig_propagation_emitter+sig_propagation_line(:,4,ii_plot),'k--');                
 set(ss,'LineWidth',2);
 ss = plot(time_bPAC/scale_factor_time,sig_propagation_line(:,4,ii_plot)+sig_propagation_line(:,3,ii_plot),'k');                
 set(ss,'LineWidth',2);
 elseif (length(index_propagation_line)==3)
 ss = plot(time_bPAC/scale_factor_time,sig_propagation_emitter+sig_propagation_line(:,3,ii_plot),'k--');                
 set(ss,'LineWidth',2);
 end;
 ss = plot(time_bPAC/scale_factor_time,sig_propagation_line(:,3,ii_plot)+sig_propagation_line(:,2,ii_plot),'b');                
 set(ss,'LineWidth',2);
 ss = plot(time_bPAC/scale_factor_time,sig_propagation_line(:,2,ii_plot)+sig_propagation_line(:,1,ii_plot),'m');                
 %ss = plot(time_bPAC/scale_factor_time,sig_propagation_line(:,2,ii_plot),'m');                
 set(ss,'LineWidth',2);
 
 if (length(index_propagation_line)==3)
   legend('emitter + adj recievers (av.)', ...
       strcat('cells emitter-',num2str(index_propagation_line_image(3)),' interface'), ...
       strcat('cells ',num2str(index_propagation_line_image(3)),'-',num2str(index_propagation_line_image(2)),' interface'), ...
       strcat('cells ',num2str(index_propagation_line_image(2)),'-',num2str(index_propagation_line_image(1)),' interface'));
 elseif (length(index_propagation_line)==4)
   legend('emitter + adj recievers (av.)', ...
       strcat('cells emitter-',num2str(index_propagation_line_image(4)),' interface'), ...
       strcat('cells ',num2str(index_propagation_line_image(4)),'-',num2str(index_propagation_line_image(3)),' interface'), ...
       strcat('cells ',num2str(index_propagation_line_image(3)),'-',num2str(index_propagation_line_image(2)),' interface'), ...
       strcat('cells ',num2str(index_propagation_line_image(2)),'-',num2str(index_propagation_line_image(1)),' interface'));
 end;
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 %title(strcat('bPAC cluster:',num2str(jjj)));
  title(strcat('one GJ pop, signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
 ylabel('bPAC');
 xlim([0 max(time_Erk)/scale_factor_time]);
  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
  % ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
  % ylim([min(signal_average_bPAC_cluster) 1.1*max(signal_average_bPAC_cluster)]);
  %end;
      sig_dummy_test = [signal_average_bPAC_cluster' signal_average_non_bPAC_cluster_inner' signal_average_bPAC_cluster'+signal_average_non_bPAC_cluster_inner'];
      ylim([max(sig_dummy_test)+1.1*(min(sig_dummy_test)-max(sig_dummy_test)) min(sig_dummy_test)+1.1*((max(sig_dummy_test)*(1+1e-6))-min(sig_dummy_test))]);

 hold off;
 subplot(3,1,2);
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_inner,'m');

 set(ss,'LineWidth',2);
 legend('GJC^j_a/P_j (non-bPAC (av.))');
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_non_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 ylabel('non-bPAC');
 xlim([0 max(time_Erk)/scale_factor_time]);
 ylim([max(sig_dummy_test)+1.1*(min(sig_dummy_test)-max(sig_dummy_test)) min(sig_dummy_test)+1.1*((max(sig_dummy_test)*(1+1e-6))-min(sig_dummy_test))]);

 hold off;
 subplot(3,1,3)
 ylabel('bPAC');
 for ii_input_plot = 1:num_inputs_plot
 hold on;
 if (ii_input_plot == 2)&(num_inputs_plot == 3)
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
 else
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
 end;
 set(ss,'LineWidth',2);
 hold off;
 end;
 xlim([0 max(time_Erk)/scale_factor_time]);
 ylim([0 1.1]);
 ylabel('inputs');
 xlabel(str_time_representation);
  if (num_inputs_plot == 1)
      legend(str_input_plot1);
  elseif (num_inputs_plot == 2)
      legend(str_input_plot1,str_input_plot2);
  elseif (num_inputs_plot == 3)
      legend(str_input_plot1,str_input_plot2,str_input_plot3);
  end;
 hold off;
    
   if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) > 0)|(do_gap_junction_interface == 0)         
      print('-depsc',strcat('PROPAGATION_GJ_one_population_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   elseif (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(do_gap_junction_interface == 1)      
      print('-depsc',strcat('PROPAGATION_GJ_INTERFACE_one_population_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   end;   
