 while (do_write_file == 0)

 obtain_and_plot_localized_cells_within_box

 do_write_file = input('enter 1 if the box is sufficient:');
 
 if (isempty(do_write_file))
  do_write_file = 0;
 end;
     
 if (do_write_file == 0)   
 x_coord_min_local =  input('enter the value for x_coord_min_local:');
 x_coord_max_local =  input('enter the value for x_coord_max_local:');
 y_coord_min_local =  input('enter the value for y_coord_min_local:');
 y_coord_max_local =  input('enter the value for y_coord_max_local:');
 end;
 
 isempty(do_write_file)
 
end;
