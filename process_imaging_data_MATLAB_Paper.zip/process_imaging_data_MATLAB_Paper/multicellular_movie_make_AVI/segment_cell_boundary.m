x_coord_min = round(max(1,mean_x_tot_time_mapped_t0(iii,which_frame)-50));    
x_coord_max = round(min(xLength,mean_x_tot_time_mapped_t0(iii,which_frame)+50));        
y_coord_min = round(max(1,mean_y_tot_time_mapped_t0(iii,which_frame)-50));    
y_coord_max = round(min(yLength,mean_y_tot_time_mapped_t0(iii,which_frame)+50));    

signal_nuclear_average = sum(sum(int16(M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max)).*int16(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max))))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
max_FITC_local = max(max(M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))


signal_normalized = (signal_nuclear_average - min_min_FITC)/(max_max_FITC-min_min_FITC);
threshold = .75*signal_normalized;

M_FITC_NORMALIZED_adjusted(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = min(0,M_FITC_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max)-signal_normalized);
for ii = x_coord_min:x_coord_max
 for jj = y_coord_min:y_coord_max
    
     if (M_FITC_NORMALIZED_adjusted(ii,jj) ==0 )
         M_FITC_NORMALIZED_adjusted(ii,jj) = -1e6;
     end;
     
 end;
end;
M_FITC_NORMALIZED_adjusted = M_FITC_NORMALIZED_adjusted + signal_normalized;

    M_FITC_binary(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_FITC_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold);   % convert to binary image
    %M_FITC_binary(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_FITC_NORMALIZED_adjusted(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold);   % convert to binary image
    M_FITC_binary_FILL = bwareaopen(M_FITC_binary, nucleus_min_pixels);  % removie 
    M_FITC_binary_FILL = imfill(M_FITC_binary_FILL,'holes');    
    Cell_marker_FILL = bwconncomp(M_FITC_binary_FILL);
       %num_nuclei = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));
       %M_marker_id_threshold = 0*M_marker_threshold;     
       %for idx = 1:num_nuclei
       %  M_marker_id_threshold(Cell_marker_FILL.PixelIdxList{idx}) = idx;
       %end;

           figure(120)
           imagesc(M_FITC_binary_FILL);
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min y_coord_max]);
           ylim([x_coord_min x_coord_max]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');

           figure(121)
           imagesc(max(int16(M_FITC),int16(1.1*max_FITC_local*M_marker_threshold)));
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min y_coord_max]);
           ylim([x_coord_min x_coord_max]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');

           figure(122)
           imagesc(max(int16(M_FITC),int16(-1.1*max_FITC_local*M_marker_threshold)));
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min y_coord_max]);
           ylim([x_coord_min x_coord_max]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');
           pause;
