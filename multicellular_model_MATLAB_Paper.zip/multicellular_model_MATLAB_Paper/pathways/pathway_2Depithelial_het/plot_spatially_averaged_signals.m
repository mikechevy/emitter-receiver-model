

do_PPT = 0;  % 0 - no, 1 - yes

%  Here we plot spatially averaged signals, either taking from those cells
%  averged from data to compare with simulation, or just simulation.


num_bPAC_pulses = 1;

s_sig = ['b', 'g', 'r', 'k' 'm'];
s_input = ['b', 'g', 'r', 'k' 'm'];


%  Average and plot the signals from the designated groups here
%  
%  TO DO:  grab necessary code from analyze bPAC clusters.m (in this
%  folder 'pathway_2Depithelial\bPAC_cluster_analysis'), which comes from the movie processing
%  code. Here we will analyze inner, outer and all bPAC cells as well as
%  surrounding layers of non-bPAC cells.
% 


time_bPAC = time_mean-shift_zero_value/scale_time_rates
time_Erk = time_mean-shift_zero_value/scale_time_rates;

X_data_sampled = x_mean;


scale_factor_time = 60;

if scale_factor_time == 60
    str_time_representation = 'time (minutes)';
end;

pathway_str_global = pwd;
cd(pathway_str_global);
addpath(pathway_str_global);

%mkdir(strcat('image_model_runs\',str_movie_write,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
%cd(strcat('image_model_runs\',str_movie_write,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));

if (do_run_specific_examples == 0)
 mkdir(strcat('image_model_runs\',str_movie_write,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('image_model_runs\',str_movie_write,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
else
 mkdir(strcat('specific_examples\',str_specific_example,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('specific_examples\',str_specific_example,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
end;


     delete(strcat(str_Species_to_plot,'_bPAC_cluster_bPAC_signals-',str_movie,'.ppt'));
     delete(strcat(str_Species_to_plot,'_bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'));
     delete(strcat(str_Species_to_plot,'_average_signals_bPAC_cluster-',str_movie,'.ppt'));


     
for jjj = 1:length(size_bPAC_clusters)     
figure(110+jjj)
    %eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    %eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %%imshow(mat2gray(M_NM_bPAC));
    %eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    %eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %%imshow(mat2gray(M_NM));
    %%%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    %image_RGB = zeros(xLength,yLength,3);
    %image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    %image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    %imshow(image_RGB)
    imagesc(M_marker_threshold_TEST)
    
    title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
      for iii = 1:size_bPAC_clusters(jjj)
         idx = bPAC_clusters(jjj,iii);   
         which_frame = 1;
          if (bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));           
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
          end;
         set(tt,'Color','w');
      end;
      for iii = 1:size_non_bPAC_clusters(jjj)
         idx = non_bPAC_clusters(jjj,iii);   
          if (non_bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));            
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
          end;
         set(tt,'Color','k');
      end;
      
        for iii = 1:length(index_group)
            for kkk = iii+1:length(index_group)
            
                if (mat_cAMP_gap(iii,kkk) == 1)
                    idx_iii = index_group(iii)
                    idx_kkk = index_group(kkk)
                   tt=line([mean_y_tot_time_mapped_t0(idx_iii,which_frame) mean_y_tot_time_mapped_t0(idx_kkk,which_frame)],[mean_x_tot_time_mapped_t0(idx_iii,which_frame) mean_x_tot_time_mapped_t0(idx_kkk,which_frame)]);           
                   set(tt,'Color','m');
                end;
        
            end;
        end;
      
      
   set(gcf,'inverthardcopy','off')   
   print('-depsc',strcat('map-cluster_',num2str(jjj),'-',str_movie,'.eps'));
      
end;
     
     
     

num_max_plots = 3;
ii_figure_count = 1;
ii_figure_count_tot = 1;
     
for jjj = 1:length(size_bPAC_clusters)     
    
    
       
        ii_plot_count = 0; 
    
        sig_dummy_bPAC = [];
        sig_dummy_bPAC_inner = [];
        sig_dummy_bPAC_outer = [];
        sig_dummy_non_bPAC = 0;

        sig_dummy_non_bPAC = [];
        sig_dummy_non_bPAC_inner = [];
        sig_dummy_non_bPAC_outer = [];
        
        
 % bPAC
 for iii = 1:size_bPAC_clusters(jjj)
       idx = bPAC_clusters(jjj,iii);   
    
        str_bPAC = ' (bPAC)';
       
  %if (max(bPAC_pulse_cell(idx,:)) == 1)
    
        
    figure(200+ii_figure_count)
    
    subplot(num_max_plots+1,1,ii_plot_count+1)     
        if (ii_plot_count+1==1)
         %title(strcat(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', bPAC cell signals'));
         title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', bPAC cell signals, Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
        end;
         hold on;
              
         [val,ii_index_group] = min(abs(index_group-idx));         
         sig_dummy =  X_data_sampled(:,(ii_index_group-1)*num_molecules_cell+ii_Species_to_plot)
            if (ii_Species_to_plot == ii_ERKKTR_n)&(do_ERK_KTR_N_over_C == 1)
               sig_dummy_num = sig_dummy;
               sig_dummy_den = X_data_sampled(:,(ii_index_group-1)*num_molecules_cell+ii_ERKKTR_c)
               sig_dummy = sig_dummy_num./sig_dummy_den;    
            end;
         [val index_time_0] = min(abs(time_Erk/scale_factor_time))            
         sig_dummy(1:index_time_0-1) = sig_dummy(index_time_0);
         
if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) > 0)|(do_gap_junction_interface == 0)         
         if (iii == 1)
          sig_dummy_bPAC =  sig_dummy;
         else
          sig_dummy_bPAC = sig_dummy_bPAC + sig_dummy;
         end;
         
         
          if (bPAC_clusters_location(jjj,iii) == 1)
           if (length(sig_dummy_bPAC_outer) == 0)
            sig_dummy_bPAC_outer =  sig_dummy;
           else
            sig_dummy_bPAC_outer = sig_dummy_bPAC_outer + sig_dummy;
           end;
          else
           if (length(sig_dummy_bPAC_inner) == 0)
            sig_dummy_bPAC_inner =  sig_dummy;              
           else
            sig_dummy_bPAC_inner = sig_dummy_bPAC_inner + sig_dummy;              
           end;
          end;
          
elseif (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(do_gap_junction_interface == 1)         
    
         if (iii == 1)
          sig_dummy_bPAC =  sig_dummy/N_coupled(ii_index_group);
         else
          sig_dummy_bPAC = sig_dummy_bPAC + sig_dummy/N_coupled(ii_index_group);
         end;
         
         
          if (bPAC_clusters_location(jjj,iii) == 1)
           if (length(sig_dummy_bPAC_outer) == 0)
            sig_dummy_bPAC_outer =  sig_dummy/N_coupled(ii_index_group);
           else
            sig_dummy_bPAC_outer = sig_dummy_bPAC_outer + sig_dummy/N_coupled(ii_index_group);
           end;
          else
           if (length(sig_dummy_bPAC_inner) == 0)
            sig_dummy_bPAC_inner =  sig_dummy/N_coupled(ii_index_group);              
           else
            sig_dummy_bPAC_inner = sig_dummy_bPAC_inner + sig_dummy/N_coupled(ii_index_group);              
           end;
          end;
end;      
         
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     %%ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;

     if (bPAC_clusters_location(jjj,iii) == 1)         
     ylabel([strcat('nuc:',num2str(idx),'*'), 10, str_bPAC]);
     else
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     end;
      
      %if (num_bPAC_pulses == 1)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      %elseif (num_bPAC_pulses == 2)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      %end;
      
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*((max(sig_dummy)*(1+1e-6))-min(sig_dummy))]);
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
    

        
     ii_plot_count = ii_plot_count+1;
        if (iii == size_bPAC_clusters(jjj))
          subplot(num_max_plots+1,1,num_max_plots+1)
          %ylabel('bPAC');
          %plot(time_bPAC/scale_factor_time,X_data_sampled(:,ii_I_bPAC));
           for ii_input_plot = 1:num_inputs_plot
           hold on;
           if (ii_input_plot == 2)&(num_inputs_plot == 3)
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
           else
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
           end;
           set(ss,'LineWidth',2);
           hold off;
           end;
            if (num_inputs_plot == 1)
                legend(str_input_plot1);
            elseif (num_inputs_plot == 2)
                legend(str_input_plot1,str_input_plot2);
            elseif (num_inputs_plot == 3)
                legend(str_input_plot1,str_input_plot2,str_input_plot3);
            end;
          xlim([0 max(time_Erk)/scale_factor_time]);
          %ylim([0 1.1*max(X_data_sampled(:,ii_I_bPAC))]);
          ylim([0 1.1]);
          ylabel('inputs');
          xlabel(str_time_representation);
          print('-depsc',strcat(str_Species_to_plot,'_cluster_',num2str(jjj),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));          
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,X_data_sampled(:,ii_I_bPAC));
           for ii_input_plot = 1:num_inputs_plot
           hold on;
           if (ii_input_plot == 2)&(num_inputs_plot == 3)
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
           else
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
           end;
           set(ss,'LineWidth',2);
           hold off;
           end;
            if (num_inputs_plot == 1)
                legend(str_input_plot1);
            elseif (num_inputs_plot == 2)
                legend(str_input_plot1,str_input_plot2);
            elseif (num_inputs_plot == 3)
                legend(str_input_plot1,str_input_plot2,str_input_plot3);
            end;
          xlim([0 max(time_Erk)/scale_factor_time]);
          %ylim([0 1.1*max(X_data_sampled(:,ii_I_bPAC))]);
          ylim([0 1.1]);
          ylabel('inputs');
          xlabel(str_time_representation);
          print('-depsc',strcat(str_Species_to_plot,'_cluster_',num2str(jjj),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
          ii_figure_count = ii_figure_count+1;
          ii_figure_count_tot = ii_figure_count_tot+1;
          ii_plot_count = 0;
        end;
        
        
                if (iii == size_bPAC_clusters(jjj))|(ii_figure_count == 4)
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig201 = figure(201)
                       fig202 = figure(202)
                       fig203 = figure(203)
                       s_combine = 'bPAC cells around in a bPAC cluster';
   
                       saveppt2(strcat(str_Species_to_plot,'_bPAC_cluster_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig201 fig202 fig203], 'halign','center','title', s_combine);
                      close 201;
                      close 202;
                      close 203;
                     
                      ii_figure_count = 1;
                      
                      end; % if (do_PPT ==1)
                end; % if (iii == size_bPAC_clusters(jjj))|(ii_figure_count == 4)
        
        
  %end;  
 end;

 
 
 
ii_plot_count = 0;
ii_figure_count = 1;
ii_figure_count_tot = 1;

 
 % non-bPAC
 for iii = 1:size_non_bPAC_clusters(jjj)
       idx = non_bPAC_clusters(jjj,iii);   
       
        str_bPAC = ' (non-bPAC)';
       
  %if (max(bPAC_pulse_cell(idx,:)) == 1)
    
    figure(300+ii_figure_count)
    
    subplot(num_max_plots+1,1,ii_plot_count+1)       
        if (ii_plot_count+1==1)
         %title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', non-bPAC cell signals'));
         title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', non-bPAC cell signals, Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
        end;
         hold on;

         [val,ii_index_group] = min(abs(index_group-idx));         
         sig_dummy =  X_data_sampled(:,(ii_index_group-1)*num_molecules_cell+ii_Species_to_plot)
            if (ii_Species_to_plot == ii_ERKKTR_n)&(do_ERK_KTR_N_over_C == 1)
               sig_dummy_num = sig_dummy;
               sig_dummy_den = X_data_sampled(:,(ii_index_group-1)*num_molecules_cell+ii_ERKKTR_c)
               sig_dummy = sig_dummy_num./sig_dummy_den;    
            end;
         [val index_time_0] = min(abs(time_Erk/scale_factor_time))            
         sig_dummy(1:index_time_0-1) = sig_dummy(index_time_0);

                  
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
         
         
 if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) > 0)|(do_gap_junction_interface == 0)  
    
        if (iii == 1)
         sig_dummy_non_bPAC = sig_dummy;
        else
         sig_dummy_non_bPAC = sig_dummy_non_bPAC + sig_dummy;
        end;
        
         
         
          if (non_bPAC_clusters_location(jjj,iii) == 1)
           if (length(sig_dummy_non_bPAC_inner) == 0)
            sig_dummy_non_bPAC_inner =  sig_dummy;              
           else
            sig_dummy_non_bPAC_inner = sig_dummy_non_bPAC_inner + sig_dummy;              
           end;
          else
           if (length(sig_dummy_non_bPAC_outer) == 0)
            sig_dummy_non_bPAC_outer =  sig_dummy;
           else
            sig_dummy_non_bPAC_outer = sig_dummy_non_bPAC_outer + sig_dummy;
           end;
          end;
 elseif (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(do_gap_junction_interface == 1)      
     
        if (iii == 1)
         sig_dummy_non_bPAC = sig_dummy/N_coupled(ii_index_group);
        else
         sig_dummy_non_bPAC = sig_dummy_non_bPAC + sig_dummy/N_coupled(ii_index_group);
        end;
        
         
         
          if (non_bPAC_clusters_location(jjj,iii) == 1)
           if (length(sig_dummy_non_bPAC_inner) == 0)
            sig_dummy_non_bPAC_inner =  sig_dummy/N_coupled(ii_index_group);              
           else
            sig_dummy_non_bPAC_inner = sig_dummy_non_bPAC_inner + sig_dummy/N_coupled(ii_index_group);              
           end;
          else
           if (length(sig_dummy_non_bPAC_outer) == 0)
            sig_dummy_non_bPAC_outer =  sig_dummy/N_coupled(ii_index_group);
           else
            sig_dummy_non_bPAC_outer = sig_dummy_non_bPAC_outer + sig_dummy/N_coupled(ii_index_group);
           end;
          end;
     
 end;       
        
         
         
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     %%ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
     
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
      
      %if (num_bPAC_pulses == 1)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      %elseif (num_bPAC_pulses == 2)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      %end;
      
      if (sig_dummy == 0)
          del_zero = 1e-6; % ensures ylim has separation in the min and max
      else
          del_zero = 0;
      end;
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*((max(sig_dummy+del_zero)*(1+1e-6))-min(sig_dummy))]);
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
    

        
     ii_plot_count = ii_plot_count+1;
        if (iii == size_non_bPAC_clusters(jjj))
          subplot(num_max_plots+1,1,num_max_plots+1)
          %ylabel('bPAC');
          %plot(time_bPAC/scale_factor_time,X_data_sampled(:,ii_I_bPAC));
           for ii_input_plot = 1:num_inputs_plot
           hold on;
           if (ii_input_plot == 2)&(num_inputs_plot == 3)
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
           else
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
           end;
           set(ss,'LineWidth',2);
           hold off;
           end;
            if (num_inputs_plot == 1)
                legend(str_input_plot1);
            elseif (num_inputs_plot == 2)
                legend(str_input_plot1,str_input_plot2);
            elseif (num_inputs_plot == 3)
                legend(str_input_plot1,str_input_plot2,str_input_plot3);
            end;
          xlim([0 max(time_Erk)/scale_factor_time]);
          %ylim([0 1.1*max(X_data_sampled(:,ii_I_bPAC))]);
          ylim([0 1.1]);
          ylabel('inputs');
          xlabel(str_time_representation);
          print('-depsc',strcat(str_Species_to_plot,'_cluster_',num2str(jjj),'-non_bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,1,num_max_plots+1)
           for ii_input_plot = 1:num_inputs_plot
           hold on;
           if (ii_input_plot == 2)&(num_inputs_plot == 3)
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
           else
             ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
           end;
           set(ss,'LineWidth',2);
           hold off;
           end;
            if (num_inputs_plot == 1)
                legend(str_input_plot1);
            elseif (num_inputs_plot == 2)
                legend(str_input_plot1,str_input_plot2);
            elseif (num_inputs_plot == 3)
                legend(str_input_plot1,str_input_plot2,str_input_plot3);
            end;
          xlim([0 max(time_Erk)/scale_factor_time]);
          %ylim([0 1.1*max(X_data_sampled(:,ii_I_bPAC))]);
          ylim([0 1.1]);
          ylabel('inputs');
          xlabel(str_time_representation);
          print('-depsc',strcat(str_Species_to_plot,'_cluster_',num2str(jjj),'-non_bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
          ii_figure_count = ii_figure_count+1;
          ii_figure_count_tot = ii_figure_count_tot+1;
          ii_plot_count = 0;
        end;
          
                if (iii == size_non_bPAC_clusters(jjj))|(ii_figure_count == 4)
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig301 = figure(301)
                       fig302 = figure(302)
                       fig303 = figure(303)
                       s_combine = 'non-bPAC cells around in a bPAC cluster';
   
                       saveppt2(strcat(str_Species_to_plot,'_bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig301 fig302 fig303], 'halign','center','title', s_combine);
                      close 301;
                      close 302;
                      close 303;
   
                      ii_figure_count = 1;                      
    
                      end; % if (do_PPT ==1)
                end; % if (iii == size_non_bPAC_clusters(jjj))|(ii_figure_count == 4)

  %end;  
 end;

  signal_average_bPAC_cluster = sig_dummy_bPAC/size_bPAC_clusters(jjj);
  if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj)) 
  signal_average_bPAC_cluster_outer = sig_dummy_bPAC_outer/sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj)));
  signal_average_bPAC_cluster_inner = sig_dummy_bPAC_inner/(size_bPAC_clusters(jjj)-sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))));
  end;
  signal_average_non_bPAC_cluster = sig_dummy_non_bPAC/size_non_bPAC_clusters(jjj);
  if (sum(non_bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_non_bPAC_clusters(jjj)) 
  signal_average_non_bPAC_cluster_inner = sig_dummy_non_bPAC_inner/sum(non_bPAC_clusters_location(jjj,1:size_non_bPAC_clusters(jjj)));
  signal_average_non_bPAC_cluster_outer = sig_dummy_non_bPAC_outer/(size_non_bPAC_clusters(jjj)-sum(non_bPAC_clusters_location(jjj,1:size_non_bPAC_clusters(jjj))));
  end;

  %  For two population gap-junctin simulations
if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)    
if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(length(ii_Species_to_plot_array) == 1)  
   plot_one_gap_juncttion_population_results;
elseif (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(min(abs(ii_Species_to_plot_array - ii_GJ2_complex_on)) == 0)  
  if (ii_Species_to_plot == ii_GJ_complex_on)
   signal_average_bPAC_cluster_GJ = signal_average_bPAC_cluster
   signal_average_non_bPAC_cluster_inner_GJ =    signal_average_non_bPAC_cluster_inner;  
  elseif (ii_Species_to_plot == ii_GJ2_complex_on)
   sum_signal_average_bPAC_cluster_GJ_GJ2 = signal_average_bPAC_cluster_GJ + signal_average_bPAC_cluster;
   sum_signal_average_non_bPAC_cluster_inner_GJ_GJ2 = signal_average_non_bPAC_cluster_inner_GJ + signal_average_non_bPAC_cluster_inner;  
   plot_two_gap_juncttion_population_results;
  end;
end;  
end;
  
 figure(jjj+500)
 subplot(3,1,1)
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster,str_which_GJ_model);                
 set(ss,'LineWidth',2);
  if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
   ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster_outer,'k');                
   set(ss,'LineWidth',2);
   ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster_inner,'r');
   set(ss,'LineWidth',2);
   legend('all bPAC cells','outer bPAC cells', 'inner bPAC cells');
  else
   legend('all bPAC cells');
  end;
 set(ss,'LineWidth',2);
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 %title(strcat('bPAC cluster:',num2str(jjj)));
  if (do_GJ2 == 1)
  title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
  else
  title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),',which GJ model=',num2str(which_GJ_model)));
  end;
 ylabel('bPAC');
 xlim([0 max(time_Erk)/scale_factor_time]);
  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
  % ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
  % ylim([min(signal_average_bPAC_cluster) 1.1*max(signal_average_bPAC_cluster)]);
  %end;
      sig_dummy = signal_average_bPAC_cluster;
      ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*((max(sig_dummy)*(1+1e-6))-min(sig_dummy))]);

 hold off;
 subplot(3,1,2);
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster);
 set(ss,'LineWidth',2);
  if (sum(non_bPAC_clusters_location(jjj,1:size_non_bPAC_clusters(jjj))) ~= size_non_bPAC_clusters(jjj))   
   ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_inner,str_which_GJ_model);
   set(ss,'LineWidth',2);
   ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_outer,'k');                
   set(ss,'LineWidth',2);
   legend('all non-bPAC cells','adjacent non-bPAC', 'separated non-bPAC cells');
  else
   legend('all non-bPAC cells');
  end;
 set(ss,'LineWidth',2);
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_non_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 ylabel('non-bPAC');
 xlim([0 max(time_Erk)/scale_factor_time]);
%  if (sum(non_bPAC_clusters_location(jjj,1:size_non_bPAC_clusters(jjj))) ~= size_non_bPAC_clusters(jjj))   
%   ylim([min([min(signal_average_non_bPAC_cluster) min(signal_average_non_bPAC_cluster_outer) min(signal_average_non_bPAC_cluster_inner)]) 1.1*max([max(signal_average_non_bPAC_cluster) max(signal_average_non_bPAC_cluster_outer) max(signal_average_non_bPAC_cluster_inner)]) ]);
%  else
%   ylim([min(signal_average_non_bPAC_cluster) max(signal_average_non_bPAC_cluster)]);
%  end;
    sig_dummy = signal_average_bPAC_cluster;
    sig_dummy_non_bPAC = signal_average_non_bPAC_cluster_outer;
    delta_non_bPAC =  max(0, 1.1*(max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))- min(sig_dummy_non_bPAC)))
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))-delta_non_bPAC min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))-delta_non_bPAC]);

  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
   %ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
   %ylim([min(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster)]);
  %end;
 hold off;
 subplot(3,1,3)
 ylabel('bPAC');
 for ii_input_plot = 1:num_inputs_plot
 hold on;
 if (ii_input_plot == 2)&(num_inputs_plot == 3)
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
 else
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
 end;
 set(ss,'LineWidth',2);
 hold off;
 end;
 xlim([0 max(time_Erk)/scale_factor_time]);
 ylim([0 1.1]);
 ylabel('inputs');
 xlabel(str_time_representation);
  if (num_inputs_plot == 1)
      legend(str_input_plot1);
  elseif (num_inputs_plot == 2)
      legend(str_input_plot1,str_input_plot2);
  elseif (num_inputs_plot == 3)
      legend(str_input_plot1,str_input_plot2,str_input_plot3);
  end;
 hold off;

   subplot(3,1,2);
  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
  % ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
  % ylim([min(signal_average_bPAC_cluster) 1.1*max(signal_average_bPAC_cluster)]);
  %end;
    sig_dummy = signal_average_bPAC_cluster;
    sig_dummy_non_bPAC = signal_average_non_bPAC_cluster_outer;
    delta_non_bPAC =  max(0, 1.1*(max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))- min(sig_dummy_non_bPAC)))
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))-delta_non_bPAC min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))-delta_non_bPAC]);
    
 
  if (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) > 0)|(do_gap_junction_interface == 0)         
   print('-depsc',strcat(str_Species_to_plot,'_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   %print('-depsc',strcat(str_Species_to_plot,'_average_signals-cluster_',num2str(jjj),'-',str_movie,'_norm.eps'));
   elseif (min(abs(ii_Species_to_plot_array - ii_GJ_complex_on)) == 0)&(do_gap_junction_interface == 1)      
   print('-depsc',strcat(str_Species_to_plot,'INTERFACE_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   end;
   
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig501 = figure(500+jjj)
                       s_combine = 'average signals of bPAC and non-bPAC cells ';
   
                       saveppt2(strcat(str_Species_to_plot,'_average_signals_bPAC_cluster-',str_movie,'.ppt'),'figure',[fig110 fig501], 'halign','center','title', s_combine);
                     
                      ii_figure_count = 1;
                      
                      end; % if (do_PPT ==1)
   
 
end; % for jjj = 1:length(size_bPAC_clusters)     


cd(pathway_str_global);
