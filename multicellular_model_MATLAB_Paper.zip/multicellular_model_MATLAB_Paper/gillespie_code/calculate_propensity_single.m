

function a_jj = calculate_propensity_single(x,jj)


global num_molecules;
global stochasticity;
global stochasticity_conj;
global num_reactions;
global reaction_constant;
global sign_reaction;
global reaction_type;
global reaction_molecules;
global c_mu;
global kappa;
global a_0;
global a_1;
global a_2;
global a_3;
global a_4;
global a_5;
global a_6;
global a_7;
global a_8;
global a_9;
global a_0_eff;
global a_1_eff;
global eta_0_eff;  % constants in the function f_eff
global eta_1_eff;  % constants in the function f_eff
global n_eff; % constants in the function f_eff
global x_ref;

%  INDEX MAP OF REACTIONS
%   1 - * -> reaction products
%   2 - S_j -> reaction products
%   3 - S_j + S_k -> reaction products (j~=k)
%   4 - 2 S_j -> reaction products
%   5 - S_i + S_j + S_k -> reaction products (i~=j~=k)
%   6 - S_j + 2 S_k -> (j~=k)
%   7 - 3 S_j
%   12 - (S_j0-S_j) -> reaction products, difference between inital value and current
%   13 - (S_j0-S_j)/2 -> reaction products, difference between inital value and current (dimer version)
%   20 - (S_k0/(S_k0+S_i))^2  2 S_j  - competition theory UPR, module 1
%   30 - S_i^n/(a0 + S_i^n)  - gene regulation function #1 (Hill function) Activation
%   31 - a0^n/(a0^n + S_i^n)  - gene regulation function #1 (Hill function) Repressor
%   31 - (S_i0-S_i)^2/(a0 + a1*(S_i0-S_i) + (S_i0-S_i)^2)  - gene regulation function #2
%   32 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #3, cooperativity: independent
%   33 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #4, cooperativity: causal
%   34 -  gene regulation  function, activator or repressor, depending on constants
%   40 - decay of species 1 due to species 2 (activation) dependent decay rate
%   41 - decay of species 1 due to species 2 (repression) dependent decay rate
%   50 - min((S_i0-S_i)/2, S_j)  - minimum of two quantities represents the rate limiting step
    

species1 = reaction_molecules(jj,1);
species2 = reaction_molecules(jj,2);
species3 = reaction_molecules(jj,3);
species4 = reaction_molecules(jj,4);


        
        if (reaction_type(jj)==1)  

            a_jj = c_mu(jj); 

        elseif (reaction_type(jj)==2)

            a_jj = c_mu(jj)*x(species1); 

        elseif (reaction_type(jj)==3)

            a_jj = c_mu(jj)*x(species1)*x(species2); 

        elseif (reaction_type(jj)==4)

            a_jj = c_mu(jj)*x(species1)*(x(species1)-1)/2; 

        elseif (reaction_type(jj)==5)

            a_jj = c_mu(jj)*x(species1)*x(species2)*x(species3); 

        elseif (reaction_type(jj)==6)

            a_jj = c_mu(jj)*x(species1)*x(species2)*(x(species2)-1)/2; 

        elseif (reaction_type(jj)==7)

            a_jj = c_mu(jj)*x(species1)*(x(species1)-1)*(x(species1)-2)/6; 

        elseif (reaction_type(jj)==12) % c_mu * (x_ref(species1)-x(species1))

            a_jj = c_mu(jj)*(x_ref(species1)-x(species1)); 

        elseif (reaction_type(jj)==13) % c_mu * (x_ref(species1)-x(species1))/2  

            a_jj = c_mu(jj)*(x_ref(species1)-x(species1))/2; 

        elseif (reaction_type(jj)==20)

            a_jj = c_mu(jj)*power(x_ref(reaction_molecules(jj,1))/(x_ref(reaction_molecules(jj,1))+kappa(jj)*x(reaction_molecules(jj,1))),2)*x(reaction_molecules(jj,2))*(x(reaction_molecules(jj,2))-1)/2; 

        elseif (reaction_type(jj)==30) % activator
              n_hill = a_0(jj);
              k_hill = a_1(jj);
              a_jj = c_mu(jj)*power(x(reaction_molecules(jj,1)),n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,1)),n_hill));
        elseif (reaction_type(jj)==31) % repressor
              n_hill = a_0(jj);
              k_hill = a_1(jj);
              a_jj = c_mu(jj)*power(k_hill,n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,1)),n_hill));
        elseif (reaction_type(jj)==32)  % cooperativity-independent
            a_jj = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))/(a_0(jj) + a_1(jj)*x(reaction_molecules(jj,1)) + a_2(jj)*x(reaction_molecules(jj,2)) + x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)));
        elseif (reaction_type(jj)==33)  % cooperativity-causal
            a_jj = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))/(a_0(jj) + a_1(jj)*x(reaction_molecules(jj,1)) + x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)));
        elseif (reaction_type(jj)==34)  % hill function from David's paper on two-entangled feedback loop motifs
% R_star = activate_R*R_tot*power(s/K_R_s,h_s)/(1 + power(s/K_R_s,h_s)) + (1-activate_R)*R_tot/(1 + power(s/K_R_s,h_s));
%A_E = eps_E + activate_E*(1-eps_E)*power(R_star/K_E,h_E)/(1+power(R_star/K_E,h_E)) + (1-activate_E)*(1-eps_E)/(1+power(R_star/K_E,h_E));
   %    c_mu = eps_E;
   %    a_0 = K_R_s;
   %    a_1 = h_s;
   %    a_2 = activate_R;
   %    a_3 = R_tot;
   %    a_4 = K_E;
   %    a_5 = h_E;
   %    a_6 = activate_E;
              dummy1 = power(x(reaction_molecules(jj,1))/a_0(jj),a_1(jj));
              dummy_star = ( a_2(jj)*a_3(jj)*dummy1 + (1-a_2(jj))*a_3(jj) ) / (1+dummy1);
              dummy2 = power(dummy_star/a_4(jj),a_5(jj));
              a_jj = a_7(jj)*( c_mu(jj) + (1-c_mu(jj))*( a_6(jj)*dummy2 + (1-a_6(jj)) ) / (1+dummy2) );
        elseif (reaction_type(jj)==35)
                 coop_on = a_0(jj);
                 n_hill_coop = a_1(jj);
                 k_hill_coop = a_2(jj);
                 crowding_on = a_3(jj);
                 n_hill_crowding = a_4(jj);
                 k_hill_crowding = a_5(jj);
             if (x(reaction_molecules(jj,1)) == 0)
             a_jj = 0;
             else
              a_jj = c_mu(jj)*x(reaction_molecules(jj,1))*(coop_on*power(k_hill_coop,n_hill_coop)/(power(k_hill_coop,n_hill_coop) + power(x(reaction_molecules(jj,1)),n_hill_coop))  + crowding_on*power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2)),n_hill_crowding)/(power(k_hill_crowding,n_hill_crowding) + power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2)),n_hill_crowding)) );
             end;

        elseif (reaction_type(jj)==36)
                 crowding_on_enter = a_0(jj);
                 n_hill_crowding = a_1(jj);
                 k_hill_crowding = a_2(jj);
              a_jj = c_mu(jj)*x(reaction_molecules(jj,4))*(1-crowding_on_enter + crowding_on_enter*power(k_hill_crowding,n_hill_crowding)/(power(k_hill_crowding,n_hill_crowding) + power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2))+x(reaction_molecules(jj,3)),n_hill_crowding)) );

     elseif (reaction_type(jj)==39)  %  uses: x_ref(species1)-x(species1), UPRE hill function

              a_jj = c_mu(jj)*power(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)),2)/(a_0(jj) + a_1(jj)*(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1))) + power(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)),2));  % propensity

     elseif (reaction_type(jj)==40) % decay of species 1 due to species 2 (activation) dependent decay rate 

              n_hill = a_0(jj);
              k_hill = a_1(jj);
              a_jj = c_mu(jj)*x(reaction_molecules(jj,1))*power(x(reaction_molecules(jj,2)),n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,2)),n_hill));
              
     elseif (reaction_type(jj)==41) % decay of species 1 due to species 2 (repression) dependent decay rate 

              n_hill = a_0(jj);
              k_hill = a_1(jj);
              a_jj = c_mu(jj)*x(reaction_molecules(jj,1))*power(k_hill,n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,2)),n_hill));

     elseif (reaction_type(jj)==42) % MI paper: used for global translation effets, plus global estradiol-depednent repression
         
              n_hill = a_0(jj);
              k_hill = a_1(jj);
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(x(reaction_molecules(jj,2)),n_hill)*power(k_hill,n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,3)),n_hill));              
              
     elseif (reaction_type(jj)==50)   %  c_mu * min( (x_ref(species1)-x(species1))/2, x(species2) )*(a_0_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )/(a_1_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )

% NOTE: a_0_eff,a_1_eff have the power n_eff absorbed in it the preprocessing

              a_jj = c_mu(jj)*min(abs(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2,abs(x(reaction_molecules(jj,2))))*( a_0_eff(jj) + power(eta_0_eff(jj)*x(reaction_molecules(jj,3))+eta_1_eff(jj)*x(reaction_molecules(jj,4)),n_eff(jj)) )/( a_1_eff(jj) + power(eta_0_eff(jj)*x(reaction_molecules(jj,3))+eta_1_eff(jj)*x(reaction_molecules(jj,4)),n_eff(jj)) );

        elseif (reaction_type(jj)==51)   %  c_mu * min( (x_ref(species1)-x(species1))/2-x(species2), x(species3) )

              a_jj = c_mu(jj)*min( abs((x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2-x(reaction_molecules(jj,2)) ),abs(x(reaction_molecules(jj,3))));

        elseif (reaction_type(jj)==54) % NEW UPR Splicing function  %  c_mu * min( x(species1), x(species2) )

              a_jj = c_mu(jj)*min( abs( x(reaction_molecules(jj,1)) ),abs(x(reaction_molecules(jj,2))) );  % propensity


        elseif (reaction_type(jj)==57) % NEW UPR Foci decay function  %  c_mu * x(species1)*power(x_0,n) / ( power(x_0,n) + power(x(species1),n) )

              x_0  = a_0_eff(jj);
              n_0  = n_eff(jj);

              a_jj = c_mu(jj)*x(reaction_molecules(jj,1))*power(x_0,n_0)/( power(x_0,n_0) + power(x(reaction_molecules(jj,1)),n_0) );  % propensity
        
     elseif (reaction_type(jj)==60) %  c_mu * x(species1)/ (1 + k_0*x(species2) )

              k_0  = a_0(jj);

              a_jj = c_mu(jj)*x(reaction_molecules(jj,1))/( 1 + k_0*x(reaction_molecules(jj,2)) );  % propensity          
    
     elseif (reaction_type(jj)==61) %  c_mu * (x(species1)/(1 + k_0*x(species2)))*x(species3)/(x_0 + x(species3)))

              k_0  = a_0(jj);
              x_0  = a_1(jj);

              a_jj = c_mu(jj)*(x(reaction_molecules(jj,1))/( 1 + k_0*x(reaction_molecules(jj,2)) ))...
                                         *(x(reaction_molecules(jj,3))/( x_0 + x(reaction_molecules(jj,3)) ));  % propensity
     elseif (reaction_type(jj)==62) %  c_mu * (x(species1)/(x_tot - x(species2))
         
              x_tot  = a_0(jj);
              x_0  = a_1(jj);

             if ( x_tot-x(reaction_molecules(jj,2)) <= 1.0)
              a_jj = 0.0;
             else
              a_jj = c_mu(jj)*(x(reaction_molecules(jj,1))/( x_tot-x(reaction_molecules(jj,2)) ));
             end;           
              
              
     elseif (reaction_type(jj)==63) %  c_mu * min(x(species1),x(species2))
         
              a_jj = c_mu(jj)*min(x(reaction_molecules(jj,1)),x(reaction_molecules(jj,2)));

     elseif (reaction_type(jj)==64) %  c_mu * (x(species1) - x_tot )
         
              x_tot  = a_0(jj);
     
              a_jj = c_mu(jj)*(x(reaction_molecules(jj,1))-x_tot);
              
     end;
        

   
    
    
    
