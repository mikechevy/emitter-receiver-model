% used to throwout the top 'num_throwout' values, to discuard clusters when
% calculating mean and std pixel number
num_throwout = 20;

% USED TO DETERMIN IF pixel region is small enough to label as single nucleus: if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
fac_std_nuclear_size = -0.5;  % if mean_pix + fac_std_nuclear_size
fac_std_nuclear_size_recursive = -.5;  % if mean_pix + fac_std_nuclear_size

% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  


%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;

%  bursting periods
period_burst_Ca = 25;  % seconds
period_burst_Erk = 25*60;
%  bursting thresholds
threshold_burst_Ca = 3;
threshold_burst_Erk = 10;


%setup the array that maps the marker from a particular channel
marker_from_channel = zeros(num_different_markers,1);

if which_movie == 0  % mixed MDCK and MDCK+bPAC cells  
    str_movie = 'Pos0'
    numCh=3;
    numFr=120;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\img_000000000_Cy3_000.tif');
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_bPAC_marker) = ii_CY3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
        % time sequence parameters for movie
         tau_first = 30; % 30 second sample period
         num_samples_first = numFr-1;
        time_sample_first = tau_first*ones(numFr-1,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        num_sample_sequence = [num_samples_first];
        tau_sample_movie = tau_first;
        dt_sequence_movie = time_sample_first;
elseif which_movie == 1  % pure MDCK+bPAC  
    str_movie = 'Pos1'
    numCh=3;
    numFr=120;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\img_000000000_Cy3_000.tif');
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_bPAC_marker) = ii_CY3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
        % time sequence parameters for movie
         tau_first = 30; % 30 second sample period
         num_samples_first = numFr-1;
        time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        num_sample_sequence = [num_samples_first];
        tau_sample_movie = tau_first;
        dt_sequence_movie = time_sample_first;
%  bursting thresholds
%threshold_burst_Ca = 40;
threshold_burst_Ca = 80;
elseif which_movie == 2  % mixed MDCK and MDCK+bPAC cells
    str_movie = 'Pos2'  
    numCh=3;
    numFr=120;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\img_000000000_Cy3_000.tif');
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_bPAC_marker) = ii_CY3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
        % time sequence parameters for movie
         tau_first = 30; % 30 second sample period
         num_samples_first = numFr-1;
        time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        num_sample_sequence = [num_samples_first];
        tau_sample_movie = tau_first;
        dt_sequence_movie = time_sample_first;
elseif which_movie == 3  % pure MDCK  
    str_movie = 'Pos3'
    numCh=3;
    numFr=120;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\img_000000000_Cy3_000.tif');
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
        % time sequence parameters for movie
         tau_first = 30; % 30 second sample period
         num_samples_first = numFr-1;
        time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        num_sample_sequence = [num_samples_first];
        tau_sample_movie = tau_first;
        dt_sequence_movie = time_sample_first;
elseif (which_movie == 4)  % Creb reporter, no drug 
    str_movie = 'Creb_no_drug'
    numCh=2;
    numFr=103;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Creb_no_drug.nd2');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Creb_marker) = ii_FITC;
elseif (which_movie == 5)  % Creb reporter, forskolin 
    str_movie = 'Creb_forskolin'
    numCh=2;
    numFr=103;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Creb_forskolin.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Creb_marker) = ii_FITC;
elseif (which_movie == 6)  % Creb reporter, pka inhibitor 
    str_movie = 'Creb_pka_inhibitor'
    numCh=2;
    numFr=103;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Creb_pka_inhibitor.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Creb_marker) = ii_FITC;
elseif (which_movie == 7)  % Creb reporter, ibmx 
    str_movie = 'Creb_ibmx'
    numCh=2;
    numFr=103;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Creb_ibmx.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Creb_marker) = ii_FITC;
elseif (which_movie == 8)  % MDCK, Erk, Ca  (high fcs)
    str_movie = '150626_Erk_Ca'
    numCh=3;
    numFr=379;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Erk_Ca_highfcs_smooth_long.tif');    
    ii_CY3 = 1;
    ii_FITC = 2;
    ii_DAPI = 3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Erk_marker) = ii_CY3;
    marker_from_channel(ii_Ca_marker) = ii_FITC;  % ?????? check with Joao to make sure this is correct
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 50;  % 10X is used  
        % time sequence parameters for movie
         tau_first = 6; % 6 second sample period
         num_samples_first = 120;
        time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 6*60; % 6 minute sample period
         num_samples_second = 9;
        time_sample_second = tau_second*ones(num_samples_second,1); 
        sample_sequence = [1 2 1 2 1];
        num_sample_sequence = [num_samples_first num_samples_second num_samples_first num_samples_second num_samples_first];
        tau_sample_movie = [tau_first tau_second tau_first tau_second tau_first];
        dt_sequence_movie = [time_sample_first; time_sample_second; time_sample_first; time_sample_second; time_sample_first];   % 6 seconds sample period
         %  bursting thresholds
            threshold_burst_Ca = 250;        
elseif (which_movie == 9)  % MDCK (bPAC), Erk (no fcs)
    str_movie = 'Erk_bPAC_passive'
    numCh=3;
    numFr=75;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Erk_bPAC_passive.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;  % CY3 was recorded but no marker existed for this channel
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Erk_marker) = ii_FITC;
        % time sequence parameters for movie
         tau_first = 6; % 6 second sample period
          num_samples_first = 121        
         time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        num_sample_sequence = [num_samples_first];
        tau_sample_movie = [tau_first];        
        dt_sample_movie = tau_sample_first;
elseif (which_movie == 10)  %  MDCK,   (low fcs)
    str_movie = '150707_MDCKI_39_117_207_highfcs'
    numCh=3;
    numFr=379;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\MDCKI_39_117_207_highfcs.tif');    
    ii_DAPI = 3;
    ii_FITC = 1;
    ii_CY3 = 2;  % CY3 was recorded but no marker existed for this channel
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
    marker_from_channel(ii_Erk_marker) = ii_CY3;
      nucleus_min_pixels = 40;  % 10X is used  
      delta_xDim = 100;
      delta_yDim = 100;   
        % time sequence parameters for movie
         tau_first = 6; % 6 second sample period
          num_samples_first = 121;        
         time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 6*60; % 6 minute sample period
          num_samples_second = 9;        
        time_sample_second = tau_second*ones(num_samples_second,1); 
         tau_third = 6; % 6 second sample period
          num_samples_third = 118;        
         time_sample_third = tau_third*ones(num_samples_third,1); 
        sample_sequence = [1 2 1 2 3];
        num_sample_sequence = [num_samples_first num_samples_second num_samples_first num_samples_second num_samples_third];
        tau_sample_movie = [tau_first tau_second tau_first tau_second tau_third];
        dt_sequence_movie = [time_sample_first; time_sample_second; time_sample_first; time_sample_second; time_sample_third];   % 6 seconds sample period
          %  bursting thresholds
          threshold_burst_Ca = 1000;
          threshold_burst_Erk = 10;
elseif (which_movie == 11)  %  MDCK, PKA marker (high fcs)
    str_movie = 'Fast_cells_high_fcs'
    numCh=2;
    numFr=75;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Fast_cells_high_fcs.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Pka_marker) = ii_FITC;
      nucleus_min_pixels = 50;  % 10X is used  
      delta_xDim = 100;
      delta_yDim = 100;    
elseif (which_movie == 12)  %  MDCK, PKA  (low fcs)
    str_movie = 'Fast_cells_low_fcs'
    numCh=2;
    numFr=75;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Fast_cells_low_fcs.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Pka_marker) = ii_FITC;
      nucleus_min_pixels = 50;  % 10X is used  
      delta_xDim = 100;
      delta_yDim = 100;    
elseif (which_movie == 13)  %  MDCK, PKA  (low fcs)
    str_movie = 'Calcium_061215'
    numCh=3;
    numFr=100;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Calcium_061215.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
        % time sequence parameters for movie
         tau_first = 6; % 6 second sample period
          num_samples_first = numFr-1;        
         time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        tau_sample_movie = [tau_first];
        num_sample_sequence = [num_samples_first];
        dt_sequence_movie = time_sample_first;  
elseif (which_movie == 14)  %  MDCK, PKA  (low fcs)
    str_movie = 'Ca_Erk_noBpac_6s'
    numCh=3;
    numFr=100;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Ca_Erk_noBpac_6s.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
    marker_from_channel(ii_Erk_marker) = ii_CY3;
        % time sequence parameters for movie
         tau_first = 6; % 6 second sample period
          num_samples_first = numFr-1;        
         time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        tau_sample_movie = [tau_first];
        num_sample_sequence = [num_samples_first];
        dt_sequence_movie = time_sample_first;  
elseif (which_movie == 15)  %  MDCK, PKA  (low fcs)
    str_movie = 'Ca_Erk_noBpac_15s'
    numCh=3;
    numFr=100;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\Ca_Erk_noBpac_15s.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_FITC;
    marker_from_channel(ii_Erk_marker) = ii_CY3;
        % time sequence parameters for movie
         tau_first = 6; % 6 second sample period
          num_samples_first = numFr-1;        
         time_sample_first = tau_first*ones(num_samples_first,1); 
         tau_second = 0; % no second sample period
        sample_sequence = [1];
        num_sample_sequence = [num_samples_first];
        tau_sample_movie = [tau_first];
        dt_sequence_movie = time_sample_first;  % 6 seconds sample period
elseif (which_movie == 16)  %  MDCK, PKA  (low fcs)
    str_movie = '150820_MDCKI-198-232'
    numCh=3;
    numFr=140;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\150820_MDCKI-198-232.tif');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 3;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Ca_marker) = ii_CY3;
    marker_from_channel(ii_Erk_marker) = ii_FITC;
      nucleus_min_pixels = 30;  % 10X is used  
      delta_xDim = 100;
      delta_yDim = 100;    
        % time sequence parameters for movie
         tau_first = 6*60; % 6 minute second sample period
          num_samples_first = 9;        
         time_sample_first = tau_first*ones(num_samples_first,1); 
        tau_second = 6; % 6 second second sample period
          num_samples_second = 121;        
        time_sample_second = tau_second*ones(num_samples_second,1); %          
        sample_sequence = [1 2 1];
        num_sample_sequence = [num_samples_first num_samples_second num_samples_first];
        tau_sample_movie = [tau_first tau_second tau_first];
        dt_sequence_movie = [time_sample_first; time_sample_second; time_sample_first];  % 6 seconds sample period
elseif (which_movie == 17)  
    str_movie = '198-117_6min-150min_6s-20min_6min-150min_DAPI-50ms-20_FITC-50ms_20_1'
    numCh=2;
    numFr=250;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\198-117_6min-150min_6s-20min_6min-150min_DAPI-50ms-20_FITC-50ms_20_1_MMStack.ome');    
    ii_DAPI = 1;
    ii_FITC = 2;
    ii_CY3 = 1;
    marker_from_channel(ii_nuclear_marker) = ii_DAPI;
    marker_from_channel(ii_Erk_marker) = ii_FITC;
      %nucleus_min_pixels = 30;  % 10X is used  
      %delta_xDim = 200;
      %delta_yDim = 200;    
        % time sequence parameters for movie
         tau_first = 6*60; % 6 minute second sample period
          num_samples_first = 25;        
         time_sample_first = tau_first*ones(num_samples_first,1); 
        tau_second = 6; % 6 second second sample period
          num_samples_second = 201;        
        time_sample_second = tau_second*ones(num_samples_second,1); %          
        sample_sequence = [1 2 1];
        num_sample_sequence = [num_samples_first num_samples_second num_samples_first];
        tau_sample_movie = [tau_first tau_second tau_first];
        dt_sequence_movie = [time_sample_first; time_sample_second; time_sample_first];  % 6 seconds sample period
end;    

  time_sequence_movie = 0;
for iii = 1:length(dt_sequence_movie)
  time_sequence_movie = [time_sequence_movie; sum(dt_sequence_movie(1:iii))];
end;



