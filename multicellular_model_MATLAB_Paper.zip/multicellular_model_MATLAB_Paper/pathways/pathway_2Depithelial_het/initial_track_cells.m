%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  1.  Map all nuclei that have unique trajectories.
%  2.  Fill in nuclei that have intermittent signal (due to tresholding),
%  either that disappear for some images or merge with nuclei in other
%  images.
%  3.  Remaining cells should be new cells, either daughter of from border
%  of the image
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


delta_move_threshold = 10;
%delta_move_threshold = max(xLength,yLength);
       
% Can capture more than one cell whos distance is closest to a prior cell
% location
% num_index_m1_mapped(index_min) = num_index_m1_mapped(index_min)+1; 
% index_m1_mapped(index_min,num_index_m1_mapped(index_min)) = ii;
    


tic
for kkk = 2:numFr
    which_frame = which_frames(kkk);
    mean_x_tot = mean_x_tot_time(1:num_nuclei_time(which_frame),which_frame);
    mean_y_tot = mean_y_tot_time(1:num_nuclei_time(which_frame),which_frame);
    mean_x_tot_m1 = mean_x_tot_time(1:num_nuclei_time(which_frame-1),which_frame-1);
    mean_y_tot_m1 = mean_y_tot_time(1:num_nuclei_time(which_frame-1),which_frame-1);
for iii = 1:num_nuclei_time(which_frame)
     [val_min,index_min] =  sort(sqrt(power(mean_x_tot(iii)-mean_x_tot_m1,2) + power(mean_y_tot(iii)-mean_y_tot_m1,2)));
       index_map_backward(iii,:) = index_min(1:num_mapped);
       dist_map_backward(iii,:) = val_min(1:num_mapped);
       index_map_backward_tot(iii,which_frame) = index_map_backward(iii,1);
       dist_map_backward_tot(iii,which_frame) = dist_map_backward(iii,1);
end;
for iii = 1:num_nuclei_time(which_frame-1)
     [val_min,index_min] =  sort(sqrt(power(mean_x_tot_m1(iii)-mean_x_tot,2) + power(mean_y_tot_m1(iii)-mean_y_tot,2)));
     
      %if (val_min(1) < delta_move_threshold)
       index_map_forward(iii,:) = index_min(1:num_mapped);
       dist_map_forward(iii,:) = val_min(1:num_mapped);
       index_map_forward_tot(iii,which_frame-1) = index_map_forward(iii,1);
       dist_map_forward_tot(iii,which_frame-1) = dist_map_forward(iii,1);
       
       index_map_backward_tot_f(index_map_forward(iii,1),which_frame) = iii;
       dist_map_backward_tot_f(iii,which_frame-1) = dist_map_forward(iii,1);
      %else  % forward case where the nucleus exists at time 0
          %num_nuclei_time(which_frame) = num_nuclei_time(which_frame)+1;
          %mean_x_tot_time(num_nuclei_time(which_frame),which_frame) = mean_x_tot_m1(iii);
          %mean_y_tot_time(num_nuclei_time(which_frame),which_frame) = mean_y_tot_m1(iii);
          %num_pixels_tot_NUCLEUS_time(num_nuclei_time(which_frame),which_frame) = num_pixels_tot_NUCLEUS_time(iii,which_frame-1);
          %  index_map_forward_tot(iii,which_frame-1) = num_nuclei_time(which_frame);
          %  dist_map_forward_tot(iii,which_frame-1) = 0;
      % 
      %    index_map_backward_tot_f(num_nuclei_time(which_frame),which_frame) = iii;
      %    dist_map_backward_tot_f(iii,which_frame-1) = 0;
      %end;
       
end;
end;
toc


 num_nuclei_t0 = num_nuclei_max;
 num_nuclei_t0 = num_nuclei_time(1);
 
 
  % mapping of nuclei that existed at time 0 
 index_map_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
 mean_x_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
 mean_y_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
 dist_map_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
 cytosolic_FITC_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames));
 cytosolic_CY3_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames));
 nuclear_FITC_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames));
 nuclear_CY3_tot_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames));
 num_pixels_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames));
 num_pixels_tot_CELL_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames));
  x_coord_min_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
  x_coord_max_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
  y_coord_min_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 
  y_coord_max_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,length(which_frames)); 

       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% map the nucleus movements between frames, including mean positions and
% pixels number (size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for iii = 1:num_nuclei_t0
    ii_map = iii;  % points to the normal order for the first frame only
for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk);
     if (kkk < length(which_frames))
      index_map_tot_time_mapped_t0(iii,which_frame+1) = index_map_forward_tot(ii_map,which_frame);
      dist_map_tot_time_mapped_t0(iii,which_frame+1) = dist_map_forward_tot(ii_map,which_frame);
     end;
    mean_x_tot_time_mapped_t0(iii,which_frame) = mean_x_tot_time(ii_map,which_frame);
    mean_y_tot_time_mapped_t0(iii,which_frame) = mean_y_tot_time(ii_map,which_frame);
    num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = num_pixels_tot_NUCLEUS_time(ii_map,which_frame);
    x_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = x_coord_min_tot_time(ii_map,which_frame);
    x_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = x_coord_max_tot_time(ii_map,which_frame);
    y_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = y_coord_min_tot_time(ii_map,which_frame);
    y_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = y_coord_max_tot_time(ii_map,which_frame);
     
    if (kkk == 1)
      index_map_tot_time_mapped_t0(iii,which_frame) = iii;  
    end;
    ii_map = index_map_forward_tot(ii_map,which_frame);  % points to the index of the properly mapped nuclues in the next frame
end;
end; 





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIRST: determine the number of nuclei that are uniquely mapped throughout the whole 
% movie.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

test_for_convergence_events   

used_nuclei_track_time = used_nuclei_track_time_dummy;
used_nuclei_track_time_INITIAL = used_nuclei_track_time_dummy;
convergence_event_INITIAL = convergence_event



do_substitution_nuclei_time = 0;
if (do_substitution_nuclei_time == 1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SECOND: of the nuclei that converged into one at any given time,
% determine those which can be uniquely determined by using all of the
% frames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    min_dist_time = zeros(length(convergence_event(:,1)),numFr);
    index_min_dist_time = zeros(length(convergence_event(:,1)),numFr);
    index_ref_min_dist_time = zeros(length(convergence_event(:,1)),numFr);
    frame_ref_min_dist_time = zeros(length(convergence_event(:,1)),numFr);


    
    
    
for iii = 1:length(convergence_event(:,1))   
    mean_x_tot_mN = mean_x_tot_time(1:num_nuclei_time(1),1);
    mean_y_tot_mN = mean_y_tot_time(1:num_nuclei_time(1),1);    
    index_dummy =  convergence_event(iii,1);   
    index_ref_min_dist_time(iii,1:2) = index_dummy;    
    frame_ref_min_dist_time(iii,1:2) = 1;
  for kkk = 2:length(which_frames)
    which_frame = which_frames(kkk);
    mean_x_tot = mean_x_tot_time(1:num_nuclei_time(which_frame),which_frame);
    mean_y_tot = mean_y_tot_time(1:num_nuclei_time(which_frame),which_frame);
     [val_min,index_min] =  sort(sqrt(power(mean_x_tot_mN(index_dummy)-mean_x_tot,2) + power(mean_y_tot_mN(index_dummy)-mean_y_tot,2)));     
      min_dist_time(iii,which_frame) = val_min(1);
      index_min_dist_time(iii,which_frame) = index_min(1);
      
      if (val_min(1) < delta_move_threshold)          
        mean_x_tot_mN = mean_x_tot_time(1:num_nuclei_time(which_frame),which_frame);
        mean_y_tot_mN = mean_y_tot_time(1:num_nuclei_time(which_frame),which_frame);
        index_dummy = index_min(1);
       frame_ref_min_dist_time(iii,which_frame+1) = which_frame;
       index_ref_min_dist_time(iii,which_frame+1) = index_min(1);
      else
       frame_ref_min_dist_time(iii,which_frame+1) = frame_ref_min_dist_time(iii,which_frame);
       index_ref_min_dist_time(iii,which_frame+1) = index_ref_min_dist_time(iii,which_frame) ;
      end;
  end;  
end;    



num_nuclei_time_original = num_nuclei_time;

% place the nuclei into the stucts and relevant information in other arrays
for kkk = 2:length(which_frames)
  which_frame = which_frames(kkk)
      for idx = 1:length(index_ref_min_dist_time(:,1))
          which_frame_CELL = frame_ref_min_dist_time(idx,which_frame);
          idx_map = index_ref_min_dist_time(idx,which_frame);
       
          used_nuclei_track_time(idx_map,which_frame_CELL) = 1;  % make sure it is checked as used
          
          index_dummy = index_ref_min_dist_time(idx,1);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
       %  update all arrays
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
       %eval(['Cell_nucleus_FILL_',num2str(which_frame)])
       eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList = [Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList Cell_nucleus_FILL_',num2str(which_frame_CELL),'.PixelIdxList{idx_map}];']);
       eval(['Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects = Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects+1;']);   
       %eval(['Cell_nucleus_FILL_',num2str(which_frame)])
       mean_x_tot_time_mapped_t0(index_dummy,which_frame) = mean_x_tot_time(idx_map,which_frame_CELL);       
       mean_y_tot_time_mapped_t0(index_dummy,which_frame) = mean_y_tot_time(idx_map,which_frame_CELL);       
       num_pixels_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = num_pixels_tot_NUCLEUS_time(idx_map,which_frame_CELL);
       index_map_tot_time_mapped_t0(index_dummy,which_frame) = eval(['Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects']);
       dist_map_tot_time_mapped_t0(index_dummy,which_frame) = min_dist_time(idx,which_frame_CELL);
        x_coord_min_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = x_coord_min_tot_time(idx_map,which_frame_CELL);
        x_coord_max_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = x_coord_max_tot_time(idx_map,which_frame_CELL);
        y_coord_min_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = y_coord_min_tot_time(idx_map,which_frame_CELL);
        y_coord_max_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = y_coord_max_tot_time(idx_map,which_frame_CELL);
       
      end;
end;  % END OF: for kkk = 1:length(which_frames)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% here we need to make sure that the newly placed nuclei don't overlap the nuclei it converged with
% if so, we go to the closes frame where both nuclei are separated and
% substitute that in.
%
%  NOTE: eventually we might just rethreshold these nuclie in the current
%  image rather than substituting.  However,  as long as the nuclei are
%  BARELY moving, it doesn't matter.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    M_marker_threshold = int16(zeros(xLength,yLength));
    
for idx = 2:length(convergence_event(:,1))
 if convergence_event(idx-1,2) == convergence_event(idx,2)  %  
  for kkk = 2:length(which_frames)
   for ggg = 1:2
   which_frame = which_frames(kkk);
   M_marker_threshold = 0*M_marker_threshold;
   index_dummy = convergence_event(idx-1+ggg-1,1);      
   [val_min,index_min] =  sort(sqrt( power(mean_x_tot_time_mapped_t0(index_dummy,which_frame)- mean_x_tot_time_mapped_t0(1:num_nuclei_t0,which_frame),2) + power(mean_y_tot_time_mapped_t0(index_dummy,which_frame)-mean_y_tot_time_mapped_t0(1:num_nuclei_t0,which_frame),2)));     
   index_neighbor_test(1) = index_dummy;
   index_neighbor_test(2) = index_min(2);
   index_neighbor_test(3) = index_min(3);
     for ppp = 1:3  
     index_dummy = index_neighbor_test(ppp);
     idx_map_dummy = index_map_tot_time_mapped_t0(index_dummy,which_frame);
      M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map_dummy}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map_dummy}'])) + 1;
     end;    
    if (max(max(M_marker_threshold)) == 2)  % overlap  
        % substitute in the prior     
     for ppp = 1:3            
      index_dummy = index_neighbor_test(ppp);
       idx_map = index_map_tot_time_mapped_t0(index_dummy,which_frame);
        idx_map_m1 = index_map_tot_time_mapped_t0(index_dummy,which_frame-1);
      eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_nucleus_FILL_',num2str(which_frame-1),'.PixelIdxList{idx_map_m1}']);
     end;
    end;    
        
        
  end;  % END OF: for ggg = 1:2
 end;  % END OF: for kkk = 1:length(which_frames)
 
 end;
end; 
 
end;  % END OF: if (do_substitution_nuclei_time == 1)



test_for_convergence_events   



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LAST STEP: Identify and string togeth nuclei that were not present 
% in the first image, either by the threshold test or a new daughter or movile border cell
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate the number of unused nuclei (those not part of a sequence so far)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
used_nuclei_tot_time = zeros(numFr,1);
used_nuclei_tot_time_INITIAL = zeros(numFr,1);
for kkk = 1:numFr
    which_frame = which_frames(kkk);
    used_nuclei_tot_time(which_frame) = sum(used_nuclei_track_time(1:num_nuclei_time(which_frame),which_frame));
    used_nuclei_tot_time_INITIAL(which_frame) = sum(used_nuclei_track_time_INITIAL(1:num_nuclei_time(which_frame),which_frame));
end;

unused_nuclei_tot_time = (num_nuclei_time-used_nuclei_tot_time)'
unused_nuclei_tot_time_INITIAL = (num_nuclei_time-used_nuclei_tot_time_INITIAL)'







check_for_daughters = 0;
if (check_for_daughters == 1)

  %  TO DO:  daugher and mother must get the same prior signal
  % add new cell here
  %index_map_forward_daughter(index_map_forward(jj),jj) = index_new_cell;
  
  
  
  num_daughters_current = 0;
  
  
  

for ii = 1:num_nuclei
    
    cell_divided = 0;
    
    %  only signals that exist over the whole duration will be counted
    
    
    signal_nucleus_FITC_time(ii,1) = signal_nucleus_FITC(ii);     
    
    for jj = 1:numFr-1        
       signal_nucleus_FITC_time(ii,jj) = signal_nucleus_FITC(index_map_forward(jj));
        if (index_map_forward_daughter(index_map_forward(jj),jj) > 0)
           cell_divided = 1;
           num_daughter_current = num_daughter_current + 1; 
           signal_nucleus_FITC_time_daughter(num_daughter_current,1:jj-1) = signal_nucleus_FITC(ii,1:jj-1); 
             index_daughter_current(num_daughter_current) = index_map_forard_daughter(index_map_forward(jj),jj);
             signal_nucleus_FITC_time_daughter(ii,jj) = signal_nucleus_FITC(index_map_forward(index_daughter_current(num_daughter_current)));
        elseif (cell_divided == 1)
            index_daughter_current(num_daughter_current) = index_map_forward(index_daughter_current(num_daughter_current));   
            signal_nucleus_FITC_time_daughter(ii,jj) = signal_nucleus_FITC(index_map_forward(index_daughter_current(num_daughter_current)));
        end;
    end;
    
end;


end;  % END OF: if (check_for_daugthers == 1)
