


if (do_CH2 == 1)        
figure(2)

     subplot(2,4,[1 2]) 
     title(strcat('nuclear CH2 signal'));
     plot(time_CH2,cytosolic_CH2_tot_time_mapped_t0(idx,:)-cytosolic_CH2_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_CH2,cytosolic_CH2_tot_time_mapped_t0(idx,:)-cytosolic_CH2_tot_time_mapped_t0(idx,1));
     plot([time_CH2(which_frame) time_CH2(which_frame)],[min(cytosolic_CH2_tot_time_mapped_t0(idx,:)-cytosolic_CH2_tot_time_mapped_t0(idx,1)) max(cytosolic_CH2_tot_time_mapped_t0(idx,:)-cytosolic_CH2_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CH2)
     legend(strcat('CH2 (cyt-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH2)
     legend(strcat('CH2 (cyt-Ca2+),nuc:',num2str(which_nucleus)))
     end;
     xlabel('time (seconds)');
     xlim([0 max(time_CH2)]);


     subplot(2,4,[3 4]) 
     title(strcat('nuclear CH2 signal'));
     plot(time_CH2,nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_CH2,nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1));
     plot([time_CH2(which_frame) time_CH2(which_frame)],[min(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1)) max(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CH2)
     legend(strcat('CH2 (nuc-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH2)
     legend(strcat('CH2 (nuc-Ca2+),nuc:',num2str(which_nucleus)))
     end;
     xlabel('time (seconds)');
     xlim([0 max(time_CH2)]);
    

    
end; % END OF: if (do_CH2 == 1)        

     
     
     
if (do_CH1 == 1)    
    
     subplot(2,4,[5 6]) 
     title(strcat('cytosolic CH1 signal'));
     plot(time_CH1,cytosolic_CH1_tot_time_mapped_t0(idx,:)-cytosolic_CH1_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_CH1,cytosolic_CH1_tot_time_mapped_t0(idx,:)-cytosolic_CH1_tot_time_mapped_t0(idx,1));
     plot([time_CH1(which_frame) time_CH1(which_frame)],[min(cytosolic_CH1_tot_time_mapped_t0(idx,:)-cytosolic_CH1_tot_time_mapped_t0(idx,1)) max(cytosolic_CH1_tot_time_mapped_t0(idx,:)-cytosolic_CH1_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CH1)
     legend(strcat('CH1 (cyt-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH1)
     legend(strcat('CH1 (cyt-Ca2+),nuc:',num2str(which_nucleus)))
     end;     
     xlabel('time (seconds)');
     xlim([0 max(time_CH1)]);
     ylim([min(cytosolic_CH1_tot_time_mapped_t0(idx,:)-cytosolic_CH1_tot_time_mapped_t0(idx,1)) max(cytosolic_CH1_tot_time_mapped_t0(idx,:)-cytosolic_CH1_tot_time_mapped_t0(idx,1))]);

    
     subplot(2,4,[7 8]) 
     title(strcat('nuclear CH1 signal'));
     plot(time_CH1,nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_CH1,nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1));
     plot([time_CH1(which_frame) time_CH1(which_frame)],[min(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1)) max(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CH1)
     legend(strcat('CH1 (nuc-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH1)
     legend(strcat('CH1 (nuc-Ca2+),nuc:',num2str(which_nucleus)))
     end;     
     xlabel('time (seconds)');
     xlim([0 max(time_CH1)]);
     ylim([min(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1)) max(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1))]);
     
       
     if (marker_from_channel(ii_Ca_marker) == ii_CH1)
         index_sample_frame_CH1 = index_sample_frame_Ca;
     elseif (marker_from_channel(ii_Erk_marker) == ii_CH1)
         index_sample_frame_CH1 = index_sample_frame_Erk;
     end;

%      for jjj = 1:length(pulse_sequence_index_start_CH1)
% 
%          
%          start_frame = pulse_sequence_index_start_CH1(jjj);
%          end_frame = pulse_sequence_index_end_CH1(jjj);
%          
%      figure(11)
%      subplot(length(pulse_sequence_index_start_CH1),2,2*jjj) 
%      title(strcat('nuclear CH1 signal'));
%      plot(time_CH1(start_frame:end_frame),nuclear_CH1_tot_time_mapped_t0(idx,start_frame:end_frame)-nuclear_CH1_tot_time_mapped_t0(idx,1));
%      hold on;
%      plot(time_CH1(start_frame:end_frame),nuclear_CH1_tot_time_mapped_t0(idx,start_frame:end_frame)-nuclear_CH1_tot_time_mapped_t0(idx,1));
%      hold off;
%      if (marker_from_channel(ii_Erk_marker) == ii_CH1)
%      legend(strcat('CH1 (nuc-Erk),nuc:',num2str(which_nucleus)))
%      elseif (marker_from_channel(ii_Ca_marker) == ii_CH1)
%      legend(strcat('CH1 (nuc-Ca2+),nuc:',num2str(which_nucleus)))
%      end;     
%      xlabel('time (seconds)');
%      xlim([time_CH1(start_frame) time_CH1(end_frame)]);
%      ylim([min(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1)) max(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1))]);
%      
%      end;  % end of: for jjj = 1:length(index_sequence_frame_CH1)
     
     
      
     
     
end; % END OF: if (do_CH1 == 1)        
