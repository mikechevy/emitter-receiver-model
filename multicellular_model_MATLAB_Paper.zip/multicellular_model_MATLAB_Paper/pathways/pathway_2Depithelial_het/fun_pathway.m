function y_prime = fun_path_ht(y)


global ss_or_transient;

%  molecule indexes
global ii_x0;
global ii_x1;
global ii_x2;
global ii_x3;
global ii_x4;
global ii_x5;
global ii_x6
global ii_x7;
global ii_x8;
global ii_xmax;

global source_u;
global passed_constants;
global which_pathway;


if (which_pathway ==0)

          alpha_A = passed_constants(1);
          alpha_prime_A = passed_constants(2);
          alpha_R = passed_constants(3);
          alpha_prime_R = passed_constants(4);
          beta_A = passed_constants(5);
          beta_R = passed_constants(6);
          delta_MA = passed_constants(7);
          delta_MR = passed_constants(8);
          delta_A = passed_constants(9);
          delta_R = passed_constants(10);
          gamma_A = passed_constants(11);
          gamma_R = passed_constants(12);
          gamma_C = passed_constants(13);
          theta_A = passed_constants(14);
          theta_R = passed_constants(15);


          D_A = y(1);
          D_R = y(2);
          D_prime_A = y(3);
          D_prime_R = y(4);
          M_A = y(5);
          M_R = y(6);
          A = y(7);
          R = y(8);
          C = y(9);


        %  equations
          y_prime(1) = theta_A*D_prime_A -gamma_A*D_A*A;
          y_prime(2) = theta_R*D_prime_R -gamma_R*D_R*A;

          y_prime(3) = -theta_A*D_prime_A +gamma_A*D_A*A;
          y_prime(4) = -theta_R*D_prime_R +gamma_R*D_R*A;

          y_prime(5) = alpha_prime_A*D_prime_A + alpha_A*D_A - delta_MA*M_A;
          y_prime(6) = alpha_prime_R*D_prime_R + alpha_R*D_R - delta_MR*M_R;

          y_prime(7) =  beta_A*M_A + theta_A*D_prime_A + theta_R*D_prime_R...
                       -A*(gamma_A*D_A + gamma_R*D_R + gamma_C*R + delta_A);

          y_prime(8) = beta_R*M_R - gamma_C*A*R + delta_A*C - delta_R*R;

          y_prime(9) = gamma_C*A*R - delta_A*C;
        
elseif (which_pathway == 1)

         y_prime(1:14) = 0;

elseif (which_pathway == 2)

                      k_1 = passed_constants(1);
                      k_m1 = passed_constants(2);
                      k_2 = passed_constants(3);
                      k_m2 = passed_constants(4);
                      k_3 = passed_constants(5);
                      k_m3 = passed_constants(6);
                      k_4 = passed_constants(7);                      
                      k_m4 = passed_constants(8);
                      k_d = passed_constants(9);
                      P_0 = passed_constants(10);
                      d_t = passed_constants(11);
                      r_basal = passed_constants(12);
                      n_per_translation = passed_constants(13);
                      k_t = passed_constants(14);
                      R_0 = passed_constants(15);
                      k_on_R = passed_constants(16);
                      k_off_R = passed_constants(17);
                      k_mRNA_X = passed_constants(18);
                      alpha_mRNA_X = passed_constants(19);
                      k_X = passed_constants(20);

X = y(1);
X_2 =  y(2);
D =  y(3);
D_X_2 = y(4);
D_X_2_conj = y(5);
D_X_2_X_2 = y(6);
if (ii_xmax == 7)
mRNA_X = y(7);
end;

if (ii_xmax == 6)
y_prime(1) =  -2*k_1*X*(X-1)/2 +2*k_m1*X_2 +k_d*X_2 - k_d*X + P_0*k_t*n_per_translation*D_X_2 + r_basal;
else
y_prime(1) =  -2*k_1*X*(X-1)/2 +2*k_m1*X_2 +k_d*X_2 - k_d*X + k_X*mRNA_X;
y_prime(7) = k_mRNA_X*D_X_2 + r_basal*alpha_mRNA_X/k_X - alpha_mRNA_X*mRNA_X;
end;
y_prime(2) =     k_1*X*(X-1)/2 -k_m1*X_2 - k_d*X_2 - k_2*D*X_2 + k_m2*D_X_2 - k_3*D*X_2 + k_m3*D_X_2_conj - k_4*D_X_2*X_2 + k_m4*D_X_2_X_2;
y_prime(3) =    -k_2*D*X_2 + k_m2*D_X_2 - k_3*D*X_2 + k_m3*D_X_2_conj;
y_prime(4) =     k_2*D*X_2 - k_m2*D_X_2 - k_4*D_X_2*X_2 + k_m4*D_X_2_X_2;
y_prime(5) =     k_3*D*X_2 - k_m3*D_X_2_conj;
y_prime(6) =     k_4*D_X_2*X_2 - k_m4*D_X_2_X_2;



elseif (which_pathway == 3)

          k_1 = passed_constants(1);
          k_2 = passed_constants(2);
 y_prime(1) =  -2*k_1*y(1)*(y(1)-1)/2-k_2*y(1)*y(3);
 y_prime(2) =   k_1*y(1)*(y(1)-1)/2;
 y_prime(3) =  -k_2*y(1)*y(3);
 y_prime(4) =   k_2*y(1)*y(3);
end;
            
      
      
if (ss_or_transient == 0)    %  in steady state, y_prime*y_prime' is error
 y_prime = y_prime*y_prime';
end;
 y_prime = y_prime';
      
