
if (do_ssa_raw_out == 1)

%  Output data stuff
count_data=count_data+1;  % before for matlab, after for Petsc
   X_data(count_data,:) = x_old;
   time_data(count_data) = time_old;
   species_restricted_data(count_data,:) = species_restricted;
    if (count_data==max_count_data)
        for ii = 1:max_count_data
        fwrite(fids_state_data,X_data(ii,:),'double');
        fwrite(fids_restricted_data,species_restricted_data(ii,:),'int');
        end;
        fwrite(fids_time_data,time_data(1:max_count_data),'double');
        time_data_final = time_data(max_count_data);
        count_data_total = count_data_total + max_count_data;
        count_data = 0;
    end; 

end;


if (do_ssa_sampled_out == 1)



             while ((count_data_sampled_total*dt_sampled<time)&(count_data_sampled_total<num_sampled_ssa))
                 count_data_sampled = count_data_sampled+1;
                 count_data_sampled_total = count_data_sampled_total+1;
                 for ii = 1:num_molecules
                    X_data_sampled(count_data_sampled,ii) = x_old(ii);
                    %X_data_sampled(count_data_sampled,ii) = x_g(ii);
                 end;


               if (count_data_sampled==max_count_data_sampled)
                 for ii=1:max_count_data_sampled
                   fwrite(fids_data_sampled,X_data_sampled(ii,:),'double');
                 end;
                  count_data_sampled = 0;
               end;


             end;  % end of 'while


end;
