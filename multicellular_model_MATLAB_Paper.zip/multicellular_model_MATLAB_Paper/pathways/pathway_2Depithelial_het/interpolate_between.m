

function [index_X_upper index_X_lower upper lower] = interpolate_between(X_to,ii_to,X_from);   

    [val,index_X] = min(abs(X_to(ii_to) - X_from));
    
    if ( X_to(ii_to) <= X_from(index_X) )
       index_X_upper = index_X;
       index_X_lower = index_X-1;
    else
       index_X_upper = index_X+1;
       index_X_lower = index_X;
    end;
    
    if (index_X_lower==0)
       index_X_upper = index_X_upper+1;
       index_X_lower = index_X_lower+1;        
    elseif (index_X_lower==length(X_from))
       index_X_upper = index_X_upper-1;
       index_X_lower = index_X_lower-1;        
    end;
    upper = (X_to(ii_to)-X_from(index_X_lower))/( X_from(index_X_upper)-X_from(index_X_lower) );
    lower = 1-upper;
