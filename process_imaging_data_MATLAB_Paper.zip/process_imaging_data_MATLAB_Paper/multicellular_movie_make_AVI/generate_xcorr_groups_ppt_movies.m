
ratio_xcorr = 1/1.8;  % one over the ratio of max value to next closest value  
[xcorr_group,size_xcorr_group] = findHotSpotsMetric(nuclear_Ca_signal_adjusted,num_nuclei,ratio_xcorr,ii_xcorr);


  which_frame = 1

  str_movie_processed = strcat(str_movie,'_processed')
  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus);

  M_marker_threshold = M_DAPI_threshold_FILL;
  box_coords = box_coords_DAPI;
  mean_x_tot = mean_x_tot_DAPI;
  mean_y_tot = mean_y_tot_DAPI;
  
box_coords_cluster = zeros(length(size_xcorr_group),4);  
num_clusters = length(size_xcorr_group);
size_cluster = size_xcorr_group;
cluster = xcorr_group;

  box_coords_cluster(:,1) = xLength+1;
  box_coords_cluster(:,2) = 0;
  box_coords_cluster(:,3) = yLength+1;
  box_coords_cluster(:,4) = 0;

for ii = 1:length(size_xcorr_group)
ii
length(size_xcorr_group)

                 fig100 = figure(100);
                 imagesc(M_marker_threshold)
    
    for jj = 1:size_xcorr_group(ii)
    
                 figure(100)
                 hold on;
                 x_coord_min = box_coords(xcorr_group(ii,jj),1);
                 x_coord_max = box_coords(xcorr_group(ii,jj),2);
                 y_coord_min = box_coords(xcorr_group(ii,jj),3);
                 y_coord_max = box_coords(xcorr_group(ii,jj),4);

                 box_coords_cluster(ii,1) = min(box_coords_cluster(ii,1),box_coords(xcorr_group(ii,jj),1)); 
                 box_coords_cluster(ii,2) = max(box_coords_cluster(ii,2),box_coords(xcorr_group(ii,jj),2)); 
                 box_coords_cluster(ii,3) = min(box_coords_cluster(ii,3),box_coords(xcorr_group(ii,jj),3)); 
                 box_coords_cluster(ii,4) = max(box_coords_cluster(ii,4),box_coords(xcorr_group(ii,jj),4)); 
                 
                % have to swith the x with the y coordinates for this
                 rectangle('Position', [y_coord_min,x_coord_min,...
                   y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
                         'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                         'EdgeColor', 'r');
                  text(mean_y_tot(xcorr_group(ii,jj)),mean_x_tot(xcorr_group(ii,jj)),num2str(jj))
                  hold off;
        
      fig1000 = figure(1000);
      subplot(size_xcorr_group(ii),2,2*(jj-1)+2)
      plot(nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),:),'g--');
      ylabel(strcat('cell ',num2str(jj)));
      ylim([0 600]);
      xlim([1 length(nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),:))]);
      
      fig2000 = figure(2000);
      subplot(size_xcorr_group(ii),1,jj)
       if (jj ==1)
           title('cross-correlation with each surrounding cells');
       end;
       time_xcorr = -119:119;
      plot(time_xcorr,xcorr(nuclear_Ca_signal_adjusted(xcorr_group(ii,1),:),nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),:)));
      ylabel(strcat('cell ',num2str(jj)));
      
      figBlank = figure(10000);
     %    figure(101)
     %    imagesc(M_marker_threshold)
     %    hold on;
        

    end;

       dosavePPT2=1; % 1 - saves as ppt file, 0 - no
       %pptTitle = strcat('/',str_movie_processed,'/xcorr');
       pptTitle = strcat('xcorr');
        if dosavePPT2 == 1
             save_figs_to_ppt2_xcorr
        end;
       
end;

   
%  makes movies in each region that contains a cluster
make_localized_movie_for_each_cluster

which_cluster = 1;
view_movie_of_cluster(which_cluster,str_movie)
