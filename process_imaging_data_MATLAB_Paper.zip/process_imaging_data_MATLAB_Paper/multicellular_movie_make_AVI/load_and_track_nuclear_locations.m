%close all;
%clear all;

set_globals;

if (length(which_movie) == 0)  % used for individual calls to this script
which_movie = input('which movie number do you want, e.g. 1 ,2, etc. ? ');    
end;
get_movie_info_for_processing  % which_movie must already be set
%str_movie_processed = strcat(str_movie,'_processed')
str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
  
do_load_movie_arrays = 1;  % 1 - yes, 0 - no
if (do_load_movie_arrays == 1)&(exist('M_CH1_total')==0)
% load in processed data from nuclear tracking code
file_movie_arrays = strcat(str_movie_processed,'\movie_arrays'); 
load(file_movie_arrays);  
end;

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);





% load in the thresholded nuclei information from all frames 
file_nucleus_tot = strcat(str_movie_processed,'\Cell_nucleus_structs_tot');
load(file_nucleus_tot);

% load time series file foor tracking the cells
file_track_cells = strcat(str_movie_processed,'\time_series_for_tracking_cells');
load(file_track_cells);


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN:  setup some arrays
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
 index_map_forward_tot = zeros(num_nuclei_max, numFr_NM);
 dist_map_forward_tot = zeros(num_nuclei_max, numFr_NM);
 index_map_backward_tot_f = zeros(num_nuclei_max, numFr_NM); % backwards mapping only for those cells that mapped forward
 index_map_backward_tot = zeros(num_nuclei_max, numFr_NM);  % backward mapping to closest cells, this is mainly for determining daughters
 dis_map_backward_tot = zeros(num_nuclei_max, numFr_NM);
 
 num_mapped = 5;
 index_map_forward = zeros(num_nuclei_max,num_mapped);
 dist_map_forward = zeros(num_nuclei_max,num_mapped);
 index_map_backward = zeros(num_nuclei_max,num_mapped);
 dist_map_backward = zeros(num_nuclei_max,num_mapped);
 index_mapped_m1 = zeros(num_nuclei_max,num_mapped);
 num_index_m1_mapped = zeros(num_nuclei_max,1);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % END:  setup some arrays
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  %%%%%%%%%%%%%%%%%%%%%%%% 
  % Tracking code
  %%%%%%%%%%%%%%%%%%%%%%%% 
  initial_track_cells


  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Plot movie of tracked cells
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
  %plot_all_nuclei_movements_CELL
  %plot_localized_group_of_nuclei_over_time

  
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% write out the final nuclei-pixel array file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
for kkk = 1:numFr_NM
    which_frame = kkk;
     if (which_frame == 1)
       save(file_nucleus_tot_FINAL,strcat('Cell_nucleus_FILL_',num2str(which_frame)));
     else
       save(file_nucleus_tot_FINAL,strcat('Cell_nucleus_FILL_',num2str(which_frame)),'-append');
     end;
end;

  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Save processed tracking data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
save(file_track, 'num_pixels_tot_NUCLEUS_time','mean_x_tot_time','mean_y_tot_time','num_nuclei_time','unique_nuclei_track_time','index_map_tot_time_mapped_t0','num_pixels_tot_NUCLEUS_time_mapped_t0','mean_x_tot_time_mapped_t0','mean_y_tot_time_mapped_t0','dist_map_tot_time_mapped_t0','num_nuclei_t0','x_coord_min_tot_NUCLEUS_time_mapped_t0','x_coord_max_tot_NUCLEUS_time_mapped_t0','y_coord_min_tot_NUCLEUS_time_mapped_t0','y_coord_max_tot_NUCLEUS_time_mapped_t0','num_mapped','num_nuclei_max','index_map_forward_tot','dist_map_forward_tot','index_map_backward_tot_f','index_map_backward_tot','dis_map_backward_tot','xLength','yLength','do_substitution_nuclei_time');


  
  
  
  