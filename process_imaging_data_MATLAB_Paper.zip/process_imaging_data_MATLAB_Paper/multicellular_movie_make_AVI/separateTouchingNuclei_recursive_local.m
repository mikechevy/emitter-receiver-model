function [M_marker_threshold_out] = separateTouchingNuclei_recursive_local(M_marker_threshold,M_marker,box_coords, threshold, nucleus_min_pixels,mean_pix,std_pix,min_min_M_marker,max_max_M_marker)


global fac_std_nuclear_size_recursive;

%tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Divide and conquer:  Recurvisthreshold into two pieces at a time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

max_separate_nuclei = 20;
    
box_coords_new = zeros(max_separate_nuclei,4);

    M_marker_threshold_TEST = 0*M_marker_threshold;    
    M_marker_threshold_FILL = 0*M_marker_threshold;    
    
M_marker_NORMALIZED = double(M_marker-min_min_M_marker)/double(max_max_M_marker-min_min_M_marker);
   
                 x_coord_min = 1;
                 x_coord_max = box_coords(2)-box_coords(1)+1;
                 y_coord_min = 1;
                 y_coord_max = box_coords(4)-box_coords(3)+1;
                 
threshold_max = max(max(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
num_iterations_threshold = 30;
delta_threshold = (threshold_max-threshold)/num_iterations_threshold;                 

nuclei_separated = 0;  % 1 - yes, 0 no
threshold_test = threshold;
  if (delta_threshold <= 0)  % this probably never happens
      delta_threshold = 0;
      threshold_test = threshold_max;
  end;

fac_std = fac_std_nuclear_size_recursive;


while (threshold_test < min(threshold_max,1))&(nuclei_separated == 0)

    threshold_test = threshold_test + delta_threshold;
          
   if (threshold_test <= 1)
    M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold_test);
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = bwareaopen(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max), nucleus_min_pixels);  % removie 
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');    
    Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    num_nuclei_separate = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));
                           
              
              if (num_nuclei_separate > 1)
                  nuclei_separated  = 1;                 
              elseif (sum(sum(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max))) < mean_pix + fac_std*std_pix)
                  nuclei_separated  = -1;
              end;
   end;
              
end % END OF: while (ii_threshold <=num_iterations_threshold)&(all_nuclei_separated == 0)



               M_marker_threshold_out = 0*M_marker_threshold;

             if (num_nuclei_separate <= 1)  % single nucleus!!!!
               % return box_coords;              
               %box_coords_out = box_coords;
               num_nuclei_out = 1;  
               M_marker_threshold_out = M_marker_threshold; 
             elseif (num_nuclei_separate > 1)  % single nucleus!!!!
                 
                 box_coords_out = [];
              for ii_num_nuclei = 1:num_nuclei_separate   
                M_marker_threshold_TEST = 0*M_marker_threshold_TEST;   
                M_marker_threshold_TEST(Cell_marker_FILL.PixelIdxList{ii_num_nuclei}) = 1;

               if (sum(sum(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max))) > mean_pix + fac_std*std_pix)
                     do_plot_threshold_results = 0; % 1 - yes, 0 - no
                 if (do_plot_threshold_results == 1)
                  test_plot_separate_nuclei
                  pause;
                 end;   % END OF:  if (do_plot_threshold_results == 1)
                  
                                                 
                M_marker_TEST = M_marker.*int16(M_marker_threshold_TEST);  % remove others
                
               [M_marker_threshold_separate] =   separateTouchingNuclei_recursive_local(M_marker_threshold_TEST,M_marker_TEST,box_coords, threshold_test, nucleus_min_pixels,mean_pix,std_pix,min_min_M_marker,max_max_M_marker);
               M_marker_threshold_out = M_marker_threshold_out + M_marker_threshold_separate;
               else
                M_marker_threshold_out = M_marker_threshold_out + M_marker_threshold_TEST;
               end;
              end;
             end;


 %toc_out = toc
          
