

if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 

do_just_nuclear_signal = 0;  % 0-ratio of nuclear to cytosol, 1-nuclear signal/min(nuclear signal);  For powerpoint stuff

  if (which_nuclei_signal_type == 1) % shrink
      str_nuclei_signal_type = 'SHRINK_';
  elseif (which_nuclei_signal_type == 2) % intersect
      str_nuclei_signal_type = 'INTERSECT_';
  elseif (which_nuclei_signal_type == 3) % circle
      str_nuclei_signal_type = 'CIRCLE_';
  end;
      
if (do_just_nuclear_signal == 1)
  str_just_nuclear = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
elseif (do_just_nuclear_signal == 0)
  str_just_nuclear = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
end;


M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);



s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);

          
          diff_bPAC_signal = diff(bPAC_ledvals);
          
%  determine pulse locations here, bPAC
             num_pulses = 0;
             num_bPAC_pulses = 0;
             index_bPAC_pulse_start = [];
             index_bPAC_pulse_stop = [];
     for ii = 1:length(diff_bPAC_signal)
         
         if (diff_bPAC_signal(ii) > 0)
             index_bPAC_pulse_start(num_bPAC_pulses+1) = ii+1; % top of pulse (rise)
             num_bPAC_pulses = num_bPAC_pulses + 1;
         elseif (diff_bPAC_signal(ii) < 0)
             index_bPAC_pulse_stop(num_bPAC_pulses) = ii; % top of pulse (decline)
         end;
             
     end;
            if length(index_bPAC_pulse_stop) < length(index_bPAC_pulse_start)
                index_bPAC_pulse_stop(num_bPAC_pulses) = length(time_bPAC); 
            end;
            
            %  this calculates the end of each step-pulse that are all but
            %  the last in a step-up sequence
            if (num_bPAC_pulses > 1)
               for ii = 1:num_bPAC_pulses -1
                if (index_bPAC_pulse_stop(ii) == 0)
                   index_bPAC_pulse_stop(ii) = index_bPAC_pulse_start(ii+1)-1;
                end;
               end;
            end;
            

%  determine indexes of time_Erk that are within the bPAC pulse times
             index_bPAC_pulse_start_Erk = [];
             index_bPAC_pulse_stop_Erk = [];
     for ii = 1:num_bPAC_pulses
  
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_start(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_start(ii)) )
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy+1;         
          %else
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
          %end;
          index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         
          
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_stop(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_stop(ii)) )
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy;         
          %else
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy-1;          
          %end;
          index_bPAC_pulse_stop_Erk(ii) =  min(index_dummy+1,length(time_Erk));   % captures full experimental duration of pulse       
          
          
     end;
     
     bPAC_pulse_width = index_bPAC_pulse_stop - index_bPAC_pulse_start +1;
            
          % plots average signals
          sig_dummy_nuclear_average = zeros(1, length(time_Erk));
          sig_dummy_ratio_average = sig_dummy_nuclear_average;          
          ratio_signal = zeros(num_nuclei_t0,length(time_Erk));
     
          
mkdir(strcat(str_movie_processed_figures,'\transfer_function'));
cd(strcat(str_movie_processed_figures,'\transfer_function'));


     delete(strcat(str_movie,'-nuclear_Erk_signals.ppt'));     
     delete(strcat('bPAC_pulsing_cells.ppt'));     
     delete(strcat('transfer_function_bPAC_signals-',str_movie,'.ppt'));
     delete(strcat('average_signals_transfer_function-',str_movie,'.ppt'));
          
          
          
num_bPAC_pulsing_cells = 0;            
bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MIKE: TRANSFER FUNCTION CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (do_use_all_cells_TF == 1)
bPAC_pulse_cell_tf = ones(num_nuclei_t0,1);  % this plots all cells regardles
else
bPAC_pulse_cell_tf = zeros(num_nuclei_t0,1);
end;
max_tf_time_points = 4; % delay between a cAMP signal and Erk signal
Erk_tf_average = zeros(num_bPAC_pulses+1, max_tf_time_points);   % Cell-Averaged Erk output from Transfer Function
str_tf = ['k' 'r' 'g' 'b' 'm'];

tf_time_shift_array = [-3 -2 -1 0];
%tf_time_shift_array = [0 1 2 3];  % original (pre - 04/15/20)

for idx = 1:num_nuclei_t0
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Pulse analysis 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     for ii = 1:num_bPAC_pulses     

         
         % TIME: time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,

         diff_time_Erk = diff(time_Erk)
         dt_pre_pulse = 4*60; 
         dt_pre_post = 5*60; 
         num_samps_pre = round(dt_pre_pulse/diff_time_Erk(2));
         num_samps_post = ceil(dt_pre_post/diff_time_Erk(2));
         
         %NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         sig_dummy_cytosol = double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy);
         min_sig = min(sig_dummy);         
          signal_dummy =  sig_dummy(index_bPAC_pulse_stop_Erk(ii))/sig_dummy_cytosol(index_bPAC_pulse_stop_Erk(ii));
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii))/sig_dummy_cytosol(index_bPAC_pulse_start_Erk(ii));
          
          
          pulse_dummy = signal_dummy - signal_dummy_pre_pulse;          
          % SETUP PULSE ANALYSIS HERE
          passed_pulse_test = 0; 

          epsilon_pulse_nucleus = .15;
          if pulse_dummy > epsilon_pulse_nucleus 
           passed_pulse_test = 1;
          end;
          
              
          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
          
         %RATIO OF NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;
          signal_dummy =  (sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig)
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)
         
          shift_rise = 4;
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));
          
         
          epsilon_pulse_ratio = .08;
          if pulse_dummy > epsilon_pulse_ratio 
           passed_pulse_test = 1;
          end;
          % SETUP PULSE ANALYSIS HERE

          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
        else
           passed_pulse_test = 1;
        end;
          
          if (passed_pulse_test == 1)
              %if (ii == 1)  %passed the first pulse only
              %sig_dummy_nuclear_average = sig_dummy_nuclear_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))/double(min(nuclear_Erk_tot_time_mapped_t0_median(idx,:)));
              %sig_dummy_ratio_average = sig_dummy_ratio_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));       
              %ratio_signal(idx,:) = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));  
              %end;
          end;
          
     end;     
    
   
end; % for idx = 1:num_nuclei_t0


which_frame = length(eval(['time_CH',num2str(ii_NM)]));
               rect_width = 10;
figure(112)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    
    
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
         
          y_coord_min = y_coord_min_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          y_coord_max = y_coord_max_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          x_coord_min = x_coord_min_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          x_coord_max = x_coord_max_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          %y_coord_min = y_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
          %y_coord_max = y_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
          %x_coord_min = x_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
          %x_coord_max = x_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
         
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
               
                    delta_y = y_coord_max-y_coord_min+1
                    delta_x = x_coord_max-x_coord_min+1
               if (ii_NM == ii_NM_bPAC)  % all bPAC cells
               set(tt,'Color','m');
                if (bPAC_pulse_cell(jjj,1)==1)
                    rectangle('Position', [y_coord_min,x_coord_min,...
                               delta_y,delta_x],...
                              'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                   
                if (num_bPAC_pulses==2)
                if (bPAC_pulse_cell(jjj,2)==1)
                    rectangle('Position', [y_coord_min-delta_y/4,x_coord_min-delta_x/4,...
                               1.5*delta_y,1.5*delta_x],...
                              'LineWidth', 2,'LineStyle','-', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                end;
                
               elseif (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
                if (bPAC_pulse_cell(jjj,1)==1)
                    rectangle('Position', [y_coord_min,x_coord_min,...
                               delta_y,delta_x],...
                              'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                if (num_bPAC_pulses==2)
                if (bPAC_pulse_cell(jjj,2)==1)
                    rectangle('Position', [y_coord_min-delta_y/4,x_coord_min-delta_x/4,...
                               1.5*delta_y,1.5*delta_x],...
                              'LineWidth', 2,'LineStyle','-', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                end;

               else
               set(tt,'Color','y');
                if (bPAC_pulse_cell(jjj,1)==1)
                    rectangle('Position', [y_coord_min,x_coord_min,...
                               delta_y,delta_x],...
                              'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                              'EdgeColor', 'y');
                end;
                if (num_bPAC_pulses==2)
                if (bPAC_pulse_cell(jjj,2)==1)
                    rectangle('Position', [y_coord_min-delta_y/4,x_coord_min-delta_x/4,...
                               1.5*delta_y,1.5*delta_x],...
                              'LineWidth', 2,'LineStyle','-', 'LineWidth', 2,...
                              'EdgeColor', 'y');
                end;
                end;
                
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
                 
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:index_bPAC_pulse_start_Erk(1)),mean_x_tot_time_mapped_t0(idx,1:index_bPAC_pulse_start_Erk(1)));
             %  set(ll,'Color','w');
             %ll = line(mean_y_tot_time_mapped_t0(idx,index_bPAC_pulse_start_Erk(1):which_frame),mean_x_tot_time_mapped_t0(idx,index_bPAC_pulse_start_Erk(1):which_frame));
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (ii_NM == ii_NM_bPAC)
               set(ll,'Color','m');
               elseif (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               %set(ll,'Color','w');
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
           % rectangle('Position', [y_coord_min,x_coord_min,...
           %            y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
           %           'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
           %           'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'),'interpreter','none');   
     if (num_bPAC_pulses == 1)
xlabel('dashed box - bPAC pulse respone')
elseif (num_bPAC_pulses == 2)
xlabel('dashed box - bPAC pulse 1 respone, solid box - bPAC pulse 2 respone', 'interpreter','none')
end;


     
do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)
 % save the figures to a powerpoint slide

 

  fig111 = figure(112)
  figure(1111)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
   s_combine = 'pulsing cells induced (in)directly by bPAC';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   delete('bPAC_pulsing_cells.ppt')
   saveppt2(strcat('bPAC_pulsing_cells.ppt'),'figure',[fig111 fig1111 fig111 fig1111], 'halign','center','title', s_combine);

    done_cells_tracked_ppt = 1;  % have made the ppt file
    
end; % if (do_PPT ==1)
     
     






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plots of cells and their signals about a given bPAC cell
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                 
if (ii_NM==ii_NM_bPAC) % only bPAC cells
bPAC_NUCLEUS_time_mapped_t0 = ones(num_nuclei_t0,length(eval(['time_CH',num2str(ii_NM)])));
end;
bPAC_NUCLEUS_time_mapped_t0_dummy = bPAC_NUCLEUS_time_mapped_t0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MIKE: TRANSFER FUNCTION CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine usable cells for calculation of transfer function
for iii = 1:num_nuclei_t0
    if (bPAC_pulse_cell(iii,num_bPAC_pulses) == 1)&(bPAC_pulse_cell(iii,num_bPAC_pulses-1) == 1)    
       bPAC_pulse_cell_tf(iii)=1;
          idx = iii;
          sig_dummy_nuclear_average = sig_dummy_nuclear_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))/double(min(nuclear_Erk_tot_time_mapped_t0_median(idx,:)));
          sig_dummy_ratio_average = sig_dummy_ratio_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));       
          ratio_signal(idx,:) = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));  
    end;
end;

bPAC_pulse_cell_tf_dummy = bPAC_pulse_cell_tf

num_cells_surround_max = min(9,sum(bPAC_pulse_cell_tf));

  
for jjj = 1:num_nuclei_t0
which_nucleus = jjj;

if (jjj == 1)
delete(str_just_nuclear)
end;

if (bPAC_NUCLEUS_time_mapped_t0_dummy(which_nucleus,1) == 1)&(bPAC_pulse_cell_tf(which_nucleus)==1)

width_surround = 10;

num_cells_surround = 0;

%while (num_cells_surround <= num_cells_surround_max)&((num_cells_surround ~= sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))|(which_movie == 43))
while (num_cells_surround <= num_cells_surround_max)&(((num_cells_surround+1<sum(bPAC_pulse_cell_tf_dummy))&(ii_NM_bPAC==ii_NM))|(ii_NM_bPAC~=ii_NM))%&((num_cells_surround ~= sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))|(which_movie == 43))

width_surround = width_surround + 1;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
    
    
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MIKE: TRANSFER FUNCTION CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if (bPAC_pulse_cell_tf_dummy(iii)==1)    
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
      bPAC_pulse_cell_tf_dummy(iii) = 0;
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
      bPAC_pulse_cell_tf_dummy(iii) = 0;
     end;
    end;
    end;
end;

num_cells_surround = ii_count;

end; % while (num_cells_surround < num_cells_surround_max)

if (num_cells_surround > num_cells_surround_max) 
width_surround = width_surround - 1;
end;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MIKE: TRANSFER FUNCTION CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    if  (bPAC_pulse_cell_tf(iii)==1)
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
      bPAC_NUCLEUS_time_mapped_t0_dummy(iii,:) = 0;      
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     end;
    end;
    end;
end;


which_frame = length(eval(['time_CH',num2str(ii_NM)]));
figure(110)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    
     if (do_plot_nuclei_number == 1)
     for idx = 1: num_nuclei_t0
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','w');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','w');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));         

num_max_plots = 3;     
ii_plot_count = 0;
ii_figure_count = 1;     
for iii = 1:length(index_group)
    idx = index_group(iii);
    
    if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
        str_bPAC = ' (bPAC)';
    else
        str_bPAC = ' (non-bPAC)';
    end;
        
     figure(200+ii_figure_count)
    subplot(num_max_plots+1,2,2*ii_plot_count+1)
    
    if (do_just_nuclear_signal == 1)

        % NO LONGER EVALUATING THIS SIGNAL
        
    elseif (do_just_nuclear_signal == 0)
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;

       for jj_tf = 1:max_tf_time_points
           tf_time_shift_dummy = tf_time_shift_array(jj_tf); 
           index_dummy = index_bPAC_pulse_stop_Erk(1)+tf_time_shift_dummy;
           hold on;
           plot(time_Erk(index_dummy)/scale_factor_time,sig_dummy(index_dummy),strcat(str_tf(jj_tf),'h'));
           hold off;
       end;
     
     
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
      
      if (num_bPAC_pulses == 1)
      text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      elseif (num_bPAC_pulses == 2)
      text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      end;
      
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
     
     
      if (ii_plot_count+1 == 1)
        title(strcat('(nuclear Erk signal)/(cytosolic Erk signal) (',Erk_str,')'));       
      end;
     

      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MIKE: TRANSFER FUNCTION CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
%   Calculate and plot time-dependent transfer function here
         subplot(num_max_plots+1,2,2*ii_plot_count+2)
          if (ii_plot_count == 0)
          title(str_movie);
          end;
         bPAC_pulse_width = index_bPAC_pulse_stop - index_bPAC_pulse_start+1
         bPAC_pulse_amplitude_tf = bPAC_ledvals(index_bPAC_pulse_stop);
         bPAC_pulse_amplitude_tf = [0 bPAC_pulse_amplitude_tf];
                  
                  
       %%%for ii_tf  = 1:num_bPAC_pulses   
           for jj_tf = 1:max_tf_time_points
                
              tf_time_shift_dummy = tf_time_shift_array(jj_tf); 
              index_dummy = index_bPAC_pulse_stop_Erk(:)+tf_time_shift_dummy;

                               
               Erk_tf = sig_dummy(index_dummy)-sig_dummy(index_bPAC_pulse_start_Erk(:));
               Erk_tf = [0 Erk_tf];
               Erk_tf_average(:,jj_tf) = Erk_tf_average(:,jj_tf) + Erk_tf(:);
               hold on;
               plot(bPAC_pulse_amplitude_tf,Erk_tf,str_tf(jj_tf));
               hold off;
               ylim([0 1.5*max(Erk_tf)+1e-6]);
               xlim([0 max(bPAC_ledvals)]);
               
           end;
       %%%end;
     
    end;  %     if (do_just_nuclear_signal == 1)

    
    

     ii_plot_count = ii_plot_count+1;

        if (iii == length(index_group))
          subplot(num_max_plots+1,2,2*(num_max_plots+1)-1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          title(strcat('bPAC pulse width:', num2str(bPAC_pulse_width(1)*(time_bPAC(2)-time_bPAC(1))/60),' m'));
          xlabel(str_time_representation);
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,2,2*(num_max_plots+1)-1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          title(strcat('bPAC pulse width:', num2str(bPAC_pulse_width(1)*(time_bPAC(2)-time_bPAC(1))/60),' m'));
          ii_figure_count = ii_figure_count+1;
          ii_plot_count = 0;
        end;

end; % for iii = 1:length(index_map)
     
do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)
 % save the figures to a powerpoint slide

 ii_count_fig = 0;
while(ii_count_fig <=  ii_figure_count)
 
  fig110 = figure(110)
   %print('-depsc',strcat(str_movie_processed_figures,'\',str_just_nuclear_eps,'\map-',str_movie,'.eps'));
   set(gcf,'inverthardcopy','off')   
   print('-depsc',strcat('map-',str_movie,'.eps'));
  fig201 = figure(201+ii_count_fig)
   %print('-depsc',strcat(str_movie_processed_figures,'\',str_just_nuclear_eps,'\nuc_',num2str(idx),'_a-',str_movie,'.eps'));
   print('-depsc',strcat('nuc_',num2str(which_nucleus),'_a',num2str(ii_count_fig),'-',str_movie,'.eps'));
  fig202 = figure(202+ii_count_fig)
   print('-depsc',strcat('nuc_',num2str(which_nucleus),'_b',num2str(ii_count_fig),'-',str_movie,'.eps'));
  fig203 = figure(203+ii_count_fig)
   print('-depsc',strcat('nuc_',num2str(which_nucleus),'_c',num2str(ii_count_fig),'-',str_movie,'.eps'));
   s_combine = 'cells surround a given bPAC cell';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   
   saveppt2(strcat('transfer_function_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig201 fig202 fig203], 'halign','center','title', s_combine);
   %pause;
   close(fig201);
   close(fig202);
   close(fig203);
   
   ii_count_fig = ii_count_fig+3;
end; % end of 'while(ii_count_fig <=  ii_figure_count)'
   
    
end; % if (do_PPT ==1)
     

%pause
          
end; %  if (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) == 1) 

    
    

    
end; %  for iii = 1:num_nuclei_t0





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  MIKE: TRANSFER FUNCTION CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sig_dummy_nuclear_average = sig_dummy_nuclear_average/sum(bPAC_pulse_cell_tf);
sig_dummy_ratio_average = sig_dummy_ratio_average/sum(bPAC_pulse_cell_tf);
Erk_tf_average = Erk_tf_average/sum(bPAC_pulse_cell_tf);



Erk_tf_average = Erk_tf_average

figure(333)
subplot(3,2,1)
ss = plot(time_Erk/scale_factor_time,sig_dummy_nuclear_average)
set(ss,'LineWidth',2);
     title(strcat('average signal of responsive cells,number of cells:',num2str(sum(bPAC_pulse_cell_tf))));
     ylim([.9*min(sig_dummy_nuclear_average) 1.1*max(sig_dummy_nuclear_average)]);
     xlim([0 max(time_Erk)/scale_factor_time]);
     ylabel(strcat('nuc/min(nuc)'));
subplot(3,2,3)
ss = plot(time_Erk/scale_factor_time,sig_dummy_ratio_average)
set(ss,'LineWidth',2);
     ylim([.9*min(sig_dummy_ratio_average) 1.1*max(sig_dummy_ratio_average)]);
       for jj_tf = 1:max_tf_time_points
              tf_time_shift_dummy = tf_time_shift_array(jj_tf); 
              index_dummy = index_bPAC_pulse_stop_Erk(1)+tf_time_shift_dummy;
           
           hold on;
           plot(time_Erk(index_dummy)/scale_factor_time,sig_dummy_ratio_average(index_dummy),strcat(str_tf(jj_tf),'h'));
           hold off;
       end;
     xlim([0 max(time_Erk)/scale_factor_time]);
     ylabel(strcat('nuc/cyto'));
     subplot(3,2,5)
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          title(strcat('bPAC pulse width:', num2str(bPAC_pulse_width(1)*(time_bPAC(2)-time_bPAC(1))/60),' m'));
          ylabel('bPAC');
     xlabel('time (minutes)');
     
          subplot(3,2,4)
           for jj_tf = 1:max_tf_time_points               
               hold on;
               plot(bPAC_pulse_amplitude_tf,Erk_tf_average(:,jj_tf),str_tf(jj_tf));
               hold off;
           end;
               ylim([0 1.5*max(max(Erk_tf_average))]);
               title(str_movie);
               xlabel('bPAC');
               ylabel('Erk (nuc/cyto)');
               xlim([0 max(bPAC_ledvals)]);
fig333 = figure(333);
   print('-depsc',strcat('average_signals-',str_movie,'.eps'));



figure(334)
imagesc(ratio_signal);
fig334 = figure(334)
title('reponse of all pulsing cells');
xlabel('frames');
ylabel('nucleus');

   %print('-depsc',strcat(str_movie_processed_figures,'\average_signals_and_all\heat_map-',str_movie,'.eps'));
   print('-depsc',strcat('heat_map-',str_movie,'.eps'));

   saveppt2(strcat('average_signals_transfer_function-',str_movie,'.ppt'),'figure',[fig333 fig334], 'halign','center','title', s_combine);
 
cd(str_processing);
   
end;   % if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)
   


