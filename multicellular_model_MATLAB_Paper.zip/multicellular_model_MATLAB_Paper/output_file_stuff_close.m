
if (do_mean_or_full==1)
% Output file stuff
fclose(fids_state_data);
fclose(fids_restricted_data);
fclose(fids_time_data);
fclose(fids_propensities_partition_data);
fclose(fids_stochasticity_partition_data);
fclose(fids_moment_error_data);
fclose(fids_run_data);
fclose(fids_data_sampled);
end;
