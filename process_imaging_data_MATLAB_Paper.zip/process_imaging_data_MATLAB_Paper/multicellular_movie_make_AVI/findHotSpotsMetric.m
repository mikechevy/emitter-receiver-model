function [hot_spot_groups,size_hot_spot_groups] = findHotSpotsMetric(r_event,numEvents,length_max,which_metric)


global ii_physical_distance;
global ii_xcorr;
global length_per_pixel;
global seconds_per_frame;
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%  Begin: Cluster events
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

matrix_hot_spot = zeros(numEvents,numEvents);
hot_spot_groups = zeros(numEvents,numEvents);


if (which_metric == ii_physical_distance) 
   z = length_per_pixel*pdist(r_event); % micrometers
elseif (which_metric == ii_xcorr)
    
    
    max_delay = round(150/seconds_per_frame);  % number of frames (currently based 30 seconds)
    %max_delay = round(60/seconds_per_frame);  % number of frames (currently based 30 seconds)
    
    do_threshold_bursting = 1; % 0 - normalized xcorr, 1 - threshold bursting
    
     count_z = 0;
       for jj = 1:numEvents-1
        for kk = jj+1:numEvents % N*(N-1)/2, where N = numEvents
         %plot(xcorr_test)
         %pause
        if (do_threshold_bursting == 1)    
            xcorr_test = xcorr(r_event(jj,:),r_event(kk,:));  
            [val_max, index_max] = max(xcorr_test);
            xcorr_test(index_max) = 0;
            [val_max_next, index_max_next] = max(xcorr_test);
            distance_xcorr = abs(val_max_next/val_max);
        else
            xcorr_test = xcorr(r_event(jj,:)-mean(r_event(jj,:)),r_event(kk,:)-mean(r_event(kk,:)));  
            [val_max, index_max] = max(xcorr_test);
           distance_xcorr = 1-abs(val_max/(sqrt(r_event(jj,:)*r_event(jj,:)')*sqrt(r_event(kk,:)*r_event(kk,:)')));
        end;
          if abs(index_max - round(length(xcorr_test+1)/2)) <= max_delay  
             z(count_z+1) = distance_xcorr;
          else
             z(count_z+1) = 2*length_max;
          end;
         count_z = count_z+1;
        end;
       end;
    
       max(z)
       
end;


count_z = 0;
count_groups = 0;

%  Clustering loop
for jj = 1:numEvents-1
for kk = jj+1:numEvents % N*(N-1)/2, where N = numEvents
   
    if (z(count_z+1) <= length_max)  % length_max is a passed argument
        matrix_hot_spot(jj,kk) = 1;
        matrix_hot_spot(kk,jj) = 1;   
    end;
count_z = count_z+1;    
end;
end;

matrix_hot_spot_test = matrix_hot_spot;
nnz_matrix = zeros(numEvents,1);
nnz_matrix_next = nnz_matrix;



for jj = 1:numEvents

    indexGroup = find(matrix_hot_spot_test(jj,:)>0);
    
  if (length(indexGroup) > 0)  % determine the whole cluster

    nnz_matrix(jj) = 1;
      
    while (sum(abs(nnz_matrix_next-nnz_matrix))~=0)        

      indexGroup_nnz = find(nnz_matrix>0); 
%      indexGroup_nnz_next = find(nnz_matrix>0); 
        
      for kk = 1:length(indexGroup_nnz)
         row = indexGroup_nnz(kk);
        %if (nnz_matrix(row)~=1)&(nnz_matrix_next(row)~=1)
        if (nnz_matrix(row)~=nnz_matrix_next(row))
          indexGroup = find(matrix_hot_spot_test(row,:)>0);
         if length(indexGroup>0)
          for mm=1:length(indexGroup)
           nnz_matrix(indexGroup(mm)) = 1;
          end;
         end;
        nnz_matrix_next(row) = 1;
        end;
      end;
                
    end;
    
          indexGroup_nnz = find(nnz_matrix>0);
          hot_spot_groups(count_groups+1,1:length(indexGroup_nnz)) = indexGroup_nnz;
          size_hot_spot_groups(count_groups+1) = length(indexGroup_nnz);
          count_groups = count_groups+1;
          for kk = 1:length(indexGroup_nnz)
            matrix_hot_spot_test(indexGroup_nnz(kk),:) = 0; % remove clustered events
          end;
          
          %indexGroup_nnz
        %pause;
          nnz_matrix = 0*nnz_matrix;
          nnz_matrix_next = 0*nnz_matrix_next;
  end;
    
end;

if (count_groups>0)
  hot_spot_groups = hot_spot_groups(1:count_groups,1:max(size_hot_spot_groups(1:count_groups)));
  size_hot_spot_groups = size_hot_spot_groups(1:count_groups);
  %hot_spot_groups
  %count_groups
  %pause
else
    hot_spot_groups = [];
    size_hot_spot_groups = [];
end;

