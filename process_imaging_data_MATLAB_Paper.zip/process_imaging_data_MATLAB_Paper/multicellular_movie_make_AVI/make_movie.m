do_make_movie = 1;  % 1 - yes, 0 - no

scale_factor_time = 60;  % minutes

channel_make_movie = ii_CH1;
%channel_make_movie = ii_NM;
%channel_make_movie = ii_NM_bPAC;


time_Erk = time_CH1

          if (do_make_movie == 1)
            if (channel_make_movie == ii_CH1)
              filename_movie = strcat(str_movie_processed,'\CH1_movie_',str_movie);
            elseif (channel_make_movie == ii_NM)
              filename_movie = strcat(str_movie_processed,'\NM_movie_',str_movie);
            elseif  (channel_make_movie == ii_NM_bPAC)
              filename_movie = strcat(str_movie_processed,'\NM_bPAC_movie_',str_movie);
            end;
          delete(strcat(filename_movie,'.avi'));
          mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',floor(numFr_CH(ii_CH1)/20));
          end;
          
          
  

if (length(ii_NM_bPAC) == 1)
 which_channels = [ii_CH1 ii_NM ii_NM_bPAC];
else
 which_channels = [ii_CH1 ii_NM];
end;
frame_direction = 1;  % start in the up direction

for ii = 1:numFr_CH(ii_CH1)

which_frame = ii;



    eval(['[val,which_frame_NM]= min(abs(time_CH',num2str(1),'(which_frame)-time_CH',num2str(ii_NM),'));']);     

for kk = 1:length(which_channels)
    
    which_channel = which_channels(kk);

    ii_figure = 1000+which_channel
    if (which_channel == channel_make_movie)
      H = figure(1000+which_channel)  
    else
      figure(1000+which_channel)  
    end;

M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(:,:,:)']))))*int16(ones(xLength,yLength));
fac_max = 1;

  
    which_frame
    numFr_CH(which_channel)

    eval(['[val,which_frame_CH]= min(abs(time_CH',num2str(1),'(which_frame)-time_CH',num2str(which_channel),'));']);     
    

    %if (length(which_channels) == 2)|(ii_NM == ii_NM_bPAC)
      subplot(5,2,[1:8]);      
      %subplot(4,2,[1:6]);
    %elseif (length(which_channels) == 3)
    %  subplot(2,2,kk);
    %end;
      
        
  %imagesc(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame),fac_max*M_max)']));
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
  
  
  if (marker_from_channel(ii_Erk_marker)>0)&(ii == 1)
      title(strcat('Erk signal',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
  elseif (marker_from_channel(ii_Ca_marker)>0)&(ii == 1)
      title(strcat('Erk signal',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
  elseif (ii == 2)
      title(strcat('Nuclear marker',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
  elseif (ii_NM~=ii_NM_bPAC)&(ii == 3)
      title(strcat('bPAC marker',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
  end;
      
  
  
      subplot(5,2,[9 10]);
      %subplot(4,2,[7 8]);
      ylabel('bPAC');
      hold on;
      plot(time_bPAC/scale_factor_time,bPAC_ledvals);
      plot([time_CH1(which_frame)/scale_factor_time time_CH1(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
      hold off;
      
      xlim([0 max(time_CH1)/scale_factor_time]);
      ylim([0 1.1*max(bPAC_ledvals)]);
      xlabel('minutes');

    if (do_make_movie == 1)&(which_channel == channel_make_movie)
    %H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
    end;
  
    close(ii_figure)
   
end;



  
end;

             mov = close(mov)
