%  load in acqdat.txt file


path_movie = strcat('..\multicellular_movies\',str_movie)

found_file_microscope = fileattrib(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'))

if (found_file_microscope == 1)  % movie has input_info.mat file
    
  load(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'));
  
end;  
    


  

    numFr_CH = zeros(numCh,1);
    
    for jj = 1:numCh
       eval(['image_index_CH',num2str(jj),'=[];']); 
     for kk = 1:length(bPAC_ledvals)
      if(kk<10)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_00000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk<=99)&(kk>9)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_0000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk>99)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      end;  
      
          
      if(kk+shift_file<10)
       path_image_shift = strcat('..\multicellular_movies\',str_movie,'\img_00000000',num2str(kk+shift_file),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk+shift_file<=99)&(kk+shift_file>9)
       path_image_shift = strcat('..\multicellular_movies\',str_movie,'\img_0000000',num2str(kk+shift_file),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk+shift_file>99)
       path_image_shift = strcat('..\multicellular_movies\',str_movie,'\img_000000',num2str(kk+shift_file),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      end;  
         
          
      path_image
      found_file_image = fileattrib(path_image);
      if (found_file_image == 1)
       copyfile(path_image,path_image_shift);
      end;
     end;
    end;   
