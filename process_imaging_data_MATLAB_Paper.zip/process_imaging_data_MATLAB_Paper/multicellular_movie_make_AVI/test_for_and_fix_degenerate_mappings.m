


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIRST: determine the number of nuclei that are uniquely mapped throughout the whole 
% movie.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

test_for_convergence_events   

used_nuclei_track_time = used_nuclei_track_time_dummy;
used_nuclei_track_time_INITIAL = used_nuclei_track_time_dummy;
convergence_event_INITIAL = convergence_event



do_substitution_nuclei_time =1;
if (do_substitution_nuclei_time == 1)&(length(convergence_event)>0)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SECOND: of the nuclei that converged into one at any given time,
% determine those which can be uniquely determined by using all of the
% frames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    min_dist_time = zeros(length(convergence_event(:,1)),numFr_NM);
    index_min_dist_time = zeros(length(convergence_event(:,1)),numFr_NM);
    index_ref_min_dist_time = zeros(length(convergence_event(:,1)),numFr_NM);
    frame_ref_min_dist_time = zeros(length(convergence_event(:,1)),numFr_NM);


    
    
    
for iii = 1:length(convergence_event(:,1))   
    mean_x_tot_mN = mean_x_tot_time(1:num_nuclei_time(1),1);
    mean_y_tot_mN = mean_y_tot_time(1:num_nuclei_time(1),1);    
    index_dummy =  convergence_event(iii,1);   
    index_ref_min_dist_time(iii,1:2) = index_dummy;    
    frame_ref_min_dist_time(iii,1:2) = 1;
  for kkk = 2:numFr_NM
    which_frame = kkk;
    mean_x_tot = mean_x_tot_time(1:num_nuclei_time(which_frame),which_frame);
    mean_y_tot = mean_y_tot_time(1:num_nuclei_time(which_frame),which_frame);
     [val_min,index_min] =  sort(sqrt(power(mean_x_tot_mN(index_dummy)-mean_x_tot,2) + power(mean_y_tot_mN(index_dummy)-mean_y_tot,2)));     
      min_dist_time(iii,which_frame) = val_min(1);
      index_min_dist_time(iii,which_frame) = index_min(1);
      
      if (val_min(1) < delta_move_threshold)          
        mean_x_tot_mN = mean_x_tot_time(1:num_nuclei_time(which_frame),which_frame);
        mean_y_tot_mN = mean_y_tot_time(1:num_nuclei_time(which_frame),which_frame);
        index_dummy = index_min(1);
       frame_ref_min_dist_time(iii,which_frame+1) = which_frame;
       index_ref_min_dist_time(iii,which_frame+1) = index_min(1);
      else
       frame_ref_min_dist_time(iii,which_frame+1) = frame_ref_min_dist_time(iii,which_frame);
       index_ref_min_dist_time(iii,which_frame+1) = index_ref_min_dist_time(iii,which_frame) ;
      end;
  end;  
end;    



num_nuclei_time_original = num_nuclei_time;

% place the nuclei into the stucts and relevant information in other arrays
for kkk = 2:numFr_NM
  which_frame = kkk;
      for idx = 1:length(index_ref_min_dist_time(:,1))
          which_frame_CELL = frame_ref_min_dist_time(idx,which_frame);
          idx_map = index_ref_min_dist_time(idx,which_frame);
       
          used_nuclei_track_time(idx_map,which_frame_CELL) = 1;  % make sure it is checked as used
          
          index_dummy = index_ref_min_dist_time(idx,1);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
       %  update all arrays
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%          
       %eval(['Cell_nucleus_FILL_',num2str(which_frame)])
       eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList = [Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList Cell_nucleus_FILL_',num2str(which_frame_CELL),'.PixelIdxList{idx_map}];']);
       eval(['Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects = Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects+1;']);   
       %eval(['Cell_nucleus_FILL_',num2str(which_frame)])
       mean_x_tot_time_mapped_t0(index_dummy,which_frame) = mean_x_tot_time(idx_map,which_frame_CELL);       
       mean_y_tot_time_mapped_t0(index_dummy,which_frame) = mean_y_tot_time(idx_map,which_frame_CELL);       
       num_pixels_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = num_pixels_tot_NUCLEUS_time(idx_map,which_frame_CELL);
       index_map_tot_time_mapped_t0(index_dummy,which_frame) = eval(['Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects']);
       dist_map_tot_time_mapped_t0(index_dummy,which_frame) = min_dist_time(idx,which_frame_CELL);
        x_coord_min_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = x_coord_min_tot_time(idx_map,which_frame_CELL);
        x_coord_max_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = x_coord_max_tot_time(idx_map,which_frame_CELL);
        y_coord_min_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = y_coord_min_tot_time(idx_map,which_frame_CELL);
        y_coord_max_tot_NUCLEUS_time_mapped_t0(index_dummy,which_frame) = y_coord_max_tot_time(idx_map,which_frame_CELL);
       
      end;
end;  % END OF: for kkk = 1:numFr_NM

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% here we need to make sure that the newly placed nuclei don't overlap the nuclei it converged with
% if so, we go to the closes frame where both nuclei are separated and
% substitute that in.
%
%  NOTE: eventually we might just rethreshold these nuclie in the current
%  image rather than substituting.  However,  as long as the nuclei are
%  BARELY moving, it doesn't matter.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    M_marker_threshold = int16(zeros(xLength,yLength));
    
for idx = 2:length(convergence_event(:,1))
 if convergence_event(idx-1,2) == convergence_event(idx,2)  %  
  for kkk = 2:numFr_NM
   for ggg = 1:2
   which_frame = kkk;
   M_marker_threshold = 0*M_marker_threshold;
   index_dummy = convergence_event(idx-1+ggg-1,1);      
   [val_min,index_min] =  sort(sqrt( power(mean_x_tot_time_mapped_t0(index_dummy,which_frame)- mean_x_tot_time_mapped_t0(1:num_nuclei_t0,which_frame),2) + power(mean_y_tot_time_mapped_t0(index_dummy,which_frame)-mean_y_tot_time_mapped_t0(1:num_nuclei_t0,which_frame),2)));     
   index_neighbor_test(1) = index_dummy;
   index_neighbor_test(2) = index_min(2);
   index_neighbor_test(3) = index_min(3);
     for ppp = 1:3  
     index_dummy = index_neighbor_test(ppp);
     idx_map_dummy = index_map_tot_time_mapped_t0(index_dummy,which_frame);
      M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map_dummy}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map_dummy}'])) + 1;
     end;    
    if (max(max(M_marker_threshold)) == 2)  % overlap  
        % substitute in the prior     
     for ppp = 1:3            
      index_dummy = index_neighbor_test(ppp);
       idx_map = index_map_tot_time_mapped_t0(index_dummy,which_frame);
        idx_map_m1 = index_map_tot_time_mapped_t0(index_dummy,which_frame-1);
      eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_nucleus_FILL_',num2str(which_frame-1),'.PixelIdxList{idx_map_m1}']);
     end;
    end;    
        
        
  end;  % END OF: for ggg = 1:2
 end;  % END OF: for kkk = 1:numFr_NM
 
 end;
end; 
 
end;  % END OF: if (do_substitution_nuclei_time == 1)



test_for_convergence_events   
