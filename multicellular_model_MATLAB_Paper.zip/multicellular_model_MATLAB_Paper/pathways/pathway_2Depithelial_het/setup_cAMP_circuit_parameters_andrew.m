%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%  Andrew's Python Code, uncommented variables are used in setup_gillespie_pathway_multicellular.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

% Input
%
%tt1 = arange(0,10,1e-2)
%tt2 = arange(10,15,1e-2)
%tt3 = arange(15,20,1e-2)
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN:  put in 06/24/20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
scale_time_rates = 5/(40*60);  % scales a 5 second time window to a 40 minute time window

if (do_transfer_function_pulse == 0)
%pulse_start_effective = 10;
shift_zero_value = 20;
pulse_start_effective = shift_zero_value + 5;
pulse_width_effective = 5;
time_to_off_effective = 5;
elseif (do_transfer_function_pulse == 1)   
%pulse_start_effective = 5 + 5*15/40;
shift_zero_value = 15 +2 + (do_IBMX*.3);
pulse_start_effective = shift_zero_value + 5*15/40;
pulse_width_effective = 5*6/40;
time_to_off_effective = 5;
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  binary factors (0 or 1), turns on or off various inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fac_I_bPAC = 1;  % 0-no, 1-yes
fac_I_cAMP_gap = do_GJ_inhibition;  % 0-no, 1-yes (inihbition)
fac_I_Calcium_gap = 0;  % 0-no, 1-yes
fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
fac_I_H89 = do_H89;  % 0-no, 1-yes


      % if do_CX43_NGFP == 1    % broken gap-junctions, weaker fluxe
      %   fac_I_cAMP_gap = 1;  % 0-no, 1-yes
      % end;



if (do_ALL_bPAC == 1)
bPAC_NUCLEUS_time_mapped_t0(:,:) = 1;
end;

     amp_bPAC = bPAC_amplitude; %  0 <= amp_bPAC <= 1




%  Some of Andrews original values
beta_c_b_andrew = 10*scale_time_rates; %#nmol/min/mg Rate of production of cAMP from bPAC
beta_c_ac_andrew = 1*scale_time_rates; %#Rate of production of cAMP from native AC
gamma_c_pd_andrew = 0*3*scale_time_rates; %#Rate of basal cAMP degradation
gamma_c_pd_basal_andrew = 1*scale_time_rates; %#Rate of basal cAMP degradation through PDE
gamma_c_basal_andrew = 0.2*scale_time_rates; %#Rate of basal cAMP degradation through non-PDE means

num_cAMP_0 = (beta_c_b_andrew+beta_c_ac_andrew)/gamma_c_pd_basal_andrew;
num_Calcium_0 = 1;
num_PKA_0 = 1;
num_PDE_0 = 1;
num_ERK_0 = 1;
num_ERKKTR_0 = 1;
num_GJ_complex_0 = 1;


 do_andrew_parameters = 0; % 1-andrews parameters, 0-user defined
if (do_andrew_parameters==1)
    num_PKA = 1;
    num_PDE = 1;
    num_cAMP = num_cAMP_0;    
    num_ERK= 1;
    num_ERKKTR = 1;
else
    num_PKA = 10;%100;
    num_PDE = 1;%100;
    num_cAMP = 100;% num_cAMP_0;
    num_ERK= 10;
    num_ERKKTR = 10;
    %%num_GJ_complex = num_PKA;  % before 06/21/19
    %num_GJ_complex = num_GJ_complex_tot;
    %num_Calcium = 1;
end;    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END:  put in 06/24/20
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

factAC = 1; %#Turns on feedback from PKA to AC
fact_PP = 1; %#turns on feedback from PDE to PKA
fact_Pc = 1; %#turns on feedback from PDE to cAMP

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  binary factors (0 or 1), turns on or off various regulatory connections
%  between pathway elements
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fac_ac_pk = do_PKA_reg_AC; %#Turns on feedback from PKA to AC
fac_c_pd = fact_Pc; %#turns on feedback from PDE to cAMP
fac_pk_pd = fact_PP; %#turns on feedback from PDE to PKA
fac_gj_pk = do_PKA_reg_GJ; %#  1 - pka regulated gap junctions (our model), 0 - constant gap junction activity


do_TEST = 1; % 0 - do original, 1 - do test parameters

if (do_TEST ==0)
    
  %fac_Kb = 1;  % multiplication factor on Kb, %#nmol/min/mg Rate of production of cAMP from bPAC
  %fac_ACmax = 1;  % multiplication factor on ACmax,%#Rate of production of cAMP from native AC 
  %fac_KD_cAMP = 1.0;  % multiplication factor on KD_cAMP, %#Half-max constant for rate of cAMP production
  %fac_Ka1 = 1; % multiplicative factor on Ka1 %#Rate of PKA activation by cAMP
  %fac_Kdeg_PP = 3.0; % multiplicative factor on Kdeg_PP, %#Rate of deactivation of PKA by PDE
  %fac_KD_PP = 5; % multiplicative factor on KD_PP, %#Half-max constant for deactivation of PKA by PDE
  %fac_Kdeg_Pc = 3.0; % multiplicative factor on Kdeg_Pc, %#Rate of degradation of cAMP by PDE
  %fac_KD_Pc = 1.0;   % multiplicative factor on KD_Pcm, %#Half-max constant for PDE degradation activity of cAMP
  %fac_Kdeg_c = 1.0;  % multiplicative factor on Kdeg_c, %#Rate of basal cAMP degradation
  %fac_Kdiff_cAMP = 1.0; % multiplicative factor of Kdiff_cAMP, %#Rate of diffusion of cAMP through gap junctions

   fac_Kb = 1;  % multiplication factor on Kb, %#nmol/min/mg Rate of production of cAMP from bPAC
   fac_ACmax = 1;  % multiplication factor on ACmax,%#Rate of production of cAMP from native AC 
   fac_KD_cAMP = 1.0;  % multiplication factor on KD_cAMP, %#Half-max constant for rate of cAMP production
   fac_Ka1 = 1; % multiplicative factor on Ka1 %#Rate of PKA activation by cAMP
   fac_Kdeg_PP = 3.0; % multiplicative factor on Kdeg_PP, %#Rate of deactivation of PKA by PDE
   fac_KD_PP = 5; % multiplicative factor on KD_PP, %#Half-max constant for deactivation of PKA by PDE
   fac_Kdeg_Pc = 3.0; % multiplicative factor on Kdeg_Pc, %#Rate of degradation of cAMP by PDE
   fac_KD_Pc = 1.0;   % multiplicative factor on KD_Pcm, %#Half-max constant for PDE degradation activity of cAMP
   fac_Kdeg_c = 1.0;  % multiplicative factor on Kdeg_c %#Rate of basal cAMP degradation
   fac_Kdiff_cAMP = 1.0; % multiplicative factor of Kdiff_cAMP, %#Rate of diffusion of cAMP through gap junctions


elseif (do_TEST == 1)

 fac_Kb = 20;  % multiplicative factor on Kb, %#nmol/min/mg Rate of production of cAMP from bPAC
 fac_ACmax = 1;  % multiplicative factor on ACmax,%#Rate of production of cAMP from native AC
 fac_KD_cAMP = fac_Kb*1.0;  % multiplication factor on KD_cAMP, %#Half-max constant for rate of cAMP production
 fac_Ka1 = 1/power(fac_Kb,4); % multiplicative factor on Ka1 %#Rate of PKA activation by cAMP
 fac_Kdeg_PP = 3.0; % multiplicative factor on Kdeg_PP, %#Rate of deactivation of PKA by PDE
 fac_KD_PP = 5; % multiplicative factor on KD_PP, %#Half-max constant for deactivation of PKA by PDE
 fac_Kdeg_Pc = 1.2; % multiplicative factor on Kdeg_Pc, %#Rate of degradation of cAMP by PDE
 fac_KD_Pc = 1.0/fac_Kb;   % multiplicative factor on KD_Pcm, %#Half-max constant for PDE degradation activity of cAMP
 fac_Kdeg_c = 1.0;  % multiplicative factor on Kdeg_c %#Rate of basal cAMP degradation
 fac_Kdiff_cAMP = .25; % multiplicative factor of Kdiff_cAMP, %#Rate of diffusion of cAMP through gap junctions

end;

on = 1; %#bPAC on
off = 0; %#bPAC off


%tt1 = arange(0,10,1e-2)
%tt2 = arange(10,15,1e-2)
%tt3 = arange(15,20,1e-2)


%beta_c_b = 2*fac_cAMP_bPAC_beta*beta_c_b_andrew*num_cAMP/num_cAMP_0; %#nmol/min/mg Rate of production of cAMP from bPAC
%beta_c_ac = .5*fac_cAMP_basal_beta*beta_c_ac_andrew*num_cAMP/num_cAMP_0; %#Rate of production of cAMP from native AC
%gamma_c_basal = fac_gamma_c_basal*4*gamma_c_basal_andrew;  %#Rate of basal cAMP degradation through non-PDE means
%gamma_c_pd_basal = fac_gamma_c_pd_hetero*.20*2*gamma_c_pd_basal_andrew; %#Rate of basal cAMP degradation through PDE


Kb = fac_Kb*10*scale_time_rates; %#nmol/min/mg Rate of production of cAMP from bPAC
% Kb = fac_Kb*2*fac_cAMP_bPAC_beta*beta_c_b_andrew*num_cAMP/num_cAMP_0; %#nmol/min/mg Rate of production of cAMP from bPAC

ACmax = fac_ACmax*10*scale_time_rates; %#Rate of production of cAMP from native AC
% ACmax = fac_ACmax*.5*fac_cAMP_basal_beta*beta_c_ac_andrew*num_cAMP/num_cAMP_0; %#Rate of production of cAMP from native AC

KD_cAMP = fac_KD_cAMP*0.3; %#Half-max constant for rate of cAMP production

Ka1 = fac_Ka1*0.01*scale_time_rates; %#Rate of PKA activation by cAMP

Kdeg_Pc = fac_Kdeg_Pc*3*scale_time_rates; %#Rate of degradation of cAMP by PDE
% Kdeg_Pc = fac_gamma_c_basal*4*gamma_c_basal_andrew;  %#Rate of basal cAMP degradation through non-PDE means
 
KD_Pc = fac_KD_Pc*0.1; %#Half-max constant for PDE degradation activity of cAMP

Kdeg_c = fac_Kdeg_c*0.5*scale_time_rates; %#Rate of basal cAMP degradation
% Kdeg_c = fac_gamma_c_all*fac_gamma_c_pd_hetero*.20*2*gamma_c_pd_basal_andrew; %#Rate of basal cAMP degradation through PDE
 
Kdeg_PP = fac_Kdeg_PP*5*scale_time_rates; %#Rate of deactivation of PKA by PDE

KD_PP = fac_KD_PP*0.3*fac_KD_PP; %#Half-max constant for deactivation of PKA by PDE

KD1 = 2*scale_time_rates; %#Rate of basal PKA deactivation
KD2 = 0.5*scale_time_rates; %#Rate of PDE deactivation
Ka2 = 1*scale_time_rates; %#Rate of PDE activation
Kdiff = 10*scale_time_rates; %#Rate of diffusion through gap junctions

% mike added
n_AC = 1;  %% order of hill repressor on the PKA_on mediated suppression of Adenylil Cyclase
n_Pc = 1;  %% order of hill activator for PDE_on regulated decay of cAMP
n_PP = 1;  %% order of hill activator for PDE_on regulated dedactivation of PKA_on

Kdiff_cAMP = fac_Kdiff_cAMP*fac_k_diff_c_basal*Kdiff; %#Rate of diffusion of cAMP through gap junctions
k_diff_c_basal = Kdiff_cAMP;  % from Mikes code; 06/24/20
Kdiff_Calcium = Kdiff; %#Rate of diffusion of Calcium through gap junctions
x_flux_max_basal = num_cAMP; % from Mikes code; 06/24/20
   x_flux_max_basal = 5;  % TEST 10/05/20

n_cAMP_PKA = 4; % order of PKA activation through cAMP
KD_cAMP_PKA = 10*(Kb+ACmax)/Kdeg_c; %  currently a much larger number than the max value of cAMP through bPAC


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  ERK regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
  k_e_basal = fac_gamma_e_c*2*7*scale_time_rates;  % basal activation rate of Erk
  gamma_e_basal = fac_gamma_e_c*2*1*scale_time_rates;  % basal deactivation rate of Erk
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  Parameters for deactivation of ERK through upregulated
  %  deactivation rate at is dependent on EPAC through cAMP
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  n_e_c = 1; %% order of hill activator for cAMP regulated deactivation of Erk
  KD_e_c = num_cAMP; %% half-max constant for cAMP regulated deactivation of Erk
  gamma_e_c =   fac_gamma_e_c*2*2*gamma_e_basal;  % maxi deactivation rate for cAMP regulation of Erk

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  ERK-KTR regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
  k_ek_e = 1*scale_time_rates*num_ERK_0/num_ERK;  % basal activation rate (to cytosol) of Erk-KTR through Erk, reaction_type 3
  gamma_ek_basal = 8*scale_time_rates;  % deactivation rate (to nucleus) of Erk-KTR





% #[50, 5, 0.3, 0.01, 3, 0.1, 0.5, 5, 0.3, 2, 0.5, 1, 0.25]

%x0 = np.array([0,1,0,1,0,0,1,0,1,0])

%yy1 = odeint(model1,x0,tt1,args=(off,factAC,fact_Pc,fact_PP,Kb,ACmax,KD_cAMP,Ka1,Kdeg_Pc,KD_Pc,Kdeg_c,Kdeg_PP,KD_PP,KD1,KD2,Ka2,Kdiff), atol=1e-6, rtol=1e-5)
%yy2 = odeint(model1,yy1[len(yy1)-1,:],tt2,args=(on,factAC,fact_Pc,fact_PP,Kb,ACmax,KD_cAMP,Ka1,Kdeg_Pc,KD_Pc,Kdeg_c,Kdeg_PP,KD_PP,KD1,KD2,Ka2,Kdiff), atol=1e-6, rtol=1e-5)
%yy3 = odeint(model1,yy2[len(yy2)-1,:],tt3,args=(off,factAC,fact_Pc,fact_PP,Kb,ACmax,KD_cAMP,Ka1,Kdeg_Pc,KD_Pc,Kdeg_c,Kdeg_PP,KD_PP,KD1,KD2,Ka2,Kdiff), atol=1e-6, rtol=1e-5)

ii_cAMP = 1;
ii_PKA_off = 2;
ii_PKA_on = 3;
ii_PDE_off = 4;
ii_PDE_on = 5;
ii_ERK_off = 6;
ii_ERK_on = 7;
ii_ERKKTR_n = 8;
ii_ERKKTR_c = 9;   

 num_molecules_cell = 9;
 num_inputs = 5;  % global inputs
 
  num_molecules = num_molecules_cell*num_cells + num_inputs;

ii_I_bPAC = num_molecules_cell*num_cells + 1;
ii_I_cAMP_gap = num_molecules_cell*num_cells + 2;
ii_I_Calcium_gap = num_molecules_cell*num_cells + 3;
ii_I_IBMX = num_molecules_cell*num_cells + 4;  % gap junction inhibitor
ii_I_H89 = num_molecules_cell*num_cells + 5;   %


num_inputs_plot = fac_I_bPAC + fac_I_cAMP_gap + fac_I_Calcium_gap + fac_I_IBMX + fac_I_H89

 if (num_inputs_plot == 1)&(fac_I_bPAC==1)
  str_input_plot1 = 'bPAC';
  which_inputs_plot = [ii_I_bPAC]; 
 elseif (num_inputs_plot == 2)&(fac_I_bPAC==1)
  if (fac_I_cAMP_gap == 1)   
    str_input_plot1 = 'gap junction inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_cAMP_gap ii_I_bPAC]; 
  elseif (fac_I_IBMX == 1)   
    str_input_plot1 = 'PDE inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_IBMX ii_I_bPAC]; 
  elseif (fac_I_H89 == 1)   
    str_input_plot1 = 'PKA inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_H89 ii_I_bPAC]; 
  end;
 elseif (num_inputs_plot == 3)&(fac_I_bPAC==1)&(fac_I_cAMP_gap == 1)
  if (fac_I_IBMX == 1)   
    str_input_plot1 = 'gap junction inhibitor';
    str_input_plot2 = 'PDE inhibitor';
    str_input_plot3 = 'bPAC';
    which_inputs_plot = [ii_I_cAMP_gap ii_I_IBMX ii_I_bPAC]; 
  elseif (fac_I_H89 == 1)   
    str_input_plot1 = 'gap junction inhibitor';
    str_input_plot1 = 'PKA inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_cAMP_gap ii_I_H89 ii_I_bPAC]; 
  end;
 end;


 
  for ii = 1:num_cells
  %y_0(num_molecules_cell*(ii-1)+ii_cAMP) = 0;
  %y_0(num_molecules_cell*(ii-1)+ii_PKA_off) = 1;
  %y_0(num_molecules_cell*(ii-1)+ii_PKA_on) = 0;
  %y_0(num_molecules_cell*(ii-1)+ii_PDE_off) = 1;
  %y_0(num_molecules_cell*(ii-1)+ii_PDE_on) = 0;
  %y_0(num_molecules_cell*(ii-1)+ii_ERK_off) = 1;
  %y_0(num_molecules_cell*(ii-1)+ii_ERK_on) = 0;
  %y_0(num_molecules_cell*(ii-1)+ii_ERKKTR_n) = 1;
  %y_0(num_molecules_cell*(ii-1)+ii_ERKKTR_c) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_cAMP) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_PKA_off) = num_PKA;
  y_0(num_molecules_cell*(ii-1)+ii_PKA_on) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_PDE_off) = num_PDE;
  y_0(num_molecules_cell*(ii-1)+ii_PDE_on) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_ERK_off) = num_ERK;
  y_0(num_molecules_cell*(ii-1)+ii_ERK_on) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_ERKKTR_n) = num_ERKKTR;
  y_0(num_molecules_cell*(ii-1)+ii_ERKKTR_c) = 0;
  end;
 

%tt1 = arange(0,10,1e-2)
%tt2 = arange(10,15,1e-2)
%tt3 = arange(15,20,1e-2)
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % setup input time array
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      num_inputs_time_samples = 6;  % number of times samples to construct the input time signal
      map_inputs_data_sampled = zeros(num_inputs,1);
      time_inputs_data_sampled = zeros(num_inputs,num_inputs_time_samples);
      inputs_data_sampled = zeros(num_inputs,num_inputs_time_samples);

      time_max = 20;

      %  initialize, and adjust below for specific inputs
      for ii = 1:num_inputs
      time_inputs_data_sampled(ii,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii,2) = 12.5/scale_time_rates;
      time_inputs_data_sampled(ii,3) = (12.5+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii,4) = (20-2e-6)/scale_time_rates;
      time_inputs_data_sampled(ii,5) = (20-1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii,6) = (20)/scale_time_rates;
      end;
 
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_I_bPAC
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_bPAC == 1)
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      
      
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,1) = 0;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,2) = 0;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,3) = amp_bPAC;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,4) = amp_bPAC;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,5) = 0;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,6) = 0;
      end;  % if (fac_I_bPAC == 1)


      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_cAMP_gap
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_cAMP_gap == 1)
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = 12.5/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = (12.5+1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = (20-2e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = (20-1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = (20)/scale_time_rates;      
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 1; %1;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = 1; %1;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = 1; %0;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = 1; %0;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = 1; %0;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = 1; %0;
      
       %if do_CX43_NGFP == 1   % broken gap-junctions, weaker fluxe  
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = fac_CX43_NGFP; %1;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = fac_CX43_NGFP; %1;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = fac_CX43_NGFP; %0;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = fac_CX43_NGFP; %0;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = fac_CX43_NGFP; %0;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = fac_CX43_NGFP; %0;
       %end;
      
      
      end;
      
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_I_IBMX
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_IBMX == 1)
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,2) = 12.5/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,3) = (12.5+1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,4) = (20-2e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,5) = (20-1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,6) = (20)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,1) = 1; 
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,2) = 1; 
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,3) = 1;
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,4) = 1;
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,5) = 1;
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,6) = 1;
      end;
      
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_I_H89
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_H89 == 1)
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,2) = 12.5/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,3) = (12.5+1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,4) = (20-2e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,5) = (20-1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,6) = (20)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,1) = 1; 
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,2) = 1; 
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,3) = 1;
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,4) = 1;
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,5) = 1;
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,6) = 1;
      end;
      

      time_max = max(time_inputs_data_sampled(1,length(time_inputs_data_sampled(1,:))));


  for ii = 1:num_inputs
   y_0(num_molecules_cell*num_cells+ii) = inputs_data_sampled(ii,1);  % inhibitor input;
  end;
  
  
 
% %tt1 = arange(0,10,1e-2)
% %tt2 = arange(10,15,1e-2)
% %tt3 = arange(15,20,1e-2)
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       % setup input time array
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       num_inputs_time_samples = 6;  % number of times samples to construct the input time signal
%       map_inputs_data_sampled = zeros(num_inputs,1);
%       time_inputs_data_sampled = zeros(num_inputs,num_inputs_time_samples);
%       inputs_data_sampled = zeros(num_inputs,num_inputs_time_samples);
% 
%       time_max = 20;
% 
%       %  initialize, and adjust below for specific inputs
%       for ii = 1:num_inputs
%       time_inputs_data_sampled(ii,1) = 0;
%       time_inputs_data_sampled(ii,2) = 12.5;
%       time_inputs_data_sampled(ii,3) = 12.5+1e-6;
%       time_inputs_data_sampled(ii,4) = time_max-2e-6;
%       time_inputs_data_sampled(ii,5) = time_max-1e-6;
%       time_inputs_data_sampled(ii,6) = time_max;
%       end;
%  
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       % ii_I_bPAC
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,1) = 0;
%       time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,2) = 10;
%       time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,3) = 10+1e-6;
%       time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,4) = 15;
%       time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,5) = 15+1e-6;
%       time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,6) = time_max;
% 
%       inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,1) = 0;
%       inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,2) = 0;
%       inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,3) = 1;
%       inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,4) = 1;
%       inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,5) = 0;
%       inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,6) = 0;
% 
% 
%       do_cAMP_gap = 1;  % 0-no, 1-yes
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       % ii_cAMP_gap
%       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       if (do_cAMP_gap == 1)
%       time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 0;
%       time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = 12.5;
%       time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = 12.5+1e-6;
%       time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = time_max-2e-6;
%       time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = time_max-1e-6;
%       time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = time_max;
% 
%       inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 1;
%       inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = 1;
%       inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = 0;
%       inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = 0;
%       inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = 0;
%       inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = 0;
%       end;
% 
% 
% 
%   for ii = 1:num_inputs
%    y_0(num_molecules_cell*num_cells+ii) = inputs_data_sampled(ii,1);  % inhibitor input;
%   end;
