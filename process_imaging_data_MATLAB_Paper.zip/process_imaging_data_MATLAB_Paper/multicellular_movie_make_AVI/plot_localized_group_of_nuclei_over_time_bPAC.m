
do_plot_cytosol_and_nuclear_signal = 0; % 1 - yes, 0 - no
do_NM = 1;  % 1 - yes, 0 - no
do_CH1 = 1;  % 1 - yes, 0 - no
do_CH2 = 0;  % 1 - yes, 0 - no
    if (length(signal_channels)==1)
        do_CH2 = 0;
    end;
           
    
do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 
    
                 %x_coord_min = 1;
                 %x_coord_max = xLength;
                 %y_coord_min = 1;
                 %y_coord_max = yLength;
                 

                 
                 width_surround = 60;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);
                 

M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);



                 
ii_count = 0;
index_group = [];
for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
    end;
end;
                 

    
%ii_lower = 1;
ii_lower = length(eval(['time_CH',num2str(1)]));

for kkk = ii_lower:length(eval(['time_CH',num2str(1)]))
    
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
      
M_CH1(:,:) =  M_CH1_total(:,:,which_frame_signal);  

figure(1)
imshow(mat2gray(M_CH1));
xlim([y_coord_min y_coord_max]);
ylim([x_coord_min x_coord_max]);

figure(111)
%imshow(mat2gray(M_CH1));
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,which_frame);']);
    imshow(mat2gray(M_NM));
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));             
                  
                  
figure(112)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    imshow(mat2gray(M_NM_bPAC));
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));             
                  
  
 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
M_marker_threshold_TEST = 0*M_marker_threshold_TEST;

 for jjj = 1:length(index_group)
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_DAPI_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
         if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1) 
          M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   2;
           %M_CH1(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = max(max(M_CH1));
           M_CH1(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = max(max(M_CH1));
           M_CH1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = (.5*max(max(M_CH1)));
         else
          M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
           %M_CH1(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = max(max(M_CH1));
           M_CH1(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = max(max(M_CH1));
           M_CH1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = (.5*max(max(M_CH1)));
         end;
       end;
 end;

figure(2)
imagesc(M_marker_threshold_TEST)
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr_NM),', bPAC (red), non-bPAC (green)'));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
       
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
            end;  
            
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

figure(3)
imshow(mat2gray(M_CH1));

title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr_NM),', bPAC (red), non-bPAC (green)'));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
       
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
               set(tt,'Color','m');
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
               set(tt,'Color','m');
              end
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
    
    
    
end;  % end of  'for kkk = 1:length(which_frames)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plot the signals of the cells within the box
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


s_sig = ['b' 'r' 'm' 'g'];
    num_plots_max = 3;
    ii_figure_count = 1;
    ii_plot_count = 0;
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
     figure(1000+ii_figure_count)  
     title(strcat('nuclear CH1 signal (',CH1_str,')'));
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
     subplot(1+1+1,1,1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     ss = plot(time_CH1/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     %ss = plot(time_CH1,nuclear_CH1_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     ylabel(strcat('Erk (nuclear/max val)'));
     ylim([0 1.1]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
          if (jjj == length(index_group))
           if (ii_plot_count+1 == 1)     
            legend(strcat('nucleus:',num2str(index_group(min(max(1,jjj-ii_plot_count+1-1),length(index_group))))));
           elseif (ii_plot_count+1 == 2)     
            legend(strcat('nucleus:',num2str(index_group(min(max(1,jjj-ii_plot_count+1-1),length(index_group))))), strcat('nucleus:',num2str(index_group(min(max(1,jjj-ii_plot_count+2-1),length(index_group))))));
           elseif (ii_plot_count+1 == 3)
            legend(strcat('nucleus:',num2str(index_group(min(max(1,jjj-ii_plot_count+1-1),length(index_group))))), strcat('nucleus:',num2str(index_group(min(max(1,jjj-ii_plot_count+2-1),length(index_group))))),....
                   strcat('nucleus:',num2str(index_group(min(max(1,jjj-ii_plot_count+3-1))))));
           end;
          elseif (ii_plot_count+1 == num_plots_max)
          legend(strcat('nucleus:',num2str(index_group(min(max(1,jjj-num_plots_max+1),length(index_group))))), strcat('nucleus:',num2str(index_group(min(max(1,jjj-num_plots_max+2),length(index_group))))),....
                strcat('nucleus:',num2str(index_group(min(max(1,jjj-num_plots_max+3),length(index_group))))), strcat('nucleus:',num2str(index_group(min(max(1,jjj-num_plots_max+4),length(index_group))))));      
          end;
     subplot(1+1+1,1,1+1) 
     hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0(idx,:))./double(cytosolic_CH1_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0_median(idx,:))./double(cytosolic_CH1_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     ss = plot(time_CH1/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     
     hold off;
     ylabel(strcat('Erk (nuclear/cytosol)'));
     xlabel('number of frames');
     ylim([0 1.1]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     if (ii_plot_count+1 == num_plots_max)|(jjj == length(index_group))
         subplot(1+1+1,1,1+1+1) 
         ylabel('bPAC');
         plot(time_bPAC/scale_factor_time,bPAC_ledvals);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylim([0 1.1*max(bPAC_ledvals)]);
         ylabel('bPAC');
         xlabel(str_time_representation);
     end;

     if (length(signal_channels) > 1)&(do_CH2 == 1)
     figure(2000+ii_figure_count)  
     title(strcat('nuclear CH2 signal (',CH2_str,')'));
     subplot(num_plots_max+1,1,ii_plot_count+1) 
     plot(which_frames,nuclear_CH2_tot_time_mapped_t0(idx,:));
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');
     end;
     
     ii_plot_count = ii_plot_count+1;
     if (ii_plot_count == num_plots_max)&(jjj < length(index_group))
         ii_figure_count = ii_figure_count+1;
         ii_plot_count = 0;
     else
     end;
         
    end    

ii_figure_count_hi = ii_figure_count;

do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)&(done_cells_tracked_ppt == 0)
 % save the figures to a powerpoint slide


  fig111 = figure(111)
  figure(1111)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
   s_combine = 'cell trajectories';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111 fig111 fig1111], 'halign','center','title', s_combine);

    movefile('cells_tracked.ppt',strcat(str_movie_processed,'\',str_movie,'-cells_tracked.ppt'));
    done_cells_tracked_ppt = 1;  % have made the ppt file
    
end; % if (do_PPT ==1)
