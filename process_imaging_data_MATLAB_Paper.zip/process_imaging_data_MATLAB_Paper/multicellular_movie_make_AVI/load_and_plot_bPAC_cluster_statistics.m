%close all;
%clear all;

do_time_representation = 1; % 0-seconds, 1-minutes, 2-hours
if (do_time_representation == 0) % seconds
    scale_factor_time = 1;  
    str_time_representation = 'time (seconds)';
elseif (do_time_representation == 1) % minutes   
    scale_factor_time = 60;  
    str_time_representation = 'time (minutes)';
elseif (do_time_representation == 2) % minutes   
    scale_factor_time = 3600;  
    str_time_representation = 'time (hours)';
end;

str_processing = pwd;  % get processing directory
addpath(str_processing);  % for reference m files

%  PPT checks
done_cells_tracked_ppt = 0;  % 0-not yet made ppt file, 1-made ppt file

set_globals;

if (exist('which_movie_array')==0)
 if (length(which_movie) == 0)  % used for individual calls to this script
 which_movie = input('which movie number do you want, e.g. 1 ,2, etc. ? ');  
 end;
else
 which_movie = which_movie_array;
end;

get_movie_info_for_processing  % which_movie must already be set


%str_movie_processed = strcat(str_movie,'_processed')
str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
str_movie_processed_figures = strcat(str_movie_processed,'\figures-',str_movie);
mkdir(str_movie_processed_figures);

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);


%  num_nuclei_signal_types = 3; % 1- shrink, 2- intersect (over time), 3 -circles  

if (exist('which_nuclei_signal_combine') == 0)
 which_nuclei_signal_type = input('which nuclei signal? (1- shrink, 2- intersect (over time), 3 -circles)');
else
 which_nuclei_signal_type = which_nuclei_signal_combine;
end;
 
% load in cellular signals file for processing
if (which_nuclei_signal_type == 1) % shrink
file_signals = strcat(str_movie_processed,'\cellular_signals');
elseif (which_nuclei_signal_type == 2) % intersect
file_signals = strcat(str_movie_processed,'\cellular_signals_intersect');
elseif (which_nuclei_signal_type == 3) % circle
file_signals = strcat(str_movie_processed,'\cellular_signals_circle');
end
load(file_signals);

% load in processed data from nuclear tracking code
file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
load(file_track);


do_load_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_nucleus_structs ==1)&(exist('Cell_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
load(file_nucleus_tot_FINAL);
end;

do_load_shrink_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_shrink_nucleus_structs ==1)&(exist('Cell_shrink_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_shrink_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_shrink_nucleus_structs_tot_FINAL');
load(file_shrink_nucleus_tot_FINAL);
end;
if (exist('Cell_intersect_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_intersect_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_intersect_nucleus_structs_tot_FINAL');
load(file_intersect_nucleus_tot_FINAL);
end;
if (exist('Cell_circle_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_circle_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_circle_nucleus_structs_tot_FINAL');
load(file_circle_nucleus_tot_FINAL);
end;


do_load_cytosol_structs = 1;  % 1 - yes, 0 - no
if (do_load_cytosol_structs ==1)&(exist('Cell_cytosol_FILL_6')==0)
% load in the thresholded cytosol information from all frames 
file_cytosol_tot_FINAL = strcat(str_movie_processed,'\Cell_cytosol_structs_tot_FINAL');
load(file_cytosol_tot_FINAL);
end;




do_load_movie_arrays = 1;  % 1 - yes, 0 - no
if (do_load_movie_arrays == 1)&((exist('M_CH1_total')==0)|(exist('which_movie_array')==1))
% load in processed data from nuclear tracking code
file_movie_arrays = strcat(str_movie_processed,'\movie_arrays'); 
load(file_movie_arrays);  
end;


found_file_microscope = fileattrib(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'))

if (found_file_microscope == 1)  % movie has input_info.mat file
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% variables in file: bPAC_amp  bPAC_ledvals  bPAC_max  measurement_order measurement_skipframes  seconds_per_frame    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
  load(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'));
  time_bPAC = 0:seconds_per_frame:seconds_per_frame*(length(bPAC_ledvals)-1);
  
else
    
    if which_movie == 103
        seconds_per_frame = 60;
    end;
  time_bPAC = 0:seconds_per_frame:seconds_per_frame*(length(bPAC_ledvals)-1);
    
end;  

%plot_all_nuclei_movements;  

%plot_localized_group_of_nuclei_over_time

%%%plot_specific_nucleus_and_signals(which_nucleus,M_DAPI_id_threshold,M_DAPI,M_FITC,M_CY3,box_coords);  % this has thresholding test to separare touching nuclei


 


 if bPAC_amp_max > 1
  bPAC_ledvals = bPAC_ledvals/bPAC_amp_max;
 end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate average nuclear signals (per pixel)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for kkk = 1:length(time_CH1)
    %which_frame = image_index_CH1(kkk);
     eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
     
    average_nuclear_CH1_tot_time(which_frame_signal) = 0;
for which_nucleus = 1:num_nuclei_time(which_frame)
 average_nuclear_CH1_tot_time(which_frame_signal) = average_nuclear_CH1_tot_time(which_frame_signal) + nuclear_CH1_tot_time(which_nucleus,kkk)*num_pixels_tot_NUCLEUS_time(which_nucleus,which_frame);
end;
 average_nuclear_CH1_tot_time(which_frame_signal) = average_nuclear_CH1_tot_time(which_frame_signal)/sum(num_pixels_tot_NUCLEUS_time(1:num_nuclei_time(which_frame),which_frame));
end;

if (length(signal_channels)>1)
for kkk = 1:length(time_CH2)
    %which_frame = image_index_CH2(kkk);
    eval(['[val,index_frame]= min(abs(time_CH',num2str(2),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
     
    average_nuclear_CH2_tot_time(which_frame_signal) = 0;
for which_nucleus = 1:num_nuclei_time(which_frame)
 average_nuclear_CH2_tot_time(which_frame_signal) = average_nuclear_CH2_tot_time(which_frame_signal) + nuclear_CH2_tot_time(which_nucleus,kkk)*num_pixels_tot_NUCLEUS_time(which_nucleus,which_frame);
end;
    average_nuclear_CH2_tot_time(which_frame_signal) = average_nuclear_CH2_tot_time(which_frame_signal)/sum(num_pixels_tot_NUCLEUS_time(1:num_nuclei_time(which_frame),which_frame));
end;
end

figure(2222)
subplot(2,1,1);
plot(time_CH1,average_nuclear_CH1_tot_time);
xlim([0 max(time_CH1)]);
title(strcat('Average Nuclear Signal per pixel MOVIE:',path_movie,')'));
ylabel(CH1_str);
xlabel('time (seconds)');
subplot(2,1,2);
if (length(signal_channels)>1)
plot(time_CH2,average_nuclear_CH2_tot_time);
xlim([0 max(time_CH2)]);
ylabel(CH2_str);
xlabel('time (seconds)');
end;

%figure(2223)
%subplot(2,1,1);
%plot(time_sequence_movie(2:length(time_sequence_movie)),1./dt_sequence_movie)
%xlim([0 max(time_sequence_movie)]);
%ylabel('sampling/bPAC impuls frequency (Hz)');
%xlabel('time (seconds)');


found_file_bPAC_mapped = fileattrib(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL.mat'))
if ( found_file_bPAC_mapped == 1 )
  load(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL'));
else
   do_mixed_bPAC_population_analysis = 1; % 1 - yes, 0 - no
   if (do_location_bPAC_nuclei == 1)&(do_mixed_bPAC_population_analysis==1)
    load(strcat(str_movie_processed,'\time_series_for_tracking_cells_bPAC'));
    load(strcat(str_movie_processed,'\Cell_nucleus_bPAC_structs_tot'));
    mixed_bPAC_population_analysis;
   end;
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Process ERK signals if present
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (marker_from_channel(ii_Erk_marker) > 0)

    
      % Setup Erk signal arrays
      eval(['nuclear_Erk_tot_time_mapped_t0 = nuclear_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0;']);
      eval(['nuclear_Erk_tot_time_mapped_t0_median = nuclear_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0_median;']);
      eval(['cytosolic_Erk_tot_time_mapped_t0 = cytosolic_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0;']);
      eval(['cytosolic_Erk_tot_time_mapped_t0_median = cytosolic_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0_median;']);
      eval(['time_Erk = time_CH',num2str(marker_from_channel(ii_Erk_marker))]); 
      eval(['Erk_str = CH',num2str(marker_from_channel(ii_Erk_marker)),'_str']); 

   % if bPAC cells has a different color Erk marker
   if (marker_from_channel(ii_Erk_bPAC_marker) > 0)
      eval(['Erk_bPAC_str = CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_str']); 
    for idx = 1:num_nuclei_t0
     if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)         
      eval(['nuclear_Erk_tot_time_mapped_t0(idx,:) = nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(idx,:);']);
      eval(['nuclear_Erk_tot_time_mapped_t0_median(idx,:) = nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0_median(idx,:);']);
      eval(['cytosolic_Erk_tot_time_mapped_t0(idx,:) = cytosolic_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(idx,:);']);
      eval(['cytosolic_Erk_tot_time_mapped_t0_median(idx,:) = cytosolic_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0_median(idx,:);']);
     end; 
    end;
   end;
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate mean Erks signals and plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for kkk = 1:length(time_Erk)
     eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
    
    average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) = 0;
    average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) = 0;
for which_nucleus = 1:num_nuclei_t0
 average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) = average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) + nuclear_Erk_tot_time_mapped_t0(which_nucleus,which_frame_signal)*num_pixels_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame);
 average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) = average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) + nuclear_Erk_tot_time_mapped_t0(which_nucleus,which_frame_signal)/...
                                                         cytosolic_Erk_tot_time_mapped_t0(which_nucleus,which_frame_signal);
end;
 average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) = average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal)/sum(num_pixels_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame));
 average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) = average_ratio_Erk_tot_time_mapped_t0(which_frame_signal)/num_nuclei_t0;
end;
    

    if (ii_NM == ii_NM_bPAC)
       bPAC_NUCLEUS_time_mapped_t0 = ones(num_nuclei_t0,1);
    end;



load(strcat(str_movie_processed,'\bPAC_statistics_arrays'));
 if exist('do_emitter_reciever_amp_distance') == 1
  if (do_emitter_statistics == 1)
   make_bPAC_statistics_plots
  end;
 else
  make_bPAC_statistics_plots
 end;

%  spatial analyze of cells and their signals within a bPAC cluster and
%  non-bPAC cells outside the cluster
 if (ii_NM~=ii_NM_bPAC)  % do only if there is a mix of bPAC and non-bPAC cells
 %analyze_bPAC_clusters_statistics;
 end;
 

 if exist('do_emitter_reciever_amp_distance') == 1
  if do_emitter_reciever_amp_distance == 1
      
     num_emitters = sum(bPAC_NUCLEUS_time_mapped_t0(:,1));
     
     distance_to_emitter = zeros(num_nuclei_t0, num_emitters);
     distance_to_emitter_min = zeros(num_nuclei_t0, num_emitters);
     index_distance_to_emitter_min = zeros(num_nuclei_t0, 1);
     emitter_nuclei = zeros(num_emitters,1);
     ii_nuclei = 0;
     which_frame_start = 1;

    % clauclate distances between a nuclei and all emitter nuclei
    for idx = 1:num_nuclei_t0
     if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)
         ii_nuclei = ii_nuclei +1;
          emitter_nuclei(ii_nuclei) = idx;
         for which_nucleus = 1:num_nuclei_t0
             distance_to_emitter(which_nucleus,ii_nuclei) = sqrt(power(x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start) - x_coord_min_tot_NUCLEUS_time_mapped_t0(idx,which_frame_start),2) ...
                                                      +power(y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start) - y_coord_min_tot_NUCLEUS_time_mapped_t0(idx,which_frame_start),2));
         end;
     end; 
    end;

    
        distance_to_emitter_min = distance_to_emitter_min - 100;  % this simlply sets all entries negative,                                                                   
        %because not all array locations will be set with values (positive) allowing us to plot everything, but keep the range greater than zero 
    
        for idx = 1:num_nuclei_t0
            [val index] = min(distance_to_emitter(idx,:))
           distance_to_emitter_min(idx,index) = max(val,0);
           %index_distance_to_emitter_min(idx) = index;
        end;
        
            % convert from pixes to micrometers
              pixel_length_1X = 16;  % 16 microns per pixel,  got this from Ben, need to confirm
              magnification_X = 40;  %  usually 40X, but can also be 15X 
              distance_to_emitter_min = distance_to_emitter_min*pixel_length_1X/magnification_X;   
              
              
            if (exist('bPAC_pulse_start')==0)
                bPAC_pulse_start = 1;
                bPAC_pulse_start = num_bPAC_pulses;
            end;    
        
 idx_tot_count = 0;  % count signals that passed the test in 'analyze_Erk_cellular_response_to_bPAC_statistics.m'
 num_LW = 3;  % linewidth
 pulse_or_not = 1;  % 0 - use all date, 1 - use only signals that passed the test in 'analyze_Erk_cellular_response_to_bPAC_statistics.m'
        figure(100)
        close 100;
       for ii_emitter = 1:1%num_emitters
        for idx = 1:num_nuclei_t0
        for ii = bPAC_pulse_start:bPAC_pulse_stop        
        figure(100)
        hold on;
         if (bPAC_pulse_cell(idx,ii) >= pulse_or_not)
         ss = scatter(distance_to_emitter_min(idx,ii_emitter),overshoot_bPAC_pulse_cell(idx,ii)/overshoot_bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii),'go');
                set(ss,'LineWidth',num_LW);
                idx_tot_count = idx_tot_count+1
         end;
        hold off;
        end;
        end;
        for ii = bPAC_pulse_start:bPAC_pulse_stop        
        figure(100)
        hold on;
           for ii_dummy = 1:length(non_bPAC_clusters_inner)
              ii_receiver_inner = non_bPAC_clusters_inner(ii_dummy);
            if (bPAC_pulse_cell(ii_receiver_inner,ii) >= pulse_or_not)
              ss = scatter(distance_to_emitter_min(ii_receiver_inner,ii_emitter),overshoot_bPAC_pulse_cell(ii_receiver_inner,ii)/overshoot_bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii),'md');
                set(ss,'LineWidth',num_LW);
            end;
           end;
            if (bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii) >= pulse_or_not)   
              ss = scatter(distance_to_emitter_min(emitter_nuclei(ii_emitter),ii_emitter),overshoot_bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii)/overshoot_bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii),'cs');
                set(ss,'LineWidth',num_LW);
            end;
        hold off;        
        end;
       end;
       % xlim([0 max(max(distance_to_emitter_min))])
        xlim([0 max_distance_plot])
        ylim([0 1.2]);
        xlabel('distance from emitter ({\mu}m)');
        ylabel('max signal amplitude (normalized to emitter)');
        title(strcat(str_movie,', num data points:',num2str(idx_tot_count),'/',num2str(num_nuclei_t0*(bPAC_pulse_stop-bPAC_pulse_start+1)),',pulses:',num2str(bPAC_pulse_stop),' to ',num2str(bPAC_pulse_start)));
        
        done_print_map = 0;  % 0 - no, 1 - yes,
        
        for idx = 1:num_nuclei_t0
            
              if (idx==1)  % remove if file exists
               str_dir_dummy = pwd;
               cd(str_combined_stats_do_case);                
               delete(strcat(str_movie,'-nuclear_Erk_signals_statistics_DISTANCE_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'.ppt'));
               cd(str_dir_dummy)
              end;
            
            
             figure(100);
             a1 = gca;
             f2 = figure;
             a2 = copyobj(a1,f2);
             h = gcf;
        for ii = bPAC_pulse_start:bPAC_pulse_stop        
    
          hold on;
         if (ii == 1)
          if (bPAC_pulse_cell(idx,ii) >= pulse_or_not)
          ss = scatter(distance_to_emitter_min(idx,ii_emitter),overshoot_bPAC_pulse_cell(idx,ii)/overshoot_bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii),'ko');
                 set(ss,'LineWidth',2*num_LW);
                text(.5*max(max(distance_to_emitter_min)),1.1, strcat('black: nuclei:', num2str(idx),', pulse number:',num2str(ii)));              
          end;
         elseif (ii == 2)  % this only works when num_bPAC_pulses = 2, which is fine for this paper
          if (bPAC_pulse_cell(idx,ii) >= pulse_or_not)   
          ss = scatter(distance_to_emitter_min(idx,ii_emitter),overshoot_bPAC_pulse_cell(idx,ii)/overshoot_bPAC_pulse_cell(emitter_nuclei(ii_emitter),ii),'bo');
                set(ss,'LineWidth',2*num_LW);
               text(.5*max(max(distance_to_emitter_min)),.9, strcat('blue: nuclei:', num2str(idx),', pulse number:',num2str(ii)));              
          end;
         end;
          hold off;   
        end;             

             if (sum(bPAC_pulse_cell(idx,bPAC_pulse_start:bPAC_pulse_stop)) > 0)
                view_specific_Erk_cellular_response_to_bPAC_statistics;  % test here, uses idx             
                figH = figure(h);
                
                    % BEGIN: draw boundary of plots
                    figure(10000)    
                      r = max_distance_plot*magnification_X/pixel_length_1X;   %pixels
                      th = 0:pi/50:2*pi;
                      xunit = r * cos(th) + mean_x_tot_time_mapped_t0(bPAC_clusters(1),1);
                      yunit = r * sin(th) + mean_y_tot_time_mapped_t0(bPAC_clusters(1),1);
                      hold on;
                      xx = plot(yunit, xunit,strcat('c','--'));
                     set(xx,'LineWidth',2);
                     for iii_adjacent = 1:length(non_bPAC_clusters_inner)
                      tt = text(mean_y_tot_time_mapped_t0(non_bPAC_clusters_inner(iii_adjacent),1),mean_x_tot_time_mapped_t0(non_bPAC_clusters_inner(iii_adjacent),1),strcat(num2str(non_bPAC_clusters_inner(iii_adjacent))));
                      set(tt,'Color','m');
                     end;
                    % END: draw boundary of plots
                
                fig10000 = figure(10000)
                fig200 = figure(200)
                s_combine = strcat(str_movie,':nuclear Erk signals');
                
                str_dir_dummy = pwd;
                cd(str_combined_stats_do_case);                
                saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_DISTANCE_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);                
                  if (done_print_map == 0)
                        figure(10000);
                        print('-depsc',strcat('map-emitter_reciever_amp_distance-',str_movie,'.eps'));
                        done_print_map = 1;
                  end;
                cd(str_dir_dummy)
                
                close(200)
                close(10000);
             end;
                close(h)
        
        end;
        
        
    
  end;
 end;
 
 
 
end;  % if (marker_from_channel(ii_Erk_marker) > 0)
