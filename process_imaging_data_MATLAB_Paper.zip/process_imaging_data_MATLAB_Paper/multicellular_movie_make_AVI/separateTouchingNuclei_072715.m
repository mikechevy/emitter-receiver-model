function [box_coords_out,M_marker_threshold_out] = separateTouchingNuclei(M_marker_threshold,M_marker,box_coords, threshold, nucleus_min_pixels,mean_pix,std_pix)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Divide and conquer:  Recurvisthreshold into two pieces at a time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

max_separate_nuclei = 20;
    
box_coords_new = zeros(max_separate_nuclei,4);

    M_marker_threshold_TEST = 0*M_marker_threshold;    
    M_marker_threshold_FILL = 0*M_marker_threshold;    
    M_marker_NORMALIZED = double(M_marker);    
    
   
                 x_coord_min = box_coords(1);
                 x_coord_max = box_coords(2);
                 y_coord_min = box_coords(3);
                 y_coord_max = box_coords(4);


%M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = double(M_marker(x_coord_min:x_coord_max,y_coord_min:y_coord_max)-min(min(M_marker(x_coord_min:x_coord_max,y_coord_min:y_coord_max))))/double(max(max(M_marker(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))-min(min(M_marker(x_coord_min:x_coord_max,y_coord_min:y_coord_max))));
M_marker_NORMALIZED = double(M_marker-min(min(M_marker)))/double(max(max(M_marker))-min(min(M_marker)));
threshold_max = max(max(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
threshold_min = threshold;        


num_iterations_threshold = 10;
delta_threshold = (threshold_max-threshold_min)/num_iterations_threshold;

nuclei_separated = 0;  % 1 - yes, 0 no
ii_threshold = 1;


while (ii_threshold <= num_iterations_threshold)&(nuclei_separated == 0)

    threshold_test = threshold + ii_threshold*delta_threshold;

    tic
    %M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold_test);
    M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold_test);
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = bwareaopen(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max), nucleus_min_pixels);  % removie 
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');    
    %Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max));
    Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    toc
    num_nuclei_separate = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));

                           
              ii_threshold = ii_threshold + 1;
              
              if (num_nuclei_separate > 1)
                  nuclei_separated  = 1;                 
              elseif sum(sum(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max))) < mean_pix + std_pix
                  nuclei_separated  = -1;
              end;
              
end % END OF: while (ii_threshold <=num_iterations_threshold)&(all_nuclei_separated == 0)




               M_marker_threshold_out = 0*M_marker_threshold;

             if (num_nuclei_separate <= 1)  % single nucleus!!!!
               % return box_coords;              
               box_coords_out = box_coords;
               num_nuclei_out = 1;  
                % for ii = x_coord_min:x_coord_max                 
                % for jj = y_coord_min:y_coord_max                 
                %  if (M_marker_id_threshold(ii,jj) == which_nucleus)&(M_marker_NORMALIZED(ii,jj) > threshold) 
                %     M_marker_id_threshold_out(ii,jj) = M_marker_id_threshold(ii,jj); 
                %  end;
                % end;
                % end;                                              
                     M_marker_threshold_out = M_marker_threshold; 
             elseif (num_nuclei_separate > 1)  % single nucleus!!!!
                 box_coords_new = zeros(num_nuclei_separate,4);
                 box_coords_new(:,1) = x_coord_max+1;
                 box_coords_new(:,2) = 0;
                 box_coords_new(:,3) = y_coord_max+1;
                 box_coords_new(:,4) = 0;
                 
                 box_coords_out = [];
              for ii_num_nuclei = 1:num_nuclei_separate   
                M_marker_threshold_TEST = 0*M_marker_threshold_TEST;   
                M_marker_threshold_TEST(Cell_marker_FILL.PixelIdxList{ii_num_nuclei}) = 1;

                     do_plot_threshold_results = 0; % 1 - yes, 0 - no
                 if (do_plot_threshold_results == 1)
                  test_plot_separate_nuclei
                  pause;
                 end;   % END OF:  if (do_plot_threshold_results == 1)
                  
                
%                  for ii = x_coord_min:x_coord_max                 
%                  for jj = y_coord_min:y_coord_max                
%                      if (M_marker_threshold_TEST(ii,jj) == 1)
%                       if (box_coords_new(ii_num_nuclei,1) > ii)
%                           box_coords_new(ii_num_nuclei,1) = ii;
%                       end;
%                       if (box_coords_new(ii_num_nuclei,2) < ii)
%                           box_coords_new(ii_num_nuclei,2) = ii;
%                       end;
%                       if (box_coords_new(ii_num_nuclei,3) > jj)
%                           box_coords_new(ii_num_nuclei,3) = jj;
%                       end;
%                       if (box_coords_new(ii_num_nuclei,4) < jj)
%                           box_coords_new(ii_num_nuclei,4) = jj;
%                       end;                         
%                      end;
%                  end;
%                  end;                 
%                  box_coords_new(ii_num_nuclei,:)
                 
                 [I_nuclei,J_nuclei] = find(M_marker_threshold_TEST);%,size(M_marker'))
                box_coords_new(ii_num_nuclei,:) =  [min(I_nuclei) ; max(I_nuclei) ; min(J_nuclei) ; max(J_nuclei)];
                %box_coords_new(ii_num_nuclei,:)                
                %pause
                 
                M_marker_TEST = M_marker.*int16(M_marker_threshold_TEST);  % remove others
                
               [box_coords_separate, M_marker_threshold_separate] =   separateTouchingNuclei(M_marker_threshold_TEST,M_marker_TEST,box_coords_new(ii_num_nuclei,:), threshold_test ,nucleus_min_pixels,mean_pix,std_pix);
               box_coords_out = [box_coords_out ; box_coords_separate];
               M_marker_threshold_out = M_marker_threshold_out + M_marker_threshold_separate; 
              end;
             end;


            
