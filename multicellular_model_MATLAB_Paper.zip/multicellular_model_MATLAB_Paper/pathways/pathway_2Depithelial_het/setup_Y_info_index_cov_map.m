function [Y_info_index_cov_map X_info_index_cov_map] = setup_Y_info_index_cov_map(Y_info_index,X_info_index)
    
   global covariance_map
    
       for ii_dummy = 1:length(covariance_map)
        % Y_index stuff   
        if (covariance_map(ii_dummy,1) == Y_info_index(1))&(covariance_map(ii_dummy,2) == Y_info_index(1))   
          Y_info_index_cov_map(1) = ii_dummy;
        end;
          if (length(Y_info_index)==2)              
             if (covariance_map(ii_dummy,1) == Y_info_index(2))&(covariance_map(ii_dummy,2) == Y_info_index(2))   
               Y_info_index_cov_map(2) = ii_dummy;
             end;         
               %% BEGIN:covariance terms
               if (covariance_map(ii_dummy,1) == Y_info_index(1))&(covariance_map(ii_dummy,2) == Y_info_index(2))   
                 Y_info_index_cov_map(3) = ii_dummy;
               end;          
               if (covariance_map(ii_dummy,1) == Y_info_index(2))&(covariance_map(ii_dummy,2) == Y_info_index(1))   
                 Y_info_index_cov_map(3) = ii_dummy;
               end;          
               %% END:covariance terms             
          end;
              
        % X_index stuff   
        if (covariance_map(ii_dummy,1) == X_info_index(1))&(covariance_map(ii_dummy,2) == X_info_index(1))   
          X_info_index_cov_map(1) = ii_dummy;
        end;
          if (length(X_info_index)==2)              
             if (covariance_map(ii_dummy,1) == X_info_index(2))&(covariance_map(ii_dummy,2) == X_info_index(2))   
               X_info_index_cov_map(2) = ii_dummy;
             end;         
          end;
          
       end;
