


% generate max Delta ERK-KTR N/C amplidute versus relative Cytosolic ring
% intensity
ii_count_dummy = 0;
y_dummy = [];
x_dummy = [];

figure(6);
hold on;
for idx = 1:num_nuclei_t0
      if ((max(bPAC_pulse_cell(idx,:)) > 0)&(min(abs(idx-nuclei_not_to_use))>0))|((just_nuclei_not_to_use==1)&(min(abs(idx-nuclei_not_to_use))>0))
           
         plot(mean(cytosolic_Erk_tot_time_mapped_t0_median(idx,:)), Delta_ERK_KTR_pulse(idx,1), 'ko');
         plot(mean(cytosolic_Erk_tot_time_mapped_t0_median(idx,:)), Delta_ERK_KTR_pulse(idx,2), 'bo');
         % plot(mean(cytosolic_Erk_tot_time_mapped_t0(idx,:)), Delta_ERK_KTR_pulse(idx,1), 'ko');
         % plot(mean(cytosolic_Erk_tot_time_mapped_t0(idx,:)), Delta_ERK_KTR_pulse(idx,2), 'bo');
         y_dummy = [y_dummy Delta_ERK_KTR_pulse(idx,1)];
         y_dummy = [y_dummy Delta_ERK_KTR_pulse(idx,2)];
         x_dummy = [x_dummy mean(cytosolic_Erk_tot_time_mapped_t0_median(idx,:))];
         x_dummy = [x_dummy mean(cytosolic_Erk_tot_time_mapped_t0_median(idx,:))];
         ii_couunt_dummy = ii_count_dummy+2;
     end;
end;
y_est = polyfit(x_dummy, y_dummy,1);

plot(x_dummy,y_est(2) + y_est(1)*x_dummy,'g--');

hold off;
xlabel('relative intensity');
ylabel('\Delta ERK-KTR N/C');
          %xlim([.9*min max(time_Erk)/scale_factor_time]);
          %ylim([0 1.1*max(bPAC_ledvals)]);
