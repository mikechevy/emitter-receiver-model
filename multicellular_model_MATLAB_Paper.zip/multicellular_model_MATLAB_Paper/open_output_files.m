        fids_info = fopen('data/Particles_out.info','w');
         fwrite(fids_info,m_Np,'int');
         fwrite(fids_info,m_xdim,'int');
         fwrite(fids_info,m_ydim,'int');
         fwrite(fids_info,m_zdim,'int');
         fwrite(fids_info,m_delt,'double');
         fwrite(fids_info,m_delx,'double');
         fwrite(fids_info,m_dely,'double');
         fwrite(fids_info,m_delz,'double');
         fwrite(fids_info,num_timesteps,'int');
         fwrite(fids_info,subgrid_fac,'int');

   fids_part = fopen('data/Particles.bin','w');

   
   
   
rank = Parts(1,RANK)


fids_encounters = fopen(strcat('data/encounter.record',num2str(rank)),'w');

%zero 'output' counting variables
num_encounter_writes = 0;

fids_dimurs = fopen(strcat('data/dimurs.record',num2str(rank)),'w');

%zero 'output' counting variables
num_dimurize_writes = 0;

if (use_subgrid==1)&(use_subgrid_pdf==0)
count_SubgridFile = 0;
block_subgrid = 10;
fpSubgridFile=fopen('data/subgrid.record0','w');
end;
   
