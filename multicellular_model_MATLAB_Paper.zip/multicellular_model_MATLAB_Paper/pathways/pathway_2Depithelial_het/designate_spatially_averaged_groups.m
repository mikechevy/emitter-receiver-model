

%  The designated groups are either taken from those cells
%  averged from data to compare with simulation, or just simulation.

% Different cases for which spatially averaged groups are designated
% Each group needs to be a Row, NOT a Column

if (strcmp(str_movie_write, 'imagefile_160902_198_198-117_EA_100_250_225_300') == 1)

    bPAC_clusters = 28
    size_bPAC_clusters = 1

    bPAC_clusters_location = [1];  % determines bPAC cells adjacent to non_bPAC
    
    
    non_bPAC_clusters =  [29];
    size_non_bPAC_clusters = 1;

    non_bPAC_clusters_location = [1];  % determines non_bPAC cells adjacent to bPAC cluster
    
    
elseif (strcmp(str_movie_write, 'imagefile_160902_198_198-117_EA_100_400_150_400') == 1)
    
    
    bPAC_clusters = 28
    size_bPAC_clusters = 1

    bPAC_clusters_location = [1];  % determines bPAC cells adjacent to non_bPAC
    
    non_bPAC_clusters =  [19    22    23    24    25    29    30    34  37    39];
    size_non_bPAC_clusters = 10;

    non_bPAC_clusters_location = [0 1 1 1 0 1 1 1 1 1];  % determines non_bPAC cells adjacent to bPAC cluster
    
 
elseif (strcmp(str_movie_write, 'imagefile_160905_198_198-117_JP_250_400_150_250') == 1)

    bPAC_clusters = 36
    size_bPAC_clusters = 1

    bPAC_clusters_location = [1];  % determines bPAC cells adjacent to non_bPAC
    
    non_bPAC_clusters =  [31 32 40 41];
    size_non_bPAC_clusters = 4;
    
    non_bPAC_clusters_location = [1 1 1 1];  % determines non_bPAC cells adjacent to bPAC cluster
    
elseif (strcmp(str_movie_write, 'imagefile_160905_198_198-117_JP_200_450_100_300') == 1)

     bPAC_clusters = [31 32 36 40 41]
     size_bPAC_clusters = 5;
 
     bPAC_clusters_location = [1 0 0 1 1];  % determines bPAC cells adjacent to non_bPAC
    
     non_bPAC_clusters =  [24 26 29 34 35 44 46 48 49 51 52];
     size_non_bPAC_clusters = 11;
          non_bPAC_clusters_location = [1 1 1 1 0 0 1 1 1 0 0];  % determines non_bPAC cells adjacent to bPAC cluster

          
elseif (strcmp(str_movie_write, 'imagefile_160905_198_198-117_JP_200_450_100_300_same1') == 1)

    bPAC_clusters = [32 36 41]
    size_bPAC_clusters = 3;

    bPAC_clusters_location = [0 0 1];  % determines bPAC cells adjacent to non_bPAC
    
    non_bPAC_clusters =  [24 26 29 31 34 35 40 44 46 48 49 51 52];
    size_non_bPAC_clusters = 13;
    
    non_bPAC_clusters_location = [1 1 1 1 0 0 0 0 1 1 1 0 0];  % determines non_bPAC cells adjacent to bPAC cluster
    
    
elseif (strcmp(str_movie_write, 'imagefile_160905_198_198-117_JP_100_490_100_400') == 1)
    bPAC_clusters = [41 ];
    size_bPAC_clusters = 1;
    
    bPAC_clusters_location = [ 1 ];  % determines bPAC cells adjacent to non_bPAC
      
   if (  which_modeling_case == 6) 
       
    non_bPAC_clusters =  [23    24    26    27    28    29  31 32   34 ...
                          35    36    40    44    45    46  48 49  ... 
                          50    51 52   54    55    56    57    58    59 ...
                          60    61    63    65    66    68    69];
    size_non_bPAC_clusters = 33;
        
   elseif (  which_modeling_case == 7)  
                  
    non_bPAC_clusters =  [23    24    26    27    28    29  31 32   34 ...
                          35    36    40    44    45    46  48 49  ... 
                          50    51 52   54    55    56    57    58    59 ...
                          60    61    63    65    66    68    69 ...
                          2 3 4 5 6 11 13 14 15 20 23 27];                      
   end;  % end of 'if (  which_modeling_case == 6)' 
                      
        non_bPAC_inner = [31 35 36 40 46 48 49];   % adjacent receivers
                  
     size_non_bPAC_clusters = length(non_bPAC_clusters);
     non_bPAC_clusters_location = zeros(1, size_non_bPAC_clusters);

     for iii_non = 1:length(non_bPAC_inner)
       [val index_dummy] = min(abs(non_bPAC_inner(iii_non)-non_bPAC_clusters))
       index_dummy
       non_bPAC_clusters(index_dummy)
       non_bPAC_inner
      non_bPAC_clusters_location(index_dummy) = 1;
     end;

     index_group = sort([non_bPAC_clusters bPAC_clusters])
     num_cells = length(index_group);

end;  % end of 'if (strcmp(str_movie_write, 'imagefile_160902_198_198-117_EA_100_250_225_300') == 1)'




%for jjj = 1:length(size_bPAC_clusters)
%for iii = 1:size_bPAC_clusters(jjj)
%    which_nucleus_bPAC = bPAC_clusters(jjj,iii);
%     num_adjacent_non_bPAC =    sum(matrix_bPAC_plus(which_nucleus_bPAC,:)-matrix_bPAC(which_nucleus_bPAC,:));
%     if (num_adjacent_non_bPAC>=2)
%         bPAC_clusters_location(jjj,iii) = 1;  % determines bPAC cells adjacent to non_bPAC
%     end;
%end;
%end;



