M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_Erk = zeros(xLength,yLength);

    % Default for now, but movie specific later
    scale_Erk_channel = 0.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels


kkk = 1;
which_frame = kkk;

    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    eval(['M_Erk(:,:) = M_CH',num2str(marker_from_channel(ii_Erk_marker)),'_total(:,:,index_frame_bPAC);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %imshow(mat2gray(M_NM));
    %%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    figure(10000)
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
    image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)


which_frame_NM = 1;
    
    
for kkk = 1:num_nuclei_t0

             tt = text(mean_y_tot_time_mapped_t0(kkk,which_frame_NM),mean_x_tot_time_mapped_t0(kkk,which_frame_NM),strcat(num2str(kkk)));
             %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),'.');
             if ii_NM == ii_NM_bPAC  % all bPAC cells
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
               str_emitter = 'm';
               set(tt,'Color',str_emitter);
               %set(tt,'fontsize',12);
             else
               if (bPAC_NUCLEUS_time_mapped_t0(kkk,1) == 1)    
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
                   str_emitter = 'c';
                 set(tt,'Color',str_emitter);
               else
               set(tt,'Color','y');
               end;
             end;
             
                 if (idx == kkk)  % (place circle around specified nucleus) 
                      %e
                      %r= desired radius
                      %x = x coordinates of the centroid
                      %y = y coordinates of the centroid
                      r = 20;   %pixels
                      th = 0:pi/50:2*pi;
                      xunit = r * cos(th) + mean_x_tot_time_mapped_t0(kkk,which_frame_NM);
                      yunit = r * sin(th) + mean_y_tot_time_mapped_t0(kkk,which_frame_NM);
                      hold on;
                       if (bPAC_NUCLEUS_time_mapped_t0(kkk,1) == 1)    
                        xx = plot(yunit, xunit,strcat(str_emitter,'--'));
                       else
                        xx = plot(yunit, xunit,'y--');
                       end;
                       set(xx,'LineWidth',2);
                       hold off;
                 end;


end;             

             
% if (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)



if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 

do_just_nuclear_signal = 0;  % 0-ratio of nuclear to cytosol, 1-nuclear signal/min(nuclear signal);  For powerpoint stuff

  if (which_nuclei_signal_type == 1) % shrink
      str_nuclei_signal_type = 'SHRINK_';
  elseif (which_nuclei_signal_type == 2) % intersect
      str_nuclei_signal_type = 'INTERSECT_';
  elseif (which_nuclei_signal_type == 3) % circle
      str_nuclei_signal_type = 'CIRCLE_';
  end;
      
if (do_just_nuclear_signal == 1)
  str_just_nuclear = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
elseif (do_just_nuclear_signal == 0)
  str_just_nuclear = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
end;
  mkdir(strcat(str_movie_processed_figures,'\cellular_signals_eps_statistics'));
  
M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);

sig_dummy_average_bPAC_pulse_cell = zeros(1, length(time_Erk));
count_pulse_cell = 0;

s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
      
        figure(1000)
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);          
          diff_bPAC_signal = diff(bPAC_ledvals);
          
%  determine pulse locations here, bPAC
             num_pulses = 0;
             num_bPAC_pulses = 0;
             index_bPAC_pulse_start = [];
             index_bPAC_pulse_stop = [];
     for ii = 1:length(diff_bPAC_signal)
         
         if (diff_bPAC_signal(ii) > 0)
             index_bPAC_pulse_start(num_bPAC_pulses+1) = ii+1; % top of pulse (rise)
             num_bPAC_pulses = num_bPAC_pulses + 1;
         elseif (diff_bPAC_signal(ii) < 0)
             index_bPAC_pulse_stop(num_bPAC_pulses) = ii; % top of pulse (decline)
         end;
             
     end;
            if length(index_bPAC_pulse_stop) < length(index_bPAC_pulse_start)
                index_bPAC_pulse_stop(num_bPAC_pulses) = length(time_bPAC); 
            end;
            
            
            %  this calculates the end of each step-pulse that are all but
            %  the last in a step-up sequence
            if (num_bPAC_pulses > 1)
               for ii = 1:num_bPAC_pulses -1
                if (index_bPAC_pulse_stop(ii) == 0)
                   index_bPAC_pulse_stop(ii) = index_bPAC_pulse_start(ii+1)-1;
                end;
               end;
            end;
            

%  determine indexes of time_Erk that are within the bPAC pulse times
             index_bPAC_pulse_start_Erk = [];
             index_bPAC_pulse_stop_Erk = [];
     for ii = 1:num_bPAC_pulses
  
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_start(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_start(ii)) )
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy+1;         
          %else
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
          %end;
          index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         
          
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_stop(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_stop(ii)) )
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy;         
          %else
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy-1;          
          %end;
          index_bPAC_pulse_stop_Erk(ii) =  min(index_dummy+1,length(time_Erk));   % captures full experimental duration of pulse       
          
          
     end;
            
          % plots average signals
          sig_dummy_nuclear_average = zeros(1, length(time_Erk));
          sig_dummy_ratio_average = sig_dummy_nuclear_average;          
          ratio_signal = zeros(num_nuclei_t0,length(time_Erk));
     
num_bPAC_pulsing_cells = 0;            


%for idx = 1:num_nuclei_t0
idx 
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Pulse analysis 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     for ii = 1:num_bPAC_pulses     

         
         % TIME: time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,

         diff_time_Erk = diff(time_Erk)
         dt_pre_pulse = 4*60; 
         dt_pre_post = 5*60; 
         num_samps_pre = round(dt_pre_pulse/diff_time_Erk(2));
         num_samps_post = ceil(dt_pre_post/diff_time_Erk(2));
         
         %NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy);
         min_sig = min(sig_dummy);         
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig;
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)/min_sig;

          
          
          %shift_rise = 4; 
          shift_rise = 9;  % normal step response timescale (1 minute frame)
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));          
          % SETUP PULSE ANALYSIS HERE
          passed_pulse_test = 0; 

          epsilon_pulse_nucleus = .08;
          if pulse_dummy > epsilon_pulse_nucleus 
           passed_pulse_test = 1;
          end;
        else
            passed_pulse_test = 1
        end;
          
              
          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
          
         %RATIO OF NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;
          signal_dummy =  (sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig)
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)

          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          % Begin: calculate overshoot statistice
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %mean_sig_dummy_start_pre = mean(sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1));            
            %if (index_bPAC_pulse_stop_Erk(ii) + num_samps_post < length(sig_dummy))
            % mean_sig_dummy_end_post = mean(sig_dummy(index_bPAC_pulse_stop_Erk(ii)+1:index_bPAC_pulse_stop_Erk(ii)+num_samps_post));
            %else
            % mean_sig_dummy_end_post = mean_sig_dummy_start_pre;   
            %end;
         
           %[overshoot_dummy  index_overshoot_dummy] = max(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_start_Erk(ii)+num_samps_overshoot-1) - mean_sig_dummy_start_pre); 
           %[overshoot_whole_dummy  index_overshoot_whole_dummy] = max(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_start_Erk(ii)+num_samps_overshoot_whole-1) - mean_sig_dummy_start_pre); 
           %steady_state_dummy = mean(sig_dummy(index_bPAC_pulse_stop_Erk(ii)-num_samps_steady_state+1:index_bPAC_pulse_stop_Erk(ii))-mean_sig_dummy_end_post);
           %steady_state_dummy = abs(mean(sig_dummy(index_bPAC_pulse_stop_Erk(ii)-num_samps_steady_state+1:index_bPAC_pulse_stop_Erk(ii))-mean_sig_dummy_end_post));

           %overshoot_bPAC_pulse_cell(idx,ii) = overshoot_dummy;
           %index_overshoot_bPAC_pulse_cell(idx,ii) = index_overshoot_dummy+index_bPAC_pulse_start_Erk(ii)-1;
           %index_overshoot_whole_bPAC_pulse_cell(idx,ii) = index_overshoot_whole_dummy+index_bPAC_pulse_start_Erk(ii)-1;
           %time_overshoot_bPAC_pulse_cell(idx,ii) = index_overshoot_dummy;
           %time_overshoot_whole_bPAC_pulse_cell(idx,ii) = index_overshoot_whole_dummy;
           %steady_state_bPAC_pulse_cell(idx,ii) = steady_state_dummy;
           %ratio_overshoot_ss_bPAC_pulse_cell(idx,ii) = overshoot_dummy/steady_state_dummy;          
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          % End: calculate overshoot statistice
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
          
          %shift_rise = 4;  
          shift_rise = 9;  % normal step response timescale (1 minute frame)
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));
          
          epsilon_pulse_ratio = .08;
          if pulse_dummy > epsilon_pulse_ratio 
           passed_pulse_test = 1;
          end;
          % SETUP PULSE ANALYSIS HERE

          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
        else
           passed_pulse_test = 1;
        end;
          
          if (passed_pulse_test == 1)
              if (ii == 1)  %passed the first pulse only
              sig_dummy_nuclear_average = sig_dummy_nuclear_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))/double(min(nuclear_Erk_tot_time_mapped_t0_median(idx,:)));
              sig_dummy_ratio_average = sig_dummy_ratio_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));       
              ratio_signal(idx,:) = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));  
              end;
          end;
          
     end;     
    
   
     do_plot_stuff = 1; % 0 - no, 1 - yes
     if (do_plot_stuff == 1)
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Make plot of result 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     ii_plot_count = 0;
     figure(200)
     title(strcat('nuclear Erk signal (',Erk_str,')'));
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
     subplot(3,1,1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(ii_plot_count+1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig,s_pulse(ii));
               set(ss,'LineWidth',3);
     end;
     ylabel(strcat('(nuc-min(nuc))/max(nuc-min(nuc))'));
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+1.1*(max(sig_dummy/min_sig)-1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
           if (num_bPAC_pulses+1 == 1)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)));
           elseif (num_bPAC_pulses+1 == 2)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse'));
           elseif (num_bPAC_pulses+1 == 3)
            %lgnd = legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse 1'), strcat('signal during bPAC pulse 2'));
           end;
            %set(lgnd,'color','none');
           
       if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
           str_bPAC = ' (bPAC)';
           str_bPAC_eps = '-bPAC';
       else
           str_bPAC = ' (non-bPAC)';
           str_bPAC_eps = '-non-bPAC';
       end;
            
            
      if (num_bPAC_pulses == 1)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test =',num2str(bPAC_pulse_cell(idx,1))));
      elseif (num_bPAC_pulses == 2)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']'));
      elseif (num_bPAC_pulses == 3)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),';',num2str(bPAC_pulse_cell(idx,3)),']'));
      end;
      
     
     subplot(3,1,2) 
     hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(ii));
               set(ss,'LineWidth',3);
          % plot overshoot value and location
          if (bPAC_pulse_cell(idx,ii) == 1)&(ii==1)
          ss = plot(time_Erk(index_overshoot_whole_bPAC_pulse_cell(idx,ii))/scale_factor_time,sig_dummy(index_overshoot_whole_bPAC_pulse_cell(idx,ii)),'ko');
               set(ss,'LineWidth',3);
          elseif (bPAC_pulse_cell(idx,ii) == 1)&(ii==2)
          ss = plot(time_Erk(index_overshoot_whole_bPAC_pulse_cell(idx,ii))/scale_factor_time,sig_dummy(index_overshoot_whole_bPAC_pulse_cell(idx,ii)),'co');
               set(ss,'LineWidth',3);
          end;
     end;
     
     ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*max((max(sig_dummy)-min(sig_dummy)),.1)]);
     xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;

      if (max(bPAC_pulse_cell(idx,:)) > 0)
          sig_dummy_average_bPAC_pulse_cell = sig_dummy_average_bPAC_pulse_cell + sig_dummy;
          count_pulse_cell = count_pulse_cell + 1;
      end;



          subplot(3,1,3)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          
          
     
          %pause
          %figure(200)
          %cd(strcat('figures-',str_movie,'\cellular_signals_eps_statistics'));          
          %print('-depsc',strcat('nuc_',num2str(idx),str_bPAC_eps,'-Erk-',str_movie,'.eps'));   
          %cd ../../;
          %close(200)

           
     end; % end of 'if (do_plot_stuff == 1)'
%end; % for idx = 1:num_nuclei_t0






   
end;   % if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)
   
%end; % if (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)




