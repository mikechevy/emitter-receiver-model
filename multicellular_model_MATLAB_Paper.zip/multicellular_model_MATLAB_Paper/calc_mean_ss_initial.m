         for ii = 1:num_molecules
          species_cov(ii) = 1;
          species_cov_conj(ii) = 0;
          species_restricted(ii) = 0;
          species_restricted_conj(ii) = 1;
         end;
         for ii = 1:num_reactions
          stochasticity(ii) = 0;
          stochasticity_conj(ii) = 1;
         end;

  count_cov_map = 0;

  if (do_covariances == 1)
     for jj = 1:num_molecules

       %if ( ( species_cov(jj) == 1 )&( jj ~= 1)&(jj~=3) )
       %if ( ( species_cov(jj) == 1 )&( jj ~= 8 ) )
       if ( species_cov(jj) == 1 )
         for ii = jj:num_molecules
             if ( species_cov(jj)*species_cov(ii) == 1 )
                 covariance_map(count_cov_map+1,:) = [jj ii];
                 count_cov_map = count_cov_map + 1;

             end;
         end; % for ii
       end;
     end; % for jj
          
     index_of_covariance_map = zeros(num_molecules,num_molecules);

     for ii = 1:count_cov_map
               index_1 = covariance_map(ii,1);
               index_2 = covariance_map(ii,2);

               index_of_covariance_map(index_1 , index_2) = ii;  %  C_jj_ii
               index_of_covariance_map(index_2 , index_1) = ii;  %  C_ii_jj
      end;
     
  end;

length_x_moms = num_molecules + count_cov_map + 1;


cd gillespie_code;

x_0_mean = y_0_ma;  % use the mass-action input
x_0_mean = x_0_mean(1:num_molecules);
x_0_mean = [x_0_mean zeros(1,length(covariance_map))];
%x_0_mean = [x_0_mean zeros(1,length(covariance_map)+1)];


if (do_cell_cycle_effects == 1)
  x_0_mean = y_0_ma;    
end;

     % calculate stationary initial conditions
     if (do_initial_conditions==1)&(done_do_initial_conditions==0)
          if (do_pathway_specific_function==1)
            cd(strcat('../',pathway_str));
             pathway_specific_function
            cd ../../gillespie_code;
          end;
      if (do_include_moment_data == 0)
           [time_mean, x_mean] = ode15s('moments_unrestricted',[0 t_ss],x_0_mean',options);
      elseif (do_include_moment_data==1)
           [time_mean, x_mean] = ode15s('moments_ss_with_data_t0',[0 t_ss],x_0_mean',options);
      end;
            x_0_mean = x_mean(length(time_mean),:);
            clear x_mean;
            clear time_mean;
     end;

cd ../;
