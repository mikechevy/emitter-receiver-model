do_make_movie = 1;  % 1 - yes, 0 - no

    % set initial values
    x_coord_min = 1;
    x_coord_max = xLength;
    y_coord_min = 1;
    y_coord_max = yLength
    fac_max = 1;


M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
    
    
scale_factor_time = 60;  % minutes

channel_make_movie = ii_CH1;
%channel_make_movie = ii_NM;
%channel_make_movie = ii_NM_bPAC;

found_file_BOX = fileattrib(strcat(str_movie_processed,'\x_y_box_fac_max.mat'))

if (found_file_BOX == 1)
    load(strcat(str_movie_processed,'\x_y_box_fac_max.mat'));
end;
    
time_Erk = time_CH1

          
which_channel = 1;    
which_frame_CH = 1;
M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(:,:,:)']))))*int16(ones(xLength,yLength));
 test_box = [];       
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN:iteratively setup the range of interest
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
              rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  test_box = input('does the box size work? 1-for yes,otherwise hit return')
  
 while (length(test_box)==0)          
  x_coord_min = input(strcat('please set x_min of image (current value:',num2str(x_coord_min),'):'));
  x_coord_max = input(strcat('please set x_max of image (current value:',num2str(x_coord_max),'):'));
  y_coord_min = input(strcat('please set y_min of image (current value:',num2str(y_coord_min),'):'));
  y_coord_max = input(strcat('please set y_max of image (current value:',num2str(y_coord_max),'):'));
  %[x_coord_min x_coord_max y_coord_min y_coord_max] = input('please set range of image')
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
              rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  test_box = input('does the box size work? 1-for yes,otherwise hit return.')
 end;


 test_fac_max = [];       
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
              rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  test_fac_max  = input('does the intensity range work? 1-for yes,otherwise hit return.')

 while (length(test_fac_max)==0)          
  fac_max = input(strcat('please set fac_max between 0 and 1 (current value:',num2str(fac_max),'):'));
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
              rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  test_fac_max  = input('does the intensity range work? 1-for yes,otherwise hit return.')
 end;

 save(strcat(str_movie_processed,'\x_y_box_fac_max.mat'),'x_coord_min','x_coord_max','y_coord_min','y_coord_max','fac_max')

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % END: iteratively setup the range of interest
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN: FIND Nuclei within the BOX
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (length(num_nuclei_t0) > 0) 
 label_cluster_only = 0; % 1 - yes, 0 - no
if (label_cluster_only == 1)
    index_group = zeros(length(size_cluster(which_cluster)),1);
for iii = 1:size_cluster(which_cluster)
      index_group(iii) = cluster(which_cluster,iii); 
end;
else % label all cells within the box
  ii_count = 0;
index_group = [];
which_frame = 1;
 for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,which_frame) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,which_frame) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,which_frame) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,which_frame) <= y_coord_max)
      index_group = [index_group ; iii]; 
      ii_count = ii_count+1;
    end;% end;
end;
end;
end; % if (length(num_nuclei_t0) > 0) 


 
 
 
if (length(ii_NM_bPAC) == 1)
 which_channels = [ii_CH1 ii_NM ii_NM_bPAC];
else
 which_channels = [ii_CH1 ii_NM];
end;
 which_channels = [signal_channels ii_NM ii_NM_bPAC];;

frame_direction = 1;  % start in the up direction

%for ppp = 1:length(which_channels);

for kk = 1:length(which_channels)
    
    which_channel = which_channels(kk);
    which_frame_CH = 1;
    which_frame = 1;
    
           if (do_make_movie == 1)
            if (which_channel == ii_CH1)
              filename_movie = strcat(str_movie_processed,'\CH1_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channel == ii_CH2)
              filename_movie = strcat(str_movie_processed,'\CH2_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channel == ii_NM)
              filename_movie = strcat(str_movie_processed,'\CH_NUCLEI_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channel == ii_NM_bPAC)
              filename_movie = strcat(str_movie_processed,'\CH_NUCLEI_bPAC_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
%            elseif (which_channel == ii_CH4)
%              filename_movie = strcat(str_movie_processed,'\CH4_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
%            elseif (channel_make_movie == ii_NM)
%              filename_movie = strcat(str_movie_processed,'\NM_movie_',str_movie);
%            elseif  (channel_make_movie == ii_NM_bPAC)
%              filename_movie = strcat(str_movie_processed,'\NM_bPAC_movie_',str_movie);
            end;
          delete(strcat(filename_movie,'.avi'));
          %mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',floor(numFr_CH(ii_CH1)/20));
          mov = VideoWriter(strcat(filename_movie,'.avi'));%,'COMPRESSION','None','FPS',floor(numFr_CH(ii_CH1)/20));
          mov.FrameRate = 10;
          end;
open(mov);
    
    
    
  if (kk > 1) 
      
    M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(x_coord_min:x_coord_max,y_coord_min:y_coord_max,which_frame)']))))*int16(ones(xLength,yLength));
    fac_max = 1;
    imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
                rectangle('Position', [y_coord_min,x_coord_min,...
                        y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                       'EdgeColor', 'm');
      
    test_fac_max  = input('does the intensity range work? 1-for yes,otherwise hit return.')

   while (length(test_fac_max)==0)          
    fac_max = input(strcat('please set fac_max between 0 and 1 (current value:',num2str(fac_max),'):'));
    imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
                rectangle('Position', [y_coord_min,x_coord_min,...
                        y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                       'EdgeColor', 'm');
   test_fac_max  = input('does the intensity range work? 1-for yes,otherwise hit return.')
   end;
  end;
    


for ii = 1:numFr_CH(which_channel)

which_frame = ii;



    eval(['[val,which_frame_NM]= min(abs(time_CH',num2str(which_channel),'(which_frame)-time_CH',num2str(ii_NM),'));']);     


M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(x_coord_min:x_coord_max,y_coord_min:y_coord_max,which_frame)']))))*int16(ones(xLength,yLength));

    ii_figure = 1000+which_channel
    %if (which_channel == channel_make_movie)
      H = figure(1000+which_channel)  
    %else
    %  figure(1000+which_channel)  
    %end;
  
    which_frame
    numFr_CH(which_channel)

    eval(['[val,which_frame_CH]= min(abs(time_CH',num2str(which_channel),'(which_frame)-time_CH',num2str(which_channel),'));']);     
    

    %if (length(which_channels) == 2)|(ii_NM == ii_NM_bPAC)
      subplot(5,2,[1:8]);      
      %subplot(4,2,[1:6]);
    %elseif (length(which_channels) == 3)
    %  subplot(2,2,kk);
    %end;
      
        
  %imagesc(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame),fac_max*M_max)']));
  if kk <= length(signal_channels)
   imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
  elseif (which_channels(kk) == ii_NM) % movie of emitter/receiver nuclei
       eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(ii_NM),'(which_frame_CH)-time_CH',num2str(ii_NM_bPAC),'));']);     
       eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
       eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,which_frame);']);
    
       image_RGB = zeros(xLength,yLength,3);
       image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
       image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
       imshow(image_RGB)
  elseif (which_channels(kk) == ii_NM_bPAC) % movie of emitter/receiver nuclei
   imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
  end;
  if (length(num_nuclei_t0)>0)
     hold on;                 
    for jjj = 1:length(index_group)
       idx = index_group(jjj);
       
    eval(['[val,which_frame_NM]= min(abs(time_CH',num2str(which_channel),'(which_frame)-time_CH',num2str(ii_NM),'));']);     
       
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame_NM);
       
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             %set(ll,'Color','m');

             
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),strcat(num2str(idx)));
             %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),'.');
             if ii_NM == ii_NM_bPAC  % all bPAC cells
               set(tt,'Color','w');
               %set(tt,'fontsize',12);
             else
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
                if (which_channel == ii_NM_bPAC)
                 set(tt,'Color','m');
                else
                 set(tt,'Color','w');
                end;
               else
               set(tt,'Color','y');
               end;
             end;
    end;
   hold off;  
  end;   % end of 'if (length(num_nuclei_t0)>0)'
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

  
 % if (marker_from_channel(ii_Erk_marker)>0)&(ii == 1)
 %     title(strcat('Erk signal',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % elseif (marker_from_channel(ii_Ca_marker)>0)&(ii == 1)
 %     title(strcat('Erk signal',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % elseif (ii == 2)
 %     title(strcat('Nuclear marker',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % elseif (ii_NM~=ii_NM_bPAC)&(ii == 3)
 %     title(strcat('bPAC marker',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % end;
      
  
  
      subplot(5,2,[9 10]);
      %subplot(4,2,[7 8]);
      ylabel('bPAC');
      hold on;
      plot(time_bPAC/scale_factor_time,bPAC_ledvals);
       if (which_channel == ii_CH1)
         plot([time_CH1(which_frame)/scale_factor_time time_CH1(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       elseif (which_channel == ii_CH2)
         plot([time_CH2(which_frame)/scale_factor_time time_CH2(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       elseif (which_channel == ii_CH3)
         plot([time_CH3(which_frame)/scale_factor_time time_CH3(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       elseif (which_channel == ii_CH4)
         plot([time_CH4(which_frame)/scale_factor_time time_CH4(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       end;
      hold off;
      
      xlim([0 max(time_CH1)/scale_factor_time]);
      ylim([0 1.1*max(bPAC_ledvals)]);
      xlabel('minutes');

    if (do_make_movie == 1)%&(which_channel == channel_make_movie)
    %H = gcf;
    F = getframe(H);                    
    %mov = addframe(mov,F);
    writeVideo(mov,F);
    end;
  
    if (do_make_figure == 1)%&(which_channel == channel_make_movie)    
  
       if min(abs(which_frame-which_frames_to_save))==0
           
         if kk <= length(signal_channels)
           print(strcat(str_movie_processed,'\CH',num2str(which_channel),'_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie,'_which_frame',num2str(which_frame),'.eps'),'-depsc');
         elseif (which_channels(kk) == ii_NM) % movie of emitter/receiver nuclei
           print(strcat(str_movie_processed,'\CH_NUCLEI_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie,'_which_frame',num2str(which_frame),'.eps'),'-depsc');
         end;
       
       end;
       
    end;
    
    
    close(ii_figure)
   
end;



  
end;

%end;  % for ppp = 1:length(which_channels);


             %mov = close(mov)
             close(mov)
