global x_current;
global num_molecules;
global stochasticity;
global stochasticity_eq;
global stochasticity_conj;
global num_reactions;
%global reaction_constant;
global propensities;
global sign_value_reaction;
global reaction_type;
global reaction_molecules;
global c_mu;
global x_ref;
global kappa;
global passed_constants;

        
cd gillespie_code;


% set max number of reactions and time
max_count_reactions = 8000;  %  max number of  reactions
max_time = max_time + t_max; % seconds
time_start = time;

% run the gillespie algorithm
 if (which_gillespie == 0)
   gillespie;
 elseif (which_gillespie == 1)
   gillespie_hybrid_old;  % this runs only the zeroth order hybrid algorithm
 elseif (which_gillespie == 2)
   gillespie_hybrid_test;  % this runs the hybrid algorithm from Mike's hybrid paper
 elseif (which_gillespie == 3)
   gillespie_NMSSA;  % NMSSA
 end;
 
% Calculate the same system using the mass-action equations

x_0_mean = y_g; % use the gillespie input

% for non-stiff systems
%[time_mean, x_mean] = ode45('mean_theory',[time_start time],x_0_mean');
% for stiff_systems
[time_mean, x_mean] = ode23t('mean_theory',[time_start time],x_0_mean');

cd ../
