%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Andrew's differential equation (emitter/receiver duo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           #Sender cell
%            d x[0]/dt =    Kb*1*on + ACmax*KD_cAMP/(KD_cAMP + factAC * x[2]) - Ka1*x[0]**4*x[1] - fact_Pc*Kdeg_Pc*x[4]/(KD_Pc + x[4])*x[0] - Kdeg_c*x[0] - Kdiff*x[0] + Kdiff*x[5],
%            d x[1]/dt = fact_PP*Kdeg_PP*x[4]/(KD_PP + x[4])*x[2] + KD1 * x[2] - Ka1*x[0]**4*x[1],
%            d x[2]/dt =  Ka1*x[0]**4*x[1] - fact_PP*Kdeg_PP*x[4]/(KD_PP + x[4])*x[2] - KD1 * x[2],
%            d x[3]/dt =   KD2*x[4] - Ka2*x[2]*x[3],
%            d x[4]/dt =   Ka2*x[2]*x[3] - KD2*x[4],
%           #Receiver cell
%            d x[5]/dt =    ACmax*KD_cAMP/(KD_cAMP + factAC * x[7]) - Ka1*x[5]**4*x[6] - fact_Pc*Kdeg_Pc*x[9]/(KD_Pc + x[9])*x[5] - Kdeg_c*x[5] - Kdiff*x[5] + Kdiff*x[0],
%            d x[6]/dt =    fact_PP*Kdeg_PP*x[9]/(KD_PP + x[9])*x[7] + KD1 * x[7] - Ka1*x[5]**4*x[6],
%            d x[7]/dt =    Ka1*x[5]**4*x[6] - fact_PP*Kdeg_PP*x[9]/(KD_PP + x[9])*x[7] - KD1 * x[7],
%            d x[8]/dt =    KD2*x[9] - Ka2*x[7]*x[8],
%            d x[9]/dt =    Ka2*x[7]*x[8] - KD2*x[9]
%
%            x[0] = cAMP
%            x[1] = PKA_off
%            x[2] = PKA_on
%            x[4] = PDE_off
%            x[5] = PDE_on
%
%            EQUATIONS:
%            d [cAMP]/dt =    Kb*[I_bPAC] + ACmax*KD_cAMP/(KD_cAMP + factAC * [PKA_on]) - Ka1*[cAMP]**4*[PKA_off] - fact_Pc*Kdeg_Pc*[PDE_on]/(KD_Pc + [PDE_on])*[cAMP] - Kdeg_c*[cAMP] - Kdiff*[cAMP,this cell] + Kdiff*[cAMP,other cells],
%            d [PKA_off]/dt = fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*x[2] + KD1 * [PKA_on] - Ka1*[cAMP]**4*x[PKA_off],
%            d [PKA_on]/dt =  Ka1*[cAMP]**4*[PKA_off] - fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*[PKA_off] - KD1 * [PKA_on],
%            d [PDE_off]/dt =   KD2*[PDE_on] - Ka2*[PKA_on]*[PDE_off],
%            d [PDE_on]/dt =   Ka2*[PKA_on]*[PDE_off] - KD2*[PDE_on],
%
%            biochemical reactions/ propensities
%            1.  0 -> cAMP ,   Kb*x[ii_I_bPAC]*is_bPAC_cell
%            2.  0 -> cAMP ,   ACmax*KD_cAMP/(KD_cAMP + x[ii_PKA_on]), for PKA feedback  or just ACmax for no PKA feedback 
%            3.  cAMP + PKA_off -> PKA_on ,   Ka1*x[ii_cAMP]^4 * x[ii_PKA_off],     activation of PKA through cAMP
%            4.  cAMP -> 0 ,   fact_Pc*Kdeg_Pc*x[ii_PDE_on]/(KD_Pc + x[ii_PDE_on])*x[ii_cAMP], PDE_on feedback 
%            5.  cAMP -> 0 ,   Kdeg_c*x[ii_cAMP],    basal degradation
%            6.  PKA_on -> PKA_off       fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*x[2],  PDE_on dependent inactivation of PKA_on
%            7.  PKA_on -> PKA_off       KD1 * [PKA_on],  basal inactivation of PKA_on
%            8.  PDE_off -> PDE_on       Ka2*[PKA_on]*[PDE_off],
%            9.  PDE_on -> PDE_off       KD2*[PDE_on],
%
%            cell-cell coupling/propensities
%            10.  cAMP (cell i) -> cAMP (cell j) ,  Kdiff*x[ii_cAMP (cell i)], diffusion of cAMP from cell i to cell j
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 %  cAMP/PKA/ERK circuit in each cell         
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 for ii = 1:num_cells
    
   % reaction 1:  0 -> cAMP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % I_bPAC is the input species 
     which_mol = ii_I_bPAC;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_c_b*bPAC_NUCLEUS_time_mapped_t0(index_group(ii),1);

   if (fac_ac_pk == 0)
   % reaction 2:  0 -> cAMP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 1;
   % no the input species 
   % 1 caMP molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_c_ac*(1+alpha_bPAC_basal*bPAC_NUCLEUS_time_mapped_t0(index_group(ii),1));
   elseif (fac_ac_pk == 1)
   % reaction 2:  0 -> cAMP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 31;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_c_ac*(1+alpha_bPAC_basal*bPAC_NUCLEUS_time_mapped_t0(index_group(ii),1));
     a_0(which_reaction) = n_ac_pk; 
     a_1(which_reaction) = KD_ac_pk; 
    end;

   do_old_PKA_on = 1;
   if (do_old_PKA_on == 1)
   % reaction 3:  cAMP + PKA_off -> PKA_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 81;
   % cAMP,PKA_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species2) = which_mol;
   %  PKA_off molecules lost, 1 PKA_on molecule gained
     %%which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;   % old andrew does not scale arbitrarily
     %%sign_value = -1; % old andrew does not scale arbitrarily
     %%sign_value_reaction(which_reaction,which_mol) = sign_value; % old andrew does not scale arbitrarily
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = (1-fac_I_H89)*beta_pk_c;
     a_0(which_reaction) = n_pk_c; 
     %a_1(which_reaction) = KD_cAMP_PKA; 
   elseif (do_old_PKA_on == 0)
   % reaction 3:  cAMP + PKA_off -> PKA_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PKA_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 cAMP, PKA_off molecules lost, 1 PKA_on molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = (1-fac_I_H89)*beta_pk_c*power(KD_pk_c,n_pk_c);
     a_0(which_reaction) = n_pk_c; 
     a_1(which_reaction) = KD_pk_c; 
     end;

   % reaction 4:  cAMP  -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PDE_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 cAMP lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = (1-fac_I_IBMX)*fac_c_pd*gamma_c_pd;  % upregulated PDE-dependent decay of cAMP 
     a_0(which_reaction) = n_c_pd; 
     a_1(which_reaction) = KD_c_pd; 


   % reaction 5:  cAMP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % cAMP is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = (1-fac_I_IBMX)*gamma_c_pd_basal;  % basal PDE-dependent decay of cAMP

   % reaction 6:  cAMP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % cAMP is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_c_basal;  % basal non-PDE decay of cAMP
     
     
   % reaction 7:  PKA_on -> PKA_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PDE_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 PKA_on lost, 1 PKA_off gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = fac_pk_pd*gamma_pk_pd;
     a_0(which_reaction) = n_pk_pd; 
     a_1(which_reaction) = KD_pk_pd; 

   % reaction 8:  PKA_on -> PKA_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_pk;

   % reaction 9:  PDE_off -> PDE_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 3;
   % PDE_off,PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_pd_pk;


   % reaction 10:  PDE_on -> PDE_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_pd;

     
     
   % reaction 11:  Erk_on -> Erk_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PKA_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 Erk_on molecules lost, 1 Erk_off molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_e_c;
     a_0(which_reaction) = n_e_c; 
     a_1(which_reaction) = KD_e_c; 
     
   % reaction 12:  Erk_on -> Erk_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % ERK_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 ERK_on molecule is lost, 1 ERK_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_e_basal;

   % reaction 13:  Erk_off -> Erk_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % ERK_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 ERK_off molecule is lost, 1 ERK_on molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = k_e_basal;
     
   % reaction 14:  ERKKTR_n -> EKRKTR_c
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 3;
   % PDE_off,PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_n;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_n;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_c;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = k_ek_e;

     
   % reaction 15:  ERKKTR_c -> ERKKTR_n
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_c;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_c;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_n;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_ek_basal;

     
   if (num_gjc_delay_steps == 0) 
       
   % reaction 16:  GJ_complex_off -> GJ_complex_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % PKA_on, ii_GJ_complex_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 ii_GJ_complex_off molecules lost, 1 GJ_complex_on molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_pk;
     a_0(which_reaction) = n_gjc_pk; 
     a_1(which_reaction) = KD_gjc_pk; 
  
   elseif (num_gjc_delay_steps > 0) 
   do_PKA_GJ = 0;
if do_PKA_GJ == 0  
    
   % reaction 16:  GJ_complex_off -> GJ_complex_on_1
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % PKA_on, ii_GJ_complex_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 ii_GJ_complex_off molecules lost, 1 ii_GJ_complex_on_1 molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_on_1;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_pk;
     a_0(which_reaction) = n_gjc_pk; 
     a_1(which_reaction) = KD_gjc_pk; 

elseif do_PKA_GJ == 1       

   % reaction 16:  PKA_on + GJ_complex_off -> PKA_on + GJ_complex_on_1
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % GJ_complex_on_i is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 GJ_complex_off molecule is lost, 1 GJ_complex_on_1 molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_on_1;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_pk;
end;
     
     
   for ii_gjc = 1:num_gjc_delay_steps-1     
   % reaction 17:  GJ_complex_on_i -> GJ_complex_on_i+1
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % GJ_complex_on_i is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ_complex_on_',num2str(ii_gjc)));
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 GJ_complex_on_i molecule is lost, 1 GJ_complex_on_i+1 molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ_complex_on_',num2str(ii_gjc)));
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ_complex_on_',num2str(ii_gjc+1)));
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_delay_steps;
   end;
     
   % reaction 18:  GJ_complex_on_N -> GJ_complex_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ_complex_on_',num2str(num_gjc_delay_steps)));
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ_complex_on_',num2str(num_gjc_delay_steps)));
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_delay_steps;
     
   end;

   % reaction 19:  GJ_complex_on -> GJ_complex_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ_complex_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_gjc_basal;



   
   if (do_GJ2==1)
       
   if (num_gjc2_delay_steps == 0) 
       
   % reaction 20:  GJ2_complex_off -> GJ2_complex_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % PKA_on, ii_GJ2_complex_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 ii_GJ2_complex_off molecules lost, 1 GJ2_complex_on molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_pk;
     a_0(which_reaction) = n_gjc_pk; 
     a_1(which_reaction) = KD_gjc_pk; 
  
   elseif (num_gjc2_delay_steps > 0) 
   do_PKA_GJ = 0;
if do_PKA_GJ == 0  
    
   % reaction 20:  GJ2_complex_off -> GJ2_complex_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % PKA_on, ii_GJ2_complex_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 ii_GJ2_complex_off molecules lost, 1 ii_GJ2_complex_on_1 molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_on_1;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_pk;
     a_0(which_reaction) = n_gjc_pk; 
     a_1(which_reaction) = KD_gjc_pk; 

elseif do_PKA_GJ == 1       

   % reaction 20:  PKA_on + GJ2_complex_off -> PKA_on + GJ2_complex_on_1
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % GJ_complex_on_i is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 GJ2_complex_off molecule is lost, 1 GJ2_complex_on_1 molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_on_1;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc_pk;
end;
     
     
   for ii_gjc2 = 1:num_gjc2_delay_steps-1     
   % reaction 21:  GJ2_complex_on_i -> GJ2_complex_on_i+1
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % GJ2_complex_on_i is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ2_complex_on_',num2str(ii_gjc2)));
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 GJ2_complex_on_i molecule is lost, 1 GJ2_complex_on_i+1 molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ2_complex_on_',num2str(ii_gjc2)));
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ2_complex_on_',num2str(ii_gjc2+1)));
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc2_delay_steps;
   end;
     
   % reaction 22:  GJ2_complex_on_NUM_STEPS -> GJ2_complex_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ2_complex_on_',num2str(num_gjc_delay_steps)));
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+eval(strcat('ii_GJ2_complex_on_',num2str(num_gjc_delay_steps)));
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_gjc2_delay_steps;
     
   end;
       
     
     
   % reaction 23:  GJ2_complex_on -> GJ2_complex_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_GJ2_complex_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_gjc2_basal;
     
   end;  %   if (do_GJ2==1)
     
 end; % for ii = 1:num_cells


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  cell-to-cell coupling
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 for ii = 1:num_cells
    
     for jj = 1:num_cells

         if (mat_cAMP_gap(ii,jj) == 1)

           % reaction 24:  a cAMP molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction:
             reaction_type(which_reaction) = 80;
           % an cAMP from both cells ii and jj ,and I_cAMP_gap are is the input species
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species3) = which_mol;
           % 1 cAMP molecule from cell ii lost, 1 cAMP molecule from cell jj gained
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = k_diff_c_basal;
             
             a_0(which_reaction) = x_flux_max_basal;
 
             
          if (fac_gj_pk == 1)

          if (do_GJ_complex == 0)    

           % reaction 25:  a cAMP molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction:
             reaction_type(which_reaction) = 82;
           % an cAMP from both cells ii and jj ,and I_cAMP_gap are is the input species
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = (ii-1)*(num_molecules_cell) + ii_PKA_on;
             reaction_molecules(which_reaction,species3) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_PKA_on;
             reaction_molecules(which_reaction,species4) = which_mol;
               species5 = 5;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species5) = which_mol;               
           % 1 cAMP molecule from cell ii lost, 1 cAMP molecule from cell jj gained
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = k_diff_c_gj_pk;
             
             a_0(which_reaction) = n_gj_pk;
             a_1(which_reaction) = KD_gj_pk;
             a_2(which_reaction) = x_flux_max_gj_pk;
             a_3(which_reaction) = fac_gj_flux_MOD;
             
          elseif (do_GJ_complex == 1)    
           % reaction 25:  a cAMP molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction:
             reaction_type(which_reaction) = 82;
           % an cAMP from both cells ii and jj ,and I_cAMP_gap are is the input species
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = (ii-1)*(num_molecules_cell) + ii_GJ_complex_on;
             reaction_molecules(which_reaction,species3) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_GJ_complex_on;
             reaction_molecules(which_reaction,species4) = which_mol;
               species5 = 5;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species5) = which_mol;               
           % 1 cAMP molecule from cell ii lost, 1 cAMP molecule from cell jj gained
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = k_diff_c_gj_gjc;
             
             a_0(which_reaction) = n_gj_gjc;
             a_1(which_reaction) = KD_gj_gjc;
             a_2(which_reaction) = x_flux_max_gj_gjc;
             a_3(which_reaction) = fac_flux_MOD_gj_gjc;
             a_4(which_reaction) = N_coupled(ii);  % partition
             a_5(which_reaction) = N_coupled(jj);  % partition

             
          if (do_GJ2 == 1)
             % reaction 26:  a cAMP molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction:
             reaction_type(which_reaction) = 82;
           % an cAMP from both cells ii and jj ,and I_cAMP_gap are is the input species
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = (ii-1)*(num_molecules_cell) + ii_GJ2_complex_on;
             reaction_molecules(which_reaction,species3) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_GJ2_complex_on;
             reaction_molecules(which_reaction,species4) = which_mol;
               species5 = 5;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species5) = which_mol;               
           % 1 cAMP molecule from cell ii lost, 1 cAMP molecule from cell jj gained
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = k_diff_c_gj_gjc;
             
             a_0(which_reaction) = n_gj_gjc;
             a_1(which_reaction) = KD_gj_gjc;
             a_2(which_reaction) = x_flux_max_gj_gjc;
             a_3(which_reaction) = fac_flux_MOD_gj_gjc;
             a_4(which_reaction) = N_coupled(ii);  % partition
             a_5(which_reaction) = N_coupled(jj);  % partition
   
            end; % if (do_GJ2 == 1)

          end;
             
             
          end;



         end;

%         if (mat_Calcium_gap(ii,jj) == 1)
%
%           % reaction 11:  a Calcium molecule from cell ii diffuses to cell jj
%              which_reaction = last_reaction+1;
%              last_reaction = last_reaction+1;
%           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
%             stochasticity(which_reaction) = 1;
%           % type of reaction:
%             reaction_type(which_reaction) = 80;
%           % an cAMP from both cells ii and jj ,and I_Calcium_gap are is the input species
%             which_mol = (ii-1)*(num_molecules_cell) + ii_Calcium;
%             reaction_molecules(which_reaction,species1) = which_mol;
%             which_mol = ii_I_Calcium_gap;
%             reaction_molecules(which_reaction,species2) = which_mol;
%           % 1 Calcium molecule from cell ii lost, 1 Calcium molecule from cell jj gained
%             which_mol = (ii-1)*(num_molecules_cell) + ii_Calcium;
%             sign_value = -1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%             which_mol = (jj-1)*(num_molecules_cell) + ii_Calcium;
%             sign_value = 1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%           % reaction_constant
%             c_mu(which_reaction) = k_diff_Ca;
%
%
%
%         end;

     end; % for jj = 1:num_cells
 end; % for ii = 1:num_cells



           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %  time dependent inputs
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

           % reaction 27:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_bPAC;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;

           % reaction 28:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;

           % reaction 29:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_Calcium_gap;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;


           % reaction 30:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_IBMX;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;


           % reaction 31:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_H89;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;

