function [box_coords_out,M_marker_threshold_out] = separateTouchingNuclei(M_marker_threshold,M_marker,box_coords, threshold, nucleus_min_pixels,mean_pix,std_pix,min_min_M_marker,max_max_M_marker)


global fac_std_nuclear_size;


max_separate_nuclei = 20;
    
box_coords_new = zeros(max_separate_nuclei,4);

    M_marker_threshold_TEST = 0*M_marker_threshold;    
    M_marker_threshold_FILL = 0*M_marker_threshold;    
    
M_marker_NORMALIZED = double(M_marker-min_min_M_marker)/double(max_max_M_marker-min_min_M_marker);
   
                 x_coord_min = box_coords(1);
                 x_coord_max = box_coords(2);
                 y_coord_min = box_coords(3);
                 y_coord_max = box_coords(4);


num_nuclei_separate_array = [];

threshold_max = max(max(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
num_iterations_threshold = 10;
delta_threshold = (threshold_max-threshold)/num_iterations_threshold;
threshold_test = threshold;



ii_threshold = 1;
    threshold_test = threshold + ii_threshold*delta_threshold;
    M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold_test);
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = bwareaopen(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max), nucleus_min_pixels);  % removie 
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');    
    Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    num_nuclei_separate_array = [num_nuclei_separate_array ;length(cellfun(@numel,Cell_marker_FILL.PixelIdxList))];
ii_threshold = 2;
    
not_done = 1; % 1-yes, 0-no
while (threshold_test < threshold_max)&(not_done == 1)

    threshold_test = threshold + ii_threshold*delta_threshold;

    M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold_test);
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = bwareaopen(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max), nucleus_min_pixels);  % removie 
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');    
    Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    num_nuclei_separate_array = [num_nuclei_separate_array ;length(cellfun(@numel,Cell_marker_FILL.PixelIdxList))];

     if (num_nuclei_separate_array(ii_threshold) < num_nuclei_separate_array(ii_threshold-1))
         not_done = 0;
     end;
                           
 ii_threshold = ii_threshold + 1;             
              
end % END OF: while (ii_threshold <=num_iterations_threshold)&(all_nuclei_separated == 0)

[val,index_max] = max(num_nuclei_separate_array);

     % redo with the final threshold;
    threshold_test = threshold + index_max*delta_threshold;

    M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_marker_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold_test);
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = bwareaopen(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max), nucleus_min_pixels);  % removie 
    M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');    
    Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    num_nuclei_separate = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));



 
               box_coords_out = box_coords;
               num_nuclei_out = num_nuclei_separate;  
               M_marker_threshold_out = M_marker_threshold_FILL; 


          
