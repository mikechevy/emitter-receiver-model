
       for ii_x_g_i = 1:length(time_g_interp);
         count_x_g = 1;
         while (time_g(count_x_g)<time_g_interp(ii_x_g_i))&(count_x_g<length(time_g))
           count_x_g = count_x_g+1;
         end;

         if (count_x_g ==1)|(count_x_g==length(time_g))
              x_g_interp(ii_x_g_i,:) = x_g_interp(ii_x_g_i,:) + x_g(count_x_g,:);
         else
             weight_lo = (time_g(count_x_g)-time_g_interp(ii_x_g_i))/(time_g(count_x_g)-time_g(count_x_g-1));
             weight_hi = (time_g_interp(ii_x_g_i)-time_g(count_x_g-1))/(time_g(count_x_g)-time_g(count_x_g-1));
              x_g_interp(ii_x_g_i,:) = x_g_interp(ii_x_g_i,:) + weight_hi*x_g(count_x_g,:)+weight_lo*x_g(count_x_g-1,:);
         end;
       end;

