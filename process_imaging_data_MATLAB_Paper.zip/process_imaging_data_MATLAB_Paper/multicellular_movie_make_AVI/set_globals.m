
global ii_xcorr;
global ii_physical_distance;
global length_per_pixel;
global seconds_per_frame;
global ii_nuclear_marker;
global ii_bPAC_marker;
global ii_Erk_bPAC_marker;
global ii_Ca_marker;
global ii_Erk_marker;
global ii_Creb_marker;
global num_different_markers;

global fac_std_nuclear_size;
global fac_std_nuclear_size_recursive;
global num_throwout;
global num_throwout_max;

global nucleus_min_pixels;

%  adaptive threshold local dimensions
global delta_xDim;
global delta_yDim;
global delta_xDim_step;
global delta_yDim_step;

%  time values of the movie
global time_sequence_movie;
global sample_sequence;
global num_sample_sequence;
global tau_sample_movie;
global dt_sample_movie;

global which_movie;


% global settings, these particular variables should't change during the run
length_per_pixel = 1;  % micrometers
ii_physical_distance = 1;  % metric index
ii_xcorr = 2;  % metric index;
seconds_per_frame = 30;

%  current indexes for markers in the array 'marker_from_channel'
ii_nuclear_marker = 1;
ii_bPAC_marker = 2;
ii_Ca_marker = 3;
ii_Erk_marker = 4;
ii_Creb_marker = 5;
ii_Pka_marker = 6;
ii_Erk_bPAC_marker = 7;

num_different_markers = 10;  % currently the max number of markers


