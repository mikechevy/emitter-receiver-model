 
which_frame
tic  
[mean_x_tot_NM,mean_y_tot_NM,var_x_tot_NM,var_y_tot_NM,cov_xy_tot_NM,box_coords_NM,num_pixels_tot_NM,num_NM,M_NM_threshold,M_NM_id_threshold,M_NM_threshold_FILL,Cell_NM_FILL,threshold_NM] = determine_nuclear_locations_adaptive_recursive(M_NM,which_frame,xLength,yLength,nucleus_min_pixels,M_S1,M_S2,do_threshold_fac_adjust);

 if which_frame == 1
    num_pixels_tot_NUCLEUS_time = zeros(2*num_NM, numFr_NM);
    mean_x_tot_time = zeros(2*num_NM, numFr_NM);
    mean_y_tot_time = zeros(2*num_NM, numFr_NM);
    var_x_tot_time = zeros(2*num_NM, numFr_NM);
    var_y_tot_time = zeros(2*num_NM, numFr_NM);
    cov_xy_tot_time = zeros(2*num_NM, numFr_NM);
    num_nuclei_time = zeros(numFr_NM,1);         
     x_coord_min_tot_time = zeros(2*num_NM, numFr_NM);
     x_coord_max_tot_time = zeros(2*num_NM, numFr_NM);
     y_coord_min_tot_time = zeros(2*num_NM, numFr_NM);
     y_coord_max_tot_time = zeros(2*num_NM, numFr_NM);
 end;
num_nuclei_max = max(num_nuclei_max,num_NM);
toc

     num_pixels_tot_NUCLEUS_time(1:num_NM,which_frame) = num_pixels_tot_NM(1:num_NM);
     mean_x_tot_time(1:num_NM,which_frame) = mean_x_tot_NM(1:num_NM);
     mean_y_tot_time(1:num_NM,which_frame) = mean_y_tot_NM(1:num_NM);
     var_x_tot_time(1:num_NM,which_frame) = var_x_tot_NM(1:num_NM);
     var_y_tot_time(1:num_NM,which_frame) = var_y_tot_NM(1:num_NM);
     cov_xy_tot_time(1:num_NM,which_frame) = cov_xy_tot_NM(1:num_NM);
     num_nuclei_time(which_frame) = num_NM;         
     x_coord_min_tot_time(1:num_NM,which_frame) = box_coords_NM(1:num_NM,1);
     x_coord_max_tot_time(1:num_NM,which_frame) = box_coords_NM(1:num_NM,2);
     y_coord_min_tot_time(1:num_NM,which_frame) = box_coords_NM(1:num_NM,3);
     y_coord_max_tot_time(1:num_NM,which_frame) = box_coords_NM(1:num_NM,4);
     


    figure(102)
    imagesc(M_NM_threshold)
    title('data (binary)');
    figure(103)
    imagesc(M_NM_threshold_FILL)
    title('data (binary,fill)');
    figure(104)
    imagesc(M_NM_id_threshold)
    title('data (id)');
    
    
    str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
    mkdir(str_movie_processed);
    % Save into a file here
    file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
    save(file_nucleus,'box_coords_NM','num_NM','M_NM','M_NM_threshold','M_NM_id_threshold','M_NM_threshold_FILL','Cell_NM_FILL');
    for jj = 1:length(signal_channels)
      save(file_nucleus,strcat('M_S',num2str(jj)),'-append');
    end;
       Cell_FILL_dummy = genvarname(['Cell_nucleus_FILL_',num2str(which_frame)]);
       eval([Cell_FILL_dummy '=Cell_NM_FILL']);
       Cell_FILL_dummy
      file_nucleus_tot = strcat(str_movie_processed,'\Cell_nucleus_structs_tot');
     if (which_frame == 1)
       save(file_nucleus_tot,strcat('Cell_nucleus_FILL_',num2str(which_frame)));
     else
       save(file_nucleus_tot,strcat('Cell_nucleus_FILL_',num2str(which_frame)),'-append');
     end;

