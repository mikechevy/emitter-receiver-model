unique_nuclei_track_time = zeros(num_nuclei_max,numFr_NM);
unique_nuclei_track_t0 = zeros(num_nuclei_max,1);
unique_nuclei_track_t0(1:num_nuclei_t0) = 1;  % initialize the first num_nuclei_t0 nuclei

convergence_event = [];
   
for kkk = 2:numFr_NM
  which_frame = kkk;
%  [val_sort,index_sort]  = sort(index_map_tot_time_mapped_t0(1:num_nuclei_time(kkk),which_frame));
  [val_sort,index_sort]  = sort(index_map_tot_time_mapped_t0(1:num_nuclei_t0,which_frame));
%  for iii = 2:num_nuclei_time(kkk)
  for iii = 2:num_nuclei_t0
     if (val_sort(iii-1) == val_sort(iii))
         if (unique_nuclei_track_t0(index_sort(iii-1)) == 1)  % at least one of them has not converged
         convergence_event = [convergence_event ; index_sort(iii-1) val_sort(iii-1) which_frame];
         end;
         if (unique_nuclei_track_t0(index_sort(iii-1)) == 1)  % at least one of them has not converged
         convergence_event = [convergence_event ; index_sort(iii) val_sort(iii) which_frame];
         end;
         unique_nuclei_track_t0(index_sort(iii-1)) = 0;
         unique_nuclei_track_t0(index_sort(iii)) = 0;
     end;
  end;
end;

unique_nuclei_track_time(:,1) = unique_nuclei_track_t0(:);

for iii = 1:num_nuclei_t0
    ii_map = iii;  % points to the normal order for the first frame only
for kkk = 1:numFr_NM
  which_frame = kkk;
     if (kkk < numFr_NM)
        if (unique_nuclei_track_t0(iii) == 1) 
         unique_nuclei_track_time(ii_map,which_frame+1) = 1; 
         ii_map = index_map_tot_time_mapped_t0(iii,which_frame+1);  % points to the index of the properly mapped nuclues in the next frame     
        end;
     end;
    %ii_map = index_map_forward_tot(ii_map,which_frame);  % points to the index of the properly mapped nuclues in the next frame
end;

end; 

num_unique_nuclei_track_time = sum(unique_nuclei_track_time)

if (max(sum(unique_nuclei_track_time))==min(sum(unique_nuclei_track_time)))
    unique = 1
    convergence_event    
end;


used_nuclei_track_time_dummy = zeros(num_nuclei_max,numFr_NM);
for iii = 1:num_nuclei_t0
    ii_map = iii;  % points to the normal order for the first frame only
for kkk = 1:numFr_NM
  which_frame = kkk;
     if (kkk < numFr_NM)
         used_nuclei_track_time_dummy(ii_map,which_frame+1) = 1; 
         ii_map = index_map_tot_time_mapped_t0(iii,which_frame+1);  % points to the index of the properly mapped nuclues in the next frame     
     end;
    %ii_map = index_map_forward_tot(ii_map,which_frame);  % points to the index of the properly mapped nuclues in the next frame
end;

end; 


