
function [tau_off] = find_P_nr_time(rand_P_nr,power_raise)

global P_nr;
global time_P_nr;



                index_P_nr = 1;
                 while (rand_P_nr < power(P_nr(index_P_nr),power_raise))&(index_P_nr < length(P_nr))
                  index_P_nr = index_P_nr+1;
                 end;

                  if (index_P_nr==1)&(rand_P_nr == power(P_nr(1),power_raise))
                      ii_lower = 1;
                  elseif (index_P_nr==length(P_nr))&(rand_P_nr <= power(P_nr(length(P_nr)),power_raise))
                      rand_P_nr = power(P_nr(length(P_nr)),power_raise);
                      ii_lower = length(P_nr)-1;
                  else
                      ii_lower = index_P_nr;
                  end;


                     dP_nr_power = power(P_nr(ii_lower),power_raise)-power(P_nr(ii_lower+1),power_raise);

                     ii_upper = ii_lower+1;
                           upper = (power(P_nr(ii_lower),power_raise)-rand_P_nr)/dP_nr_power;
                           lower = 1-upper;
                    tau_off = upper*time_P_nr(ii_upper) + lower*time_P_nr(ii_lower);

