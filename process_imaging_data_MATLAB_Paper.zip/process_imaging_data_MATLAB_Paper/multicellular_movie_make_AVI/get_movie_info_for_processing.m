
% NOTE: Very IMPORTANt!. When setting up parameters for the movie it must contain the channels (and number of channels from the file:
% 'acqdat.txt' for a given multicellular move.  This file has the time a
% given image was taken. 

% used to throwout the top 'num_throwout' values, to discuard clusters when
% calculating mean and std pixel number
num_throwout_max = 20;

% default, unless we want to look on mixtures of non-bPAC and bPAC cells
do_location_bPAC_nuclei = 0;

% USED TO DETERMIN IF pixel region is small enough to label as single nucleus: if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
fac_std_nuclear_size = -0.5;  % if mean_pix + fac_std_nuclear_size
fac_std_nuclear_size_recursive = -.5;  % if mean_pix + fac_std_nuclear_size

% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

do_make_figure = 0;  % specify if 1 for each movie

do_median_or_mean_signal = 1; % 0-mean, 1-median (for plotting in load_and_analyze_cellular_signals.m)

do_cAMP_tests = 1;    % 0 - default, 1-titration tests (format of acqdat.txt file is altered

do_use_all_cells_TF  = 0; %Transfer Function analysis, 0- only using pulsing cells that pass a test (default), 1- use all for plots and calculations

do_all_receivers = 0;  % 1 - yes, 0 - no (default)       


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% used for determine_cytosolic_regions_per_frame.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this is the the size of the ring around the nucleus for the cytosolic
% signal
scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   do_max_or_shrink_median = 1; % 0-max, 1-shrink median
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .4;
   end;

do_tranfer_function=0;  % this will mostly be the case

%  these are handed to 'determine_nuclear_locations_adaptive_recursive' for
%  extra processing of the segmenting nuclei
do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;

% percentage a bPAC marked nucleus must appear over the movie, used in
% mixed_bPAC_population_analysis.m
fac_bPAC_percentage = .8;
% ratio of area of bPAC_NM to NM, used in mixed_bPAC_population_analysis.m
bPAC_NM_to_NM_ratio = 1.5;

%  bursting periods
period_burst_Ca = 25;  % seconds
period_burst_Erk = 25*60;
%  bursting thresholds
threshold_burst_Ca = 3;
threshold_burst_Erk = 10;

ii_NM_bPAC = [];
num_nuclei_t0 = [];


do_illumation_map_normalize = 0;  % 1 - yes, 0 - no 



%setup the array that maps the marker from a particular channel
marker_from_channel = zeros(num_different_markers,1);

if which_movie == 1  
    
str_movie = '171004_198-117_42_MC_H89_2';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'YFP-Wheel';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;

elseif which_movie == 2 

str_movie = '171003_198-117_42_MC_2';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'YFP-Wheel';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
    
elseif which_movie == 3

str_movie = '171006_198-117_42_H89_MC';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'DAPI';  % 
    CH3_str = 'CFP-wheel';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;

elseif which_movie == 4

str_movie = '171010_198-117_42_H89_MC';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'YFP-Wheel';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        

elseif which_movie == 5

str_movie = '171010_198-117_42_MC';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'YFP-Wheel';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
        
elseif which_movie == 6

str_movie = '171107_198-117_42_H89_MC';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'YFP-Wheel';  % 
    CH3_str = 'RFP';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 7

str_movie = '171107_198-117_42_MC';    
    numCh=5;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'YFP-Wheel';  % 
    CH3_str = 'RFP';  % nuclear marker
    CH4_str = 'CFP-wheel';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;


elseif which_movie == 8

str_movie = '181106_MDCK-II_207-117-61-mix_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3 ii_CH4];
       ii_NM = ii_CH3;

    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
    
        
        
elseif which_movie == 9

str_movie = '181106_MDCK-II-117_207-61-mix_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 10

str_movie = '181106_MDCK-II-117_207-61-mix_TEST_MC_2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        

elseif which_movie == 11

str_movie = '181109_207-61_207-117-61-mix_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 12

str_movie = '181109_207-61_207-117-61-mix_TEST_MC_2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;


elseif which_movie == 13

str_movie = '181109_207-61_207-117-61-mix_TEST_MC_3';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;

elseif which_movie == 14

    
str_movie = '181113_207-61_207-117-61-mix_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;

        
elseif which_movie == 15

str_movie = '181127_MDCKII-117_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;

    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 16

str_movie = '181127_MDCKII-117_207-61_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 17

str_movie = '181120_207-117-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;

elseif which_movie == 18

str_movie = '181120_207-117-61_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;

    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 19

str_movie = '181116_207-61_207-117-61_mix_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 20

str_movie = '181116_207-61_207-117-61_mix_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;

        
elseif which_movie == 21

str_movie = '181012_207-117-61_198-117-mix_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;

    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
        
elseif which_movie == 22

str_movie = '181012_207-117-61_198-117-mix_TEST_MC_2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 23
    

str_movie = '180612_198-117_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 24
        

str_movie = '180612_198-117_198_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 25
        

str_movie = '180612_207-117-61-198_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
elseif which_movie == 26

str_movie = '181214_198-117_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;
        
        
elseif which_movie == 27

str_movie = '181214_198-117_207-61_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2 ii_CH3];
       ii_NM = ii_CH3;

    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        

elseif which_movie == 28

str_movie = '181218_198-117_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    

do_make_figure = 1;
which_frames_to_save = [109 119 129 139];

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
       
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;
        
        
elseif which_movie == 29

str_movie = '181218_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;

        
        
elseif which_movie == 30

str_movie = '190215_207-117-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
elseif which_movie == 31

str_movie = '190219_207-117-61_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 300;  
        

elseif which_movie == 32

str_movie = '190222_207-117-61_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 33

str_movie = '190226_207-117-61_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  


elseif which_movie == 34

str_movie = '190226_207-117-61_207-61_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  


elseif which_movie == 35

str_movie = '190301_207-117-61_198_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;

elseif which_movie == 36

str_movie = '190301_207-117-61_198_TEST_MC_2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .2;
do_median_or_mean_signal = 0;

elseif which_movie == 37

str_movie = '190301_207-117-61_198_TEST_MC_2B';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 38

str_movie = '190305_198-117_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 39

str_movie = '190308_198-117_198_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 40

str_movie = '190312_198-117_198_TEST_MC_BADC02_60M';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 41

str_movie = '190313_198-117_198_TEST_MC_Day2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3; 
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 700;  
fac_bPAC_percentage = .5;

elseif which_movie == 42

 str_movie = '190315_198-117_198_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 43

 str_movie = '190315_198-117_198_TEST_MC_2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 44

 str_movie = '190315_198-117_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  
fac_bPAC_percentage = .5;


elseif which_movie == 45

 str_movie = '190319_207-117-61_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  
fac_bPAC_percentage = .5;


elseif which_movie == 46

 str_movie = '190319_207-117-61_207-61_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  
fac_bPAC_percentage = .5;


elseif which_movie == 47

str_movie = '190326_198-117_207-61_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 48

 str_movie = '190329_207-117-61_TEST_MC_2';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  
fac_bPAC_percentage = .5;


elseif which_movie == 49

 str_movie = '190329_207-117-61_TEST_MC_BADFLOW';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  
fac_bPAC_percentage = .5;


elseif which_movie == 50

str_movie = '190405_207-117-61_198_TEST_MC';    
    numCh=4;
    CH1_str = 'GFP';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH2;
        
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 51

str_movie = '190416_198-117_198_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 600;  

fac_bPAC_percentage = .5;


elseif which_movie == 52

str_movie = '190416_198-117_198_TEST_MC_H89_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 600;  

fac_bPAC_percentage = .5;


elseif which_movie == 53

str_movie = '190530_198-117_198-70_TEST_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 600;  

fac_bPAC_percentage = .5;





elseif which_movie == 54

str_movie = '190604_198-117-70_198-70_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;



elseif which_movie == 55

str_movie = '190604_198-117-70_198-70_TEST_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;

elseif which_movie == 56

str_movie = '190607_198-117-70_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 57

str_movie = '190607_198-117-70_198-70_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;


elseif which_movie == 58

str_movie = '190611_198-117-70_198-70_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;

elseif which_movie == 59

str_movie = '190611_198-117-70_198-70_TEST_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;


elseif which_movie == 60

str_movie = '190625_198-117_198_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;


elseif which_movie == 61

str_movie = '190628_198-117_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 1200;  

fac_bPAC_percentage = .5;

elseif which_movie == 62

str_movie = '190628_198-117_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 63

str_movie = '190709_198-117_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 64

str_movie = '190712_198-117-70_198-70_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;

elseif which_movie == 65

str_movie = '190716_198-117_198_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 66

    str_movie = '190726_198-117_198_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 67

str_movie = '190726_198-117-70_198-70_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 68

    str_movie = '190730_198-117_198_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    
do_make_figure = 1;
      
which_frames_to_save = [120 128 141];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 69

str_movie = '190730_198-117-70_198-70_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 70

    str_movie = '190801_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 71

    str_movie = '190801_198-117_198_TEST_MC_BrA_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 72

str_movie = '190802_198-117-70_198-70_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 73

str_movie = '190802_198-117-70_198-70_TEST_MC_BrA_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 74

str_movie = '190816_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 75

str_movie = '190816_198-117_198_TEST_MC_BrA_2';    
   % SAME CELLS AS '190816_198-117_198_TEST_MC_BrA'

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 76

str_movie = '190820_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 77

str_movie = '190820_198-117_198_TEST_MC_BrA_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 78

str_movie = '190822_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 79

str_movie = '190822_198-117_198_TEST_MC_BrA_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 80

str_movie = '190823_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 81

str_movie = '190823_198-117_198_TEST_MC_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_make_figure = 1;
      
which_frames_to_save = [40 50 60];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 82

str_movie = '190827_198-117_198_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 83

str_movie = '190827_198-117_198_TEST_MC_2_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 84

str_movie = '190829_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 85

str_movie = '190829_198-117_198_TEST_MC_2_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 86

str_movie = '190830_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 87

str_movie = '190903_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 88

str_movie = '190903_198-117_198_TEST_MC_2_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 89

str_movie = '190905_198-117_198_TEST_MC_BrA_BADC02';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 90

str_movie = '190906_198-117_198_TEST_MC_BrA';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 91

str_movie = '190910_198-117_198_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 92

str_movie = '190910_198-117_198_TEST_MC_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 93

str_movie = '190912_198-117_198_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 94

str_movie = '190912_198-117_198_TEST_MC_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 95

str_movie = '190913_198-117-70_198-70_TEST_MC';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 96

str_movie = '191004_198-117-70_198-70_TEST_MC_filt_blue';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 97

str_movie = '191004_198-117-70_198-70_TEST_MC_2';    

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 98

str_movie = '191015_198-117_TEST_MC_H89';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 99

str_movie = '191015_198-117_TEST_MC_2_H89';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 100

str_movie = '191018_198-117_TEST_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 101

str_movie = '191018_198-117_TEST_MC_3';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 102

str_movie = '191022_198-117_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 103

str_movie = '191022_198-117_TEST_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 104

str_movie = '191029_198-117_TEST_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 105

str_movie = '191202_198-117_TEST_MC_p23';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];

do_tranfer_function=1;  % this will mostly be the case


 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 106

str_movie = '191206_198-117_TEST_MC_p26'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  

fac_bPAC_percentage = .5;



elseif which_movie == 107

str_movie = '191206_198-117_TEST_MC_p23'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 108

str_movie = '191210_198-117_TEST_MC_p23'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 109

str_movie = '191210_198-117_MC_p23_same'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 110

str_movie = '191212_198_R4_0uM_'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;

    do_cAMP_tests = 1;    
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 111

str_movie = '191212_198_R4_66uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 112

str_movie = '191212_198_R4_66uM_66uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;



elseif which_movie == 113

str_movie = '191212_198_R5_0uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;

    do_cAMP_tests = 1;    
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 114

str_movie = '191212_198_R5_66uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 115

str_movie = '191212_198_R5_66uM_66uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 116

    str_movie = '191219_198_R2_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;

    do_cAMP_tests = 1;    
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 117

    str_movie = '191219_198_R2_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 118

str_movie = '191219_198_R2_50uM_50uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 119

    str_movie = '191219_198_R3_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;

    do_cAMP_tests = 1;    
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 120

    str_movie = '191219_198_R3_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 121

str_movie = '191219_198_R3_50uM_50uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 122

    str_movie = '191219_198_R4_0uM_'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;

    do_cAMP_tests = 1;    
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 123

    str_movie = '191219_198_R4_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 124

str_movie = '191219_198_R4_50uM_50uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;


elseif which_movie == 125

str_movie = '191219_198_R4_50uM_50uM_extra'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 500;  

fac_bPAC_percentage = .5;




elseif which_movie == 140

str_movie = '191213_198-117_198_MC_p23';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 141

str_movie = '191213_198-117_198_MC_p23_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 142

str_movie = '191217_198-117_198_MC_p26';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 143

str_movie = '191217_198-117_198_MC_p26_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 144

str_movie = '191220_198-117_198_MC_';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 145

str_movie = '200130_198-117_MC_18a_4h'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 146

str_movie = '200131_198-117_198_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 147

str_movie = '200131_198-117_198_MC_18a_4h';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 148

str_movie = '200204_198-117_MC_H89_tenth'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 149

str_movie = '200206_198-117_198_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 150

str_movie = '200206_198-117_198_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 151

str_movie = '200207_198-117_198_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 152

str_movie = '200211_198-117_198_MC';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 153

str_movie = '200211_198-117_198_MC_2';    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 154

str_movie = '200213_198-117_MC_H89'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 155

    str_movie = '200213_198-117_198_MC_H89';    
    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 156

str_movie = '200214_198-117_MC_H89'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 157

    str_movie = '200528_198-117_198_MC';    
    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 158

    str_movie = '200528_198-117_198_MC_2';    
    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 159

    str_movie = '200531_198-117_198_MC_H89';    
    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 160

str_movie = '200531_198-117_MC_H89'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 161

str_movie = '200604_198-117_MC_H89_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 162

    str_movie = '200607_198_R1_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;

    do_cAMP_tests = 1;    
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 163

    str_movie = '200607_198_R1_37uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 164

    str_movie = '200607_198_R1_37uM_37uM_37uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;

elseif which_movie == 165

    str_movie = '200611_198_R1_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;

elseif which_movie == 166

    str_movie = '200611_198_R1_75uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;


elseif which_movie == 167

    str_movie = '200611_198_R1_75uM_75uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;

elseif which_movie == 168

    str_movie = '200611_198_R1_75uM_75uM_extra'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;

elseif which_movie == 169

    str_movie = '200611_198_DMSO_0uL'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 170

    str_movie = '200611_198_DMSO_1uL'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 800;  

fac_bPAC_percentage = .5;



elseif which_movie == 171

str_movie = '200614_198-117_p26_BrA_4h'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 172

str_movie = '200618_198-117_p26_BrA_30m'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 173

str_movie = '200618_198-117_p26_BrA_4h_2'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 174

str_movie = '200621_198-117_p26'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  



fac_bPAC_percentage = .5;

elseif which_movie == 175

str_movie = '200621_198-117_p26_2_samecells'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 176

    str_movie = '200628_198_R3_F0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 177

    str_movie = '200628_198_R3_F50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 178

    str_movie = '200628_198_R3_F50uM_F50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 179

    str_movie = '200628_198_R4_F0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 180

    str_movie = '200628_198_R4_F30uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 181

    str_movie = '200628_198_R4_F30uM_F30uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 182

    str_movie = '200628_198_R5_F0uM_IBMX'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 183

    str_movie = '200628_198_R5_F30uM_IBMX'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 184

    str_movie = '200628_198_R5_F30uM_F30uM_IBMX'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 185

    str_movie = '200702_198-117_MDCKII_1';    
    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 186

    str_movie = '200705_198_R1_F0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 187

    str_movie = '200705_198_R1_F10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 188

    str_movie = '200705_198_R1_F10uM_F10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 189

    str_movie = '200705_198_R3_F0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 190

    str_movie = '200705_198_R3_F5uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 191

    str_movie = '200705_198_R3_F5uM_F5uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;





elseif which_movie == 192

str_movie = '200709_198-117_1'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 193

str_movie = '200709_198-117_2'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 194

str_movie = '200709_198-117_3'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 195

str_movie = '200712_198-117_2'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 196

    str_movie = '200723_198_R1_E15uM_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 197

    str_movie = '200723_198_R1_E15uM_20uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 198

    str_movie = '200723_198_R2_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 199

    str_movie = '200723_198_R2_20uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 200

    str_movie = '200723_198_R2_20uM_E15uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 201

    str_movie = '200723_198_R3_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 202

    str_movie = '200723_198_R3_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 203

    str_movie = '200723_198_R3_50uM_E15uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 204

    str_movie = '200726_198-117_R1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 205

    str_movie = '200726_198-117_R1_E15uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 206

str_movie = '200726_198-117_2'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 207

str_movie = '200730_198-117'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 208

str_movie = '200730_198-117_2_samecells'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 209

    str_movie = '200801_198-117_198_R2'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 210

    str_movie = '200801_198-117_198_R2_H89_10uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 211

    str_movie = '200802_198-117_198-70_2'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
%do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 212

    str_movie = '200806_198-117_R1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 213

    str_movie = '200806_198-117_R1_H89_10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 214

    str_movie = '200806_198-117_R2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 215

    str_movie = '200806_198-117_R2_H89_10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 216

    str_movie = '200809_198-117_198_R1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 217

    str_movie = '200809_198-117_198_R1_E15uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 218

    str_movie = '200809_198-117_198_R5'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 219

    str_movie = '200809_198-117_198_R5_E15uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 220

    str_movie = '200813_198-117_R2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 221

    str_movie = '200813_198-117_R2_E15uM_H89_10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 222

    str_movie = '200813_198-117_R4'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 223

    str_movie = '200813_198-117_R4_E15uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 224

    str_movie = '200816_198_FSK_R4_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 225

    str_movie = '200816_198_FSK_R4_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 226

    str_movie = '200816_198_FSK_R4_50uM_H10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 227

    str_movie = '200816_198_FSK_R5_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 228

    str_movie = '200816_198_FSK_R5_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 229

    str_movie = '200816_198_FSK_R5_50uM_E15uM_H10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 230

    str_movie = '200816_198_FSK_R7_0uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 231

    str_movie = '200816_198_FSK_R7_50uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 232

    str_movie = '200816_198_FSK_R7_50uM_E15uM_H10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 233

    str_movie = '200820_198-117_198-70_2'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
%do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 234

    str_movie = '200820_198-117_198-70_3'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
%do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 235

    str_movie = '200903_198-117_198-70'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
%do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 236

    str_movie = '200903_198-117_198-70_2'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
%do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 237

    str_movie = '200906_198-117_198_R1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 238

    str_movie = '200906_198-117_198_R1_H10uM__'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 239

    str_movie = '200906_198-117_198_R2'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 240

    str_movie = '200906_198-117_198_R2_H10uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 241

    str_movie = '200910_198-117_198_R1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 242

    str_movie = '200910_198-117_198_R6'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 243

    str_movie = '200910_198-117_198_R6_E15uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 244

    str_movie = '200913_198-117_198_R1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
    
elseif which_movie == 245

    str_movie = '200913_198-117_198_R1_H10uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 246

    str_movie = '200917_198-117_207-61_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 247

    str_movie = '200917_198-117_207-61_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 248

    str_movie = '200920_198-117_207-61_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 249

    str_movie = '200920_198-117_207-61_2_H10uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 250

    str_movie = '200920_198-117_207-61_3'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 251

str_movie = '200924_198-117_TF'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case
do_use_all_cells_TF  = 1; %Transfer Function analysis, 0- only using pulsing cells that pass a test (default), 1- use all for plots and calculations

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 252

str_movie = '200924_198-117_TF_IBMX100uM'; 
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

do_tranfer_function=1;  % this will mostly be the case
do_use_all_cells_TF  = 1; %Transfer Function analysis, 0- only using pulsing cells that pass a test (default), 1- use all for plots and calculations
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       ii_NM_bPAC = ii_NM;
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 253

    str_movie = '200927_198-117_198_R1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

     
elseif which_movie == 254

    str_movie = '200927_198-117_198_R3'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 1;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;




elseif which_movie == 255

    str_movie = '200927_198-117_198_R3_E15uM'; 

    
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 256

str_movie = '201001_207-61'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    %do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        %marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
 do_all_receivers = 1;  % 1 - yes, 0 - no (default)      
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 257

str_movie = '201001_207-61_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    %do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        %marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
 do_all_receivers = 1;  % 1 - yes, 0 - no (default)      
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 258

    str_movie = '201011_198-117_198_1_I150uM'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 259

    str_movie = '201011_198-117_198_2_I150uM'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 260

    str_movie = '201018_198-117_198_1_I100uM'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 261

    str_movie = '201018_198-117_198_2_I100uM'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 262

    str_movie = '201122_198-117_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 263

    str_movie = '201122_198-117_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 264

    str_movie = '201206_198-117_207-61_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 265

    str_movie = '201210_198-117_207-61_4'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 266

    str_movie = '201210_198-117_207-61_5_same_cells'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 267

    str_movie = '201213_198-117_207-61_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 400;  
fac_bPAC_percentage = .5;

% ratio of area of bPAC_NM to NM, used in mixed_bPAC_population_analysis.m
bPAC_NM_to_NM_ratio = 1.3;

elseif which_movie == 268

    str_movie = '201213_198-117_207-61_3'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;



elseif which_movie == 269

    str_movie = '201213_198-117_207-61_4'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 270

    str_movie = '201217_198-117_207-61_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 271

    str_movie = '201217_198-117_207-61_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;



elseif which_movie == 272

    str_movie = '201220_198-117_MDCKII_2'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 273

    str_movie = '201220_198-117_MDCKII_3'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 274

    str_movie = '201220_198-117_MDCKII_4_samecells'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 275

    str_movie = '201224_198-117_MDCKII_4'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 276

    str_movie = '201224_198-117_MDCKII_5'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 277

    str_movie = '201227_198-117_MDCKII_2'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 278

    str_movie = '201227_198-117_MDCKII_3'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 279

    str_movie = '201227_198-117_MDCKII_9'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 280

    str_movie = '201231_198-117_MDCKII_3'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 281

    str_movie = '201231_198-117_MDCKII_9'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 282

    str_movie = '210103_198-117_MDCKII_4'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 283

    str_movie = '210207_198-117_MDCKII_1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 284

    str_movie = '210211_198-117_MDCKII_1'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 285

    str_movie = '210211_198-117_MDCKII_2'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 286

    str_movie = '210211_198-117_MDCKII_3'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 287

    str_movie = '210214_198-117_MDCKII_2'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 288

    str_movie = '210221_198-117_MDCKII_4'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 289

    str_movie = '210221_198-117_MDCKII_5'; 
    
        
    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
do_cAMP_tests =0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
        
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
     
                  
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 290

    str_movie = '210228_198-117_207_5'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 291

    str_movie = '210304_198-117_207_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 292

    str_movie = '210304_198-117_207_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 293

    str_movie = '210304_198-117_207_3'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 294

    str_movie = '210307_198-117_207_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 295

    str_movie = '210307_198-117_207_4'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH2;
        marker_from_channel(ii_Erk_bPAC_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 296

    str_movie = '210314_198-117_198_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 297

    str_movie = '210314_198-117_198_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 298

    str_movie = '210318_198-117_198_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 299

    str_movie = '210318_198-117_198_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 300

    str_movie = '210321_198-117_198_2'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 301

    str_movie = '210321_198-117_198_3'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;


elseif which_movie == 302

        str_movie = '210606_198-117_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 303

        str_movie = '210606_198-117_2_samecells'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;
    

elseif which_movie == 304

        str_movie = '210609_198-117_TF_1'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;  % this will mostly be the case
do_use_all_cells_TF  = 1; %Transfer Function analysis, 0- only using pulsing cells that pass a test (default), 1- use all for plots and calculations

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;
    

elseif which_movie == 305

        str_movie = '210609_198-117_TF_2_I100uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;  % this will mostly be the case
do_use_all_cells_TF  = 1; %Transfer Function analysis, 0- only using pulsing cells that pass a test (default), 1- use all for plots and calculations

      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 306

        str_movie = '210612_198-117_1_I100uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 307

        str_movie = '210612_198-117_2_I500uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 308

        str_movie = '210612_198-117_3_I500uM_NoNDF'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 309

        str_movie = '210615_198-117_2_I500uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 310

        str_movie = '210624_198-117_1_I250uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 311

        str_movie = '210624_198-117_2_I250uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 312

        str_movie = '210627_198-117_1_I500uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 313

        str_movie = '210627_198-117_3_I500uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;

elseif which_movie == 314

        str_movie = '210718_198-117_1_I1000uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 315

        str_movie = '210718_198-117_2_I1000uM_samecells'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;


elseif which_movie == 316

        str_movie = '210724_198-117_1_I750uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
   
do_cAMP_tests = 0;    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
      
which_frames_to_save = [59 99 139 179];
    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH4;
    do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  

fac_bPAC_percentage = .5;



elseif which_movie == 317

    str_movie = '210727_198-117_MDCKII_1_I1000uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 318

    str_movie = '210730_198-117_MDCKII_1_I125uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;

elseif which_movie == 319

    %str_movie = '210730_198-117_MDCKII_2_I1000uM_samecells'; 
    str_movie = '210730_E_MDCKII_2_I1000uM'; 

    numCh=4;
    CH1_str = 'YFP-wheel';  % Erk
    CH2_str = 'RFP';  % nuclear marker
    CH3_str = 'CFP-wheel';  % bPAC marker
    CH4_str = 'DAPI';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    
which_frames_to_save = [59 99 139 179];
    
do_cAMP_tests = 0;    

 do_elsamad_microscope = 1;
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH4;
    
    marker_from_channel(ii_bPAC_marker) = ii_CH3;
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
        marker_from_channel(ii_Erk_marker) = ii_CH1;
        
% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  
fac_bPAC_percentage = .5;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SOME CLASSIC OLD EXPERIMENTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

elseif which_movie == 390 

    str_movie = '160926_198-117_IBMX_2_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    
    
elseif which_movie == 391

    str_movie = '160930_198-117_alpha18_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    
    
elseif which_movie == 392

    str_movie = '161006_198-117_alpha18_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    


elseif which_movie == 399

    str_movie = '042916_mwc_198_198-117_IBMX_1.3'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

bPAC_amp_max = 255;
    
elseif which_movie == 400
    
    
%do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
%do_illumation_map_normalize = 1;  % 1 - yes, 0 - no 
    
    %str_movie = '031416_mwc_198_198-117'
    str_movie = '031416_mwc_198_198-117_same'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = ii_CH3;
       ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
       %ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  

      
nucleus_min_pixels = 200;  % 10X is used  
fac_bPAC_percentage = .5;
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
bPAC_amp_max = 255;  % need to add this since this is an old movie
    

do_make_figure = 1;
      
which_frames_to_save = [120 129 130 131 140];

%which_frames_to_save = [59 99 139 179];
      
  

elseif which_movie == 401 
    
    str_movie = '160902_198_198-117_EA'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
fac_bPAC_percentage = .2;

scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .6;
   end;

   
elseif which_movie == 402 
    
    str_movie = '160905_198_198-117_JP'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
fac_bPAC_percentage = .5;

scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .6;
   end;
   
elseif which_movie == 403
   
    str_movie = '160922_198-117_JP'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM;
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


do_make_figure = 1;
which_frames_to_save = [119 139 159 180];


elseif which_movie == 404
   
    str_movie = '160922_198-117_IBMX_JP'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM;
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


 elseif which_movie == 405
    
    str_movie = '161007_198-117_JP'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
    
elseif which_movie == 406
    
    str_movie = '161007_198-117_H89_JP'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

elseif which_movie == 407

    str_movie = '050616_mwc_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


     %do_location_bPAC_nuclei = 1;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

bPAC_amp_max = 255;
  

elseif which_movie == 408

    str_movie = '050616_mwc_198_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       %ii_NM_bPAC = ii_NM;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

bPAC_amp_max = 255;
  
        
elseif which_movie == 409

    str_movie = '050316_mwc_198_198-117_IBMX_1.5'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

bPAC_amp_max = 255;
    
elseif which_movie == 410  % CBX is carbonoxolone

    str_movie = '042216_mwc_198_198-117_CBX_1'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
fac_bPAC_percentage = .8;
bPAC_NM_to_NM_ratio = 1.35;


bPAC_amp_max = 255;
    

end;    





