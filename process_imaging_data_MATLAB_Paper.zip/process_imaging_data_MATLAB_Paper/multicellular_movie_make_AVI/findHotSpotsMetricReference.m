function [event_x_tot, event_y_tot, event_id_tot, event_start_tot, event_size_tot] = findHotSpotsMetricReference(r_event_reference,r_events_total,xLength,yLength,mean_x_tot,mean_y_tot,length_max,which_metric,M_marker_threshold)


global ii_physical_distance;
global ii_xcorr;
global length_per_pixel;
global seconds_per_frame;
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%  Begin: Cluster events
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

max_dimension 100;

figure(111)
imagesc(M_marker_threshold);

matrix_hot_spot = zeros(xLength,yLength);

event_x_tot = [];
event_y_tot = [];
event_id_tot = [];
event_start_tot = [];
event_size_tot = [];

for iii = 1:numEvents
iii 
numEvents
    
matrix_hot_spot = 0*matrix_hot_spot;    

if (which_metric == ii_physical_distance) 
   z = length_per_pixel*pdist(r_event); % micrometers
elseif (which_metric == ii_xcorr)
    
    
    max_delay = round(60/seconds_per_frame);  % number of frames (currently based 30 seconds)

    
     count_z = 0;
       for xx = max(mean_x_tot(iii)-max_dimention,1):min(mean_x_tot(iii)-max_dimention,xLength)
        for yy = max(mean_y_tot(iii)-max_dimention,1):min(mean_y_tot(iii)-max_dimention,yLength)
          xcorr_test = xcorr(r_event_reference(iii,:),r_event_total(xx,yy,:));  
            [val_max, index_max] = max(xcorr_test);
              xcorr_test(index_max) = 0;
            [val_max_next, index_max_next] = max(xcorr_test);
            distance_xcorr = abs(val_max_next/val_max);
          if abs(index_max - round(length(xcorr_test+1)/2)) <= max_delay  
             z(count_z+1) = distance_xcorr;
          else
             z(count_z+1) = 2*length_max;
          end;
         count_z = count_z+1;
        end;
       end;
    
       
end;


count_z = 0;
count_groups = 0;

event_x_dummy = [];
event_y_dummy = [];
event_id_dummy = [];

%  Clustering loop
for xx = 1:xLength
  for yy = 1:yLength
   
    if (z(count_z+1) <= length_max)  % length_max is a passed argument
        matrix_hot_spot(xx,yy) = 1;
        event_x_dummy = [event_x_dummy xx];
        event_y_dummy = [event_y_dummy xx];
    end;
count_z = count_z+1;    
end;
end;

start_dummy = sum(event_start_tot);
event_size_tot = [event_size_tot count_z];
event_start_tot = [event_start_tot start_dummy];
event_id_tot = [event_id_tot jj];


figure(112)
imagesc(matrix_hot_spot);
pause
   
end;




