
function [index_log_time] = find_log_time_index(t)

global min_time_exp;
global max_time_exp;
global num_samps_per_decade;
global length_time_P_nr;

if (t > 0)

   log_10_time = log10(t);
   time_exp = floor(log_10_time);

   if (time_exp < min_time_exp)
   index_log_time = 1;
   elseif (time_exp > max_time_exp)
   index_log_time = length_time_P_nr-1;
   else
     % base_time = t/(10^time_exp);
   base_time = t/power(10,time_exp);
   jj_decade = floor((base_time-1)*num_samps_per_decade/9.0+1);

   index_log_time = (time_exp-min_time_exp)*num_samps_per_decade + jj_decade + 1;%shift_1_for_tzero 

   end;

else

 index_log_time = 1;

end

