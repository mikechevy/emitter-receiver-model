
c_mu_0_time_array = zeros(num_reactions,length(time_u_array));
c_mu_tv_time_array = zeros(num_reactions,length(time_u_array));
phase_c_mu_tv_time_array = zeros(num_reactions,length(time_u_array));
freq_tv_time_array = zeros(length(time_u_array),1);
time_constant_tv_time_array = zeros(length(time_u_array),1);
for ii = 1:length(time_u_array)
 c_mu_0_time_array(:,ii) = c_mu;
 if (do_prop_time_vary == 1) 
   c_mu_tv_time_array(:,ii) = c_mu_tv;
   phase_c_mu_tv_time_array(:,ii) = phase_c_mu_tv;
   freq_tv_time_array(ii) = freq_tv;
   time_constant_tv_time_array(ii) = time_constant_tv;
 end;
end;
