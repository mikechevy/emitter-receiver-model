

fclose(fids_encounters);
fclose(fids_dimurs);

fids = fopen('data/output_Parts_params.bin','w');
num_encounter_writes
fwrite(fids,num_encounter_writes,'int');
fwrite(fids,num_timesteps,'int');
fwrite(fids,Npartwrite,'int');
fwrite(fids,Nfieldwrite,'int');
fwrite(fids,num_runs_per_proc,'int');
fclose(fids);


%save output_file_params  num_encounter_writes num_timesteps reactive_map attach_map decay_map collision_map y_0ss Diff_coeff Diff_coeff_max dt dx m_xdimp m_ydimp m_zdimp;

save('data/output_file_params','num_encounter_writes','num_timesteps','reactive_map','attach_map','decay_map','collision_map','y_0ss','Diff_coeff','Diff_coeff_max','dt','dx','m_xdimp','m_ydimp','m_zdimp');


if (use_subgrid==1)&(use_subgrid_pdf==0)
fclose(fpSubgridFile);
fpSubgridFile = fopen('data/subgrid.info0','w');
fwrite(fpSubgridFile,count_SubgridFile,'int');
fwrite(fpSubgridFile,block_subgrid,'int');
fclose(fpSubgridFile);
end;


fclose(fids_part);
fclose(fids_info);
