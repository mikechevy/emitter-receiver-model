do_DAPI = 1;  % 1 - yes, 0 - no
do_FITC = 1;  % 1 - yes, 0 - no
do_CY3 = 1;  % 1 - yes, 0 - no
do_edge = 0;  % 1 - yes, 0 - no

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 0; % 1 - yes, 0 - no 
do_all_CELL = 1;  % 1 - yes, 0 -  no
 
   x_coord_min =  1;
   x_coord_max =  xLength;
   y_coord_min =  1;
   y_coord_max =  yLength;


M_marker_threshold = int16(zeros(xLength,yLength));
M_marker_threshold_CELL = int16(zeros(xLength,yLength));

M_Ca = int16(zeros(xLength,yLength));
M_Erk = int16(zeros(xLength,yLength));

  if (marker_from_channel(ii_Ca_marker)==ii_FITC)
      max_max_max_Ca   = max(max(max(M_FITC_total)));
  elseif (marker_from_channel(ii_Ca_marker)==ii_CY3)
      max_max_max_Ca   = max(max(max(M_CY3_total)));  
  end;


for kkk = 1:length(which_frames)
%for kkk = 1:1
  which_frame = which_frames(kkk);
 for jjj = 1:length(index_sample_frame_Ca)
     
     which_sample_frame = index_sample_frame_Ca(jjj);
        if (which_sample_frame == 1)
         start_frame = 1+1;
         end_frame = 1+num_sample_sequence(1);
        else
         start_frame = 1+sum(num_sample_sequence(1:which_sample_frame-1))+1;
         end_frame = 1+sum(num_sample_sequence(1:which_sample_frame));            
        end;
        
     
  if (marker_from_channel(ii_Ca_marker)==ii_FITC)
      M_Ca   = M_FITC_total(:,:,which_frame);
      max_max_Ca = max(max(M_Ca));
  elseif (marker_from_channel(ii_Ca_marker)==ii_CY3)
      M_Ca   = M_CY3_total(:,:,which_frame);
  end;
   
  
      M_marker_threshold = 0*M_marker_threshold;
       num_nuclei_dummy = eval(['Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects']);
      %for idx = 1:num_nuclei_dummy       
      %    M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}'])) + 1;
      %end;
      for idx = 1:num_nuclei_t0       
            idx_map   = index_map_tot_time_mapped_t0(idx,which_frame);         
          if( bursting_cytosolic_Ca_cells_per_sample_frame(idx,jjj) == 1)  
          M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = 4000;
            if (cytosolic_Ca_signal_adjusted(idx,which_frame)>threshold_burst_Ca)
             M_marker_threshold(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = 1000*cytosolic_Ca_signal_adjusted(idx,which_frame)/max(cytosolic_Ca_signal_adjusted(idx,start_frame:end_frame));
            end; 
             %M_marker_threshold(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = 1000;
          else
          M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = 2000;
          end;
%          M_marker_threshold(eval(['Cell_cytosol_FILL_',num2str(which_fram
%          e),'.PixelIdxList{idx_map}'])) = 1000*cytosolic_Ca_signal_adjusted(idx,which_frame)/max(cytosolic_Ca_signal_adjusted(idx,start_frame:end_frame));
      end;
 
  
  


figure(jjj)
%imagesc(M_marker_threshold+M_marker_threshold_CELL);
imagesc(M_marker_threshold);
%imagesc(max(int16(M_Ca),int16(max_max_max_Ca*M_marker_threshold)));
title(strcat('Segmented nuclei: which frame:',num2str(which_frame),', total frames:',num2str(numFr),',sample_frame:',num2str(which_sample_frame)));
   %hold on;                 
    for idx = 1:num_nuclei_t0
       which_nucleus = idx;
       %idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
          if( bursting_nuclear_Ca_cells_per_sample_frame(idx,jjj) == 1)  
                 x_coord_min = x_coord_min_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 x_coord_max = x_coord_max_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 y_coord_min = y_coord_min_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 y_coord_max = y_coord_max_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 
                                    rectangle('Position', [y_coord_min,x_coord_min,...
                                 y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                                       'EdgeColor', 'm');
                             text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
          end; % end of: if( bursting_nuclear_Ca_cells_per_sample_frame(idx,which_sample_frame) == 1)  
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
             
            if (do_plot_nuclei_number == 1)
             tt =  text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('t0:',num2str(idx)));                    
             set(tt,'Color','y');
            end; % if (do_plot_nuclei_number == 1)
    end;
   %hold off;
    xlim([1 yLength]);
    ylim([1 xLength]);


figure(length(index_sample_frame_Ca)+jjj)
%imagesc(M_marker_threshold+M_marker_threshold_CELL);
max_factor_Ca = .2;
M_Ca_max_factor = min(M_Ca,max_factor_Ca*max_max_max_Ca);
M_Ca_max_factor(1,1) = max_factor_Ca*max_max_max_Ca;
imagesc(min(M_Ca,max_factor_Ca*max_max_max_Ca));
%imagesc(max(int16(M_Ca),int16(max_max_max_Ca*M_marker_threshold)));
title(strcat('Segmented nuclei: which frame:',num2str(which_frame),', total frames:',num2str(numFr),',sample_frame:',num2str(which_sample_frame)));
   %hold on;                 
    for idx = 1:num_nuclei_t0
       which_nucleus = idx;
       %idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
          if( bursting_nuclear_Ca_cells_per_sample_frame(idx,jjj) == 1)  
                 x_coord_min = x_coord_min_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 x_coord_max = x_coord_max_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 y_coord_min = y_coord_min_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 y_coord_max = y_coord_max_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 
                                    rectangle('Position', [y_coord_min,x_coord_min,...
                                 y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                                       'EdgeColor', 'm');
                             text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
          end; % end of: if( bursting_nuclear_Ca_cells_per_sample_frame(idx,which_sample_frame) == 1)  
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
             
            if (do_plot_nuclei_number == 1)
             tt =  text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('t0:',num2str(idx)));                    
             set(tt,'Color','y');
            end; % if (do_plot_nuclei_number == 1)
    end;
   %hold off;
    xlim([1 yLength]);
    ylim([1 xLength]);
    
    
    
    pause(.2)
        
 end; % end of  'for jjj = 1:length(index_sample_frame_Ca)'
end;  % end of  'for kkk = 1:length(which_frames)





             
             
