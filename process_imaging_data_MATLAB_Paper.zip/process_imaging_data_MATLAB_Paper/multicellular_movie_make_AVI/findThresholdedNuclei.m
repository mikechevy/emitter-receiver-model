function [matrix_out,matrix_nucleus_fill,num_nuclei,box_coords,num_nuclei_grainy] = findThresholdedNuclei(matrix_nucleus,dimX,dimY,area_nucleus_min)


box_coords = zeros(1000,4);

matrix_nucleus_TEST = matrix_nucleus;
matrix_out = 0*matrix_nucleus;
matrix_ones = 0*matrix_nucleus+1;
matrix_nucleus_fill = 0*matrix_nucleus;

num_nuclei = 0;

which_nucleus = 0;
which_nucleus_grainy = 0;  % includes hits we through out

for ii = 1:dimX
    
    for jj = 1:dimY
      if (matrix_nucleus_TEST(ii,jj) == 1)             

        matrix_nucleus_SCRAP = 0*matrix_nucleus_TEST;
          
        which_nucleus = which_nucleus + 1;         
        which_nucleus_grainy = which_nucleus_grainy + 1;         
               
        FSTEP = 'W';
        if (ii == 1)
          FSTEP = 'S';
        end;
        
        %ii 
        %jj
      B = bwtraceboundary(matrix_nucleus,[ii jj],FSTEP);
         box_coords(which_nucleus,1) = min(B(:,1));
         box_coords(which_nucleus,2) = max(B(:,1));
         box_coords(which_nucleus,3) = min(B(:,2));
         box_coords(which_nucleus,4) = max(B(:,2));

                 x_coord_min = box_coords(which_nucleus,1);
                 x_coord_max = box_coords(which_nucleus,2);
                 y_coord_min = box_coords(which_nucleus,3);
                 y_coord_max = box_coords(which_nucleus,4); 
                 
         for iii = 1:length(B)
           matrix_nucleus_SCRAP(B(iii,1),B(iii,2)) = 1;
         end;
           matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');
         
         %matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = matrix_nucleus_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max);         
         
         
         do_plot = 0;
         if (do_plot ==  1)
          figure(11)
          imagesc(matrix_nucleus_SCRAP)
                 

          figure(10)
          imagesc(matrix_nucleus_TEST)
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
                    
          pause;
         end; % if (do_plot ==  1)
      
         
       %matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imclearborder(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max),4);
      
          matrix_nucleus_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = matrix_nucleus_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) - matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max);      

           % area_nucleus_min - threshold value for a minimum nucleus size in pixels
         if (area_nucleus_min < (x_coord_max-x_coord_min+1)*(y_coord_max-y_coord_min+1) ) 
          matrix_out(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = matrix_out(x_coord_min:x_coord_max,y_coord_min:y_coord_max) + which_nucleus*matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max);
          matrix_nucleus_fill(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = matrix_nucleus_fill(x_coord_min:x_coord_max,y_coord_min:y_coord_max) + matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max);
         else
          which_nucleus = which_nucleus-1;  %  do not include this one   
         end;
          
       end;
        
    end;
end;


num_nuclei = which_nucleus;
num_nuclei_grainy = which_nucleus_grainy;

%box_coords(1:num_nuclei,1)
%pause
box_coords = box_coords(1:num_nuclei,1:4);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Write code here to analyze the nuclei in each box to determine, based on
%  signal strength if there are separate nuclei that are simply touching.
%  Maybe try varying the threshold to see if a large portion suddenly
%  disappears.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%








