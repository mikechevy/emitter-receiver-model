


if  (read_rand==0)
else 
count_rand = 1;
end;


