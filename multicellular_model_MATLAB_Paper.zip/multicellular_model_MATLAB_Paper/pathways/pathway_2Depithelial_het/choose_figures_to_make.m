

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   which_case_simulation = 1,    Figure
%   which_case_simulation = 2,    Figure
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


which_case_simulation = 10;    % See list above: determines which figure(s) and simulations to run and plot 


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  Default Settings
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 do_ALL_bPAC = 0; % 0 - no, 1 set all cells to contain bPAC (all-emitter monolayer   
 do_IBMX = 0;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
 do_transfer_function_pulse = 0; % 1-yes (6 min.), 0 - no (40 min.) 
 do_parameter_sweep = 0; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
 %which_sweep = 8;  % there could be more than one type of sweeps for a given 'which_specific_example'
 which_modeling_case = 7;  % simulation space: 1 emitter, 45 receivers, 46 cells total
 

num_plot_loops = 1;  % loops through different species to plot

if (which_case_simulation == 1) % all-emitter simulations for Figure 5B-C and S7A
    
    do_ALL_bPAC = 1; % 0 - no, 1 set all cells to contain bPAC (all-emitter monolayer   
    do_transfer_function_pulse = 1; % 1-yes (6 min.), 0 - no (40 min.)
    which_specific_example = 504; % simple intracellular model, all-emitter tissue 
    do_parameter_sweep = 1; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
    which_sweep = 2;  % there could be more than one type of sweeps for a given 'which_specific_example'
    
elseif (which_case_simulation == 2)  %  all-emitter simulations with IBMX for Figure 5B-C and S6B-C
    
    do_ALL_bPAC = 1; % 0 - no, 1 set all cells to contain bPAC (all-emitter monolayer   
    do_IBMX = 1;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
    do_transfer_function_pulse = 1; % 1-yes (6 min.), 0 - no (40 min.)
    which_specific_example = 504; % simple intracellular model, all-emitter tissue 
    do_parameter_sweep = 1; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
    which_sweep = 2;  % there could be more than one type of sweeps for a given 'which_specific_example'
    
elseif (which_case_simulation == 3)  % all-emitter simulations for Figure 5D-E and S7D and S7F
    
    do_ALL_bPAC = 1; % 0 - no, 1 set all cells to contain bPAC (all-emitter monolayer   
    which_specific_example = 504; % simple intracellular model, all-emitter tissue 
    
elseif (which_case_simulation == 4)  % all-emitter simulations with IBMX for Figure 5D-E and S6E
    
    do_ALL_bPAC = 1; % 0 - no, 1 set all cells to contain bPAC (all-emitter monolayer   
    do_IBMX = 1;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
    which_specific_example = 504; % simple intracellular model, all-emitter tissue 
    
elseif (which_case_simulation == 5) % single-emitter-cluster simulations for Figure 5G 
    
    which_specific_example = 502; % constant gap junction activity, simple intracellular model 
    
elseif (which_case_simulation == 6) % single-emitter-cluster simulations for Figure S6G 
    
    which_specific_example = 502; % constant gap junction activity, simple intracellular model 
    do_parameter_sweep = 1; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
    which_sweep = 7;  % there could be more than one type of sweeps for a given 'which_specific_example'
    
elseif (which_case_simulation == 7) % single-emitter-cluster simulations for Figure 5H
    
    which_specific_example = 503; % constant gap junction activity, intracellular circuit with overshoot 

elseif (which_case_simulation == 8) % single-emitter-cluster simulations for Figure S6H
    
    which_specific_example = 503; % constant gap junction activity, intracellular circuit with overshoot 
    do_parameter_sweep = 1; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
    which_sweep = 6;  % there could be more than one type of sweeps for a given 'which_specific_example'
    
elseif (which_case_simulation == 9) % all-emitter simulations for Figure S6I
    
    do_ALL_bPAC = 1; % 0 - no, 1 set all cells to contain bPAC (all-emitter monolayer   
    which_specific_example = 503; % constant gap junction activity, intracellular circuit with overshoot     
    
elseif (which_case_simulation == 10) % single-emitter-cluster simulations for Figure 5I, S7C, and S9B
    
    str_which_case_simulation = 'single-emitter-cluster simulations for Figure 5I, S7C, and S9B';
    
    which_specific_example = 504; % delayed regulation gap junction model, simple intracellular model 
    
elseif (which_case_simulation == 11) % single-emitter-cluster simulations for Figure 7A
    
    which_specific_example = 504; % delayed regulation gap junction model, simple intracellular model 
    do_parameter_sweep = 1; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
    which_sweep = 3;  % there could be more than one type of sweeps for a given 'which_specific_example'
    
elseif (which_case_simulation == 12) % single-emitter-cluster simulations for Figure 7B
    
    which_specific_example = 504; % delayed regulation gap junction model, simple intracellular model 
    do_IBMX = 1;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
    do_parameter_sweep = 1; % 0-just specific example, 1-parameter sweep defined for each 'which_specific_example'      
    which_sweep = 3;  % there could be more than one type of sweeps for a given 'which_specific_example'
    
elseif (which_case_simulation == 13) % single-emitter-cluster simulations, reduced number of receivers, for Figure S7C
    
    which_specific_example = 504; % delayed regulation gap junction model, simple intracellular model 
    which_modeling_case = 2;  %  simulation space: 1 emitter, 11 cells totalcluster, 12 cells total
    
elseif (which_case_simulation == 14) % single-emitter-cluster simulations with IBMX for Figure S8A and S9A

    do_IBMX = 1;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
    which_specific_example = 504; % delayed regulation gap junction model, simple intracellular model for Figure 5I and 7C 
    
elseif (which_case_simulation == 15) % single-emitter-cluster simulations for Figure S8B
    
    which_specific_example = 801; % delayed regulation gap junction model, simple intracellular model, reduces gap-junctional flux 
    
elseif (which_case_simulation == 16) % single-emitter-cluster simulations for Figure S8C
    
    which_specific_example = 802; % delayed regulation gap junction model, simple intracellular model, reduces gap-junctional flux 

elseif (which_case_simulation == 17) % single-emitter-cluster simulations for Figure 6C (case 2) and S9C 
    
    which_specific_example = 602; % two-population delayed regulation gap junction model, simple intracellular model 

elseif (which_case_simulation == 18) % single-emitter-cluster simulations for Figure 6C (case 3) and S9D 
    
    which_specific_example = 603; % two-population (fast only) delayed regulation gap junction model, simple intracellular model 
    
elseif (which_case_simulation == 19) % single-emitter-cluster simulations with undershoot for Figure6D and S9E
    
    which_specific_example = 604; % delayed regulation gap junction model, simple intracellular model, undershoot inccluded 
    
elseif (which_case_simulation == 20) % single-emitter-cluster simulations with undershoot (with IBMX) for Figure6E
    
    do_IBMX = 1;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
    which_specific_example = 604; % delayed regulation gap junction model, simple intracellular model, undershoot inccluded 

elseif (which_case_simulation == 21) % single-emitter-cluster simulations with undershoot (PKA feedback on AC) for Figure6D
    
    which_specific_example = 605; % delayed regulation gap junction model, simple intracellular model, undershoot inccluded 
    
elseif (which_case_simulation == 22) % single-emitter-cluster simulations with undershoot (with IBMX and PKA feedback on AC ) for Figure6E
    
    do_IBMX = 1;  % PDE inhibitor IBMX: set in setup_cAMP_circuit_parameters_mike.m at   fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
    which_specific_example = 605; % delayed regulation gap junction model, simple intracellular model, undershoot inccluded 

end;

