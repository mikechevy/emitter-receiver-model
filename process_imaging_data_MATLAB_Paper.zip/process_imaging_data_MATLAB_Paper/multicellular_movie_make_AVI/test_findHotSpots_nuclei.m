

%HotSpotsVerstion

which_frame = 1;
Val_threshold = max(max(matrix_nucleus));

M_marker_threshold = matrix_nucleus;
M_signal_threshold = matrix_nucleus;
M_marker_threshold_TEST = M_marker_threshold;

if (which_frame == 1)
event_x_tot = [];
event_y_tot = [];
event_id_tot = [];
event_size_tot = [];
event_start_tot = [];
box_coords = [];
box_coords_pca = [];
end;

which_box = 0;

  for ii_index = 1:length(M_marker_threshold(:,1))
      %ii_index 
      %length(M_marker_threshold(:,1))
    for jj_index = 1:length(M_marker_threshold(1,:))

        if M_marker_threshold_TEST(ii_index,jj_index) == Val_threshold

            
               %%%%determine_box_size;
               determine_box_size_cluster;
               which_box
            
               start_dummy = sum(event_size_tot);
               event_x_tot = [event_x_tot event_x]; 
               event_y_tot = [event_y_tot event_y]; 
               event_id_tot = [event_id_tot which_box*ones(1,length(event_x))]; 
               event_size_tot = [event_size_tot size_hot_spot_groups(which_hot_spot)];
               event_start_tot = [event_start_tot start_dummy]; 

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %  Calculate the moments of each nuclues
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        mean_x_tot(which_box) = mean(event_x_tot(event_start_tot(which_box)+1:event_start_tot(which_box)+event_size_tot(which_box)));
        var_x_tot(which_box) = var(event_x_tot(event_start_tot(which_box)+1:event_start_tot(which_box)+event_size_tot(which_box)),1);
        mean_y_tot(which_box) = mean(event_y_tot(event_start_tot(which_box)+1:event_start_tot(which_box)+event_size_tot(which_box)));
        var_y_tot(which_box) = var(event_y_tot(event_start_tot(which_box)+1:event_start_tot(which_box)+event_size_tot(which_box)),1);
        M_dummy = cov(event_x_tot(event_start_tot(which_box)+1:event_start_tot(which_box)+event_size_tot(which_box)),event_y_tot(event_start_tot(which_box)+1:event_start_tot(which_box)+event_size_tot(which_box)),1);
        cov_xy_tot(which_box) = M_dummy(1,2);       
            
            % ensures ellipse is drawn
            if var_x_tot(which_box == 0)
                var_x_tot(which_box) = 1;
            end;
            if var_y_tot(which_box == 0)
                var_y_tot(which_box) = 1;
            end;
            
            
            %pause
                
        end;  % end of 'if M_marker_threshold_TEST(ii_index,jj_index) == Val_threshold'

    end;
  end;
  
    
    plot_thresholded_images
    num_marker = which_box;  


