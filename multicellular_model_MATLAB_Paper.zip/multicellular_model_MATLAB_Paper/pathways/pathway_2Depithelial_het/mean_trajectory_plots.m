
time_sampled_dummy = time_sampled/60;  % minutes
time_sampled_dummy = time_sampled_dummy-tau_sequence;  % first pulse is the stationary solution

       
      sample_block = floor(num_sampled_ssa/num_X_random_samples);


which_ic_in = 92;
which_ic_out = 230;
which_bit_test = 1;


ic_value = 19

ii_count = 0;

ii_count_Se = [0 0 0 0];
%which_ic_in_Se = [20 80 130 250];
which_ic_in_Se = [ic_value ic_value ic_value ic_value];
%which_ic_in_Se = [30 100 160 250];


%for ii_test = 1:300
for ii_test = 1:num_runs

  if (do_initial_condition_delta == 1)
    if (X_array(ii_test,which_bit_test*sample_block+1)==which_ic_in)&(X_array(ii_test,which_bit_test*sample_block+2)<=which_ic_out+5)&(X_array(ii_test,which_bit_test*sample_block+2)>=which_ic_out-5)&(ii_count==0)
        index_ic = ii_test;
        ii_count=1;
        
        
        figure(1000)
        subplot(2,1,1)
        h1 = plot(time_sampled_dummy(which_bit_test*sample_block:(which_bit_test+1)*sample_block),Y_array(ii_X,which_bit_test*sample_block:(which_bit_test+1)*sample_block),'b')
        xlabel('time (minutes)');
        ylabel('X(t)');
        subplot(2,1,2)
        hold on;
        h1 = plot(time_sampled_dummy(which_bit_test*sample_block:(which_bit_test+1)*sample_block),Y_array(index_ic,which_bit_test*sample_block:(which_bit_test+1)*sample_block),'b')
        set(h1,'LineWidth',2);
        h1 = plot(time_sampled_dummy(which_bit_test*sample_block+2:(which_bit_test+1)*sample_block),Y_array(index_ic,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)+sqrt(Cov_Y_array(index_ic,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)/2),'b--')
        set(h1,'LineWidth',1);
        h1 = plot(time_sampled_dummy(which_bit_test*sample_block+2:(which_bit_test+1)*sample_block),Y_array(index_ic,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)-sqrt(Cov_Y_array(index_ic,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)/2),'b--')
        set(h1,'LineWidth',1);
             plot([time_sampled_dummy(which_bit_test*sample_block+2)  time_sampled_dummy((which_bit_test+1)*sample_block)],[P_Y_X_properties(1,Y_info_index(1))-sqrt(P_Y_X_properties(1,num_molecules+Y_info_index_cov_map(1))/2) P_Y_X_properties(1,Y_info_index(1))-sqrt(P_Y_X_properties(1,num_molecules+Y_info_index_cov_map(1))/2)],'k--');
             plot([time_sampled_dummy(which_bit_test*sample_block+2)  time_sampled_dummy((which_bit_test+1)*sample_block)],[P_Y_X_properties(num_X_input_samples,Y_info_index(1))+sqrt(P_Y_X_properties(num_X_input_samples,num_molecules+Y_info_index_cov_map(1))/2) P_Y_X_properties(num_X_input_samples,Y_info_index(1))+sqrt(P_Y_X_properties(num_X_input_samples,num_molecules+Y_info_index_cov_map(1))/2)],'k--');
             ylim([0 1.1*P_Y_X_properties(num_X_input_samples,Y_info_index(1))]);
             xlim([0 time_sampled_dummy((which_bit_test+1)*sample_block)]);
        hold off;   
        xlabel('time (minutes)');
        ylabel('Y(t)');
        title(strcat('mean trajectories, x_1=',num2str(which_ic_out),',0<=x_1<=251'));
        legend('mean', 'mean +- std');
    end;
  elseif (do_initial_condition_delta == 0)
       for kkk = 1:length(ii_count_Se)  
             del_x = 15;
         if (X_array(ii_test,which_bit_test*sample_block+1)>=which_ic_in_Se(kkk)-del_x)&(X_array(ii_test,which_bit_test*sample_block+1)<=which_ic_in_Se(kkk)+del_x)&(X_array(ii_test,which_bit_test*sample_block+2)<=which_ic_out+del_x)&(X_array(ii_test,which_bit_test*sample_block+2)>=which_ic_out-del_x)&(ii_count_Se(kkk)==0)
             index_Se = ii_test
             ii_count_Se(kkk)=1;
        
             
             
X_out = X_array(index_Se,(which_bit_test+1)*sample_block)                     
[val index_X_out] = min(abs(X_out-floor(P_Y_X_properties(:,ii_X))));

X_test = ones(sample_block+1,1);
X_test = X_test*P_Y_X_properties(index_X_out,ii_X);

Y_test = ones(sample_block+1,1);
Y_test = Y_test*P_Y_X_properties(index_X_out,Y_info_index(1))



             figure(1000)
        subplot(2,1,1)
        hold on;
             h1 = plot(time_sampled_dummy(which_bit_test*sample_block:(which_bit_test+1)*sample_block),X_test,'r--')
        set(h1,'LineWidth',2);
        h1 = plot(time_sampled_dummy(which_bit_test*sample_block:(which_bit_test+1)*sample_block),X_array(index_Se,which_bit_test*sample_block:(which_bit_test+1)*sample_block),'b')
        set(h1,'LineWidth',2);
        hold off;
        xlabel('time (minutes)');
        ylabel('X(t)');
        subplot(2,1,2)
             hold on;
             h1 = plot(time_sampled_dummy(which_bit_test*sample_block:(which_bit_test+1)*sample_block),Y_test,'r--')
        set(h1,'LineWidth',2);
             h1 = plot(time_sampled_dummy(which_bit_test*sample_block:(which_bit_test+1)*sample_block),Y_array(index_Se,which_bit_test*sample_block:(which_bit_test+1)*sample_block),'g')
        set(h1,'LineWidth',2);
         %    h1 = plot(time_sampled_dummy(which_bit_test*sample_block+2:(which_bit_test+1)*sample_block),Y_array(index_Se,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)+sqrt(Cov_Y_array(index_Se,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)/2),'g--')
        %set(h1,'LineWidth',1);
         %    h1 = plot(time_sampled_dummy(which_bit_test*sample_block+2:(which_bit_test+1)*sample_block),Y_array(index_Se,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)-sqrt(Cov_Y_array(index_Se,which_bit_test*sample_block+2:(which_bit_test+1)*sample_block)/2),'g--')
        %set(h1,'LineWidth',1);
             hold off;        
         end;
           
       end;    
  end;
           
        
 end;
 
 
 