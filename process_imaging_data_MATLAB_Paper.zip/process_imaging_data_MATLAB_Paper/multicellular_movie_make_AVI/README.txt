

This describes the basic sequence of matlab scripts called to process and analyze the multi-cellular movies.
Within each of these scripts, other scripts and functions are called.  Many of those are described 
within a given scripts itself.


-----------------------------------------
load_and_process_multicellular_movie.m
-----------------------------------------
1) Initial script to call for loading in and processing a given movie

a) Asks the number of the movie to load.  The numbers are
mapped to specific movie names in 'get_movie_info_for_processing.m'. NOTE: before the movie is loaded
it must be registered in 'get_movie_info_for_processing.m' and assigned a number so that is can be properly 
loaded. Currently this contains the pathway markers used, the time-sampling, etc.
A directory for the processed movie is created and arrays of the individual markers 
over time and space are created and saved in a file.  This whole process is skipped
if this was already been done on a prior run.

b) It then calls the script process_multicellular_move



-----------------------------------------
process_multicellular_movie.m
-----------------------------------------

1) Calls the script 'determine_nuclear_locations_adaptive_recursive.m' to determine nuclei locations in each image
and saves this data:  centered mean locations for each nuclei, pixel locations for each nuclei in each image.
This data is called by later scripts for various processing. More details of the approach and its limitations are discussed in the script.

2) Calls the script 'load_and_track_nuclear_locations.m'.  This tracks individual nuclei through the time sequence of images while mapping their indexes from image to image (as their index might not remain the same between successive images).  More details of the approach and its limitations are discussed in the script. 

3) Calls the script 'load_and_calculate_cellular_signals.m'.  This calculates the average nuclear and cytosolic signals for each cell over time using all the prior, processed data. NOTE:  We currently have a very simple cytosolic calcuation based on a ring around the nucleus, this will be improved in the future for instance if the ring extends into another cells (mixed-cell signal) which we don't want.want.

4) Calls the script 'load_and_analyze_cellular_signals.m'.  This currently analyzed the spatio-temporal characteristics of signal across the tissue.  It looks for correlated signals and clusters these cells.
This will be a work in progress throughouth the project.  Other signaling statistics of the tissue can be calculates as well.  More details of the approach and its limitations are discussed in the script.



-----------------------------------------
Executing individual scripts
-----------------------------------------
Importantly, if we are happy with the processed data from a given state, e.g. the nuclei locations are acceptable, 
but want to tinker with the 'load_and_track_nuclear_locations.m' script then one can start MATLAB in the processing code directory and type in 'load_and_track_nuclear_locations'.  It will then for which movie to process. Note it will only execute the script called and not continue to subsequent scripts as called in 'process_cellular_movie.m'.



-----------------------------------------

Making movies within a small box in the field of view:

-----------------------------------------

load_processed_images_and_make_movie_BOX.m and make_movie_BOX.m  will load in a given movie and the use in movie_make_BOX.m can iteritativle choose a region 
field of view of the image that they wish to make a movie of.  In addition, they can have given frames output as .eps files.  This is set in get_movie_info_for_processing. 
To do this, they must set 'do_make_figure = 1' within the allocations for a given movie. They also must 'which_frames_to_save' array to the fromes wanted. For 
example, in which_movie == 203 we have do_make_figure = 1 and which_frames_to_save = [119 139 180];



-----------------------------------------

Processing statistic for emitter ERK-KTR N/C signals such as overshoot, and time-to-max:

-----------------------------------------

all-emiiter exeriments:
load_and_analyze_mean_std_statistics.m calls analyze_Erk_cellular_response_to_bPAC_mean_std_statistics where it calculates new statistics 
(ratio_overshoot_ss_bPAC_pulse_cell_REVISE so far) and overwrite old statistics array (ratio_overshoot_ss_bPAC_pulse_cell so far)
and with the new statistics arrays calls make_bPAC_statistics_plots_mean_std.m to make plots.

load_and_plot_bPAC_cluster_statistics_p_value.m loads statistics generated from analyze_Erk_cellular_response_to_bPAC_statistics.m called 
from load_and_analyze_bPAC_cluster_statistics.m.  It calls make_bPAC_statistics_plots_p_value.m (used for the all-emitter results).

pooled single-emitter-cluster and small-emitter-cluster experiments
combine_experiments_for_bPAC_cluster_statistics_p_value.m  has user-defined groups (single-emitter-cluster experiments (case 3), 
small-emitter cluster experiments (case 4 (wild-type) and case 5 (MDCKII receivers)) to pool together for statistical power.  
It calls make_bPAC_statistics_plots_p_value.m for each experiment and combines data to make plots.

annotated small emitter cluster experiments.
load_and_analyze_annotated_bPAC_clusters.m calls make_annotated_bPAC_clusters then analyze_annotated_bPAC_clusters 
then make_annotated_make_bPAC_statistics_plots_annotated_bPAC_clusters_p_values.m calls and. One of the folder of these outputs is 
'statistics_plots_annotated'. 
 
FOR REVISIONS, DR. PIDOUX wanted extra statistical measures, we test, save, and plot new statistics using
load_and_generate_and_plot_NEW_bPAC_cluster_statistics_REVISE calls generate_NEW_bPAC_statistics_and_plots_REVISE which calls
view_specific_Erk_cellular_response_to_bPAC_statistics_REVISE (calculates statistics and plots them for each emitter).
Statistics plots are put in folder 'statistics_plots_NEW'