
                 x_coord_min = x_coord_min_local;
                 x_coord_max = x_coord_max_local;
                 y_coord_min = y_coord_min_local;
                 y_coord_max = y_coord_max_local;
                 
                 %x_coord_min = 1;
                 %x_coord_max = xLength;
                 %y_coord_min = 1;
                 %y_coord_max = yLength;

%index_group = [];               
ii_count = 0;
index_group = [];
for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
    end;
end;
                 


%for kkk = 1:length(which_frames)
for kkk = 1:1
  which_frame = which_frames(kkk)
  
  
 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
M_marker_threshold_TEST = zeros(xLength,yLength);

 for jjj = 1:length(index_group)
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_DAPI_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end;

 

figure(22)
imagesc(M_marker_threshold_TEST)
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr),', movie: ',str_movie));
   hold on;                 
    for jj = 1:length(index_group)
       idx = index_group(jj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             %set(ll,'Color','y');
             xx = text(mean_y_tot_time_mapped_t0(idx,1),mean_x_tot_time_mapped_t0(idx,1),'x');                  
             set(xx,'Color','w');
       
        
%             if (bursting_nuclear_Ca_cells_per_sample_frame(idx) == 1)
%                  hold on;
%                  x_coord_min_dummy = box_coords(idx,1);
%                  x_coord_max_dummy = box_coords(idx,2);
%                  y_coord_min_dummy = box_coords(idx,3);
%                  y_coord_max_dummy = box_coords(idx,4);
%                  rectangle('Position', [y_coord_min_dummy,x_coord_min_dummy,...
%                    y_coord_max_dummy-y_coord_min_dummy,x_coord_max_dummy-x_coord_min_dummy],...
%                          'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
%                          'EdgeColor', 'w');
%                  hold off;
%             end;
            
    end;
   hold off;
    xlim([max(y_coord_min-40,1) min(y_coord_max+40,yLength)]);
    ylim([max(x_coord_min-40,1) min(x_coord_max+40,yLength)]);

end; %for kkk = 1:
