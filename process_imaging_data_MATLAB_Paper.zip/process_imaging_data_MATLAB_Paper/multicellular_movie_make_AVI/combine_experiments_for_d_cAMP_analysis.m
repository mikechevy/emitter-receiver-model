close all;

%  Script to generate statistics for the paper
set_globals;

str_processing = pwd;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: Set Default Values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do_DMSO  = 0;
do_8_Br_cAMP = 0;
do_Forskolin = 0;
do_ESI09 = 0;
do_bPAC = 0;
do_H89 = 0;

dose_array_drug = [];
str_drug = [];

do_single_cell_Erk_signal_eps = 0; % 1-yes, 0-no 

do_last_time_sample = 0;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

do_annotated_bPAC_cluster_linked = 0;  % 1 - yes, 0 - no 
do_full_range_ylim = 0;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own

num_plot_single_pulse = 0;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_shift_plot_single_pulse = 0;
time_begin_plot_single_pulse = 0;
time_end_plot_single_pulse = 0;

do_average_non_bPAC_inner = 1;  % 1- average (total signal dived by number of cells) , 0 - total signal (integral)
  non_bPAC_clusters_outer = [];
  non_bPAC_clusters_inner = [];
  
  size_bPAC_clusters = [];
  size_non_bPAC_clusters = [];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END: Set Default Values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





do_case = 32;  % select case to run, where each case is setup in 'experiments_to_combine_d_cAMP_analysis.m'

experiments_to_combine_d_cAMP_analysis;

do_link_nuclei = 0;  % 1-link nuclei across movies for single cell analysis, 0- run linked systems or just average (depends of linked nuclei occured



            if (do_DMSO == 0)
             if (do_8_Br_cAMP == 0)&(do_Forskolin == 0) & (do_bPAC == 0)& (do_H89 == 0)  
             str_input = 'dBcAMP (\mu M)';
             elseif do_8_Br_cAMP == 1
             str_input = '8-Br-cAMP (\mu M)';
             elseif do_Forskolin == 1
             str_input = 'Forskolin (\mu M)';
             elseif do_bPAC == 1
             str_input = 'bPAC input';
             elseif do_H89 == 1
             str_input = 'H89';
             end;
            else
             str_input = 'DMSO (\mu L/.3 mL)';
            end;          


ii_plot_count = 0;
max_value = 0;
min_value = 1e10;


time_Erk_array = [];
time_bPAC_array = [];
bPAC_ledvals_array = [];
Erk_signal_d_cAMP_average_array = [];
Erk_signal_d_cAMP_average_sum_array = [];
Erk_signal_d_cAMP_array = [];
num_doses_TF = min(3,length(dose_array));

TF_data_average = [];


if (do_link_nuclei == 1)

  link_nuclei_across_movies_d_cAMP

elseif (do_link_nuclei == 0)

  cd('../combined_d_cAMP/')
  mkdir(strcat('do_case_',num2str(do_case)));
  cd(strcat('do_case_',num2str(do_case)))
    
   if (exist('linked_nuclei_across_movies.mat','file')==2)  % single cell data and better averages
     exist_linked_nuclei = 1;
     load('linked_nuclei_across_movies');
     Erk_signal_d_cAMP_array = zeros(num_nuclei_t0_max, sum(num_time_samples_array));
   else % do bulk average, old way
     exist_linked_nuclei = 0;
   end;

cd(str_processing) 
    
    
  for ii_which_movie = 1:length(movie_array)

  which_movie = movie_array(ii_which_movie); 

  get_movie_info_for_processing;

  str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')


  cd(str_movie_processed);
  % load file
  load('d_cAMP_arrays');
  cd(str_processing) 

  if (ii_which_movie == 1)
     num_nuclei_t0_first = num_nuclei_t0
    % mean_x_tot_time_mapped_t0_first = mean_x_tot_time_mapped_t0;
    % mean_y_tot_time_mapped_t0_first = mean_y_tot_time_mapped_t0;
     mean_x_tot_time_mapped_t0_first = mean_x_tot_time_mapped_t0_array(1:num_nuclei_t0,1);
     mean_y_tot_time_mapped_t0_first = mean_y_tot_time_mapped_t0_array(1:num_nuclei_t0,1);
     bPAC_NUCLEUS_time_mapped_t0_first = bPAC_NUCLEUS_time_mapped_t0;
  end;    
      
  if (ii_which_movie > 1)
  %time_Erk = time_Erk + (ii_which_movie-1)*max(time_Erk);
  %time_bPAC = time_bPAC + (ii_which_movie-1)*max(time_bPAC);
  time_Erk = time_Erk + max(time_Erk_array);
  time_bPAC = time_bPAC + max(time_bPAC_array);
  end;

  
  if (length(dose_array_drug) > 0)
      if (ii_which_movie == index_time_drug)
          time_drug = time_Erk(1);
           if (ii_which_movie == 1)
               time_drug = 0;
           end;
      end;
  end;
  
  if (do_bPAC == 0)
  bPAC_ledvals = 0*bPAC_ledvals + dose_array(ii_which_movie);
  else
  bPAC_ledvals = bPAC_ledvals;
  end;
  
  time_Erk_array = [time_Erk_array time_Erk'];
  time_bPAC_array = [time_bPAC_array time_bPAC];
  bPAC_ledvals_array = [bPAC_ledvals_array  bPAC_ledvals];


  Erk_signal_d_cAMP_average_array = [Erk_signal_d_cAMP_average_array  Erk_signal_d_cAMP_average];
  Erk_signal_d_cAMP_average_sum_array = [Erk_signal_d_cAMP_average_sum_array  sum(Erk_signal_d_cAMP)/length(sum(Erk_signal_d_cAMP'))];
  min_value = min(min_value, min(Erk_signal_d_cAMP_average));
  max_value = max(max_value, max(Erk_signal_d_cAMP_average));

  TF_data_average = [TF_data_average; Erk_signal_d_cAMP_average(length(Erk_signal_d_cAMP_average)-1)];

     
  
    if (exist_linked_nuclei == 1) % linked nuclei, single_cell_analysis
    %Erk_signal_d_cAMP_array = [Erk_signal_d_cAMP_array Erk_signal_d_cAMP]
    %exist_linked_nuclei
    
      for jj_Erk = 1:num_nuclei_t0_first
          if (linked_nuclei_across_movies_success(jj_Erk) == 1)
            if (ii_which_movie == 1)
             Erk_signal_d_cAMP_array(jj_Erk,1:num_time_samples_array(ii_which_movie)) = Erk_signal_d_cAMP(jj_Erk,:);
             %zeros(num_nuclie_t0_max, sum(num_time_samples_array));              
            else
             index_jj_Erk_map = linked_nuclei_across_movies_array(jj_Erk,ii_which_movie);
             Erk_signal_d_cAMP_array(jj_Erk,sum(num_time_samples_array(1:ii_which_movie-1))+1:sum(num_time_samples_array(1:ii_which_movie-1))+num_time_samples_array(ii_which_movie)) = Erk_signal_d_cAMP(index_jj_Erk_map,:);              
            end;
          end;             
      end;
    
    end;

  end;


  time_Erk = time_Erk_array;
  time_bPAC = time_bPAC_array;
  bPAC_ledvals = bPAC_ledvals_array;
  Erk_signal_d_cAMP_average = Erk_signal_d_cAMP_average_array;
  Erk_signal_d_cAMP_average_sum = Erk_signal_d_cAMP_average_sum_array;
  
  
  time_CH1 = time_Erk;  % hardwired for this experiment
  time_CH4 = time_Erk;  % hardwired for this experiment
  
  
  sig_dummy_average_bPAC_pulse_cell = Erk_signal_d_cAMP_average;
    figure(1112)
    subplot(3,1,1)
     hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell, 'b');
         set(ss,'LineWidth',2);
     ss = plot(time_Erk/scale_factor_time,Erk_signal_d_cAMP_average_sum, 'g--');
         set(ss,'LineWidth',3);
             if (length(dose_array_drug) > 0)
              plot([time_drug/scale_factor_time time_drug/scale_factor_time],[max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)],'k--');
             end;
         ylim([max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
          xlabel('time (minutes)');
             if (length(dose_array_drug) == 0)
              title(strcat('average Erk-KTR signal'));
             else 
              title(strcat('average Erk-KTR signal,',str_drug,' added at t=',num2str(time_drug/scale_factor_time),' m'));
             end;
     hold off;
    subplot(3,1,2)
     hold on;
            ylabel(str_input);
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
             if (length(dose_array_drug) > 0)
              plot([time_drug/scale_factor_time time_drug/scale_factor_time],[0 max(1.1*max(bPAC_ledvals),1e-6)],'k--');
             end;
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 max(1.1*max(bPAC_ledvals),1e-6)]);
          xlabel('time (minutes)');
         % xlabel(str_time_representation);
          hold off;
    subplot(3,1,3)
     hold on;
          ylabel('ERK-KTR (N/C)');
          plot(dose_array(1:num_doses_TF), TF_data_average(1:num_doses_TF));
          xlim([0 1.1*max(dose_array)]);
          ylim([max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)]);
            xlabel(str_input);
         % xlabel(str_time_representation);
          hold off;

   fig1112 = figure(1112);





cd('../combined_d_cAMP/')
mkdir(strcat('do_case_',num2str(do_case)));
cd(strcat('do_case_',num2str(do_case)))
copyfile('../saveppt2.m','saveppt2.m');

     delete(strcat(str_movie,'-Erk_average_d_cAMP.ppt'));
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells)');
     saveppt2(strcat(str_movie,'-Erk_average_d_cAMP.ppt'),'figure',[fig1112], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_d_cAMP.eps'));   

                            
               
    if (exist_linked_nuclei == 1)&(do_annotated_bPAC_cluster_linked == 0) % linked nuclei, single_cell_analysis
        
        
     delete(strcat(str_movie,'-linked_nuclei_Erk_average_d_cAMP.ppt'));
     delete(strcat(str_movie,'-linked_nuclei_Erk_single_cells_d_cAMP.ppt'));
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: DETERMIN bPAC PULSE WIDTHS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     
          diff_bPAC_signal = diff(bPAC_ledvals);
          
%  determine pulse locations here, bPAC
             num_pulses = 0;
             num_bPAC_pulses = 0;
             index_bPAC_pulse_start = [];
             index_bPAC_pulse_stop = [];
     for ii = 1:length(diff_bPAC_signal)
         
         if (diff_bPAC_signal(ii) > 0)
             index_bPAC_pulse_start(num_bPAC_pulses+1) = ii+1; % top of pulse (rise)
             num_bPAC_pulses = num_bPAC_pulses + 1;
         elseif (diff_bPAC_signal(ii) < 0)
             index_bPAC_pulse_stop(num_bPAC_pulses) = ii; % top of pulse (decline)
         end;
             
     end;
            if length(index_bPAC_pulse_stop) < length(index_bPAC_pulse_start)
                index_bPAC_pulse_stop(num_bPAC_pulses) = length(time_bPAC); 
            end;
            
            
            
            %  this calculates the end of each step-pulse that are all but
            %  the last in a step-up sequence
            if (num_bPAC_pulses > 1)
               for ii = 1:num_bPAC_pulses -1
                if (index_bPAC_pulse_stop(ii) == 0)
                   index_bPAC_pulse_stop(ii) = index_bPAC_pulse_start(ii+1)-1;
                end;
               end;
            end;
            

%  determine indexes of time_Erk that are within the bPAC pulse times
             index_bPAC_pulse_start_Erk = [];
             index_bPAC_pulse_stop_Erk = [];
     for ii = 1:num_bPAC_pulses
  
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_start(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_start(ii)) )
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy+1;         
          %else
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
          %end;
          index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         
          
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_stop(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_stop(ii)) )
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy;         
          %else
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy-1;          
          %end;
          index_bPAC_pulse_stop_Erk(ii) =  min(index_dummy+1,length(time_Erk));   % captures full experimental duration of pulse       

     
     end;     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END: DETERMIN bPAC PULSE WIDTHS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        sig_dummy_single_cell = zeros(sum(num_time_samples_array),1);
        sig_dummy_single_cell_average = zeros(sum(num_time_samples_array),1);
        
      for jj_Erk = 1:num_nuclei_t0_first

         %sig_dummy_average_bPAC_pulse_cell = Erk_signal_d_cAMP_average
         
         
       if (linked_nuclei_across_movies_success(jj_Erk)==1)         

         sig_dummy_single_cell(:) = Erk_signal_d_cAMP_array(jj_Erk,:); 
         sig_dummy_single_cell_average = sig_dummy_single_cell_average + sig_dummy_single_cell;

         min_value = min(sig_dummy_single_cell);
         max_value = max(sig_dummy_single_cell);
           
           
       figure(2112)
       subplot(3,1,1)
        hold on;
        ss = plot(time_Erk/scale_factor_time,sig_dummy_single_cell, 'b');
            set(ss,'LineWidth',2);
          for ii = 1:num_bPAC_pulses     
              s_pulse = ['g' 'r' 'g' 'r'];
         %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
         ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy_single_cell(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(ii));
               set(ss,'LineWidth',3);
          end;
            
%        ss = plot(time_Erk/scale_factor_time,Erk_signal_d_cAMP_average_sum, 'g--');
%            set(ss,'LineWidth',3);
             if (length(dose_array_drug) > 0)
              plot([time_drug/scale_factor_time time_drug/scale_factor_time],[max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)],'k--');
             end;
            ylim([max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)]);
            xlim([0 max(time_Erk)/scale_factor_time]);
            ylabel('ERK-KTR (N/C)');
             xlabel('time (minutes)');
             title(strcat('nucleus:',num2str(jj_Erk)));
             if (length(dose_array_drug) == 0)
              title(strcat('nucleus:',num2str(jj_Erk)));
             else 
             title(strcat('nucleus:',num2str(jj_Erk),',',str_drug,'added at t=',num2str(time_drug/scale_factor_time),' m'));
             end;
        hold off;
       subplot(3,1,2)
        hold on;
            ylabel(str_input);
            
             plot(time_bPAC/scale_factor_time,bPAC_ledvals);
             if (length(dose_array_drug) > 0)
              plot([time_drug/scale_factor_time time_drug/scale_factor_time],[0 max(1.1*max(bPAC_ledvals),1e-6)],'k--');
             end;
             xlim([0 max(time_Erk)/scale_factor_time]);
             ylim([0 max(1.1*max(bPAC_ledvals),1e-6)]);
             xlabel('time (minutes)');
            % xlabel(str_time_representation);
             hold off;
       subplot(3,1,3)
        hold on;        
                     min_value = min(TF_data_average(1:num_doses_TF));
                    max_value = max(TF_data_average(1:num_doses_TF));

             ylabel('Erk-KTR (N/C)');
             plot(dose_array(1:num_doses_TF), TF_data_average(1:num_doses_TF));
             xlim([0 1.1*max(dose_array)]);
             ylim([max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)]);
             title('currently the original average, need to write code for single cell linked TF');
            xlabel(str_input);
            % xlabel(str_time_representation);
             hold off;

             
       cd(str_processing) 
       
       plot_nuclei_single_movies_d_cAMP;  % test here, uses idx             
       cd('../combined_d_cAMP/')
       cd(strcat('do_case_',num2str(do_case)))

       fig10000 = figure(10000);       
       fig2112 = figure(2112);

          s_combine = strcat(str_movie,':single cell Erk signals (pulsing cells)');
          saveppt2(strcat(str_movie,'-linked_nuclei_Erk_single_cells_d_cAMP.ppt'),'figure',[fig10000 fig2112], 'halign','center','title', s_combine);

                          if (do_single_cell_Erk_signal_eps == 1)
                             if (bPAC_NUCLEUS_time_mapped_t0_first(jj_Erk,1) == 1)     
                               str_bPAC = ' (bPAC)';
                               str_bPAC_eps = '-bPAC';
                             else
                               str_bPAC = ' (non-bPAC)';
                               str_bPAC_eps = '-non-bPAC';
                             end;

                             print('-depsc',strcat('nuc_',num2str(jj_Erk),str_bPAC_eps,'-Erk-',str_movie,'.eps'));   
                          end;
          
       close 2112;

       end; % enf of 'if (linked_nuclei_across_movies_success(jj_Erk)==1)'         
       
      end;  %  end of 'for jj_Erk = 1:num_nuclei_t0_first'

         sig_dummy_single_cell_average = sig_dummy_single_cell_average/sum(linked_nuclei_across_movies_success);
      
         min_value = min(sig_dummy_single_cell_average);
         max_value = max(sig_dummy_single_cell_average);
         
         
       figure(2113)
       subplot(3,1,1)
        hold on;
        ss = plot(time_Erk/scale_factor_time,sig_dummy_single_cell_average, 'b');
            set(ss,'LineWidth',2);
%        ss = plot(time_Erk/scale_factor_time,Erk_signal_d_cAMP_average_sum, 'g--');
%            set(ss,'LineWidth',3);
             if (length(dose_array_drug) > 0)
              plot([time_drug/scale_factor_time time_drug/scale_factor_time],[max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)],'k--');
             end;
            ylim([max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)]);
            xlim([0 max(time_Erk)/scale_factor_time]);
            ylabel('Erk-KTR (N/C)');
             xlabel('time (minutes)');
             if (length(dose_array_drug) == 0)
              title(strcat('average Erk-KTR signal from linked single cells'));
             else 
              title(strcat('average Erk-KTR signal from linked single cells,',str_drug,'added at t=',num2str(time_drug/scale_factor_time),' m'));
             end;
        hold off;
       subplot(3,1,2)
        hold on;
            ylabel(str_input);
             plot(time_bPAC/scale_factor_time,bPAC_ledvals);
             if (length(dose_array_drug) > 0)
              plot([time_drug/scale_factor_time time_drug/scale_factor_time],[0 max(1.1*max(bPAC_ledvals),1e-6)],'k--');
             end;
             xlim([0 max(time_Erk)/scale_factor_time]);
             ylim([0 max(1.1*max(bPAC_ledvals),1e-6)]);
             xlabel('time (minutes)');
            % xlabel(str_time_representation);
             hold off;
       subplot(3,1,3)
        hold on;
             ylabel('Erk-KTR (N/C)');
             plot(dose_array(1:num_doses_TF), TF_data_average(1:num_doses_TF));
             xlim([0 1.1*max(dose_array)]);
             ylim([max_value+1.1*(min_value-max_value) min_value+1.1*(max_value-min_value)]);
             %title('currently the original average, need to write code for single cell/linked average TF');
            ylabel(str_input);
            % xlabel(str_time_representation);
             hold off;

       fig2113 = figure(2113);
          s_combine = strcat(str_movie,':average Erk signal (pulsing cells)');
          saveppt2(strcat(str_movie,'-linked_nuclei_Erk_average_d_cAMP.ppt'),'figure',[fig2113], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-linked_nuclei_Erk_average_d_cAMP.eps'));   

    elseif (exist_linked_nuclei == 1)&(do_annotated_bPAC_cluster_linked == 1) % linked nuclei, particular single_cell_analysis
           
       if (ii_NM~=ii_NM_bPAC)  % do only if there is a mix of bPAC and non-bPAC cells
         s_sig = ['b' 'g' 'r'];    
         do_full_range_ylim = 0
         run_full_range_ylim = 0
         cd(str_processing) 
         analyze_annotated_bPAC_clusters_linked_nuclei 
         do_full_range_ylim = 1
         if (do_full_range_ylim == 1)
         run_full_range_ylim = 1
         cd(str_processing) 
         analyze_annotated_bPAC_clusters_linked_nuclei 
         end;
        end;
      
            
    end;  % end of  'if (exist_linked_nuclei == 1)' % linked nuclei, single_cell_analysis
             
       
    

    
cd(str_processing) 




end; % end of 'if (do_link_nuclei == 1)'
           