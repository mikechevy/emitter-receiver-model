
global num_molecules;
global stochasticity;
global stochasticity_conj;
global num_reactions;
global reaction_constant;
global sign_value_reaction;
global reaction_type;
global reaction_molecules;
global c_mu;
global x_ref;
global kappa;
global passed_constants;


cd gillespie_code;


         for ii = 1:num_molecules
          species_cov(ii) = 1;
          species_cov_conj(ii) = 0;
          species_restricted(ii) = 0;
          species_restricted_conj(ii) = 1;
         end;
         for ii = 1:num_reactions
          stochasticity(ii) = 0;
          stochasticity_conj(ii) = 1;
         end;

  count_cov_map = 0;

  if (do_covariances == 1)
     for jj = 1:num_molecules

       %if ( ( species_cov(jj) == 1 )&( jj ~= 1)&(jj~=3) )
       %if ( ( species_cov(jj) == 1 )&( jj ~= 8 ) )
       if ( species_cov(jj) == 1 )
         for ii = jj:num_molecules
             if ( species_cov(jj)*species_cov(ii) == 1 )
                 covariance_map(count_cov_map+1,:) = [jj ii];
                 count_cov_map = count_cov_map + 1;

             end;
         end; % for ii
       end;
     end; % for jj

     index_of_covariance_map = zeros(num_molecules,num_molecules);

     for ii = 1:count_cov_map
               index_1 = covariance_map(ii,1);
               index_2 = covariance_map(ii,2);

               index_of_covariance_map(index_1 , index_2) = ii;  %  C_jj_ii
               index_of_covariance_map(index_2 , index_1) = ii;  %  C_ii_jj
      end;

  end;



length_x_moms = num_molecules + count_cov_map + 1;



% set max number of reactions and time
max_count_reactions = 8000;  %  max number of  reactions
time_start = max_time;
max_time = max_time+t_max;


% for non-stiff systems
%[time_mean, x_mean] = ode45('mean_theory',[0 20000],x_0_mean');
% for stiff_systems
%[time_mean, x_mean] = ode23t('mean_theory',[time_start max_time],x_0_mean');


if (iii == 1)
x_0_mean = y_0_ma;  % use the mass-action input
x_0_mean = [x_0_mean zeros(1,count_cov_map)];
end;

  if (do_quadratic_terms == 1)|(do_covariances==0)
   %[time_mean, x_mean] = ode15s('moments_unrestricted',[time_start max_time],x_0_mean',options);
   [time_mean, x_mean] = ode15s('moments_short',[time_start max_time],x_0_mean',options);
  else  % linearized affinity assumption
   %[time_mean, x_mean] = ode15s('moments_short',[time_start max_time],x_0_mean',options);
   [time_moments_data_sampled, moments_data_sampled] = ode15s('moments_short_lin_mean',[time_start max_time],x_0_mean(1:num_molecules)',options);
           %  for kk = 1:length(time_moments_data_sampled)
           %      moments_data_sampled(kk,:) = moments_data_sampled(length(time_moments_data_sampled),:);
           %  end;
           y_ss = zeros(1,num_molecules);
           y_ss(:) = moments_data_sampled(length(time_moments_data_sampled),:);
%   [time_mean, cov_mean] = ode15s('moments_short_lin_cov',time_moments_data_sampled,x_0_mean(num_molecules+1:num_molecules+count_cov_map)',options);
   cov_mean = solve_ss_lin_cov(y_ss)
      x_mean = [moments_data_sampled cov_mean];  % combine mean and covariances
  end;




cd ../;
