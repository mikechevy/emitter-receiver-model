

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN:  Defining the difference cases for 'do_case'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (do_case == 1)  % small emitter cluster movies
    
    %  which_movie = 201, '160902_198_198-117_EA'
    %  which_movie = , ''
    %  which_movie = , ''
    %  which_movie = , ''
    
movie_array = [110 111 112];

dose_array = [0 66 132];


elseif (do_case == 2)  % small emitter cluster movies

movie_array = [113 114 115];

dose_array = [0 66 132];
    
% need to map common nuclei between movies. this is done by hand

elseif (do_case == 3)  % small emitter cluster movies

movie_array = [116 117 118];

dose_array = [0 50 100];
    
% need to map common nuclei between movies. this is done by hand


elseif (do_case == 4)  % small emitter cluster movies

movie_array = [119 120 121];

dose_array = [0 50 100];
    
% need to map common nuclei between movies. this is done by hand


elseif (do_case == 5)  % small emitter cluster movies

movie_array = [122 123 124  125];

dose_array = [0 50 100 100];
    
% need to map common nuclei between movies. this is done by hand


elseif (do_case == 6)  % small emitter cluster movies

movie_array = [162 163 164];

dose_array = [0 50 100];
    
% need to map common nuclei between movies. this is done by hand

elseif (do_case == 7)  % small emitter cluster movies

movie_array = [165 166 167 168];

dose_array = [0 75 150 150];
    
% need to map common nuclei between movies. this is done by hand
do_8_Br_cAMP = 1;


elseif (do_case == 8)  % small emitter cluster movies

movie_array = [169 170];

dose_array = [0 1]';
    
% need to map common nuclei between movies. this is done by hand

do_DMSO  = 1;

elseif (do_case == 9)  % small emitter cluster movies

movie_array = [176 177 178];

dose_array = [0 50 100]';
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;


elseif (do_case == 10)  % small emitter cluster movies

movie_array = [179 180 181];

dose_array = [0 30 60]';
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

elseif (do_case == 11)  % small emitter cluster movies

movie_array = [182 183 184];

dose_array = [0 30 60]';
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;


elseif (do_case == 12)  % small emitter cluster movies

movie_array = [186 187 188];

dose_array = [0 10 20]';
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

elseif (do_case == 13)  % small emitter cluster movies

movie_array = [189 190 191];

dose_array = [0 5 10]';
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

elseif (do_case == 14)  % small emitter cluster movies

movie_array = [196 197];

dose_array = [0 20]'; % Forskolin
dose_array_drug = [15 15]'; %  ESI-09
index_time_drug = 1;
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M))';

elseif (do_case == 15)  % small emitter cluster movies

movie_array = [198 199 200];

dose_array = [0 20 20]'; % Forskolin
dose_array_drug = [0 0 15]'; %   ESI-09
index_time_drug = 3;
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M))';

elseif (do_case == 16)  % small emitter cluster movies

movie_array = [201 202 203];

dose_array = [0 50 50]';  % Forskolin
dose_array_drug = [0 0 15]'; %   ESI-09
index_time_drug = 3;
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

elseif (do_case == 17)  % small emitter cluster movies

movie_array = [204 205];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 15]'; %   ESI-09
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

elseif (do_case == 18)  % small emitter cluster movies

movie_array = [209 210];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_H89 = 1;
str_drug = 'H89 (10 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

      do_annotated_bPAC_cluster_linked = 1;  % 1 - yes, 0 - no 
      count_clusters = 0;
      bPAC_clusters = [26];
      bPAC_clusters = sort(bPAC_clusters);
      size_bPAC_clusters = length(bPAC_clusters);

      non_bPAC_clusters_inner = [21 22 24 27 30 31 35];
      non_bPAC_clusters_outer = [];
      non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
      non_bPAC_clusters = sort(non_bPAC_clusters);
      size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
      bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
      scale_Erk_channel = 2.0;  % for RGB image of 3 channels
      scale_NM_channel = 1.0;  % for RGB image of 3 channels
      scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

      do_full_range_ylim = 1;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own


elseif (do_case == 19)  % small emitter cluster movies

movie_array = [212 213];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_H89 = 1;
str_drug = 'H89 (10 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes


elseif (do_case == 20)  % small emitter cluster movies

movie_array = [214 215];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_H89 = 1;
str_drug = 'H89 (10 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

elseif (do_case == 21)  % small emitter cluster movies

movie_array = [216 217];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes


elseif (do_case == 22)  % small emitter cluster movies

movie_array = [218 219];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes


      do_annotated_bPAC_cluster_linked = 1;  % 1 - yes, 0 - no 
      count_clusters = 0;
      bPAC_clusters = [2 4 5 7 11 13 14 18 19 20 24 26 27 32 33];
      bPAC_clusters = sort(bPAC_clusters);
      size_bPAC_clusters = length(bPAC_clusters);

      non_bPAC_clusters_inner = [1 3 6 8 10 12 22 23 30 31 34 35 38 39 40];
      non_bPAC_clusters_outer = [];
      non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
      non_bPAC_clusters = sort(non_bPAC_clusters);
      size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
      bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
      scale_Erk_channel = 2.0;  % for RGB image of 3 channels
      scale_NM_channel = 1.0;  % for RGB image of 3 channels
      scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

      do_full_range_ylim = 1;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own



elseif (do_case == 23)  % small emitter cluster movies

movie_array = [220 221];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_H89 = 1;
do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M) and H89 (10 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 0;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

elseif (do_case == 24)  % small emitter cluster movies

movie_array = [222 223];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M)';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

elseif (do_case == 25)  % small emitter cluster movies

movie_array = [224 225 226];

dose_array = [0 50 50]';  % Forskolin
dose_array_drug = [0 0 15]'; %   ESI-09
index_time_drug = 3;
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

do_H89 = 1;
str_drug = 'H89 (10 \mu M)';

%do_ESI09 = 1;
%str_drug = 'ESI-09 (15 \mu M)';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 


elseif (do_case == 26)  % small emitter cluster movies

movie_array = [227 228 229];

dose_array = [0 50 50]';  % Forskolin
dose_array_drug = [0 0 15]'; %   ESI-09
index_time_drug = 3;
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

do_H89 = 1;
do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M) and H89 (10 \mu M)';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 


elseif (do_case == 27)  % small emitter cluster movies

movie_array = [230 231 232];

dose_array = [0 50 50]';  % Forskolin
dose_array_drug = [0 0 15]'; %   ESI-09
index_time_drug = 3;
    
% need to map common nuclei between movies. this is done by hand

do_Forskolin = 1;

do_H89 = 1;
do_ESI09 = 1;
str_drug = 'ESI-09 (15 \mu M) and H89 (10 \mu M)';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 


elseif (do_case == 28)  % small emitter cluster movies

movie_array = [174 175];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 0+1e-6]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

str_drug = 'no drug just bPAC';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

elseif (do_case == 29)  % small emitter cluster movies

movie_array = [239 240];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_H89 = 1;
str_drug = 'H89 (10 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

      do_annotated_bPAC_cluster_linked = 1;  % 1 - yes, 0 - no 
      count_clusters = 0;
      bPAC_clusters = [29 31];
      bPAC_clusters = sort(bPAC_clusters);
      size_bPAC_clusters = length(bPAC_clusters);

      non_bPAC_clusters_inner = [16 19 21 22 23 26 27 32 34 36 42];
      non_bPAC_clusters_outer = [];
      non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
      non_bPAC_clusters = sort(non_bPAC_clusters);
      size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
      bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
      %scale_Erk_channel = 2.0;  % for RGB image of 3 channels
      %scale_NM_channel = 1.0;  % for RGB image of 3 channels
      %scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
      
    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
      

      do_full_range_ylim = 1;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own

elseif (do_case == 30)  % small emitter cluster movies

movie_array = [242 243];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 15]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_ESI09= 1;
str_drug = 'ESI-09 (15 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

      do_annotated_bPAC_cluster_linked = 1;  % 1 - yes, 0 - no 
      count_clusters = 0;
      bPAC_clusters = [6 0; 14 16; 40 0];
      %bPAC_clusters = sort(bPAC_clusters);
      size_bPAC_clusters = [1 2 1];

      non_bPAC_clusters_inner = [15 24 0 0 0 0; 11 12 17 20 23 25; 29 36 44 46 53 0];
      non_bPAC_clusters_outer = [];
      non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
      %non_bPAC_clusters = sort(non_bPAC_clusters);
      size_non_bPAC_clusters = [2 6 5];
    
      bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
      scale_Erk_channel = 2.0;  % for RGB image of 3 channels
      scale_NM_channel = 1.0;  % for RGB image of 3 channels
      scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

      do_full_range_ylim = 1;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own
      
elseif (do_case == 31)  % small emitter cluster movies

movie_array = [244 245];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 10]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_H89 = 1;
str_drug = 'H89 (10 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

      do_annotated_bPAC_cluster_linked = 0;  % 1 - yes, 0 - no 
      count_clusters = 0;
      bPAC_clusters = [29 31];
      bPAC_clusters = sort(bPAC_clusters);
      size_bPAC_clusters = length(bPAC_clusters);

      non_bPAC_clusters_inner = [16 19 21 22 23 26 27 32 34 36 42];
      non_bPAC_clusters_outer = [];
      non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
      non_bPAC_clusters = sort(non_bPAC_clusters);
      size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
      bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
      scale_Erk_channel = 2.0;  % for RGB image of 3 channels
      scale_NM_channel = 1.0;  % for RGB image of 3 channels
      scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

      do_full_range_ylim = 1;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own
      
elseif (do_case == 32)  % small emitter cluster movies

movie_array = [254 255];

dose_array = [0 0+1e-6]; % keep zero since bPAC input will be loaded in
dose_array_drug = [0 15]'; %   H89
index_time_drug = 2;
% need to map common nuclei between movies. this is done by hand

do_bPAC = 1;

do_ESI09= 1;
str_drug = 'ESI-09 (15 \mu M))';

do_single_cell_Erk_signal_eps = 1; % 1-yes, 0-no 

do_last_time_sample = 1;  % 1-use the last frame of the first movie to link nuclei to first from of second, 0 just use first fromes

      do_annotated_bPAC_cluster_linked = 1;  % 1 - yes, 0 - no 
      count_clusters = 0;
      %bPAC_clusters = [20 27];
      bPAC_clusters = [20];  % 27 has no repsonse
      bPAC_clusters = sort(bPAC_clusters);
      %size_bPAC_clusters = [1 1];
      size_bPAC_clusters = [length(bPAC_clusters)];

      non_bPAC_clusters_inner = [7 13 15 17 24 26 28 34];  % for bPAC_clusters = [20 27]
      %non_bPAC_clusters_inner = [7 13 15 17 24 26];   % for bPAC_clusters = [20]
      non_bPAC_clusters_outer = [];
      non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
      non_bPAC_clusters = sort(non_bPAC_clusters);
      %size_non_bPAC_clusters = [6 3];
      size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
      bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
      %scale_Erk_channel = 2.0;  % for RGB image of 3 channels
      %scale_NM_channel = 1.0;  % for RGB image of 3 channels
      %scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
      
    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*8.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels


      do_full_range_ylim = 1;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own

end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END:  Defining the difference cases for 'do_case'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

