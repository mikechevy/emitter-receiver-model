
function I_X_Y = calculate_mutual_information_1D_scale(P_X_sequence)

global covariance_map;
global Y_info_index_cov_map;
global Y_info_index;
global scale_Y_info_index;
global X_info_index;
global P_Y;
global P_X;
global P_Y_X;
global P_Y_X_properties;
global X;
global Y;
global X_sequence_sample;

% from set_globals_and_initialize
global num_molecules;





        S_Y_X = 0;        
        S_Y = 0;        
        S_X = 0;  
        P_Y = 0*P_Y;
        P_X = 0*P_X;
 
        max_y_range = 0;
        
full_width = 10;

% setup 2D Covariance matrix

% interpolate the covariance matrices for this here

for ii = 1:length(X)
    
    P_Y_X = 0*P_Y_X;
        
    
    [index_X_upper index_X_lower upper lower] = interpolate_between(X,ii,X_sequence_sample);   

    P_X(ii) = upper*P_X_sequence(index_X_upper) + lower*P_X_sequence(index_X_lower);      
    
    % interpolate here
    Cov_11(ii) = lower*P_Y_X_properties(index_X_lower,num_molecules+Y_info_index_cov_map(1)) + upper*P_Y_X_properties(index_X_upper,num_molecules+Y_info_index_cov_map(1));
    mu_1(ii) =  lower*P_Y_X_properties(index_X_lower,Y_info_index(1)) + upper*P_Y_X_properties(index_X_upper,Y_info_index(1));
    
      Cov_11(ii) = Cov_11(ii)/power(scale_Y_info_index(1),2);
      mu_1(ii) = mu_1(ii)/scale_Y_info_index(1);
    
    % test not to use gaussian approximation
    if (mu_1(ii) < 1)
       Cov_11(ii) = 0;
    end;
        
        
end; % for ii = 1:length(X)


   
figure(100)
hold on;
h1 = plot(X,mu_1,'g');
set(h1,'LineWidth',2)
h1 = plot(X,mu_1+sqrt(Cov_11),'g--');
set(h1,'LineWidth',2)
h1 = plot(X,mu_1-sqrt(Cov_11),'g--');
set(h1,'LineWidth',2)
hold off;
xlim([0 250]);
ylim([0 1.3*max(mu_1)]);


