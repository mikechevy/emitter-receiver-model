

num_frames_delta = 2;
     matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;



for iii = 1:num_nuclei_t0

        matrix_NM_DUMMY = 0*matrix_NM_DUMMY;
        matrix_NM_SCRAP = 0*matrix_NM_SCRAP;
        
        index_lower = max(1,which_frame-num_frames_delta);
        index_upper = min(numFr_NM,which_frame+num_frames_delta);
        for jjj = index_lower:index_upper
            
         idx_map = index_map_tot_time_mapped_t0(iii,jjj);  
           if (jjj == index_lower)
            matrix_NM_SCRAP(eval(['Cell_shrink_nucleus_FILL_',num2str(jjj),'.PixelIdxList{idx_map}'])) =  1;
           end;
           
           matrix_NM_DUMMY(eval(['Cell_shrink_nucleus_FILL_',num2str(jjj),'.PixelIdxList{idx_map}'])) =  1;
           matrix_NM_SCRAP = matrix_NM_SCRAP.*matrix_NM_DUMMY;
           
        end;     

        
        
    binary_FILL = bwareaopen(matrix_NM_SCRAP, 0);  % remove 
    Cell_marker_FILL = bwconncomp(binary_FILL);
     idx_map = index_map_tot_time_mapped_t0(iii,which_frame);      
     eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_marker_FILL.PixelIdxList{1};'])
        
     
     
     matrix_nucleus_SCRAP( Cell_marker_FILL.PixelIdxList{1}) = 1;
        
end;

figure(11)
imshow(matrix_nucleus_SCRAP);

