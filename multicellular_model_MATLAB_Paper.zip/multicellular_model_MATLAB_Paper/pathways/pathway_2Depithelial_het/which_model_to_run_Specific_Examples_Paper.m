
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%  which_specific_example
%  Code:  Figure x100 + specific example number:
%  example example number 3 from Figure 3 -->  300 + 3 = 303
%  This gives us up to double digit example numbers for a given Figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 



 if (do_parameter_sweep ==0)
  str_specific_example = strcat('simulation-case-',num2str(which_case_simulation)); 
 elseif (do_parameter_sweep == 1)
  str_specific_example =  strcat('sweep-simulation-case-',num2str(which_case_simulation),'-',num2str(which_sweep),'-',num2str(count_parameter_sweep)); 
 end;
     
  

 
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %  Starting parameter set multiplication factcors.  
      %  This never changes, except for parameter sweeps.
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       fac_gamma_c_pd_hetero = 1.0;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 1;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       fac_flux_MOD_gj_gjc = .50;
       time_gj_delay = 15;
       step_gj_delay = 4;    
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       N_alpha_bPAC_basal =  1; % can be -1 to N (positivive), 0 if no difference in basal cAMP rates between bPAC/non-bPAC;
       fac_k_diff_c_basal  = 1.0 % scales the %#Basal Rate of diffusion of cAMP through gap junctions


       
        if (do_parameter_sweep == 1)
         if (which_sweep == 1) 
              num_parameters_sweep = 1;
              str_parameter_sweep_1 = 'fac_gamma_c_pd_hetero'; 
             if (count_parameter_sweep == 1)
                 fac_gamma_c_pd_hetero = 0;  % no PDE (IBMX)
             elseif (count_parameter_sweep == 2)
                 fac_gamma_c_pd_hetero = .5; 
             elseif (count_parameter_sweep == 3)
                 fac_gamma_c_pd_hetero = 1; 
             elseif (count_parameter_sweep == 4)
                 fac_gamma_c_pd_hetero = 2.0; 
             end;
           count_parameter_sweep_max = 4;      
          str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': fac_gamma_c_pd_hetero =',num2str(fac_gamma_c_pd_hetero));
         elseif (which_sweep == 2) 
              num_parameters_sweep = 1;
              str_parameter_sweep_1 = 'fac_gamma_e_c'; 
             if (count_parameter_sweep == 1)
                 fac_gamma_e_c = .5;  
             elseif (count_parameter_sweep == 2)
                 fac_gamma_e_c = 1;  
             end;
           count_parameter_sweep_max = 2;      
           str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': fac_gamma_e_c =',num2str(fac_gamma_e_c));
         elseif (which_sweep == 3) 
           num_parameters_sweep = 2;
           str_parameter_sweep_1 = 'time_gj_delay'; 
           str_parameter_sweep_2 = 'step_gj_delay'; 
          if (count_parameter_sweep == 1)
              time_gj_delay = 7
              step_gj_delay = 1;    
          elseif (count_parameter_sweep == 2)
              time_gj_delay = 7
              step_gj_delay = 4;    
          elseif (count_parameter_sweep == 3)
              time_gj_delay = 7
              step_gj_delay = 7;    
          elseif (count_parameter_sweep == 4)
              time_gj_delay = 15
              step_gj_delay = 1;    
          elseif (count_parameter_sweep == 5)
              time_gj_delay = 15
              step_gj_delay = 4;    
          elseif (count_parameter_sweep == 6)
              time_gj_delay = 15
              step_gj_delay = 7;    
          elseif (count_parameter_sweep == 7)
              time_gj_delay = 20
              step_gj_delay = 1;    
          elseif (count_parameter_sweep == 8)
              time_gj_delay = 20
              step_gj_delay = 4;    
          elseif (count_parameter_sweep == 9)
              time_gj_delay = 20
              step_gj_delay = 7;    
          end;
          count_parameter_sweep_max = 9; 
          str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': time_gj_delay=',num2str(time_gj_delay),', step_gj_delay=',num2str(step_gj_delay));
         elseif (which_sweep == 4) 
              num_parameters_sweep = 2;
              str_parameter_sweep_1 = 'fac_flux_MOD_gj_gjc'; 
              str_parameter_sweep_2 = 'N_alpha_bPAC_basal'; 
             if (count_parameter_sweep == 1)
                 fac_flux_MOD_gj_gjc = .5;  
                 N_alpha_bPAC_basal = 1;
             elseif (count_parameter_sweep == 2)
                 fac_flux_MOD_gj_gjc = .5;  
                 N_alpha_bPAC_basal = 6;
             elseif (count_parameter_sweep == 3)
                 fac_flux_MOD_gj_gjc = .5;  
                 N_alpha_bPAC_basal = 15;
             elseif (count_parameter_sweep == 4)
                 fac_flux_MOD_gj_gjc = 1;  
                 N_alpha_bPAC_basal = 1;
             elseif (count_parameter_sweep == 5)
                 fac_flux_MOD_gj_gjc = 1;  
                 N_alpha_bPAC_basal = 6;
             elseif (count_parameter_sweep == 6)
                 fac_flux_MOD_gj_gjc = 1;  
                 N_alpha_bPAC_basal = 15;
             elseif (count_parameter_sweep == 7)
                 fac_flux_MOD_gj_gjc = 2.0;  
                 N_alpha_bPAC_basal = 1;
             elseif (count_parameter_sweep == 8)
                 fac_flux_MOD_gj_gjc = 2.0;  
                 N_alpha_bPAC_basal = 6;
             elseif (count_parameter_sweep == 9)
                 fac_flux_MOD_gj_gjc = 2.0;  
                 N_alpha_bPAC_basal = 15;
             elseif (count_parameter_sweep == 10)
                 fac_flux_MOD_gj_gjc = 4.0;  
                 N_alpha_bPAC_basal = 1;
             elseif (count_parameter_sweep == 11)
                 fac_flux_MOD_gj_gjc = 4.0;  
                 N_alpha_bPAC_basal = 6;
             elseif (count_parameter_sweep == 12)
                 fac_flux_MOD_gj_gjc = 4.0;  
                 N_alpha_bPAC_basal = 15;
             end;
           count_parameter_sweep_max = 12;      
           str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': fac_flux_MOD_gj_gjc =',num2str(fac_flux_MOD_gj_gjc),', N_alpha_bPAC_basal =',num2str(N_alpha_bPAC_basal));
         elseif (which_sweep == 5) 
              num_parameters_sweep = 1;
              str_parameter_sweep_1 = 'do_PKA_reg_AC'; 
             if (count_parameter_sweep == 1)
                 do_PKA_reg_AC = 0;  
             elseif (count_parameter_sweep == 2)
                 do_PKA_reg_AC = 1;  
             end;
           count_parameter_sweep_max = 2;      
           str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': do_PKA_reg_AC =',num2str(do_PKA_reg_AC));
         elseif (which_sweep == 6) 
              num_parameters_sweep = 2;
              str_parameter_sweep_1 = 'fac_gamma_e_c'; 
              str_parameter_sweep_2 = 'fac_k_diff_c_basal'; 
             if (count_parameter_sweep == 1)
                 fac_gamma_e_c = .5;  
                 fac_k_diff_c_basal = 4;  
             elseif (count_parameter_sweep == 2)
                 fac_gamma_e_c = .5;  
                 fac_k_diff_c_basal = 12;  
             elseif (count_parameter_sweep == 3)
                 fac_gamma_e_c = .5;  
                 fac_k_diff_c_basal = 36;  
             elseif (count_parameter_sweep == 4)
                 fac_gamma_e_c = 1;  
                 fac_k_diff_c_basal = 4;  
             elseif (count_parameter_sweep == 5)
                 fac_gamma_e_c = 1;  
                 fac_k_diff_c_basal = 12;  
             elseif (count_parameter_sweep == 6)
                 fac_gamma_e_c = 1;  
                 fac_k_diff_c_basal = 36;  
             end;
           count_parameter_sweep_max = 6;      
           str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': fac_gamma_e_c  =',num2str(fac_gamma_e_c) ,', fac_k_diff_c_basal =',num2str(fac_k_diff_c_basal));
         elseif (which_sweep == 7) 
              num_parameters_sweep = 2;
              str_parameter_sweep_1 = 'fac_gamma_e_c'; 
              str_parameter_sweep_2 = 'fac_k_diff_c_basal'; 
             if (count_parameter_sweep == 1)
                 fac_gamma_e_c = .5;  
                 fac_k_diff_c_basal = 1; % pre 10/5/20  
             elseif (count_parameter_sweep == 2)
                 fac_gamma_e_c = .5;  
                 fac_k_diff_c_basal = 3;  % pre 10/5/20
             elseif (count_parameter_sweep == 3)
                 fac_gamma_e_c = .5;  
                 fac_k_diff_c_basal = 9;  % pre 10/5/20
             elseif (count_parameter_sweep == 4)
                 fac_gamma_e_c = 1;  
                 fac_k_diff_c_basal = 1; % pre 10/5/20  
             elseif (count_parameter_sweep == 5)
                 fac_gamma_e_c = 1;  
                 fac_k_diff_c_basal = 3;  % pre 10/5/20
             elseif (count_parameter_sweep == 6)
                 fac_gamma_e_c = 1;  
                 fac_k_diff_c_basal = 9;  % pre 10/5/20
             end;
           count_parameter_sweep_max = 6;      
           str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': fac_gamma_e_c  =',num2str(fac_gamma_e_c) ,', fac_k_diff_c_basal =',num2str(fac_k_diff_c_basal));
         elseif (which_sweep == 8) 
              num_parameters_sweep = 1;
              str_parameter_sweep_1 = 'bPAC_amplitude'; 
             if (count_parameter_sweep == 1)
                 bPAC_amplitude = .25;  
             elseif (count_parameter_sweep == 2)
                 bPAC_amplitude = .5; 
             elseif (count_parameter_sweep == 3)
                 bPAC_amplitude = 1; 
             end;
           count_parameter_sweep_max = 3;      
          str_parameter_sweep_values = strcat('sweep-',num2str(which_sweep),'-',num2str(count_parameter_sweep),': bPAC_amplitude =',num2str(bPAC_amplitude));                      
         end;
        end; 
         
       
       
       
       
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
 %  Figure 5b (DRAFT 1):  Intracellular model (all emitters), 40 minute pulse
 %  do_ALL_bPAC = 1; do_transfer_function_pulse = 0, do_IBMX = 0 or 1
 %
 %  and 
 
 %  Figuure S4a-b (Draft 2):  Intracellular model (all emitters),  minute pulse  
 %  do_ALL_bPAC  = 1, do_transfer_function_pulse = 1, do_IBMX = 0 or 1
 %
 %
 %  All gap-junction model parameters are irrelevant since it is for
 %  Intracellular, but this intracellular model is used with all
 %  gap-junction models in Figure 5 (except for Andrew's model).
 %  Presented in Figure 5 manuscript 05/18/20 (DRAFT 1)   
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % single bPAC cell, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%               

       if (which_specific_example == 501) 
           
           % no additions
           
        if do_transfer_function_pulse == 1  
             fac_flux_MOD_gj_gjc = 20
        end;
            
       end;

      
      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure 5d (DRAFT 1): emitter/receivers with constant gap-junction activity      
 %
 %   Constant gap-junction activity: do_constant_gap_junction_activity = 1;
 %   WITHOUT PKA feedback to AC: do_PKA_reg_AC = 0 
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % single bPAC cell, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 502) 
       do_constant_gap_junction_activity = 1;  % 1 - yes, 0 - no
         if (do_constant_gap_junction_activity == 1)  % set above in model options
          do_PKA_reg_GJ = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_gj_pk = do_PKA_reg_GJ; %#  1 - pka regulated gap junctions (our model), 0 - constant gap junction activity
         end;
       %%fac_k_diff_c_basal  = 3.0 % scales the %#Basal Rate of diffusion of cAMP through gap junctions
      end;
      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure 5e (DRAFT 1): emitter/receivers (Andrew's model) with Constant gap-junction activity 
 
 %   WITHOUT PKA feedback to AC       
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 0;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % single bPAC cell, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     

      if (which_specific_example == 503) 
       which_cAMP_circuit = 0;  % 1 - current models, 0 - Andrews rotation project 
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       %%fac_k_diff_c_basal  = 3.0 % pre 10/5/20: scales the %#Basal Rate of diffusion of cAMP through gap junctions
       %%fac_k_diff_c_basal  = 9.0 % pre 10/5/20: scales the %#Basal Rate of diffusion of cAMP through gap junctions
       %%fac_k_diff_c_basal  = 4.0 % scales the %#Basal Rate of diffusion of cAMP through gap junctions
      %fac_k_diff_c_basal  = 12.0 % scales the %#Basal Rate of diffusion of cAMP through gap junctions
       %%fac_k_diff_c_basal  = 36.0 % scales the %#Basal Rate of diffusion of cAMP through gap junctions
      end;
      
      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure 5I and S8a: emitter/receivers with delay gap-junction model (overshoot model)
 %
 %  WITHOUT PKA feedback to AC:  do_PKA_reg_AC = 0       
 %
 %  Figre 5I (no IBMX):  do_IBMX = 0;
 %  Figre S8a (IBMX):  do_IBMX = 1;
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % single bPAC cell, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 504) 
 
          % no additions
          
      end;
  
       


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure 6c, case 1  (Draft 1): 
 %
 % 'Two GJ Population' model runs:  
 %  WITHOUT PKA feedback to AC: do_PKA_reg_AC = 0      
 %      do_GJ2 = 1;
 %      which_GJ_model = 1;       
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % single bPAC cell, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 601) 
       do_GJ2 = 1;
       which_GJ_model = 1;       
      end;

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure 6c, case 2  (Draft 1): 
 %
 % 'Two GJ Population' model runs:  
 %  WITHOUT PKA feedback to AC: do_PKA_reg_AC = 0      
 %      do_GJ2 = 1;
 %      which_GJ_model = 2;       
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 2;  % single bPAC cell, 11 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 602) 
       do_GJ2 = 1;
       which_GJ_model = 2;       
       fac_flux_MOD_gj_gjc = 1.0;
      end;
      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure 6c, case 3  (Draft 1): 
 %
 % 'Two GJ Population' model runs:  
 %  WITHOUT PKA feedback to AC: do_PKA_reg_AC = 0      
 %      do_GJ2 = 1;
 %      which_GJ_model = 3;       
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 2;  % single bPAC cell, 11 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 603) 
       do_GJ2 = 1;
       which_GJ_model = 3;       
       fac_flux_MOD_gj_gjc = 1.0;
      end;
      
      
      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % TESTING undershoot, no PKA feedback to AC ,for Figure 6 manuscript 05/18/20 (DRAFT 1)   
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % 1 cell bPAC cluster, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 
      if (which_specific_example == 604) 
       fac_flux_MOD_gj_gjc = .50;
       time_gj_delay = 10;
       step_gj_delay = 7;    
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       N_alpha_bPAC_basal =  15; % As expected it yields better undershoot than N_alpha_bPAC_basal =  3;
      end;
          
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % TESTING undershoot, with PKA feedback to AC (and larger N_alpha_bPAC_basal) ,for Figure 6 manuscript 05/18/20 (DRAFT 1)      
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % 1 cell bPAC cluster, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400'; 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 
      if (which_specific_example == 605) 
       fac_flux_MOD_gj_gjc = .50;
       time_gj_delay = 10;
       step_gj_delay = 7;    
       do_PKA_reg_AC = 1; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       N_alpha_bPAC_basal =  15; % As expected it yields better undershoot than N_alpha_bPAC_basal =  3;
      end;

      
      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % TESTING undershoot, no PKA feedback to AC ,for Figure 6 manuscript 05/18/20 (DRAFT 1)   
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 7;  % 1 cell bPAC cluster, 46 cells total
 %  str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 
 %  THIS IS DONE WITH IBMX
 
      if (which_specific_example == 606) 
       fac_flux_MOD_gj_gjc = .50; 
       %fac_k_diff_c_basal  = 1.0;     
       do_IBMX = 1;
       time_gj_delay = 10;
       step_gj_delay = 16;    
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       N_alpha_bPAC_basal =  15; % As expected it yields better undershoot than N_alpha_bPAC_basal =  3;
      end;
      

      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure S8b (DRAFT 1): emitter/receivers with constant gap-junction activity      
 %
 %   Strains (CX43-NGFP) resulting in REDUCED gap-junction activity: 
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 2;  % single bPAC cell, 11 cells total
 %  str_movie_write = 'imagefile_160902_198_198-117_EA_100_250_225_300'
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 801) 
       do_CX43_NGFP = 1;  % 0 - no, 1- reduced flux due to broken gap-junctions
        if do_CX43_NGFP == 1    
          fac_CX43_NGFP = .20;  % this value similates the effect of CX43-NGFP
          fac_flux_MOD_gj_gjc = fac_CX43_NGFP;
          fac_k_diff_c_basal = fac_CX43_NGFP;
        end;
              %%time_gj_delay = 20
              %%step_gj_delay = 4;            
       end;

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 % Figure S8c (DRAFT 1): emitter/receivers with constant gap-junction activity      
 %
 %   Trafficking inhibitors (Brefeldin-A) resulting in REDUCED gap-junction activity: 
 %
 %  which_pathway = 1;  % MDCK cAMP circuite                      
 %  which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
 %  which_modeling_case = 2;  % single bPAC cell, 11 cells total
 %  str_movie_write = 'imagefile_160902_198_198-117_EA_100_250_225_300'
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
       
 
      if (which_specific_example == 802) 
       do_CX43_NGFP = 1;  % 0 - no, 1- reduced flux due to broken gap-junctions
        if do_CX43_NGFP == 1    
          fac_CX43_NGFP = .25;  % this value similates the effect of CX43-NGFP
          fac_flux_MOD_gj_gjc = fac_CX43_NGFP;
          fac_k_diff_c_basal = fac_CX43_NGFP;
        end;
       end;
       
      
      
       which_model = 111;
      if (which_model == -3)  % TEST: pulsed transfer function case
       fac_gamma_c_pd_hetero = .20;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = .3;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       fac_flux_MOD_gj_gjc = 1.0;
       time_gj_delay = 15;
       step_gj_delay = 7;    
       do_transfer_function_pulse = 0*do_ALL_bPAC; % 1-yes (6 min.), 0 - no (40 min.)      
      elseif (which_model == -2)  % TEST: classic overshoot with some undershoot
       fac_gamma_c_pd_hetero = .20;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 1;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       fac_flux_MOD_gj_gjc = 1.0;
       time_gj_delay = 15;
       step_gj_delay = 7;    
      elseif (which_model == -1)  % TEST: undershoot models
       fac_gamma_c_pd_hetero = 10*.20;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 1;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       fac_flux_MOD_gj_gjc = 1.0;
       %which_GJ_model = 2; % fast      
       %do_GJ2 = 1;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
       time_gj_delay = 15;
       step_gj_delay = 4;    
       do_PKA_reg_AC = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
        N_alpha_bPAC_basal =  10; % As expected it yields better undershoot than N_alpha_bPAC_basal =  3; 
      elseif (which_model == 0)  % classic overshoot with some undershoot
       fac_gamma_c_pd_hetero = .20;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 2;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
        if (do_IBMX == 1)
         %time_gj_delay = 10;
         N_alpha_bPAC_basal =  6; % As expected it yields better undershoot than N_alpha_bPAC_basal =  3; 
        end;
      elseif (which_model == 1)  % classic overshoot with some undershoot (test for: 2 GJ popultions)
       fac_gamma_c_pd_hetero = .50;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 2;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       which_GJ_model = 1;      
        do_GJ2 = 1;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
      elseif (which_model == 2)  % medium speed overshoot with undershoot, 
        % Here faster cAMP degradation than the gap-junction turn on/off delay helps with undershoot
       fac_gamma_c_pd_hetero = 1.50;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 4;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       do_PKA_reg_AC = 1; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
       which_GJ_model = 200;
        do_GJ2 = 1;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
         N_alpha_bPAC_basal =  6; % As expected ityields better undershoot than N_alpha_bPAC_basal =  3; 
      elseif (which_model == 3)
       fac_gamma_c_pd_hetero = .50;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 2;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       which_GJ_model = 3; % fast      
        do_GJ2 = 1;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
      elseif (which_model == 4)
       fac_gamma_c_pd_hetero = .1;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 1;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20          
       which_GJ_model = 4; % classic  gap-junction regulation,  emitter/receiver-NGF
        do_GJ2 = 1;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
      elseif (which_model == 5)
       fac_gamma_c_pd_hetero = .1;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 1;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20          
       which_GJ_model = 5 % very fast  gap-junction regulation,  emitter-70/receiver-70
        do_GJ2 = 1;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
      elseif (which_model == 6)
       fac_gamma_c_pd_hetero = .20;  % adjust for different intracellular PDE-decay rate of cAMP
       fac_cAMP_basal_beta = 2;  % adjust the basal rate of cAMP production, 1 - origintal (pre-03/03/20      
       fac_cAMP_bPAC_beta = 1;  % adjust the bPAC rate of cAMP production, 1 - origintal (pre-03/03/20
       do_CX43_NGFP = 1;  % 0 - no, 1- reduced flux due to broken gap-junctions
        if do_CX43_NGFP == 1    
          %fac_CX43_NGFP = .98;
          %fac_CX43_NGFP = 1.0;
          fac_CX43_NGFP = .02;
          fac_flux_MOD_gj_gjc = fac_CX43_NGFP;
        end;
      end;
      
