
do_plot_cytosol_and_nuclear_signal = 0; % 1 - yes, 0 - no
do_NM = 1;  % 1 - yes, 0 - no
do_CH1 = 1;  % 1 - yes, 0 - no
do_CH2 = 0;  % 1 - yes, 0 - no
    if (length(signal_channels)==1)
        do_CH2 = 0;
    end;

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 
    
    

width_surround = 100;  % additional pixes in each direction about the nucleus

do_make_movie_Erk = 0;  % 1 - yes, 0 - no
 
       if (do_make_movie_Erk == 1)
          filename_movie = strcat(str_movie,'_processed\Erk_nucleus',num2str(which_nucleus),'_TEST');
          delete(strcat(filename_movie,'.avi'));
          mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',2);
       end;
          
    which_frame = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);

                 
do_track_center_of_mass = 1;  % 1 - yes, 0 - no                 
                 
                 
M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_bPAC = zeros(xLength,yLength);

index_group = which_nucleus;





count_fast = 0;
skip_fast = 10;


%ii_lower = 1;
ii_lower = length(eval(['time_CH',num2str(ii_NM)]));

for kkk = ii_lower:length(eval(['time_CH',num2str(ii_NM)]))
  which_frame = kkk;
  
  
%   if (which_frame < numFr)
%       if (dt_sequence_movie(which_frame) < 20)&(count_fast == 0)
%           count_fast = 1;
%       elseif (dt_sequence_movie(which_frame) < 20)&(count_fast < skip_fast )
%           count_fast = count_fast+1;
%       elseif (dt_sequence_movie(which_frame) < 20)&(count_fast == skip_fast )
%           count_fast = 0;
%       elseif (dt_sequence_movie(which_frame) > 20)
%           count_fast = 1;
%       end;
%   end;      
  count_fast = 1;

          
  if (count_fast == 1)        
     if (do_track_center_of_mass == 1)                 
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
     end;
  
  
  if (do_load_movie_arrays == 0)   
    str_movie_processed = strcat(str_movie,'_processed')
    file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
    load(file_nucleus);
  else
    M_NM(:,:) = eval(['M_CH',num2str(ii_NM),'_total(:,:,which_frame)']);
          eval(['[val,which_frame_CH1]= min(abs(time_CH',num2str(1),'-time_CH',num2str(ii_NM),'(kkk)));']);     
          M_CH1(:,:) = M_CH1_total(:,:,which_frame_CH1);
          if (length(signal_channels)>1)
          eval(['[val,which_frame_CH2]= min(abs(time_CH',num2str(2),'-time_CH',num2str(ii_NM),'(kkk)));']);     
          M_CH2(:,:) = M_CH2_total(:,:,which_frame_CH2);
          end;
    for iii = 1:numCh
        if ( strcmp(eval(['CH',num2str(iii),'_str']),'CFP')==1 )
          eval(['[val,which_frame_bPAC]= min(abs(time_CH',num2str(iii),'-time_CH',num2str(ii_NM),'(kkk)));']);     
         M_bPAC(:,:) = eval(['M_CH',num2str(iii),'_total(:,:,which_frame_bPAC)']);
        end;
    end;
  end;
    
 M_marker_threshold_TEST = 0*M_marker_threshold_TEST;

 for jjj = 1:length(index_group)
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_NM_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end;



                  

if (do_CH2 == 1)        
figure(10+ii_CH1)
subplot(2,1,1);
 
     title(strcat('nuclear CH2 signal (',CH2_str,')'));
     %plot(time_sequence_movie,nuclear_CH2_tot_time_mapped_t0(idx,:)-0*nuclear_CH2_tot_time_mapped_t0(idx,1));
     %hold on;
     if (marker_from_channel(ii_Erk_marker) == ii_CH2)
     plot(time_CH2,nuclear_CH2_tot_time_mapped_t0(idx,:)./cytosolic_CH2_tot_time_mapped_t0(idx,:)-0*nuclear_CH2_tot_time_mapped_t0(idx,1));
     %plot(time_sequence_movie,nuclear_CH2_tot_time_mapped_t0(idx,:)-0*nuclear_CH2_tot_time_mapped_t0(idx,1));
     %plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1)) max(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1))],'k--');
     else
     plot(time_CH2,nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1));
      if (which_frame > 1)
      plot([time_CH2(which_frame) time_CH2(which_frame)],[min(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1)) max(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1))],'k--');
      end
     end;
     %hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CH2)
     title(strcat('CH2 (Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH2)
     title(strcat('CH2 (Ca2+),nuc:',num2str(which_nucleus)))
     end;
     xlabel('time (seconds)');
     xlim([0 max(time_CH2)]);
    

subplot(2,1,2);
ylabel('bPAC');
plot(time_bPAC,bPAC_ledvals);
xlim([0 max(time_Erk)]);
ylim([0 1.1*max(bPAC_ledvals)]);
ylabel('bPAC');
xlabel('time (seconds)');
    
end; % END OF: if (do_CH2 == 1)        

     
ii_plot_count = 0;
s_sig = ['b' 'r' 'm' 'g'];

     
if (do_CH1 == 1)        
figure(10+ii_CH1)
    
     subplot(1+1+1,1,1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     ss = plot(time_CH1,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     %ss = plot(time_CH1,nuclear_CH1_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     ylabel(strcat('Erk (nuclear/max val)'));
     ylim([0 1.1]);
         xlim([0 max(time_Erk)]);
     hold off;
     subplot(1+1+1,1,1+1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0(idx,:))./double(cytosolic_CH1_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_CH1_tot_time_mapped_t0_median(idx,:))./double(cytosolic_CH1_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     ss = plot(time_CH1,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     
     hold off;
     ylabel(strcat('Krk (nuclear/cytosol)'));
     xlabel('number of frames');
     ylim([0 1.1]);
         xlim([0 max(time_Erk)]);

         subplot(1+1+1,1,1+1+1) 
         ylabel('bPAC');
         plot(time_bPAC,bPAC_ledvals);
         xlim([0 max(time_Erk)]);
         ylim([0 1.1*max(bPAC_ledvals)]);
         ylabel('bPAC');
         xlabel('time (seconds)');
     
     
end; % END OF: if (do_CH1 == 1)        
     

figure(3)
%close 3;
%figure(3)
imshow(mat2gray(M_NM));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               %if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               %else
               %set(tt,'Color','y');
               %end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               %if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               %else
               %set(ll,'Color','y');
               %end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,': Nuclear Marker: magenta (bPAC cells), yellow (non-bPAC cells)'));             

                  

  
  

figure(4)
%close 4;
%figure(4)
imshow(mat2gray(M_CH1));
title(strcat('Signal 1:',num2str(CH1_str)));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');

                  
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

  end;
  
  %M_CH1(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = max(max(M_CH1));
  M_CH1(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = max(max(M_CH1));
  M_CH1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = (.5*max(max(M_CH1)));
figure(44)
imshow(mat2gray(M_CH1));
title(strcat('Signal 1:',num2str(CH1_str),', with masks'));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

  end;
  

figure(5)
%close 5;
%figure(5)
imshow(mat2gray(M_bPAC));
title(strcat('bPAC marker: CFP'));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');

     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
             %  if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
             %  else
             %  set(tt,'Color','y');
             %  end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               %if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               %else
               %set(ll,'Color','y');
               %end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,': bPAC Marker: magenta (bPAC cells), yellow (non-bPAC cells)'));             
                  
 

    
   if (do_make_movie_Erk == 1)    
    H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
   end;

 if (do_plot_cytosol_and_nuclear_signal == 1)
   plot_cytosol_and_nuclear_signal;    
 end;


  end;   % END OF:  if (count_fast == 1)        

end;  % end of  'for kkk = 1:length(which_frames)



   if (do_make_movie_Erk == 1)   
      mov = close(mov);
   end;
     
do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)&(done_cells_tracked_ppt == 0)
 % save the figures to a powerpoint slide


  fig111 = figure(5)
  figure(1111)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
   s_combine = 'cell trajectories';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111 fig111 fig1111], 'halign','center','title', s_combine);

    movefile('cells_tracked.ppt',strcat(str_movie_processed,'\',str_movie,'-cells_tracked.ppt'));
    done_cells_tracked_ppt = 1;  % have made the ppt file

end; % if (do_PPT ==1)
              



