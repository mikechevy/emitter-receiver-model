
                 x_coord_min = x_coord_min_local;
                 x_coord_max = x_coord_max_local;
                 y_coord_min = y_coord_min_local;
                 y_coord_max = y_coord_max_local;
                 numFr = numFr_NM;
                 
                 %x_coord_min = 1;
                 %x_coord_max = xLength;
                 %y_coord_min = 1;
                 %y_coord_max = yLength;

%index_group = [];               
ii_count = 0;
index_group = [];
for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
    end;
end;
                 


for kkk = 1:1
  which_frame = kkk
  
  
 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
M_marker_threshold_TEST = zeros(xLength,yLength);

 for jjj = 1:num_nuclei_t0
     idx = jjj;
   M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}'])) =   1;
 end;
     
 for jjj = 1:length(index_group)
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
        if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)
        M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   3;
        else
        M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   2;
        end;
       end;
 end;
 

 

figure(22)
imagesc(M_marker_threshold_TEST)
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr),', movie: ',str_movie));
   hold on;                 
    for jj = 1:length(index_group)
       idx = index_group(jj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             %set(ll,'Color','y');
             xx = text(mean_y_tot_time_mapped_t0(idx,1),mean_x_tot_time_mapped_t0(idx,1),num2str(idx));                  
             set(xx,'Color','w');
       
        
                  rectangle('Position', [y_coord_min,x_coord_min,...
                    y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
                          'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                          'EdgeColor', 'w');
            
    end;
   hold off;
    %xlim([max(y_coord_min-40,1) min(y_coord_max+40,yLength)]);
    %ylim([max(x_coord_min-40,1) min(x_coord_max+40,xLength)]);
    xlim([1 yLength]);
    ylim([1 xLength]);

end; %for kkk = 1:
