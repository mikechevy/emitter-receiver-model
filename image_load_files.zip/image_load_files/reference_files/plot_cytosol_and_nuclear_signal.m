


if (do_CY3 == 1)        
figure(2)

     subplot(2,4,[1 2]) 
     title(strcat('nuclear CY3 signal'));
     plot(time_sequence_movie,cytosolic_CY3_tot_time_mapped_t0(idx,:)-cytosolic_CY3_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie,cytosolic_CY3_tot_time_mapped_t0(idx,:)-cytosolic_CY3_tot_time_mapped_t0(idx,1));
     plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(cytosolic_CY3_tot_time_mapped_t0(idx,:)-cytosolic_CY3_tot_time_mapped_t0(idx,1)) max(cytosolic_CY3_tot_time_mapped_t0(idx,:)-cytosolic_CY3_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CY3)
     legend(strcat('CY3 (cyt-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CY3)
     legend(strcat('CY3 (cyt-Ca2+),nuc:',num2str(which_nucleus)))
     end;
     xlabel('time (seconds)');
     xlim([0 max(time_sequence_movie)]);


     subplot(2,4,[3 4]) 
     title(strcat('nuclear CY3 signal'));
     plot(time_sequence_movie,nuclear_CY3_tot_time_mapped_t0(idx,:)-nuclear_CY3_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie,nuclear_CY3_tot_time_mapped_t0(idx,:)-nuclear_CY3_tot_time_mapped_t0(idx,1));
     plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(nuclear_CY3_tot_time_mapped_t0(idx,:)-nuclear_CY3_tot_time_mapped_t0(idx,1)) max(nuclear_CY3_tot_time_mapped_t0(idx,:)-nuclear_CY3_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CY3)
     legend(strcat('CY3 (nuc-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CY3)
     legend(strcat('CY3 (nuc-Ca2+),nuc:',num2str(which_nucleus)))
     end;
     xlabel('time (seconds)');
     xlim([0 max(time_sequence_movie)]);
    

    
end; % END OF: if (do_CY3 == 1)        

     
     
     
if (do_FITC == 1)    
    
     subplot(2,4,[5 6]) 
     title(strcat('cytosolic FITC signal'));
     plot(time_sequence_movie,cytosolic_FITC_tot_time_mapped_t0(idx,:)-cytosolic_FITC_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie,cytosolic_FITC_tot_time_mapped_t0(idx,:)-cytosolic_FITC_tot_time_mapped_t0(idx,1));
     plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(cytosolic_FITC_tot_time_mapped_t0(idx,:)-cytosolic_FITC_tot_time_mapped_t0(idx,1)) max(cytosolic_FITC_tot_time_mapped_t0(idx,:)-cytosolic_FITC_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_FITC)
     legend(strcat('FITC (cyt-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_FITC)
     legend(strcat('FITC (cyt-Ca2+),nuc:',num2str(which_nucleus)))
     end;     
     xlabel('time (seconds)');
     xlim([0 max(time_sequence_movie)]);
     ylim([min(cytosolic_FITC_tot_time_mapped_t0(idx,:)-cytosolic_FITC_tot_time_mapped_t0(idx,1)) max(cytosolic_FITC_tot_time_mapped_t0(idx,:)-cytosolic_FITC_tot_time_mapped_t0(idx,1))]);

    
     subplot(2,4,[7 8]) 
     title(strcat('nuclear FITC signal'));
     plot(time_sequence_movie,nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie,nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1));
     plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1)) max(nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_FITC)
     legend(strcat('FITC (nuc-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_FITC)
     legend(strcat('FITC (nuc-Ca2+),nuc:',num2str(which_nucleus)))
     end;     
     xlabel('time (seconds)');
     xlim([0 max(time_sequence_movie)]);
     ylim([min(nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1)) max(nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1))]);
     
       
     if (marker_from_channel(ii_Ca_marker) == ii_FITC)
         index_sample_frame_FITC = index_sample_frame_Ca;
     elseif (marker_from_channel(ii_Erk_marker) == ii_FITC)
         index_sample_frame_FITC = index_sample_frame_Erk;
     end;

     for jjj = 1:length(index_sample_frame_FITC)
         
        which_sample_frame = index_sample_frame_FITC(jjj);
        if (which_sample_frame == 1)
         start_frame = 1+1;
         end_frame = 1+num_sample_sequence(1);
        else
         start_frame = 1+sum(num_sample_sequence(1:which_sample_frame-1))+1;
         end_frame = 1+sum(num_sample_sequence(1:which_sample_frame));            
        end;
 
         
     figure(11)
     subplot(length(index_sample_frame_FITC),2,2*jjj) 
     title(strcat('nuclear FITC signal'));
     plot(time_sequence_movie(start_frame:end_frame),nuclear_FITC_tot_time_mapped_t0(idx,start_frame:end_frame)-nuclear_FITC_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie(start_frame:end_frame),nuclear_FITC_tot_time_mapped_t0(idx,start_frame:end_frame)-nuclear_FITC_tot_time_mapped_t0(idx,1));
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_FITC)
     legend(strcat('FITC (nuc-Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_FITC)
     legend(strcat('FITC (nuc-Ca2+),nuc:',num2str(which_nucleus)))
     end;     
     xlabel('time (seconds)');
     xlim([time_sequence_movie(start_frame) time_sequence_movie(end_frame)]);
     ylim([min(nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1)) max(nuclear_FITC_tot_time_mapped_t0(idx,:)-nuclear_FITC_tot_time_mapped_t0(idx,1))]);
     
     end;  % end of: for jjj = 1:length(index_sequence_frame_FITC)
     
     
      
     
     
end; % END OF: if (do_FITC == 1)        
