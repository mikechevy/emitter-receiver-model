mean_x_tot_time_mapped_t0= zeros(num_nuclei_t0_max,1);
mean_y_tot_time_mapped_t0= zeros(num_nuclei_t0_max,1);
bPAC_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_t0_max,1);

mean_x_tot_time_mapped_t0_first = zeros(num_nuclei_t0_first,1);
mean_y_tot_time_mapped_t0_first = zeros(num_nuclei_t0_first,1);

linked_nuclei_success = zeros(num_nuclei_t0_first,1);
linked_nuclei_across_movies_success = zeros(num_nuclei_t0_first,1);

  mean_x_tot_time_mapped_t0_first(1:num_nuclei_t0_first) = mean_x_tot_time_mapped_t0_array(1:num_nuclei_t0_first,1);
  mean_y_tot_time_mapped_t0_first(1:num_nuclei_t0_first) = mean_y_tot_time_mapped_t0_array(1:num_nuclei_t0_first,1);


cd('../combined_d_cAMP/')
mkdir(strcat('do_case_',num2str(do_case)));
cd(strcat('do_case_',num2str(do_case)))
  
delete(strcat(str_movie,'-linked_nuclei_across_movies_d_cAMP.ppt'));

  
for idx = 1:num_nuclei_t0_first

pause(.5);

for ii_which_movie = 1:length(movie_array)

  num_nuclei_t0 = num_nuclei_t0_array(ii_which_movie);
    
  mean_x_tot_time_mapped_t0(1:num_nuclei_t0) = mean_x_tot_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie);
  mean_y_tot_time_mapped_t0(1:num_nuclei_t0) = mean_y_tot_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie);
  bPAC_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,1) =  bPAC_NUCLEUS_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie);

  
  M_NM(:,:) = M_NM_d_cAMP(:,:,ii_which_movie);    
  M_NM_bPAC(:,:) = M_NM_bPAC_d_cAMP(:,:,ii_which_movie);
  M_Erk(:,:) = M_Erk_d_cAMP(:,:,ii_which_movie);
   

    % Default for now, but movie specific later
    scale_Erk_channel = 0.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels


kkk = 1;
which_frame = kkk;

    figure(10000)
    subplot(2,2,ii_which_movie);
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
    image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    title(strcat('Movie:',num2str(ii_which_movie)));

which_frame_NM = 1;
delta_min = xLength;
index_min = 0;     
    
for kkk = 1:num_nuclei_t0

             tt = text(mean_y_tot_time_mapped_t0(kkk,which_frame_NM),mean_x_tot_time_mapped_t0(kkk,which_frame_NM),strcat(num2str(kkk)));
             %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),'.');
             if ii_NM == ii_NM_bPAC  % all bPAC cells
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
               str_emitter = 'm';
               set(tt,'Color',str_emitter);
               %set(tt,'fontsize',12);
             else
               if (bPAC_NUCLEUS_time_mapped_t0(kkk,1) == 1)    
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
                   str_emitter = 'c';
                 set(tt,'Color',str_emitter);
               else
               set(tt,'Color','y');
               end;
             end;
             
         
    delta_test = sqrt(power(mean_y_tot_time_mapped_t0_first(idx,which_frame_NM) - mean_y_tot_time_mapped_t0(kkk,1),2)+power(mean_x_tot_time_mapped_t0_first(idx,which_frame_NM) - mean_x_tot_time_mapped_t0(kkk,1),2));              
    if (delta_test < delta_min)
        delta_min = delta_test;
        index_min = kkk;
    end;

end;

                 % (place circle around specified nucleus) 
                      %e
                      %r= desired radius
                      %x = x coordinates of the centroid
                      %y = y coordinates of the centroid
                      radius_pixels = 20;   %pixels
                      th = 0:pi/50:2*pi;
                      xunit = radius_pixels * cos(th) + mean_x_tot_time_mapped_t0_first(idx,which_frame_NM);
                      yunit = radius_pixels * sin(th) + mean_y_tot_time_mapped_t0_first(idx,which_frame_NM);
                      hold on;
                       if (bPAC_NUCLEUS_time_mapped_t0_first(idx,1) == 1)    
                        xx = plot(yunit, xunit,strcat(str_emitter,'--'));
                       else
                        xx = plot(yunit, xunit,'y--');
                       end;
                       set(xx,'LineWidth',2);
                       hold off;

       
         if (delta_min <= radius_pixels)              
         linked_nuclei_across_movies_array(idx,ii_which_movie) = index_min;
         end;

             
end; % end of 'for ii_which_movie = 1:length(movie_array)'

linked_nuclei_across_movies_array(idx,:)

 if (min(linked_nuclei_across_movies_array(idx,:)) > 0)
     linked_nuclei_across_movies_success(idx) = 1;     
         % save image of it
         fig10000 = figure(10000)
         s_combine = strcat(str_movie,': first movie nuclei:',num2str(idx));
         saveppt2(strcat(str_movie,'-linked_nuclei_across_movies_d_cAMP.ppt'),'figure',[fig10000], 'halign','center','title', s_combine);
 end;

 

 
end; % end of 'for idx = 1:num_nuclei_t0_first'


cd(str_processing) 


