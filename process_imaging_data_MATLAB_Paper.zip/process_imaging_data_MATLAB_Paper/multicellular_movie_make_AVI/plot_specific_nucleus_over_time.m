
do_NM = 1;  % 1 - yes, 0 - no
do_CH1 = 1;  % 1 - yes, 0 - no
do_CH2 = 1;  % 1 - yes, 0 - no


do_make_movie_Erk = 0;  % 1 - yes, 0 - no
 
       if (do_make_movie_Erk == 1)
          filename_movie = strcat(str_movie,'_processed\Erk_nucleus',num2str(which_nucleus));
          delete(strcat(filename_movie,'.avi'));
          mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',2);
       end;
          
    which_frame = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);

                 
do_track_center_of_mass = 1;  % 1 - yes, 0 - no                 
                 
                 
M_marker_threshold_TEST = zeros(xLength,yLength);


index_group = which_nucleus;

for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)

     if (do_track_center_of_mass == 1)                 
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
     end;
  
  
  str_movie_processed = strcat(str_movie,'_processed')
  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus);

 M_marker_threshold_TEST = 0*M_marker_threshold_TEST;

 for jjj = 1:length(index_group);
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_NM_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end;

figure(2)
subplot(2,4,[1 2 5 6]);
imagesc(M_marker_threshold_TEST)
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr)));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
       
            if (idx_map > 0)
              %text(mean_y_tot_NM(idx_map)-sqrt(var_y_tot_NM(idx_map)),mean_x_tot_NM(idx_map)-0*sqrt(var_x_tot_NM(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('t0:',num2str(idx)));                    
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

if (do_NM == 1)        
figure(3)
subplot(2,4,[1 2 5 6]);
imagesc(M_NM)
title(strcat('NM signal,which frame:',num2str(which_frame),', total frames:',num2str(numFr)));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
       
            if (idx_map > 0)
              %text(mean_y_tot_NM(idx_map)-sqrt(var_y_tot_NM(idx_map)),mean_x_tot_NM(idx_map)-0*sqrt(var_x_tot_NM(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('t0:',num2str(idx)));                    
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
end; % END OF: if (do_NM == 1)        

    

if (do_CH2 == 1)        
figure(4)
subplot(2,4,[1 2 5 6]);
imagesc(M_CH2)
title(strcat('CH2 signal, which frame:',num2str(which_frame),', total frames:',num2str(numFr),',nucleus:',num2str(which_nucleus)));
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');

              tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),'X');                   
              set(tt,'Color','k');
    end;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
 
     subplot(2,4,[7 8]) 
     title(strcat('nuclear CH2 signal, which_nucleus:',num2str(which_nucleus)));
     plot(time_sequence_movie,nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie,nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1));
     plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1)) max(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');
    xlim([0 numFr]);
    
   if (do_make_movie_Erk == 1)&(marker_from_channel(ii_Erk_marker)==ii_CH2)    
    H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
   end;

    
end; % END OF: if (do_CH2 == 1)        

     
     
     
if (do_CH1 == 1)        
figure(5)
subplot(2,4,[1 2 5 6]);
imagesc(M_CH1)
title(strcat('CH1 signal, which frame:',num2str(which_frame),', total frames:',num2str(numFr)));
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');

              tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),'X');                   
              set(tt,'Color','k');
    end;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
    
     subplot(2,4,[7 8]) 
     title(strcat('nuclear CH1 signal, which_nucleus:',num2str(which_nucleus)));
     plot(time_sequence_movie,nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_sequence_movie,nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1));
     plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[0 max(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');
     xlim([0 numFr]);
     
   if (do_make_movie_Erk == 1)&(marker_from_channel(ii_Erk_marker)==ii_CH1)    
    H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
   end;
end; % END OF: if (do_CH1 == 1)        
     
     
    pause(.2);


    
    
end;  % end of  'for kkk = 1:length(which_frames)



   if (do_make_movie_Erk == 1)   
      mov = close(mov);
   end;
     
              



