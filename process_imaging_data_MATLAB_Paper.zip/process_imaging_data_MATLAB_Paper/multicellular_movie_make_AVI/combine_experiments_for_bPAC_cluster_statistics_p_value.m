%  Script to generate statistics for the paper

str_processing = pwd;  % get processing directory

max_distance_plot = 80; % micrometers, used for do_emitter_reciever_amp_distance = 1


do_annotated_clusters = 0;  % 1-yes (make_annotated_clusters.m), 0-no (original)



do_case = 5;

if (do_case == 1)  % small emitter cluster movies
    
    

elseif (do_case == 2)  % small emitter cluster movies

    
elseif (do_case == 3)  % combined small (single) emitter cluster movies

  %5)	190625_198-117_198_TEST_MC, movie 60
  %6)	190716_198-117_198_TEST_MC, movie 65, might not use
  %7)	190726_198-117_198_TEST_MC, movie 66
  %8)	190730_198-117_198_TEST_MC, movie 68
  %9)	190823_198-117_198_TEST_MC_2, movie 81
  %10)	190910_198-117_198_TEST_MC, movie 91
  %11)	190912_198-117_198_TEST_MC, movie 93
  %12)	190912_198-117_198_TEST_MC_2, movie 94
  %13)	191213_198-117_198_MC_p23, movie 140
  %14)	191213_198-117_198_MC_p23_2, movie 141
  %15)	191217_198-117_198_MC_p26, movie 142
  %16)	191217_198-117_198_MC_p26_2, movie 143, might not use

%movie_array = [60 65 66 68 81 91 93 94 140 141 142 143];
movie_array = [60 66 68 81 91 93 94 140 141 142];
  
  
do_non_bPAC_clusters_inner = 0;
do_emitter_statistics = 1;
do_emitter_reciever_amp_distance = 0;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

location_vec_array = [];
time_overshoot_whole_dummy_RAND_array = [];
ratio_overshoot_dummy_array = [];
time_max_to_ss_bPAC_pulse_cell_dummy_array = [];
num_samples_array = zeros(length(movie_array),1);


elseif (do_case == 4)  % small emitter cluster movies

% 1)  031416\_mwc\_198\_198-117\_same, movei 400
% 2)  200206\_198-117\_198\_MC, movie 149
% 3)  200206\_198-117\_198\_MC\_2, movie 150
    
movie_array = [400 149 150];
  
  
do_non_bPAC_clusters_inner = 0;
do_emitter_statistics = 1;
do_emitter_reciever_amp_distance = 0;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

location_vec_array = [];
time_overshoot_whole_dummy_RAND_array = [];
ratio_overshoot_dummy_array = [];
time_max_to_ss_bPAC_pulse_cell_dummy_array = [];
num_samples_array = zeros(length(movie_array),1);

do_annotated_clusters = 0;  % 1-yes (make_annotated_clusters.m), 0-no (original)

    
elseif (do_case == 5)  % small emitter cluster movies (receivers with no gap-junctions    
    
% 1)  210103_198-117_MDCKII_4, movie 282
% 2)  201220_198-117_MDCKII_2, movei 272
% 3)  201220_198-117_MDCKII_4_samecells, movie 274
% 4)  201231_198-117_MDCKII_3, movie 280
    
movie_array = [282 272 274 280];
  
  
do_non_bPAC_clusters_inner = 0;
do_emitter_statistics = 1;
do_emitter_reciever_amp_distance = 0;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

location_vec_array = [];
time_overshoot_whole_dummy_RAND_array = [];
ratio_overshoot_dummy_array = [];
time_max_to_ss_bPAC_pulse_cell_dummy_array = [];
num_samples_array = zeros(length(movie_array),1);



do_annotated_clusters = 0;  % 1-yes (make_annotated_clusters.m), 0-no (original)


end;



cd('../combined_statistics_p_value/')
if (do_annotated_clusters == 0)
  mkdir(strcat('do_case_',num2str(do_case)));
  cd(strcat('do_case_',num2str(do_case)));
elseif (do_annotated_clusters == 1)
  mkdir(strcat('do_case_',num2str(do_case),'_annotated'));
  cd(strcat('do_case_',num2str(do_case),'_annotated'));
end;
str_combined_stats_do_case = pwd;
  delete(strcat('combined_stats_do_case_',num2str(do_case),'-nuclear_Erk_signals_statistics_EMITTERS.ppt'));
cd(str_processing) 


if (length(movie_array) > 1)
   num_rounds = 2;
else
   num_rounds = 1;
end;
    

for ii_round = 1:num_rounds

for ii_which_movie = 1:length(movie_array)

which_movie_array = movie_array(ii_which_movie); 

load_and_plot_bPAC_cluster_statistics_p_value;




 if (ii_which_movie == 1)
   str_movies_do_case = str_movie; 
 else
   str_movies_do_case = [str_movies_do_case ',' str_movie]; 
 end;

  %if (do_case == 3)
   % TO DO: write code here to combine statistics
   if (ii_round == 1)
   location_vec_array = [location_vec_array ; location_vec];
   %time_overshoot_whole_dummy_RAND_array = [time_overshoot_whole_dummy_RAND_array time_overshoot_whole_dummy_RAND];  
   time_overshoot_whole_dummy_RAND_array = [time_overshoot_whole_dummy_RAND_array time_overshoot_whole_bPAC_pulse_cell_REVISE];
   ratio_overshoot_dummy_array = [ratio_overshoot_dummy_array ratio_overshoot_dummy];
   time_max_to_ss_bPAC_pulse_cell_dummy_array = [time_max_to_ss_bPAC_pulse_cell_dummy_array time_max_to_ss_bPAC_pulse_cell_dummy];
   num_samples_array(ii_which_movie) = length(location_vec);
   end;    
  %end;



end;  %  for ii_which_movie = 1:length(movie_array)


end;  % for ii_round = 1:num_rounds
    


cd (str_combined_stats_do_case);

location_vec_array = ones(length(time_overshoot_whole_dummy_RAND_array),1);

if (do_case >= 3)  % combined single emitter cluster movies
     figure(50);  % generated in make_bPAC_statistics_plots.m
                str_dir_dummy = pwd;
                cd(str_combined_stats_do_case);              
                   s_combine = strcat(str_movie,':nuclear Erk signals');
                   % full scatter plot of all combined data
                   figure(50)
                   hold on;
                   %scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
                   scatter(location_vec_array, time_overshoot_whole_dummy_RAND_array,str_plot);
                    ss = errorbar(location_vec_array(1),mean(time_overshoot_whole_dummy_RAND_array),std(time_overshoot_whole_dummy_RAND_array),'m');
                    ss = errorbar(location_vec_array(1),mean(time_overshoot_whole_dummy_RAND_array),std(time_overshoot_whole_dummy_RAND_array)/sqrt(length(time_overshoot_whole_dummy_RAND_array)),'g');
                    set(ss,'LineWidth',2);
                      cap_width = .2;
                    ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND_array)-std(time_overshoot_whole_dummy_RAND_array) mean(time_overshoot_whole_dummy_RAND_array)-std(time_overshoot_whole_dummy_RAND_array)],'m');
                    set(ss,'LineWidth',2);
                    ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND_array)+std(time_overshoot_whole_dummy_RAND_array) mean(time_overshoot_whole_dummy_RAND_array)+std(time_overshoot_whole_dummy_RAND_array)],'m');
                    set(ss,'LineWidth',2);
                    ss = scatter(location_vec_array(1),mean(time_overshoot_whole_dummy_RAND_array),'md');
                    set(ss,'LineWidth',5);
                    ss = scatter(location_vec_array(1),median(time_overshoot_whole_dummy_RAND_array),'yd');
                    set(ss,'LineWidth',5);                   
                   ylabel('time to overshoot (min.)');
                   xlabel('combined movies');
                   title(strcat('combined movies, num samps: ',num2str( sum(num_samples_array) ),', median:',num2str(median(time_overshoot_whole_dummy_RAND_array)),',mean:',num2str(mean(time_overshoot_whole_dummy_RAND_array)),', std: ',num2str(std(time_overshoot_whole_dummy_RAND_array)))); 
                   hold off;
                   ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);                   
                   xlim([0 3]);
                fig50 = figure(50)
                saveppt2(strcat('combined_stats_do_case_',num2str(do_case),'-nuclear_Erk_signals_statistics_EMITTERS_fig50.ppt'),'figure',[fig50], 'halign','center','title', s_combine);
                cd(str_dir_dummy)
     
     print('-depsc',strcat('do_case_',num2str(do_case),'-time_to_overshoot.eps')); 
     save(strcat('do_case_',num2str(do_case),'-time_to_overshoot_data'),'time_overshoot_whole_dummy_RAND_array', 'num_samples_array')
     

     
location_vec_array = ones(length(ratio_overshoot_dummy_array),1);
     
figure(2220)
hold on;
scatter(location_vec_array, abs(ratio_overshoot_dummy_array),str_plot);
   ss = errorbar(location_vec_array(1),mean(ratio_overshoot_dummy_array),std(ratio_overshoot_dummy_array),'m');
   ss = errorbar(location_vec_array(1),mean(ratio_overshoot_dummy_array),std(ratio_overshoot_dummy_array)/sqrt(length(ratio_overshoot_dummy_array)),'g');
   set(ss,'LineWidth',2);
     cap_width = .2;
   ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(ratio_overshoot_dummy_array)-std(ratio_overshoot_dummy_array) mean(ratio_overshoot_dummy_array)-std(ratio_overshoot_dummy_array)],'m');
   set(ss,'LineWidth',2);
   ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(ratio_overshoot_dummy_array)+std(ratio_overshoot_dummy_array) mean(ratio_overshoot_dummy_array)+std(ratio_overshoot_dummy_array)],'m');
   set(ss,'LineWidth',2);
   ss = scatter(location_vec_array(1),mean(ratio_overshoot_dummy_array),'md');
   set(ss,'LineWidth',5);
   ss = scatter(location_vec_array(1),median(ratio_overshoot_dummy_array),'yd');
   set(ss,'LineWidth',5);
ylabel('overshoot ratio');
xlabel('combined movies');
title(strcat('combined movies, num samps: ',num2str( sum(num_samples_array) ),', median:',num2str(median(ratio_overshoot_dummy_array)),',mean:',num2str(mean(ratio_overshoot_dummy_array)),', std: ',num2str(std(ratio_overshoot_dummy_array)))); 

hold off;
ylim([0 3.5]);
xlim([0 3]);


     print('-depsc',strcat('do_case_',num2str(do_case),'-ratio_overshoot.eps')); 
     
     
%figure(2241)
%hold on;
%scatter(time_max_to_ss_bPAC_pulse_cell_dummy_array-time_overshoot_whole_dummy_RAND_array,ratio_overshoot_dummy_array,str_plot);
%scatter(mean(time_max_to_ss_bPAC_pulse_cell_dummy_array-time_overshoot_whole_dummy_RAND_array),mean(ratio_overshoot_dummy_array),'md');
%ylabel('overshoot_ratio') 
%xlabel('time-to-ss  -  time-to-max') 
%ylim([0 5]);


overshoot_dynamics_dummy_array = time_max_to_ss_bPAC_pulse_cell_dummy_array-time_overshoot_whole_dummy_RAND_array
     location_vec_array = ones(length(overshoot_dynamics_dummy_array),1);

figure(2221)
hold on;
scatter(location_vec_array, abs(overshoot_dynamics_dummy_array),str_plot);
   ss = errorbar(location_vec_array(1),mean(overshoot_dynamics_dummy_array),std(overshoot_dynamics_dummy_array),'m');
   ss = errorbar(location_vec_array(1),mean(overshoot_dynamics_dummy_array),std(overshoot_dynamics_dummy_array)/sqrt(length(overshoot_dynamics_dummy_array)),'g');
   set(ss,'LineWidth',2);
     cap_width = .2;
   ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(overshoot_dynamics_dummy_array)-std(overshoot_dynamics_dummy_array) mean(overshoot_dynamics_dummy_array)-std(overshoot_dynamics_dummy_array)],'m');
   set(ss,'LineWidth',2);
   ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(overshoot_dynamics_dummy_array)+std(overshoot_dynamics_dummy_array) mean(overshoot_dynamics_dummy_array)+std(overshoot_dynamics_dummy_array)],'m');
   set(ss,'LineWidth',2);
   ss = scatter(location_vec_array(1),mean(overshoot_dynamics_dummy_array),'md');
   set(ss,'LineWidth',5);
   ss = scatter(location_vec_array(1),median(overshoot_dynamics_dummy_array),'yd');
   set(ss,'LineWidth',5);
ylabel('time-to-ss  -  time-to-max');
xlabel('combined movies');
title(strcat('combined movies, num samps: ',num2str( sum(num_samples_array) ),', median:',num2str(median(overshoot_dynamics_dummy_array)),',mean:',num2str(mean(overshoot_dynamics_dummy_array)),', std: ',num2str(std(overshoot_dynamics_dummy_array)))); 
ylim([0 20]);
xlim([0 3]);
     
     print('-depsc',strcat('do_case_',num2str(do_case),'-overshoot_dynamics.eps')); 
     

     
     location_vec_array = ones(length(time_max_to_ss_bPAC_pulse_cell_dummy_array),1);

     
for ii_RAND = 1:length(time_max_to_ss_bPAC_pulse_cell_dummy_array)     
    time_max_to_ss_bPAC_pulse_cell_dummy_array(ii_RAND) = time_max_to_ss_bPAC_pulse_cell_dummy_array(ii_RAND) + rand -.5; 
end;
    

location_vec_array = ones(length(time_max_to_ss_bPAC_pulse_cell_dummy_array),1);


figure(2230)
hold on;
scatter(location_vec_array, time_max_to_ss_bPAC_pulse_cell_dummy_array,str_plot);
   ss = errorbar(location_vec_array(1),mean(time_max_to_ss_bPAC_pulse_cell_dummy_array),std(time_max_to_ss_bPAC_pulse_cell_dummy_array),'m');
   ss = errorbar(location_vec_array(1),mean(time_max_to_ss_bPAC_pulse_cell_dummy_array),std(time_max_to_ss_bPAC_pulse_cell_dummy_array)/sqrt(length(time_max_to_ss_bPAC_pulse_cell_dummy_array)),'g');
   set(ss,'LineWidth',2);
     cap_width = .2;
   ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(time_max_to_ss_bPAC_pulse_cell_dummy_array)-std(time_max_to_ss_bPAC_pulse_cell_dummy_array) mean(time_max_to_ss_bPAC_pulse_cell_dummy_array)-std(time_max_to_ss_bPAC_pulse_cell_dummy_array)],'m');
   set(ss,'LineWidth',2);
   ss = plot([location_vec_array(1)-cap_width/2 location_vec_array(1)+cap_width/2],[mean(time_max_to_ss_bPAC_pulse_cell_dummy_array)+std(time_max_to_ss_bPAC_pulse_cell_dummy_array) mean(time_max_to_ss_bPAC_pulse_cell_dummy_array)+std(time_max_to_ss_bPAC_pulse_cell_dummy_array)],'m');
   set(ss,'LineWidth',2);
   ss = scatter(location_vec_array(1),mean(time_max_to_ss_bPAC_pulse_cell_dummy_array),'md');
   set(ss,'LineWidth',5);
   ss = scatter(location_vec_array(1),median(time_max_to_ss_bPAC_pulse_cell_dummy_array),'yd');
   set(ss,'LineWidth',5);
ylabel('time from max to ss');
xlabel(str_movie);
title(strcat('combined movies, num samps: ',num2str( sum(num_samples_array) ),', median:',num2str(median(time_max_to_ss_bPAC_pulse_cell_dummy_array)),',mean:',num2str(mean(time_max_to_ss_bPAC_pulse_cell_dummy_array)),', std: ',num2str(std(time_max_to_ss_bPAC_pulse_cell_dummy_array)))); 
hold off;
ylim([0 40]);
xlim([0 3]);

     print('-depsc',strcat('do_case_',num2str(do_case),'-time_max_to_ss.eps')); 


     
figure(2240)
hold on;
scatter(time_max_to_ss_bPAC_pulse_cell_dummy_array,time_overshoot_whole_dummy_RAND_array,str_plot);
scatter(mean(time_max_to_ss_bPAC_pulse_cell_dummy_array),mean(time_overshoot_whole_dummy_RAND_array),'md');
ylabel('time-to-max') 
xlabel('time from max to ss') 
ylim([0 40]);
xlim([0 40]);

     print('-depsc',strcat('do_case_',num2str(do_case),'time-to-max_vs_time-to-ss.eps')); 


figure(2241)
hold on;
scatter(time_max_to_ss_bPAC_pulse_cell_dummy_array-time_overshoot_whole_dummy_RAND_array,ratio_overshoot_dummy_array,str_plot);
scatter(mean(time_max_to_ss_bPAC_pulse_cell_dummy_array-time_overshoot_whole_dummy_RAND_array),mean(ratio_overshoot_dummy_array),'md');
ylabel('overshoot_ratio') 
xlabel('time-to-ss  -  time-to-max') 
%ylim([0 5]);
xlim([0 30]);
     
     print('-depsc',strcat('do_case_',num2str(do_case),'-overshoot_dynamics_vs_ratio_overshoot.eps')); 
     

figure(2242)
hold on;
scatter(time_max_to_ss_bPAC_pulse_cell_dummy_array,ratio_overshoot_dummy_array,str_plot);
scatter(mean(time_max_to_ss_bPAC_pulse_cell_dummy_array),mean(ratio_overshoot_dummy_array),'md');
ylabel('overshoot_ratio') 
xlabel('time-to-ss') 
%ylim([0 5]);
xlim([0 40]);

     print('-depsc',strcat('do_case_',num2str(do_case),'-time-to-ss_vs_ratio_overshoot.eps')); 


figure(2243)
hold on;
scatter(time_overshoot_whole_dummy_RAND_array,ratio_overshoot_dummy_array,str_plot);
scatter(mean(time_overshoot_whole_dummy_RAND_array),mean(ratio_overshoot_dummy_array),'md');
ylabel('overshoot ratio') 
xlabel('time-to-max') 
%ylim([0 40]);
xlim([0 40]);

     print('-depsc',strcat('do_case_',num2str(do_case),'-time-to-max_vs_ratio_overshoot.eps')); 
     
     
end;

   if (length(movie_array) > 1)
     save(strcat('str_movies_do_case_',num2str(do_case)), 'str_movies_do_case', 'location_vec_array', 'time_overshoot_whole_dummy_RAND_array', 'num_samples_array','ratio_overshoot_dummy_array','time_max_to_ss_bPAC_pulse_cell_dummy_array');
   else
     save(strcat('str_movies_do_case_',num2str(do_case)), 'str_movies_do_case');
   end;

cd(str_processing) 
    