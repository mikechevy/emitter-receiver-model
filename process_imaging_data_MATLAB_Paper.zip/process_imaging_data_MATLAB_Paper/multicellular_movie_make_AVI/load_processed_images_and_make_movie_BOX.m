close all;
%clear all;

do_time_representation = 1; % 0-seconds, 1-minutes, 2-hours
if (do_time_representation == 0) % seconds
    scale_factor_time = 1;  
    str_time_representation = 'time (seconds)';
elseif (do_time_representation == 1) % minutes   
    scale_factor_time = 60;  
    str_time_representation = 'time (minutes)';
elseif (do_time_representation == 2) % minutes   
    scale_factor_time = 3600;  
    str_time_representation = 'time (hours)';
end;

str_processing = pwd;  % get processing directory
addpath(str_processing);  % for reference m files

%  PPT checks
done_cells_tracked_ppt = 0;  % 0-not yet made ppt file, 1-made ppt file

set_globals;

do_median_or_mean_signal = 1; % 0-mean, 1-median

if (length(which_movie) == 0)  % used for individual calls to this script
which_movie = input('which movie number do you want, e.g. 1 ,2, etc. ? ');    
end;
get_movie_info_for_processing  % which_movie must already be set


%str_movie_processed = strcat(str_movie,'_processed')
str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
str_movie_processed_figures = strcat(str_movie_processed,'\figures-',str_movie);
mkdir(str_movie_processed_figures);

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);


%  num_nuclei_signal_types = 3; % 1- shrink, 2- intersect (over time), 3 -circles  

which_nuclei_signal_type = input('which nuclei signal? (1- shrink, 2- intersect (over time), 3 -circles)');

% load in cellular signals file for processing
if (which_nuclei_signal_type == 1) % shrink
file_signals = strcat(str_movie_processed,'\cellular_signals');
elseif (which_nuclei_signal_type == 2) % intersect
file_signals = strcat(str_movie_processed,'\cellular_signals_intersect');
elseif (which_nuclei_signal_type == 3) % circle
file_signals = strcat(str_movie_processed,'\cellular_signals_circle');
end
load(file_signals);

% load in processed data from nuclear tracking code
file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
load(file_track);


do_load_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_nucleus_structs ==1)&(exist('Cell_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
load(file_nucleus_tot_FINAL);
end;

do_load_shrink_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_shrink_nucleus_structs ==1)&(exist('Cell_shrink_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_shrink_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_shrink_nucleus_structs_tot_FINAL');
load(file_shrink_nucleus_tot_FINAL);
end;
if (exist('Cell_intersect_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_intersect_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_intersect_nucleus_structs_tot_FINAL');
load(file_intersect_nucleus_tot_FINAL);
end;
if (exist('Cell_circle_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_circle_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_circle_nucleus_structs_tot_FINAL');
load(file_circle_nucleus_tot_FINAL);
end;


do_load_cytosol_structs = 1;  % 1 - yes, 0 - no
if (do_load_cytosol_structs ==1)&(exist('Cell_cytosol_FILL_6')==0)
% load in the thresholded cytosol information from all frames 
file_cytosol_tot_FINAL = strcat(str_movie_processed,'\Cell_cytosol_structs_tot_FINAL');
load(file_cytosol_tot_FINAL);
end;




do_load_movie_arrays = 1;  % 1 - yes, 0 - no
if (do_load_movie_arrays == 1)&(exist('M_CH1_total')==0)
% load in processed data from nuclear tracking code
file_movie_arrays = strcat(str_movie_processed,'\movie_arrays'); 
load(file_movie_arrays);  
end;



found_file_bPAC_mapped = fileattrib(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL.mat'))
if ( found_file_bPAC_mapped == 1 )
  load(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL'));
else
   do_mixed_bPAC_population_analysis = 1; % 1 - yes, 0 - no
   if (do_location_bPAC_nuclei == 1)&(do_mixed_bPAC_population_analysis==1)
    load(strcat(str_movie_processed,'\time_series_for_tracking_cells_bPAC'));
    load(strcat(str_movie_processed,'\Cell_nucleus_bPAC_structs_tot'));
    mixed_bPAC_population_analysis;
   end;
end;

found_file_microscope = fileattrib(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'))

if (found_file_microscope == 1)  % movie has input_info.mat file
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% variables in file: bPAC_amp  bPAC_ledvals  bPAC_max  measurement_order measurement_skipframes  seconds_per_frame    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
  load(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'));
  time_bPAC = 0:seconds_per_frame:seconds_per_frame*(length(bPAC_ledvals)-1);
  
else
    
    if which_movie == 103
        seconds_per_frame = 60;
    end;
  time_bPAC = 0:seconds_per_frame:seconds_per_frame*(length(bPAC_ledvals)-1);
    
end;  

 if bPAC_amp_max > 1
  bPAC_ledvals = bPAC_ledvals/bPAC_amp_max;
 end;


make_movie_BOX;