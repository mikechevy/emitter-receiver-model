function  index_sample = generate_cdf_and_sample(X,P_X,rand_dummy)

cdf_P_X(1) = P_X(1);
     
  for jj = 2:length(X)
      cdf_P_X(jj) = cdf_P_X(jj-1)+P_X(jj);
  end;

cdf_P_X = cdf_P_X/cdf_P_X(length(X));


  if (rand_dummy <= cdf_P_X(1))
    index_sample = 1;
  else
    for jj = 2:length(X)
        if (rand_dummy <= cdf_P_X(jj))&(rand_dummy > cdf_P_X(jj-1))
            index_sample = jj;
        end;
    end;
  end;
