

% allocate global variables
set_globals;
  num_nuclei_max = 0;
  num_nuclei_max_bPAC = 0;

% get information about movie (again)
get_movie_info_for_processing;

do_initial_low_pass = 0;  % 1 -lowpass the images, 0 - don't 

%%% condition the numerical value a nucleus takes on after thresholding the
%%% nuclear marker images
%%for which_frame = 1:numFr
%%
%%  M_FITC = double(M_FITC_total(:,:,which_frame)); 
%%        
%%end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
% BEGIN: Loop through all frames of the movie  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
which_frame_bPAC_last = 0;  

for which_frame = 1:length(eval(['time_CH',num2str(ii_NM)]))

    
  for jj = 1:length(signal_channels)
      eval(['M_S',num2str(jj),'=double(zeros(xLength,yLength));']);
      [val,which_frame_map] = min(abs(eval(['image_index_CH',num2str(jj)])-which_frame));
     eval(['[val,index_frame]= min(abs(time_CH',num2str(jj),'-time_CH',num2str(ii_NM),'(which_frame)));']);   
     which_frame_map = index_frame;
      eval(['M_S',num2str(jj),'(:,:) = double(M_CH',num2str(jj),'_total(:,:,which_frame_map));']);
  end;

    if length(signal_channels) == 1
       M_S2 = M_S1;
    end;
  
  figure(1);
  imagesc(M_S1);
  title(strcat('Channel 1:',CH1_str));
  
  figure(2);
  imagesc(M_S2);
  title(strcat('Channel 2:',CH2_str));
    if (which_frame == 1)
        M_S2_m1 = M_S2;
    else
        M_S2_m1 = M_S2;
        %M_CH3_m1 = double(cell2mat(MD(which_frame-1,ii_FITC)));
        %[val,which_frame_map] = min(abs(image_index_CH2-which_frame))
        %M_S2_m1(:,:) = M_CH2_total(:,:,which_frame-1);
    end;
    
   M_NM(:,:) = eval(['M_CH',num2str(ii_NM),'_total(:,:,which_frame)']);
  figure(3);
  imagesc(M_NM);
  title(strcat('Channel-',num2str(ii_NM),' (nuclear marker):',eval(['CH',num2str(ii_NM),'_str']) ));
     if (do_location_bPAC_nuclei == 1)
       M_NM(:,:) = eval(['M_CH',num2str(ii_NM),'_total(:,:,which_frame)']);
       figure(3);
       imagesc(M_NM);
        title(strcat('Channel-',num2str(ii_NM),' (nuclear bPAC marker):',eval(['CH',num2str(ii_NM),'_str']) ));
     end;

     
  if (do_location_bPAC_nuclei == 1)

     eval(['[val,index_frame]= min(abs(time_CH',num2str(ii_NM_bPAC),'-time_CH',num2str(ii_NM),'(which_frame)));']);     
     which_frame_bPAC = index_frame;
         
   M_NM_bPAC(:,:) = eval(['M_CH',num2str(ii_NM_bPAC),'_total(:,:,which_frame_bPAC)']);
  figure(4);
  imagesc(M_NM_bPAC);
  title(strcat('Channel-',num2str(ii_NM_bPAC),' (nuclear marker):',eval(['CH',num2str(ii_NM_bPAC),'_str']) ));
     if (do_location_bPAC_nuclei == 1)
       M_NM_bPAC(:,:) = eval(['M_CH',num2str(ii_NM_bPAC),'_total(:,:,which_frame_bPAC)']);
       figure(4);
       imagesc(M_NM_bPAC);
        title(strcat('Channel-',num2str(ii_NM_bPAC),' (nuclear bPAC marker):',eval(['CH',num2str(ii_NM_bPAC),'_str']) ));
     end;
  end
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Filtering step here, remove high spatial frequency noise, this can be in
%  IMAGEJ as well
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (do_initial_low_pass == 1)
%M_NM(:,:) = filter(M_NM(:,:));
end;
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Determine locations of each nucleus in the image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  
determine_location_of_each_nucleus

 if (do_location_bPAC_nuclei == 1)&(which_frame_bPAC~=which_frame_bPAC_last)
  determine_location_of_each_nucleus_bPAC;
  which_frame_bPAC_last = which_frame_bPAC;
 end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Determine cell signal regions around nuclues for each framewho
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    

end;  % end of 'for which_frame = 1:numFr


    num_pixels_tot_NUCLEUS_time = num_pixels_tot_NUCLEUS_time(1:num_nuclei_max,:);
    mean_x_tot_time = mean_x_tot_time(1:num_nuclei_max,:);
    mean_y_tot_time = mean_y_tot_time(1:num_nuclei_max,:);
    var_x_tot_time = var_x_tot_time(1:num_nuclei_max,:);
    var_y_tot_time = var_y_tot_time(1:num_nuclei_max,:);
    cov_xy_tot_time = cov_xy_tot_time(1:num_nuclei_max,:);

    file_track_cells = strcat(str_movie_processed,'\time_series_for_tracking_cells');
    save(file_track_cells,'num_pixels_tot_NUCLEUS_time','mean_x_tot_time','mean_y_tot_time','var_x_tot_time','var_y_tot_time','cov_xy_tot_time','num_nuclei_time','x_coord_min_tot_time','x_coord_max_tot_time','y_coord_min_tot_time','y_coord_max_tot_time','num_nuclei_max');

      if (do_location_bPAC_nuclei == 1)
       num_pixels_tot_NUCLEUS_time_bPAC = num_pixels_tot_NUCLEUS_time_bPAC(1:num_nuclei_max_bPAC,:);
       mean_x_tot_time_bPAC = mean_x_tot_time_bPAC(1:num_nuclei_max_bPAC,:);
       mean_y_tot_time_bPAC = mean_y_tot_time_bPAC(1:num_nuclei_max_bPAC,:);
       var_x_tot_time_bPAC = var_x_tot_time_bPAC(1:num_nuclei_max_bPAC,:);
       var_y_tot_time_bPAC = var_y_tot_time_bPAC(1:num_nuclei_max_bPAC,:);
       cov_xy_tot_time_bPAC = cov_xy_tot_time_bPAC(1:num_nuclei_max_bPAC,:);

       file_track_cells = strcat(str_movie_processed,'\time_series_for_tracking_cells_bPAC');
       save(file_track_cells,'num_pixels_tot_NUCLEUS_time_bPAC','mean_x_tot_time_bPAC','mean_y_tot_time_bPAC','var_x_tot_time_bPAC','var_y_tot_time_bPAC','cov_xy_tot_time_bPAC','num_nuclei_time_bPAC','x_coord_min_tot_time_bPAC','x_coord_max_tot_time_bPAC','y_coord_min_tot_time_bPAC','y_coord_max_tot_time_bPAC','num_nuclei_max_bPAC');
      end;
    

% save some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
save(file_params,'numFr_NM','numFr_CH','xLength','yLength','path_movie','numCh','nucleus_min_pixels','fac_std_nuclear_size','fac_std_nuclear_size_recursive','num_throwout','num_throwout_max');  
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Track cells and calculate their resulting signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do_load_and_track_nuclear_locations = 1;
if (do_load_and_track_nuclear_locations == 1)
load_and_track_nuclear_locations
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calculate nuclear and cytsolic cells and calculate their resulting signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do_load_and_calculate_cellular_signals = 1;
if (do_load_and_calculate_cellular_signals == 1)
load_and_calculate_cellular_signals
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Analyze the statistics and correlations of the spatio-temporal cellular
%  signals
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do_load_and_analyze_cellular_signals = 1;
if (do_load_and_analyze_cellular_signals == 1)
load_and_analyze_cellular_signals
end;



