close all;

do_median_or_mean_signal = 1; % 0-mean, 1-median

kkk = 1

do_plot_cytosol_and_nuclear_signal = 0; % 1 - yes, 0 - no
do_NM = 1;  % 1 - yes, 0 - no
do_CH1 = 1;  % 1 - yes, 0 - no
do_CH2 = 0;  % 1 - yes, 0 - no
    if (length(signal_channels)==1)
        do_CH2 = 0;
    end;
           
do_just_nuclear_signal = 1;  % 0-ratio of nuclear to cytosol, 1-nuclear signal/min(nuclear signal);  For powerpoint stuff
    
scale_factor_time = 60;
str_time_representation = '(minutes)';
    
do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 

which_frame = 1;

figure(1000)
%imshow(mat2gray(M_CH1));
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,which_frame);']);
    imshow(mat2gray(M_NM));
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));             


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  ask user for the nucleus number
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
which_nucleus = input('which nucleus do you want to check?');



                 %x_coord_min = 1;
                 %x_coord_max = xLength;
                 %y_coord_min = 1;
                 %y_coord_max = yLength;
                 

                 
                 width_surround = 60;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);
                 

M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_CM_segmented = zeros(xLength,yLength);
M_NM_segmented = zeros(xLength,yLength);







                                  
if (ii_NM==ii_NM_bPAC) % only bPAC cells
bPAC_NUCLEUS_time_mapped_t0 = ones(num_nuclei_t0,length(eval(['time_CH',num2str(ii_NM)])));
end;
bPAC_NUCLEUS_time_mapped_t0_dummy = bPAC_NUCLEUS_time_mapped_t0;

num_cells_surround_max = 4;

          
  
width_surround = 10;

num_cells_surround = 0;

while (num_cells_surround <= num_cells_surround_max)%&(num_cells_surround ~= sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))

width_surround = width_surround + 1;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
    
    
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     end;
    end;
end;

num_cells_surround = ii_count;

end; % while (num_cells_surround < num_cells_surround_max)

if (num_cells_surround > num_cells_surround_max) 
width_surround = width_surround - 1;
end;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
      bPAC_NUCLEUS_time_mapped_t0_dummy(iii,:) = 0;      
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     end;
    end;
end;


%which_frame = length(eval(['time_CH',num2str(ii_NM)]));
%for kkk = 1:length(eval(['time_CH',num2str(ii_NM)]))

figure(110)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    imshow(mat2gray(M_NM_bPAC));
     if (do_plot_nuclei_number == 1)
     for idx = 1: num_nuclei_t0
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));         

    
ii_lower = 1;
%ii_lower = length(eval(['time_CH',num2str(1)]));

for kkk = ii_lower:length(eval(['time_CH',num2str(ii_NM)]))
    
    eval(['[val,index_frame]= min(abs(time_CH',num2str(ii_NM),'(kkk)-time_CH',num2str(1),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
      
M_CH1(:,:) =  M_CH1_total(:,:,which_frame);  

figure(1)
imshow(mat2gray(M_CH1));
xlim([y_coord_min y_coord_max]);
ylim([x_coord_min x_coord_max]);

figure(111)
%imshow(mat2gray(M_CH1));
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,which_frame_signal);']);
    imshow(mat2gray(M_NM));
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame_signal),mean_x_tot_time_mapped_t0(idx,which_frame_signal),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame_signal),mean_x_tot_time_mapped_t0(idx,which_frame_signal),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame_signal),mean_x_tot_time_mapped_t0(idx,1:which_frame_signal));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));             
                  
                  
figure(112)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    imshow(mat2gray(M_NM_bPAC));
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame_signal),mean_x_tot_time_mapped_t0(idx,which_frame_signal),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame_signal),mean_x_tot_time_mapped_t0(idx,which_frame_signal),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame_signal),mean_x_tot_time_mapped_t0(idx,1:which_frame_signal));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));             
                  
  
 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
%M_marker_threshold_TEST = 0*M_marker_threshold_TEST; 
 
M_CM_segmented = 0*M_CM_segmented;
M_NM_segmented = 0*M_NM_segmented;

 for jjj = 1:length(index_group)
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame_signal);
       if (idx_map > 0)
           val_merge = .3;
        M_CM_segmented(eval(['Cell_cytosol_FILL_',num2str(which_frame_signal),'.PixelIdxList{idx_map}'])) = val_merge;
        
        %%if (which_nuclei_signal_type == 1) % regular
        %% M_NM_segmented(eval(['Cell_nucleus_FILL_',num2str(which_frame_signal),'.PixelIdxList{idx_map}'])) = val_merge;
        if (which_nuclei_signal_type == 1) % shrink
         M_NM_segmented(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame_signal),'.PixelIdxList{idx_map}'])) = val_merge;
        elseif (which_nuclei_signal_type == 2) % intersect
         M_NM_segmented(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame_signal),'.PixelIdxList{idx_map}'])) = val_merge;
        elseif (which_nuclei_signal_type == 3) % circle
         M_NM_segmented(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame_signal),'.PixelIdxList{idx_map}'])) = val_merge;
        end;
            
       end;
 end;
 
 

h2 = figure(2);
%subplot(3,3,[1  4  7 ]);

    M_NM(:,:) =  eval(['M_CH',num2str(ii_NM),'_total(:,:,which_frame_signal);']);  
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,2) = M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,1) = M_CM_segmented(:,:);
    %image_RGB(:,:,3) = M_NM_segmented(:,:);
    imshow(image_RGB);


    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

F = getframe(h2);
    IM2 = frame2im(F);
        
    
%h3 = figure(3);
%imshow(mat2gray(M_CH1));
%subplot(3,3,[2 5 8]);

    
    M_CH1(:,:) =  M_CH1_total(:,:,which_frame_signal);  
    
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,2) = M_CH1(:,:)/max(max(M_CH1));
    image_RGB(:,:,1) = M_CM_segmented(:,:);
    image_RGB(:,:,3) = M_NM_segmented(:,:);
    imshow(image_RGB);


   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame_signal);
       
             line(mean_y_tot_time_mapped_t0(idx,1:which_frame_signal),mean_x_tot_time_mapped_t0(idx,1:which_frame_signal));
       
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame_signal),mean_x_tot_time_mapped_t0(idx,which_frame_signal),strcat('X:',num2str(idx)));             
               set(tt,'Color','m');
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame_signal),mean_x_tot_time_mapped_t0(idx,which_frame_signal),strcat(num2str(idx)));            
               set(tt,'Color','m');
              end
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
    
    
    F = getframe(h2);
    IM3 = frame2im(F);
    
 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %  BEGIN: plot nuclear signal and ratio signal
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    idx = which_nucleus;
    if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
        str_bPAC = ' (bPAC)';
    else
        str_bPAC = ' (non-bPAC)';
    end;

    %figure_cell_signals = 1001;
    %h4 = figure(figure_cell_signals);
    subplot(3,1,1);
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy);
         min_sig = min(sig_dummy);
     plot([ eval(['time_CH',num2str(ii_NM),'(which_frame_signal)/scale_factor_time']) eval(['time_CH',num2str(ii_NM),'(which_frame_signal)/scale_factor_time']) ], [0 1.1*max((sig_dummy)/min_sig)],'k--');
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig,s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+1.1*(max(sig_dummy/min_sig)-1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;     
        title(strcat('(nuclear Erk signal)/min(nuclear Erk signal) (',Erk_str,')'));       
    
        
        subplot(3,1,2);
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy);
         min_sig = min(sig_dummy);
     plot([ eval(['time_CH',num2str(ii_NM),'(which_frame_signal)/scale_factor_time']) eval(['time_CH',num2str(ii_NM),'(which_frame_signal)/scale_factor_time']) ], [0 1.1*max((sig_dummy)/min_sig)],'k--');
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
     
     
        title(strcat('(nuclear Erk signal)/(cytosolic Erk signal) (',Erk_str,')'));       
     
    subplot(3,1,3);
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
    hold off;
        
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %  END: plot nuclear signal and ratio signal
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
     F = getframe(h2);
    IM4 = frame2im(F);
   
  %IM5 = cat(1,cat(1,IM3, IM2),cat(1, IM4 ,IM4));   
  IM5 = [IM3 IM2;IM4 0*IM4];   
  IM5 = [IM3 IM2 IM4]; 
 figure(5) 
 imshow(IM5, 'InitialMagnification','fit');
 %imshow(IM5);
 title(strcat('which frame:',num2str(which_frame_signal),', total frames:',num2str(numFr_NM),', bPAC (red), non-bPAC (green)'));
truesize(5)
    
    pause;
    close(2);
    
end;  % end of  'for kkk = 1:length(which_frames)


num_max_plots = 3;     
ii_plot_count = 0;
ii_figure_count = 1;     
for iii = 1:length(index_group)
    idx = index_group(iii);
    
    if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
        str_bPAC = ' (bPAC)';
    else
        str_bPAC = ' (non-bPAC)';
    end;
        
     figure(200+ii_figure_count)
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
    subplot(num_max_plots+1,1,ii_plot_count+1)
    if (do_just_nuclear_signal == 1)
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig,s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     
      if (num_bPAC_pulses == 1)
      text(.6*max(time_Erk)/scale_factor_time, .9*(1+1.1*(max(sig_dummy/min_sig)-1)),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      elseif (num_bPAC_pulses == 2)
      text(.6*max(time_Erk)/scale_factor_time, .9*(1+1.1*(max(sig_dummy/min_sig)-1)),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      end;
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+1.1*(max(sig_dummy/min_sig)-1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
           if (num_bPAC_pulses+1 == 1)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)));
           elseif (num_bPAC_pulses+1 == 2)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse'));
           elseif (num_bPAC_pulses+1 == 3)
            %lgnd = legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse 1'), strcat('signal during bPAC pulse 2'));
           end;
            %set(lgnd,'color','none');
     
      if (ii_plot_count+1 == 1)
        title(strcat('(nuclear Erk signal)/min(nuclear Erk signal) (',Erk_str,')'));       
      end;
            
      %if (num_bPAC_pulses == 1)      
      % title(strcat('Nucleus-',num2str(idx),':Erk signal (',Erk_str,'), passed pulse test =',num2str(bPAC_pulse_cell(idx,1))));
      %elseif (num_bPAC_pulses == 2)      
      % title(strcat('Nucleus-',num2str(idx),':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']'));
      %elseif (num_bPAC_pulses == 3)      
      % title(strcat('Nucleus-',num2str(idx),':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),';',num2str(bPAC_pulse_cell(idx,3)),']'));
      %end;
      
    elseif (do_just_nuclear_signal == 0)
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
      
      if (num_bPAC_pulses == 1)
      text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      elseif (num_bPAC_pulses == 2)
      text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      end;
      
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
     
     
      if (ii_plot_count+1 == 1)
        title(strcat('(nuclear Erk signal)/(cytosolic Erk signal) (',Erk_str,')'));       
      end;
     
     
    end;  %     if (do_just_nuclear_signal == 1)


     ii_plot_count = ii_plot_count+1;

        if (iii == length(index_group))
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          ii_figure_count = ii_figure_count+1;
          ii_plot_count = 0;
        end;

end; % for iii = 1:length(index_map)








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Make a powerpoint of some of the plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do_PPT = 0;  % 0 - no, 1 - yes
if (do_PPT ==1)&(done_cells_tracked_ppt == 0)
 % save the figures to a powerpoint slide


  fig111 = figure(111)
  figure(1111)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
   s_combine = 'cell trajectories';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   saveppt2(strcat(str_movie_processed,'\',str_movie,'-cells_tracked.ppt'),'figure',[fig111 fig1111 fig111 fig1111], 'halign','center','title', s_combine);

%    movefile('cells_tracked.ppt',strcat(str_movie_processed,'\',str_movie,'-cells_tracked.ppt'));
    done_cells_tracked_ppt = 1;  % have made the ppt file
    
end; % if (do_PPT ==1)
