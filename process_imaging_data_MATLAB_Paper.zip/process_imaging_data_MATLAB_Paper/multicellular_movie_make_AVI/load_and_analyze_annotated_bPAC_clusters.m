close all;
%clear all;

do_time_representation = 1; % 0-seconds, 1-minutes, 2-hours
if (do_time_representation == 0) % seconds
    scale_factor_time = 1;  
    str_time_representation = 'time (seconds)';
elseif (do_time_representation == 1) % minutes   
    scale_factor_time = 60;  
    str_time_representation = 'time (minutes)';
elseif (do_time_representation == 2) % minutes   
    scale_factor_time = 3600;  
    str_time_representation = 'time (hours)';
end;

str_processing = pwd;  % get processing directory
addpath(str_processing);  % for reference m files

%  PPT checks
done_cells_tracked_ppt = 0;  % 0-not yet made ppt file, 1-made ppt file

set_globals;


if (length(which_movie) == 0)  % used for individual calls to this script
which_movie = input('which movie number do you want, e.g. 1 ,2, etc. ? ');    
end;
get_movie_info_for_processing  % which_movie must already be set


%str_movie_processed = strcat(str_movie,'_processed')
str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
str_movie_processed_figures = strcat(str_movie_processed,'\figures-',str_movie);
mkdir(str_movie_processed_figures);

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);


%  num_nuclei_signal_types = 3; % 1- shrink, 2- intersect (over time), 3 -circles  

which_nuclei_signal_type = input('which nuclei signal? (1- shrink, 2- intersect (over time), 3 -circles)');

% load in cellular signals file for processing
if (which_nuclei_signal_type == 1) % shrink
file_signals = strcat(str_movie_processed,'\cellular_signals');
elseif (which_nuclei_signal_type == 2) % intersect
file_signals = strcat(str_movie_processed,'\cellular_signals_intersect');
elseif (which_nuclei_signal_type == 3) % circle
file_signals = strcat(str_movie_processed,'\cellular_signals_circle');
end
load(file_signals);

% load in processed data from nuclear tracking code
file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
load(file_track);


do_load_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_nucleus_structs ==1)&(exist('Cell_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
load(file_nucleus_tot_FINAL);
end;

do_load_shrink_nucleus_structs = 1;  % 1 - yes, 0 - no
if (do_load_shrink_nucleus_structs ==1)&(exist('Cell_shrink_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_shrink_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_shrink_nucleus_structs_tot_FINAL');
load(file_shrink_nucleus_tot_FINAL);
end;
if (exist('Cell_intersect_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_intersect_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_intersect_nucleus_structs_tot_FINAL');
load(file_intersect_nucleus_tot_FINAL);
end;
if (exist('Cell_circle_nucleus_FILL_6')==0)
% load in the thresholded nuclei information from all frames 
file_circle_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_circle_nucleus_structs_tot_FINAL');
load(file_circle_nucleus_tot_FINAL);
end;


do_load_cytosol_structs = 1;  % 1 - yes, 0 - no
if (do_load_cytosol_structs ==1)&(exist('Cell_cytosol_FILL_6')==0)
% load in the thresholded cytosol information from all frames 
file_cytosol_tot_FINAL = strcat(str_movie_processed,'\Cell_cytosol_structs_tot_FINAL');
load(file_cytosol_tot_FINAL);
end;




do_load_movie_arrays = 1;  % 1 - yes, 0 - no
if (do_load_movie_arrays == 1)&(exist('M_CH1_total')==0)
% load in processed data from nuclear tracking code
file_movie_arrays = strcat(str_movie_processed,'\movie_arrays'); 
load(file_movie_arrays);  
end;


found_file_microscope = fileattrib(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'))

if (found_file_microscope == 1)  % movie has input_info.mat file
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% variables in file: bPAC_amp  bPAC_ledvals  bPAC_max  measurement_order measurement_skipframes  seconds_per_frame    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
  load(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'));
  time_bPAC = 0:seconds_per_frame:seconds_per_frame*(length(bPAC_ledvals)-1);
  
else
    
    if which_movie == 103
        seconds_per_frame = 60;
    end;
  time_bPAC = 0:seconds_per_frame:seconds_per_frame*(length(bPAC_ledvals)-1);
    
end;  

%plot_all_nuclei_movements;  

%plot_localized_group_of_nuclei_over_time

%%%plot_specific_nucleus_and_signals(which_nucleus,M_DAPI_id_threshold,M_DAPI,M_FITC,M_CY3,box_coords);  % this has thresholding test to separare touching nuclei


 


 if bPAC_amp_max > 1
  bPAC_ledvals = bPAC_ledvals/bPAC_amp_max;
 end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate average nuclear signals (per pixel)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for kkk = 1:length(time_CH1)
    %which_frame = image_index_CH1(kkk);
     eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
     
    average_nuclear_CH1_tot_time(which_frame_signal) = 0;
for which_nucleus = 1:num_nuclei_time(which_frame)
 average_nuclear_CH1_tot_time(which_frame_signal) = average_nuclear_CH1_tot_time(which_frame_signal) + nuclear_CH1_tot_time(which_nucleus,kkk)*num_pixels_tot_NUCLEUS_time(which_nucleus,which_frame);
end;
 average_nuclear_CH1_tot_time(which_frame_signal) = average_nuclear_CH1_tot_time(which_frame_signal)/sum(num_pixels_tot_NUCLEUS_time(1:num_nuclei_time(which_frame),which_frame));
end;

if (length(signal_channels)>1)
for kkk = 1:length(time_CH2)
    %which_frame = image_index_CH2(kkk);
    eval(['[val,index_frame]= min(abs(time_CH',num2str(2),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
     
    average_nuclear_CH2_tot_time(which_frame_signal) = 0;
for which_nucleus = 1:num_nuclei_time(which_frame)
 average_nuclear_CH2_tot_time(which_frame_signal) = average_nuclear_CH2_tot_time(which_frame_signal) + nuclear_CH2_tot_time(which_nucleus,kkk)*num_pixels_tot_NUCLEUS_time(which_nucleus,which_frame);
end;
    average_nuclear_CH2_tot_time(which_frame_signal) = average_nuclear_CH2_tot_time(which_frame_signal)/sum(num_pixels_tot_NUCLEUS_time(1:num_nuclei_time(which_frame),which_frame));
end;
end

figure(2222)
subplot(2,1,1);
plot(time_CH1,average_nuclear_CH1_tot_time);
xlim([0 max(time_CH1)]);
title(strcat('Average Nuclear Signal per pixel MOVIE:',path_movie,')'));
ylabel(CH1_str);
xlabel('time (seconds)');
subplot(2,1,2);
if (length(signal_channels)>1)
plot(time_CH2,average_nuclear_CH2_tot_time);
xlim([0 max(time_CH2)]);
ylabel(CH2_str);
xlabel('time (seconds)');
end;

%figure(2223)
%subplot(2,1,1);
%plot(time_sequence_movie(2:length(time_sequence_movie)),1./dt_sequence_movie)
%xlim([0 max(time_sequence_movie)]);
%ylabel('sampling/bPAC impuls frequency (Hz)');
%xlabel('time (seconds)');


found_file_bPAC_mapped = fileattrib(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL.mat'))
if ( found_file_bPAC_mapped == 1 )
  load(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL'));
else
   do_mixed_bPAC_population_analysis = 1; % 1 - yes, 0 - no
   if (do_location_bPAC_nuclei == 1)&(do_mixed_bPAC_population_analysis==1)
    load(strcat(str_movie_processed,'\time_series_for_tracking_cells_bPAC'));
    load(strcat(str_movie_processed,'\Cell_nucleus_bPAC_structs_tot'));
    mixed_bPAC_population_analysis;
   end;
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Process ERK signals if present
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (marker_from_channel(ii_Erk_marker) > 0)

    
      % Setup Erk signal arrays
      eval(['nuclear_Erk_tot_time_mapped_t0 = nuclear_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0;']);
      eval(['nuclear_Erk_tot_time_mapped_t0_median = nuclear_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0_median;']);
      eval(['cytosolic_Erk_tot_time_mapped_t0 = cytosolic_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0;']);
      eval(['cytosolic_Erk_tot_time_mapped_t0_median = cytosolic_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0_median;']);
      eval(['time_Erk = time_CH',num2str(marker_from_channel(ii_Erk_marker))]); 
      eval(['Erk_str = CH',num2str(marker_from_channel(ii_Erk_marker)),'_str']); 

   % if bPAC cells has a different color Erk marker
   if (marker_from_channel(ii_Erk_bPAC_marker) > 0)
      eval(['Erk_bPAC_str = CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_str']); 
    for idx = 1:num_nuclei_t0
     if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)         
      eval(['nuclear_Erk_tot_time_mapped_t0(idx,:) = nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(idx,:);']);
      eval(['nuclear_Erk_tot_time_mapped_t0_median(idx,:) = nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0_median(idx,:);']);
      eval(['cytosolic_Erk_tot_time_mapped_t0(idx,:) = cytosolic_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(idx,:);']);
      eval(['cytosolic_Erk_tot_time_mapped_t0_median(idx,:) = cytosolic_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0_median(idx,:);']);
     end; 
    end;
   end;
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate mean Erks signals and plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for kkk = 1:length(time_Erk)
     eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_signal = kkk;
    
    average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) = 0;
    average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) = 0;
for which_nucleus = 1:num_nuclei_t0
 average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) = average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) + nuclear_Erk_tot_time_mapped_t0(which_nucleus,which_frame_signal)*num_pixels_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame);
 average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) = average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) + nuclear_Erk_tot_time_mapped_t0(which_nucleus,which_frame_signal)/...
                                                         cytosolic_Erk_tot_time_mapped_t0(which_nucleus,which_frame_signal);
end;
 average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal) = average_nuclear_Erk_tot_time_mapped_t0(which_frame_signal)/sum(num_pixels_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame));
 average_ratio_Erk_tot_time_mapped_t0(which_frame_signal) = average_ratio_Erk_tot_time_mapped_t0(which_frame_signal)/num_nuclei_t0;
end;
    

make_annotated_bPAC_clusters

%  analyze pulses when bPAC is on
%analyze_Erk_cellular_response_to_bPAC

%  analyze pulses when bPAC is on
%  spatial analyze of cells and their signals within a bPAC cluster and
%  non-bPAC cells outside the cluster
 if (ii_NM~=ii_NM_bPAC)  % do only if there is a mix of bPAC and non-bPAC cells
 s_sig = ['b' 'g' 'r'];    
  if (do_SIGMA == 1) % 1- do zero-shifted mean and standard deviation version, 0 - don't
    analyze_annotated_bPAC_clusters_SIGMA; 
  else
   run_full_range_ylim = 0
   analyze_annotated_bPAC_clusters; 
   if (do_full_range_ylim == 1)
   run_full_range_ylim = 1
   analyze_annotated_bPAC_clusters; 
   end;
   load(strcat(str_movie_processed,'\bPAC_statistics_arrays'));
   if exist(strcat(str_movie_processed,'\bPAC_statistics_arrays_ratio_overshoot_REVISE.mat'))
   load(strcat(str_movie_processed,'\bPAC_statistics_arrays_ratio_overshoot_REVISE'));
   end;
   make_bPAC_statistics_plots_annotated_bPAC_clusters  
  end;
 end;


 
 
done_analyze_annotated_bPAC_cluster = 1
%pause
 
end;  % if (marker_from_channel(ii_Erk_marker) > 0)
