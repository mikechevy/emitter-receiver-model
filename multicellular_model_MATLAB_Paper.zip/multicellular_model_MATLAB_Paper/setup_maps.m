

cd map_setup;

if (num_dim>1)
  if (do_read_file==1)
   if (m_ydimp>min_rdimp)|(m_ydimp>min_rdimp)|(m_zdimp>min_rdimp) % no dendrite shaft
    map_on = map_oj;
    map_in = map_ij;
   else
    setup_map_N;
   end;
  elseif (do_read_file==0)
   if (m_ydimp>min_rdimp)|(m_ydimp>min_rdimp)|(m_zdimp>min_rdimp) % no dendrite shaft
    setup_map_JEH_d;
    map_on = map_oj;
    map_in = map_ij;
   else
    setup_map_JEH;
    setup_map_N;
   end;
  end;
else
setup_map_N1Dz;
setup_map_JEH1Dz;
end;

if ((m_finorinf~=1)&(num_dim>2))
setup_map_zero_JE;
end;


cd ../

