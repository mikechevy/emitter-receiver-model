do_NM = 1;  % 1 - yes, 0 - no
do_S1 = 1;  % 1 - yes, 0 - no
do_S2 = 0;  % 1 - yes, 0 - no
do_edge = 0;  % 1 - yes, 0 - no
do_NM_bPAC = 1;  % 1 - yes, 0 - no
 if  do_location_bPAC_nuclei == 0;
   do_NM_bPAC = 0;
 end;

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 
do_all_CELL = 1;  % 1 - yes, 0 -  no
 
   x_coord_min =  1;
   x_coord_max =  xLength;
   y_coord_min =  1;
   y_coord_max =  yLength;


M_marker_threshold = int16(zeros(xLength,yLength));
M_marker_threshold_CELL = int16(zeros(xLength,yLength));


ii_lower = 1;
%ii_lower = numFr_NM;

for kkk = ii_lower:numFr_NM
  which_frame = kkk;
    
  

  if (do_all_CELL == 0)|(do_NM == 1)|(do_S1 == 1)|(do_S2 == 1)
    file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
    load(file_nucleus); 
    M_marker_threshold = int16(M_NM_threshold_FILL);
  end;
  
  
  if (do_all_CELL == 1)
      M_marker_threshold = 0*M_marker_threshold;
       num_nuclei_dummy = eval(['Cell_nucleus_FILL_',num2str(which_frame),'.NumObjects']);
      %for idx = 1:num_nuclei_dummy       
      %    M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}'])) + 1;
      %end;
      for idx = 1:num_nuclei_t0       
            idx_map   = index_map_tot_time_mapped_t0(idx,which_frame);      
          if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
          %M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 2;
          M_marker_threshold(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 2;
          else
          %M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
          M_marker_threshold(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
          end;
      end;
  end;
 
  
  M_marker_threshold_CELL = 0*M_marker_threshold_CELL;
  
%      %which_frame_CELL = which_frame;
%       for idx = 1:length(index_ref_min_dist_time(:,1))
% 
%           which_frame_CELL = frame_ref_min_dist_time(idx,which_frame);
%           idx_map = index_ref_min_dist_time(idx,which_frame);
%           
%        %M_marker_threshold_CELL(Cell_FILL_dummy.PixelIdxList{idx}) = 1;
%        M_marker_threshold_CELL(eval(['Cell_nucleus_FILL_',num2str(which_frame_CELL),'.PixelIdxList{idx_map}'])) = 1;
%           
%       end;



figure(1)
imshow(mat2gray(M_marker_threshold+M_marker_threshold_CELL));
%imagesc(M_marker_threshold_CELL);
title(strcat('Segmented nuclei: which frame:',num2str(which_frame),', total frames:',num2str(numFr_NM)));
   hold on;                 
    for idx = 1:num_nuclei_t0
       
       %idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
             
            if (do_plot_nuclei_number == 1)
             tt =  text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','b');
            end; % if (do_plot_nuclei_number == 1)
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

if (do_NM == 1)    
figure(2)
if (do_edge == 0)
imagesc(M_NM);
elseif (do_edge == 1)
imagesc(edge(M_NM,'prewitt'));
end;
title(strcat('Nuclear Marker (',eval(['CH',num2str(ii_NM),'_str']),'): which frame:',num2str(which_frame),', total frames:',num2str(numFr_NM)));

    for idx = 1:num_nuclei_t0
       
       %idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
            
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
end; % END OF: if (do_DAPI == 1)    
    
if (do_S1 == 1)    
figure(3)
if (do_edge == 0)
imagesc(M_S1);
elseif (do_edge == 1)
imagesc(edge(M_S1,'prewitt'));
end;
title(strcat('S1(',CH1_str,'): which frame:',num2str(which_frame),', total frames:',num2str(numFr_NM)));

    for idx = 1:num_nuclei_t0
       
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;             
            end;
            
            if (do_plot_nuclei_number == 1)
              text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
            end;
            
            
            
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
end; % END OF: if (do_DAPI == 1)    
    
if (do_S2 == 1)    
figure(4)
if (do_edge == 0)
imagesc(M_S1);
elseif (do_edge == 1)
imagesc(edge(M_S2,'prewitt'));
end;
title(strcat('S2(',CH2_str,'): which_frame:',num2str(which_frame),', total frames:',num2str(numFr_NM)));

    for idx = 1:num_nuclei_t0
       
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;             
            end;
            if (do_plot_nuclei_number == 1)
              text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
            end;        
            
            
            
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
end; % END OF: if (do_CY3 == 1)    


if (do_NM_bPAC == 1)    
[val,which_frame_map] = eval(['min(abs(time_CH',num2str(ii_NM_bPAC),'-time_CH',num2str(ii_NM),'(which_frame)));']);
M_NM_bPAC = eval(['M_CH',num2str(ii_NM_bPAC),'_total(:,:,which_frame_map);']);    
figure(5)
if (do_edge == 0)
imagesc(M_NM_bPAC);
elseif (do_edge == 1)
imagesc(edge(M_NM_bPAC,'prewitt'));
end;
title(strcat('NM_bPAC(',eval(['CH',num2str(ii_NM_bPAC),'_str']),'): which_frame:',num2str(which_frame),', total frames:',num2str(numFr_NM)));

    for idx = 1:num_nuclei_t0
       
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
       
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;             
            end;
            if (do_plot_nuclei_number == 1)
              text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
            end;        
            
            
            
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

end;


    pause(.2)
        
end;  % end of  'for kkk = 1:length(which_frames)



             
             
