
                 x_coord_min = x_coord_min_local;
                 x_coord_max = x_coord_max_local;
                 y_coord_min = y_coord_min_local;
                 y_coord_max = y_coord_max_local;
                 
                 %x_coord_min = 1;
                 %x_coord_max = xLength;
                 %y_coord_min = 1;
                 %y_coord_max = yLength;

%index_group = [];               
ii_count = 0;
index_group = [];
for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
    end;
end;
                 

max_max_max_FITC = max(max(max(M_FITC_total(x_coord_min:x_coord_max,y_coord_min:y_coord_max,:))));
min_min_min_FITC = min(min(min(M_FITC_total(x_coord_min:x_coord_max,y_coord_min:y_coord_max,:))));

%for kkk = 1:length(which_frames)
for kkk = 1:1
  which_frame = which_frames(kkk)
  
  
 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
M_marker_threshold_TEST = 0*M_marker_threshold;
M_marker_threshold_edge = 0*M_marker_threshold;
M_FITC = M_FITC_total(:,:,which_frame);
M_FITC(x_coord_min,y_coord_min) =  max_max_max_FITC;
M_FITC(x_coord_max,y_coord_max) =  min_min_min_FITC;

M_FITC = min(.5*max(max(M_FITC)),M_FITC);
%for jjjj = 1:length(which_frames)
%M_FITC = max(M_FITC,M_FITC_total(:,:,which_frames(jjjj)));
%M_FITC = M_FITC + M_FITC_total(:,:,which_frames(jjjj))/length(which_frames);
%end;

 for jjj = 1:length(index_group);
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_DAPI_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end;

M_marker_threshold_edge(x_coord_min:x_coord_max,y_coord_min:y_coord_max) =  edge(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'prewitt');
 

figure(22)
%imagesc(M_marker_threshold_TEST)
%imagesc(max(int16(M_FITC),max(max(int16(M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max))))*int16(M_marker_threshold_TEST)));
imagesc(max(int16(M_FITC),int16(1.2*max_max_max_FITC)*int16(M_marker_threshold_edge)));
%imagesc(int16(1-M_marker_threshold_edge));
%imagesc(int16(M_FITC));
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr),', movie: ',str_movie));
   hold on;                 
    for jj = 1:length(index_group);
       idx = index_group(jj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             %set(ll,'Color','y');
             %xx = text(mean_y_tot_time_mapped_t0(idx,1),mean_x_tot_time_mapped_t0(idx,1),'x');                  
             %set(xx,'Color','w');
       
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('cell-nucleus',num2str(idx)));                  
              %set(tt,'Color','y');
            end;       
        
            if (bursting_nuclear_Ca_cells_per_sample_frame(idx) == 1)
                 hold on;
                 x_coord_min_dummy = box_coords(idx,1);
                 x_coord_max_dummy = box_coords(idx,2);
                 y_coord_min_dummy = box_coords(idx,3);
                 y_coord_max_dummy = box_coords(idx,4);
                 rectangle('Position', [y_coord_min_dummy,x_coord_min_dummy,...
                   y_coord_max_dummy-y_coord_min_dummy,x_coord_max_dummy-x_coord_min_dummy],...
                         'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                         'EdgeColor', 'w');
                 hold off;
            end;
            
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

    for jj = 1:size_xcorr_group(ii)
    
                 hold on;
                 x_coord_min_dummy = box_coords(xcorr_group(ii,jj),1);
                 x_coord_max_dummy = box_coords(xcorr_group(ii,jj),2);
                 y_coord_min_dummy = box_coords(xcorr_group(ii,jj),3);
                 y_coord_max_dummy = box_coords(xcorr_group(ii,jj),4);
                                  
                % have to swith the x with the y coordinates for this
                 rectangle('Position', [y_coord_min_dummy,x_coord_min_dummy,...
                   y_coord_max_dummy-y_coord_min_dummy,x_coord_max_dummy-x_coord_min_dummy],...
                         'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                         'EdgeColor', 'm');
                  hold off;
    end;   
    
    pause
    
end;  % end of  'for kkk = 1:length(which_frames)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plot the signals of the cells within the box
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    num_plots_max = 3;
    ii_figure_count = 1;
    ii_plot_count = 0;
    for jj = 1:length(index_group);
       idx = index_group(jj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);

       
       
     figure(1000+ii_figure_count)  
     subplot(num_plots_max,2,ii_plot_count+1) 
      hold on;
      plot(time_sequence_movie,nuclear_Ca_signal_adjusted(idx,:),'g--');
      hold off;
      ylabel(strcat('cell-',num2str(idx)));
      ylim([0 3*threshold_burst_Ca]);
      xlim([time_sequence_movie(1) time_sequence_movie(length(time_sequence_movie))]);
      
     subplot(num_plots_max,2,ii_plot_count+2) 
      plot(time_sequence_movie(start_frame:end_frame),nuclear_Ca_signal_adjusted(idx,start_frame:end_frame),'g--');
      ylabel(strcat('cell-',num2str(idx)));
      ylim([0 3*threshold_burst_Ca]);
      xlim([time_sequence_movie(start_frame) time_sequence_movie(end_frame)]);
       

     figure(4000+ii_figure_count)  
     subplot(num_plots_max,2,ii_plot_count+1) 
      hold on;
      plot(time_sequence_movie,nuclear_Ca_signal(idx,:),'g--');
      plot(time_sequence_movie,nuclear_Ca_signal_floor(idx,:),'r--');
      hold off;
      ylabel(strcat('cell-',num2str(idx)));
      ylim([min(nuclear_Ca_signal_floor(idx,start_frame:end_frame)) min(nuclear_Ca_signal_floor(idx,start_frame:end_frame))+4*threshold_burst_Ca]);
      xlim([time_sequence_movie(1) time_sequence_movie(length(time_sequence_movie))]);
      
     subplot(num_plots_max,2,ii_plot_count+2) 
      hold on;
      plot(time_sequence_movie(start_frame:end_frame),nuclear_Ca_signal(idx,start_frame:end_frame),'g--');
      plot(time_sequence_movie(start_frame:end_frame),nuclear_Ca_signal_floor(idx,start_frame:end_frame),'r--');
      hold off
      ylabel(strcat('cell-',num2str(idx)));
      ylim([min(nuclear_Ca_signal_floor(idx,start_frame:end_frame)) min(nuclear_Ca_signal_floor(idx,start_frame:end_frame))+4*threshold_burst_Ca]);
      xlim([time_sequence_movie(start_frame) time_sequence_movie(end_frame)]);
      
     
     
     ii_plot_count = ii_plot_count+2;
     if (ii_plot_count == 2*num_plots_max)
         ii_figure_count = ii_figure_count+1;
         ii_plot_count = 0;
     end;
         
    end    


     %save('NSF_window_test','index_group','start_frame','end_frame','nuclear_Ca_signal','nuclear_Ca_signal_adjusted','nuclear_Ca_signal_floor','time_sequence_movie','dt_sequence_movie');

