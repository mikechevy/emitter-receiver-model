function y_prime = ode_fun_path(t,y)

global source_u;
global passed_constants;


global A_er;
global V_er;
global V_nuc;
global causal_or_independent;
global ss_or_transient;
global do_full;


y_prime = fun_pathway(y);
