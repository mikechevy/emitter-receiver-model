%  spatial analyze of cells and their signals within a bPAC cluster and
%  non-bPAC cells outside the cluster

length_max_bPAC = 120;
[bPAC_groups,size_bPAC_groups] = find_bPAC_clusters([mean_x_tot_SHRINK_time_mapped_t0(:,1) mean_y_tot_SHRINK_time_mapped_t0(:,1)],num_nuclei_t0,length_max_bPAC,ii_physical_distance,bPAC_NUCLEUS_time_mapped_t0(:,1));


M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_Erk = zeros(xLength,yLength);
M_BF = zeros(xLength,yLength);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: Located bPAC pulses in time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
      
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);

          
          diff_bPAC_signal = diff(bPAC_ledvals);
          
%  determine pulse locations here, bPAC
             num_pulses = 0;
             num_bPAC_pulses = 0;
             index_bPAC_pulse_start = [];
             index_bPAC_pulse_stop = [];
     for ii = 1:length(diff_bPAC_signal)
         
         if (diff_bPAC_signal(ii) > 0)
             index_bPAC_pulse_start(num_bPAC_pulses+1) = ii+1; % top of pulse (rise)
             num_bPAC_pulses = num_bPAC_pulses + 1;
         elseif (diff_bPAC_signal(ii) < 0)
             index_bPAC_pulse_stop(num_bPAC_pulses) = ii; % top of pulse (decline)
         end;
             
     end;
            if length(index_bPAC_pulse_stop) < length(index_bPAC_pulse_start)
                index_bPAC_pulse_stop(num_bPAC_pulses) = length(time_bPAC); 
            end;

%  determine indexes of time_Erk that are within the bPAC pulse times
             index_bPAC_pulse_start_Erk = [];
             index_bPAC_pulse_stop_Erk = [];
     for ii = 1:num_bPAC_pulses
  
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_start(ii))-time_Erk))
         % if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_start(ii)) )
         %  index_bPAC_pulse_start_Erk(ii) =  index_dummy+1;         
         % else
         %  index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         % end;
          index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         
          
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_stop(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_stop(ii)) )
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy;         
          %else
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy-1;          
          %end;
          index_bPAC_pulse_stop_Erk(ii) =  min(index_dummy+1,length(time_Erk));   % captures full experimental duration of pulse       
          
          
     end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END: Located bPAC pulses in time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%do_median_or_mean_signal = 1; % % 0-mean, 1-median



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calculate_averaged signtures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mkdir(strcat(str_movie_processed_figures,'\annotated_bPAC_clusters'));
cd(strcat(str_movie_processed_figures,'\annotated_bPAC_clusters'));

     if (run_full_range_ylim == 0)
      delete(strcat('annotated_bPAC_cluster_bPAC_signals-',str_movie,'.ppt'));
      delete(strcat('annotated_bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'));    
     elseif (run_full_range_ylim == 1)
      delete(strcat('FR_annotated_bPAC_cluster_bPAC_signals-',str_movie,'.ppt'));
      delete(strcat('FR_annotated_bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'));    
     end;
     
     delete(strcat('annotated_average_signals_bPAC_cluster-',str_movie,'.ppt'));
     
     if (num_plot_single_pulse == 1)
     delete(strcat('annotated_average_signals_bPAC_cluster-','_sp_1-',str_movie,'.ppt'));
     elseif (num_plot_single_pulse == 2)
     delete(strcat('annotated_average_signals_bPAC_cluster-','_sp_1_-',str_movie,'.ppt'));
     delete(strcat('annotated_average_signals_bPAC_cluster-','_sp_2_-',str_movie,'.ppt'));
     end;
     

kkk = 1;
which_frame = kkk;

for jjj = 1:length(size_bPAC_clusters)     
figure(110+jjj)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
     if (do_BF_channel ==0)    
        index_frame = 1;
        eval(['M_Erk(:,:) = M_CH',num2str(marker_from_channel(ii_Erk_marker)),'_total(:,:,index_frame);']);
     elseif (do_BF_channel ==1)    
       eval(['[val,index_frame_BF]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_BF),'));']);    
        eval(['M_BF(:,:) = M_CH',num2str(ii_BF),'_total(:,:,index_frame_BF);']);
     end;
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %imshow(mat2gray(M_NM));
    %%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
     if (do_BF_channel ==0)    
      image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
     elseif (do_BF_channel ==1)    
      image_RGB(:,:,2) = scale_BF_channel*M_BF(:,:)/max(max(M_BF));
     end;
    image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    
    title(strcat(str_movie,', annotated bPAC cluster:',num2str(jjj)));
      for iii = 1:size_bPAC_clusters(jjj)
         idx = bPAC_clusters(jjj,iii);   
         which_frame = kkk;
          if (bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));           
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
          end;
         set(tt,'Color','w');
      end;
      for iii = 1:size_non_bPAC_clusters(jjj)
         idx = non_bPAC_clusters(jjj,iii);   
         tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
         if (min(abs(idx-non_bPAC_clusters_inner))==0)
          set(tt,'Color','y');
         else
          set(tt,'Color','m');
         end;
      end;
      
   set(gcf,'inverthardcopy','off')   
     if (do_BF_channel ==0)    
      print('-depsc',strcat('map-annotated_cluster_',num2str(jjj),'-',str_movie,'.eps'));
     elseif (do_BF_channel ==1)    
      print('-depsc',strcat('map-annotated_cluster_BF_',num2str(jjj),'-',str_movie,'.eps'));
     end;
      
end;

     
num_max_plots = 3;
ii_figure_count = 1;
ii_figure_count_tot = 1;
     
for jjj = 1:length(size_bPAC_clusters)     
    
    
       
        ii_plot_count = 0; 
    
        sig_dummy_bPAC = [];
        sig_dummy_bPAC_inner = [];
        sig_dummy_bPAC_outer = [];
        sig_dummy_non_bPAC = 0;
        
 % bPAC
 for iii = 1:size_bPAC_clusters(jjj)
       idx = bPAC_clusters(jjj,iii);   
    
        str_bPAC = ' (bPAC)';
       
  %if (max(bPAC_pulse_cell(idx,:)) == 1)
    
        
    figure(200+ii_figure_count)
    
    subplot(num_max_plots+1,1,ii_plot_count+1)     
        if (ii_plot_count+1==1)
         title(strcat('bPAC cluster:',num2str(jjj),', bPAC cell signals'));
        end;
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         %sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
         
         if (iii == 1)
          sig_dummy_bPAC =  sig_dummy;
         else
          sig_dummy_bPAC = sig_dummy_bPAC + sig_dummy;
         end;
         
         
          if (bPAC_clusters_location(jjj,iii) == 1)
           if (length(sig_dummy_bPAC_outer) == 0)
            sig_dummy_bPAC_outer =  sig_dummy;
           else
            sig_dummy_bPAC_outer = sig_dummy_bPAC_outer + sig_dummy;
           end;
          else
           if (length(sig_dummy_bPAC_inner) == 0)
            sig_dummy_bPAC_inner =  sig_dummy;              
           else
            sig_dummy_bPAC_inner = sig_dummy_bPAC_inner + sig_dummy;              
           end;
          end;
         
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;

     if (bPAC_clusters_location(jjj,iii) == 1)         
     ylabel([strcat('nuc:',num2str(idx),'*'), 10, str_bPAC]);
     else
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     end;
      
      %if (num_bPAC_pulses == 1)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      %elseif (num_bPAC_pulses == 2)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      %end;
    
   if (run_full_range_ylim == 0)
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
   elseif (run_full_range_ylim == 1)
    max_dummy = max_dummy_array(jjj);
    min_dummy = min_dummy_array(jjj);       
    ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
   end;
    
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
    
     


        
     ii_plot_count = ii_plot_count+1;
        if (iii == size_bPAC_clusters(jjj))
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('non-bPAC');
          xlabel(str_time_representation);
           if (run_full_range_ylim == 0)
            print('-depsc',strcat('annotated_cluster_',num2str(jjj),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));          
           elseif (run_full_range_ylim == 1)
            print('-depsc',strcat('FR_annotated_cluster_',num2str(jjj),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));          
           end;
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
           if (run_full_range_ylim == 0)
            print('-depsc',strcat('annotated_cluster_',num2str(jjj),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
           elseif (run_full_range_ylim == 1)
            print('-depsc',strcat('FR_annotated_cluster_',num2str(jjj),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
           end;
          ii_figure_count = ii_figure_count+1;
          ii_figure_count_tot = ii_figure_count_tot+1;
          ii_plot_count = 0;
        end;
        
        
                if (iii == size_bPAC_clusters(jjj))|(ii_figure_count == 4)
                    do_PPT = 1;  % 0 - no, 1 - yes
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig201 = figure(201)
                       fig202 = figure(202)
                       fig203 = figure(203)
                       s_combine = 'bPAC cells around in a bPAC cluster';
   
                       if (run_full_range_ylim == 0)
                       saveppt2(strcat('annotated_bPAC_cluster_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig201 fig202 fig203], 'halign','center','title', s_combine);
                       elseif (run_full_range_ylim == 1)
                       saveppt2(strcat('FR_annotated_bPAC_cluster_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig201 fig202 fig203], 'halign','center','title', s_combine);
                       end
                      close 201;
                      close 202;
                      close 203;
                     
                      ii_figure_count = 1;
                      
                      end; % if (do_PPT ==1)
                end; % if (iii == size_bPAC_clusters(jjj))|(ii_figure_count == 4)
        
        
  %end;  
 end;

 
  signal_average_bPAC_cluster = sig_dummy_bPAC/size_bPAC_clusters(jjj);
  if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj)) 
  signal_average_bPAC_cluster_outer = sig_dummy_bPAC_outer/sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj)));
  signal_average_bPAC_cluster_inner = sig_dummy_bPAC_inner/(size_bPAC_clusters(jjj)-sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))));  
  end;

  
 
ii_plot_count = 0;
ii_figure_count = 1;
ii_figure_count_tot = 1;

sig_dummy_non_bPAC_inner = [];
sig_dummy_non_bPAC_outer = [];
 
 % non-bPAC
 for iii = 1:size_non_bPAC_clusters(jjj)
       idx = non_bPAC_clusters(jjj,iii);   
       
        str_bPAC = ' (non-bPAC)';
       
  %if (max(bPAC_pulse_cell(idx,:)) == 1)
    
    figure(300+ii_figure_count)
    
    subplot(num_max_plots+1,1,ii_plot_count+1)       
        if (ii_plot_count+1==1)
         title(strcat('bPAC cluster:',num2str(jjj),', non-bPAC cell signals'));
        end;
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
        if (iii == 1)
         sig_dummy_non_bPAC = sig_dummy;
        else
         sig_dummy_non_bPAC = sig_dummy_non_bPAC + sig_dummy;
        end;
        
        
          if (length(non_bPAC_clusters_outer > 0))  
           if (min(abs(idx-non_bPAC_clusters_outer(jjj,:)))==0)
             if length(sig_dummy_non_bPAC_outer) == 0
             sig_dummy_non_bPAC_outer = sig_dummy;                 
             else
             sig_dummy_non_bPAC_outer = sig_dummy_non_bPAC_outer + sig_dummy;
             end;
           end;
          end;
          if (length(non_bPAC_clusters_inner > 0))
           if(min(abs(idx-non_bPAC_clusters_inner(jjj,:)))==0)
             if length(sig_dummy_non_bPAC_inner) == 0
             sig_dummy_non_bPAC_inner = sig_dummy;                 
             else
             sig_dummy_non_bPAC_inner = sig_dummy_non_bPAC_inner + sig_dummy;
             end;
           end;
          end; 
        
         
         
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
      
      %if (num_bPAC_pulses == 1)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      %elseif (num_bPAC_pulses == 2)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      %end;
      
      
   if (run_full_range_ylim == 0)
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*max((max(sig_dummy)-min(sig_dummy)),.1)]);
   elseif (run_full_range_ylim == 1)
    max_dummy = max_dummy_array(jjj);
    min_dummy = min_dummy_array(jjj);           
     if  max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) < max(max_dummy+1.1*(min_dummy-max_dummy),0)
      ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) max(sig_dummy)+1.1*(min(sig_dummy)-(max(sig_dummy)) +(min_dummy+1.1*(max_dummy-min_dummy)-max(max_dummy+1.1*(min_dummy-max_dummy),0)))]);
     else
      ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
     end;
   end;
      
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
    

        
     ii_plot_count = ii_plot_count+1;
        if (iii == size_non_bPAC_clusters(jjj))
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('non-bPAC');
          xlabel(str_time_representation);
           if (run_full_range_ylim == 0)
            print('-depsc',strcat('annotated_cluster_',num2str(jjj),'-non_bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
           elseif (run_full_range_ylim == 1)
            print('-depsc',strcat('FR_annotated_cluster_',num2str(jjj),'-non_bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
           end;
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
           if (run_full_range_ylim == 0)
            print('-depsc',strcat('annotated_cluster_',num2str(jjj),'-non_bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
           elseif (run_full_range_ylim == 1)
            print('-depsc',strcat('FR_annotated_cluster_',num2str(jjj),'-non_bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));
           end;
          ii_figure_count = ii_figure_count+1;
          ii_figure_count_tot = ii_figure_count_tot+1;
          ii_plot_count = 0;
        end;
          
                if (iii == size_non_bPAC_clusters(jjj))|(ii_figure_count == 4)
                    do_PPT = 1;  % 0 - no, 1 - yes
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig301 = figure(301)
                       fig302 = figure(302)
                       fig303 = figure(303)
                       s_combine = 'non-bPAC cells around in a bPAC cluster';

                        if (run_full_range_ylim == 0)
                         saveppt2(strcat('annotated_bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig301 fig302 fig303], 'halign','center','title', s_combine);
                        elseif (run_full_range_ylim == 1)
                         saveppt2(strcat('FR_annotated_bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'),'figure',[fig110 fig301 fig302 fig303], 'halign','center','title', s_combine);
                        end;
                      close 301;
                      close 302;
                      close 303;
   
                      ii_figure_count = 1;                      
    
                      end; % if (do_PPT ==1)
                end; % if (iii == size_non_bPAC_clusters(jjj))|(ii_figure_count == 4)

  %end;  
 end;

  
      
  signal_average_non_bPAC_cluster = sig_dummy_non_bPAC/size_non_bPAC_clusters(jjj);
  
           if (length(non_bPAC_clusters_outer) > 0)
              signal_average_non_bPAC_cluster_outer = sig_dummy_non_bPAC_outer/length(non_bPAC_clusters_outer);
           end;
           if (length(non_bPAC_clusters_inner) > 0)&(length(non_bPAC_clusters_outer) > 0)
            if (do_average_non_bPAC_inner == 1) % divide by the number
             %signal_average_non_bPAC_cluster_inner = sig_dummy_non_bPAC_inner/length(non_bPAC_clusters_inner);   
             signal_average_non_bPAC_cluster_inner = sig_dummy_non_bPAC_inner/size_non_bPAC_clusters(jjj);   
            end;
           else
            signal_average_non_bPAC_cluster_inner = signal_average_non_bPAC_cluster;
           end;
 
 figure(jjj+500)
 subplot(3,1,1)
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster);                
 set(ss,'LineWidth',2);
  if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
   ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster_outer,'k');                
   set(ss,'LineWidth',2);
   ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster_inner,'r');
   set(ss,'LineWidth',2);
   legend('all bPAC cells','outer bPAC cells', 'inner bPAC cells');
  end;
 set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
      ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
 title(strcat(str_movie,', bPAC cluster:',num2str(jjj),',do_average_non_bPAC_inner =',num2str(do_average_non_bPAC_inner),',num adj. cells:',num2str(size_non_bPAC_clusters(jjj))));
 ylabel('bPAC');
 xlim([0 max(time_Erk)/scale_factor_time]);
  if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
      min_dummy = min([signal_average_bPAC_cluster signal_average_bPAC_cluster_outer signal_average_bPAC_cluster_inner]);
      max_dummy = max([signal_average_bPAC_cluster signal_average_bPAC_cluster_outer signal_average_bPAC_cluster_inner]);    
      ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
  else
   ylim([min(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster)]);
      min_dummy = min([signal_average_bPAC_cluster]);
      max_dummy = max([signal_average_bPAC_cluster]);    
      ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
  end;
  if (which_movie == 103)
      ylim([.7 1.8]);
  end;
 hold off;
 subplot(3,1,2);
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster);
 set(ss,'LineWidth',2);
                 if (length(non_bPAC_clusters_outer) > 0)
                      delta_signal_outer_shift = signal_average_non_bPAC_cluster(index_bPAC_pulse_start_Erk(1))-signal_average_non_bPAC_cluster_outer(index_bPAC_pulse_start_Erk(1));                
                      signal_average_non_bPAC_cluster_outer = signal_average_non_bPAC_cluster_outer + delta_signal_outer_shift;
                    ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_outer,'k');                     
                  end;
                 %if (length(non_bPAC_clusters_inner) > 0)
                 %   ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_inner,'r');
                 %end;  
% ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster*size_non_bPAC_clusters(jjj) ...
%                      -min(signal_average_non_bPAC_cluster*size_non_bPAC_clusters(jjj)) + max(max_dummy+1.1*(min_dummy-max_dummy),0),'r');
% set(ss,'LineWidth',2);

                 
                 
 set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
      ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_non_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
 ylabel('non-bPAC');
 xlim([0 max(time_Erk)/scale_factor_time]);
 if (length(non_bPAC_clusters_outer) > 0)
      min_dummy_non = min([signal_average_non_bPAC_cluster signal_average_non_bPAC_cluster_outer signal_average_non_bPAC_cluster_inner]);
      max_dummy_non = max([signal_average_non_bPAC_cluster signal_average_non_bPAC_cluster_outer signal_average_non_bPAC_cluster_inner]);  
        min_dummy = min(min_dummy, min_dummy_non);
        max_dummy = max(max_dummy, max_dummy_non);
      subplot(3,1,1)
        ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
      subplot(3,1,2)        
        ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
 else
      min_dummy_non = min([signal_average_non_bPAC_cluster]);
      max_dummy_non = max([signal_average_non_bPAC_cluster]);    
        min_dummy = min(min_dummy, min_dummy_non);
        max_dummy = max(max_dummy, max_dummy_non);
      subplot(3,1,1)
        ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
      subplot(3,1,2)        
        ylim([max(max_dummy+1.1*(min_dummy-max_dummy),0) min_dummy+1.1*(max_dummy-min_dummy)]);
 end;;
  if (which_movie == 103)
      ylim([.7 1.8]);
  end;
                  if (length(non_bPAC_clusters_outer) > 0)
                      legend('receiver cells adjacent to emitters','next ring of receiver cells')
                  end;   
 hold off;
 subplot(3,1,3)
 ylabel('bPAC');
 ss = plot(time_bPAC/scale_factor_time,bPAC_ledvals);
 set(ss,'LineWidth',2);
 xlim([0 max(time_Erk)/scale_factor_time]);
 ylim([0 1.1*max(bPAC_ledvals)]);

 hold off;
 
 
 %num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
%time_shift_plot_single_pulse = 30;
%time_begin_plot_single_pulse = 30;
%time_end_plot_single_pulse = 100;

  for ii_print = 1:1+num_plot_single_pulse
            

      if (ii_print > 1)
       subplot(3,1,1)
       xlim([time_begin_plot_single_pulse(ii_print-1) time_end_plot_single_pulse(ii_print-1)]);           
       subplot(3,1,2)
       xlim([time_begin_plot_single_pulse(ii_print-1) time_end_plot_single_pulse(ii_print-1)]);  
        if (num_cells_no_sig > 0)
            hold on;
               ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster*size_non_bPAC_clusters/(size_non_bPAC_clusters-num_cells_no_sig),'b--');
            hold off;
        end;
       subplot(3,1,3)
       xlim([time_begin_plot_single_pulse(ii_print-1) time_end_plot_single_pulse(ii_print-1)]);           
      end;
      
      if (ii_print > 1)
       print('-depsc',strcat('annotated_average_signals-cluster_',num2str(jjj),'_sp_',num2str(ii_print-1),'-',str_movie,'.eps'));
      else
       print('-depsc',strcat('annotated_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
      end;

                    do_PPT = 1;  % 0 - no, 1 - yes
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig501 = figure(500+jjj)
                       s_combine = 'average signals of bPAC and non-bPAC cells ';
   
                       
                     if (ii_print > 1)                         
                       saveppt2(strcat('annotated_average_signals_bPAC_cluster-','_sp_',num2str(ii_print-1),'-',str_movie,'.ppt'),'figure',[fig110 fig501], 'halign','center','title', s_combine);
                     else
                       saveppt2(strcat('annotated_average_signals_bPAC_cluster-',str_movie,'.ppt'),'figure',[fig110 fig501], 'halign','center','title', s_combine);
                     end;
                     
                      ii_figure_count = 1;
                      
                      end; % if (do_PPT ==1)
   
  end; % for ii_print = 1:1+num_plot_single_pulse
 
  min_dummy_array(jjj) = min_dummy;
  max_dummy_array(jjj) = max_dummy;
  
end; % for jjj = 1:length(size_bPAC_clusters)     
  
cd(str_processing);