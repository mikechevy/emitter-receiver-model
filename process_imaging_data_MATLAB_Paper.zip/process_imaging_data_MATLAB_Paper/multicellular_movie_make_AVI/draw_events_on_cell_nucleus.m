
 
                fig99 = figure(99);                
                imagesc(imgSum);%, [min(min(imgSum')) max(max(imgSum'))]);
           
for ii = 1:ii_count

                 y_coord_min = event_x(ii);
                 y_coord_max = event_x(ii)+1;
                 x_coord_min = event_y(ii);
                 x_coord_max = event_y(ii)+1;
                 
             rectangle('Position', [x_coord_min,y_coord_min,...
                  x_coord_max-x_coord_min,y_coord_max-y_coord_min],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
    
    
end;
    
dude = 3
pause;

do_original = 0;

if (do_original == 1)
                
          for iii = 1:length(body_coords(:,1))
                 x_coord_min = body_coords(iii,1);
                 x_coord_max = body_coords(iii,2);
                 y_coord_min = body_coords(iii,3);
                 y_coord_max = body_coords(iii,4);

             rectangle('Position', [x_coord_min,y_coord_min,...
                  x_coord_max-x_coord_min,y_coord_max-y_coord_min],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
                    
          end;

  if (length(hot_spot_groups) > 0)      
   for jj = 1:num_hot_spot_groups
       if (sum(coords_groupSpine(jj,:))~=0)
       x_coord_min = min([coords_group(jj,1) coords_groupSpine(jj,1)]);
       x_coord_max = max([coords_group(jj,2) coords_groupSpine(jj,2)]);
       y_coord_min = min([coords_group(jj,3) coords_groupSpine(jj,3)]);
       y_coord_max = max([coords_group(jj,4) coords_groupSpine(jj,4)]);
       else
       x_coord_min = coords_group(jj,1);
       x_coord_max = coords_group(jj,2);
       y_coord_min = coords_group(jj,3);
       y_coord_max = coords_group(jj,4);
       end;
              rectangle('Position', [x_coord_min-div,y_coord_min-div,...
                  x_coord_max-x_coord_min+2*div,y_coord_max-y_coord_min+2*div],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'y');
                    text(x_coord_max+2*div,y_coord_min-div,num2str(jj),'Color','r');

                    
   end;
  end;              
                    
                
                  for jj=1:length(indexKeptEventsAll)              

  do_insertion_time=0;
  if (do_insertion_time==1)
  % lead movie frames
  start_frame = event_z_frame(indexKeptEventsAll(jj))-20;
  end_frame = event_z_frame(indexKeptEventsAll(jj));
  for jjj = start_frame:end_frame
       max_matrix_tif = imread(strcat('C:/joanna/movies/',dirName,'/',movieName,'.tif'),'TIFF',jjj);%,'uint8');
       m(jjj-start_frame+1).cdata = max_matrix_tif;
                       if (jjj==start_frame);
                       imgSum = m(jjj-start_frame+1).cdata;
                       else
                       imgSum = imgSum + m(jjj-start_frame+1).cdata;
                       end;
  end;                    
    imgSum = imgSum/(end_frame-start_frame+1);
                imagesc(imgSum', [min(min(imgSum')) max(max(imgSum'))]);
  end;
                      
                      index_dummy = indexKeptEventsAll(jj);
                           %x_coord = event_x(index_dummy);
                           %y_coord = event_y(index_dummy); 
                           % rectangle('Position', [x_coord-(div+1)/2,y_coord-(div+1)/2,div,div],...
                           %  'LineWidth', 1.5,'LineStyle','-', 'LineWidth', 1.5,...
                           %  'EdgeColor', 'r');
                           x_min = eventBoundaries(index_dummy,1);
                           x_max = eventBoundaries(index_dummy,2);
                           y_min = eventBoundaries(index_dummy,3);
                           y_max = eventBoundaries(index_dummy,4);
                             %x_min = eventBoundariesRefined(index_dummy,1);
                             %x_max = eventBoundariesRefined(index_dummy,2);
                             %y_min = eventBoundariesRefined(index_dummy,3);
                             %y_max = eventBoundariesRefined(index_dummy,4);
                                 x_max = x_max+1;
                                 y_max = y_max+1;
                            rectangle('Position', [x_min,y_min,x_max-x_min,y_max-y_min],...
                             'LineWidth', 1.5,'LineStyle','-', 'LineWidth', 1.5,...
                             'EdgeColor', 'r');
                       axis xy;
                       do_gray = 1;
                       if (do_gray == 1)
                       colormap('gray');
                       end;
                      axis off;
                      axis image;
                    %  xlim([y_coord-22 y_coord+22]);
                    %  ylim([x_coord-22 x_coord+22]);
                    %  pause;
                  end;
                  title(strcat('Movie:',num2str(which_movie),', total events:',num2str(numKeptEventsAll),',number of dendritic insertions:',num2str(sum(eventBodyOrDendrite))));
                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END: read in the big image 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end; % if (do_original == 1)
