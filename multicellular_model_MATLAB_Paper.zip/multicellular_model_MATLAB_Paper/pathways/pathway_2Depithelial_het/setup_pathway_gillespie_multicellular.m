%  INDEX MAP OF REACTIONS
%   1 - * -> reaction products
%   2 - S_j -> reaction products
%   3 - S_j + S_k -> reaction products (j~=k)
%   4 - 2 S_j -> reaction products
%   5 - S_i + S_j + S_k -> reaction products (i~=j~=k)
%   6 - S_j + 2 S_k -> (j~=k)
%   7 - 3 S_j
%   12 - (S_j0-S_j) -> reaction products, difference between inital value and current
%   13 - (S_j0-S_j)/2 -> reaction products, difference between inital value and current (dimer version)
%   20 - (S_k0/(S_k0+S_i))^2  2 S_j  - competition theory UPR, module 1
%   21 - f(S_i,S_j)   2 S_j - 
%   30 - S_i^n/(a0 + S_i^n)  - gene regulation function #1 (Hill function
%   31 - (S_i0-S_i)^2/(a0 + a1*(S_i0-S_i) + (S_i0-S_i)^2)  - gene regulation function #2
%   32 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #3
%   50 - min((S_i0-S_i)/2, S_j)  - gene regulation function #3



stochasticity = zeros(1,num_molecules);  % initialize the stochastic index array
stochasticity_conj = zeros(1,num_molecules);  % initialize the stochastic conjugate index array



  if (which_pathway==0)
      
    num_input_reactions = 2;
    num_reactions = 16*num_cells+sum(sum(mat_A_gap))+sum(sum(mat_R_gap))+num_input_reactions;
    
          alpha_A = passed_constants(1);
          alpha_prime_A = passed_constants(2);
          alpha_R = passed_constants(3);
          alpha_prime_R = passed_constants(4);
          beta_A = passed_constants(5);
          beta_R = passed_constants(6);
          delta_MA = passed_constants(7);
          delta_MR = passed_constants(8);
          delta_A = passed_constants(9);
          delta_R = passed_constants(10);
          gamma_A = passed_constants(11);
          gamma_R = passed_constants(12);
          gamma_C = passed_constants(13);
          theta_A = passed_constants(14);
          theta_R = passed_constants(15);
          beta_gap_A = passed_constants(16);
          beta_gap_R = passed_constants(17);
 

%          D_A = y(1);
%          D_R = y(2);
%          D_prime_A = y(3);
%          D_prime_R = y(4);
%          M_A = y(5);
%          M_R = y(6);
%          A = y(7);
%          R = y(8);
%          C = y(9);

          ii_D_A = 1;
          ii_D_R = 2;
          ii_D_prime_A = 3;
          ii_D_prime_R = 4;
          ii_M_A = 5;
          ii_M_R = 6;
          ii_A = 7;
          ii_R = 8;
          ii_C = 9;
          
          ii_I_A = num_molecules_cell*num_cells+1;
          ii_I_R = num_molecules_cell*num_cells+2;
          

%        %  Oscillator equations in each cell
%          y_prime(1) = theta_A*D_prime_A -gamma_A*D_A*A;
%          y_prime(2) = theta_R*D_prime_R -gamma_R*D_R*A;
%
%          y_prime(3) = -theta_A*D_prime_A +gamma_A*D_A*A;
%          y_prime(4) = -theta_R*D_prime_R +gamma_R*D_R*A;
%
%          y_prime(5) = alpha_prime_A*D_prime_A + alpha_A*D_A - delta_MA*M_A;
%          y_prime(6) = alpha_prime_R*D_prime_R + alpha_R*D_R - delta_MR*M_R;
%
%          y_prime(7) =  beta_A*M_A + theta_A*D_prime_A + theta_R*D_prime_R...
%                       -A*(gamma_A*D_A + gamma_R*D_R + gamma_C*R + delta_A);
%
%          y_prime(8) = beta_R*M_R - gamma_C*A*R + delta_A*C - delta_R*R;
%
%          y_prime(9) = gamma_C*A*R - delta_A*C;



  elseif (which_pathway==1)  % to determined

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Andrew's differential equation (emitter/receiver duo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           #Sender cell
%            d x[0]/dt =    Kb*1*on + ACmax*KD_cAMP/(KD_cAMP + factAC * x[2]) - Ka1*x[0]**4*x[1] - fact_Pc*Kdeg_Pc*x[4]/(KD_Pc + x[4])*x[0] - Kdeg_c*x[0] - Kdiff*x[0] + Kdiff*x[5],
%            d x[1]/dt = fact_PP*Kdeg_PP*x[4]/(KD_PP + x[4])*x[2] + KD1 * x[2] - Ka1*x[0]**4*x[1],
%            d x[2]/dt =  Ka1*x[0]**4*x[1] - fact_PP*Kdeg_PP*x[4]/(KD_PP + x[4])*x[2] - KD1 * x[2],
%            d x[3]/dt =   KD2*x[4] - Ka2*x[2]*x[3],
%            d x[4]/dt =   Ka2*x[2]*x[3] - KD2*x[4],
%           #Receiver cell
%            d x[5]/dt =    ACmax*KD_cAMP/(KD_cAMP + factAC * x[7]) - Ka1*x[5]**4*x[6] - fact_Pc*Kdeg_Pc*x[9]/(KD_Pc + x[9])*x[5] - Kdeg_c*x[5] - Kdiff*x[5] + Kdiff*x[0],
%            d x[6]/dt =    fact_PP*Kdeg_PP*x[9]/(KD_PP + x[9])*x[7] + KD1 * x[7] - Ka1*x[5]**4*x[6],
%            d x[7]/dt =    Ka1*x[5]**4*x[6] - fact_PP*Kdeg_PP*x[9]/(KD_PP + x[9])*x[7] - KD1 * x[7],
%            d x[8]/dt =    KD2*x[9] - Ka2*x[7]*x[8],
%            d x[9]/dt =    Ka2*x[7]*x[8] - KD2*x[9]
%
%            x[0] = cAMP
%            x[1] = PKA_off
%            x[2] = PKA_on
%            x[4] = PDE_off
%            x[5] = PDE_on
%
%            EQUATIONS:
%            d [cAMP]/dt =    Kb*1*on + ACmax*KD_cAMP/(KD_cAMP + factAC * [PKA_on]) - Ka1*[cAMP]**4*[PKA_off] - fact_Pc*Kdeg_Pc*[PDE_on]/(KD_Pc + [PDE_on])*[cAMP] - Kdeg_c*[cAMP] - Kdiff*[cAMP,this cell] + Kdiff*[cAMP,other cells],
%            d [PKA_off]/dt = fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*x[2] + KD1 * [PKA_on] - Ka1*[cAMP]**4*x[PKA_off],
%            d [PKA_on]/dt =  Ka1*[cAMP]**4*[PKA_off] - fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*[PKA_off] - KD1 * [PKA_on],
%            d [PDE_off]/dt =   KD2*[PDE_on] - Ka2*[PKA_on]*[PDE_off],
%            d [PDE_on]/dt =   Ka2*[PKA_on]*[PDE_off] - KD2*[PDE_on],
%
%            biochemical reactions/ propensities
%            1.  0 -> cAMP ,   Kb*x[ii_I_bPAC]
%            2.  0 -> cAMP ,   ACmax*KD_cAMP/(KD_cAMP + x[ii_PKA_on]) for PKA feedback  or just ACmax for no PKA feedback 
%            2.  cAMP -> 0 ,   KA feedback 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    num_input_reactions = 5;
    
    if (which_cAMP_circuit == 0)
    num_reactions = 14*num_cells+sum(sum(mat_cAMP_gap))+sum(sum(mat_Calcium_gap))+num_input_reactions;
    elseif (which_cAMP_circuit == 1)
     if (do_GJ2==0)
      num_reactions = (17+num_gjc_delay_steps)*num_cells+(1+fac_gj_pk)*sum(sum(mat_cAMP_gap))+sum(sum(mat_Calcium_gap))+num_input_reactions;
     elseif (do_GJ2==1)
      num_reactions = (17+num_gjc_delay_steps + num_gjc2_delay_steps+2)*num_cells+(1+fac_gj_pk)*sum(sum(mat_cAMP_gap))+ do_GJ2*fac_gj_pk*sum(sum(mat_cAMP_gap))+sum(sum(mat_Calcium_gap))+num_input_reactions;
     end;
    end
        
      
  end;

  
  
non_stochastic = zeros(1,num_reactions);  % for hybrid, initialize array for reactions that are always non-stochastic reactions
molecule_gene = zeros(1,num_molecules);  % for hybrid, initialize array for molecules that are to be labelled as genes

      % some reaction constants
      kappa = zeros(num_reactions,1);
      a_0_eff = zeros(num_reactions,1);
      a_1_eff = zeros(num_reactions,1);
      eta_0_eff = zeros(num_reactions,1);
      eta_1_eff = zeros(num_reactions,1);
      n_eff = zeros(num_reactions,1);
      a_0 = zeros(num_reactions,1);
      a_1 = zeros(num_reactions,1);
      a_2 = zeros(num_reactions,1);
      a_3 = zeros(num_reactions,1);
      a_4 = zeros(num_reactions,1);
      a_5 = zeros(num_reactions,1);
      a_6 = zeros(num_reactions,1);
      a_7 = zeros(num_reactions,1);
      a_8 = zeros(num_reactions,1);
      a_9 = zeros(num_reactions,1);
  
% species constants
species1 = 1;
species2 = 2;
species3 = 3;
species4 = 4;

%  This array defines the particular molecules involved for a given reaction
reaction_molecules = zeros(num_reactions,num_molecules+2);

%  This array defines the number of a particular molecule involved for a given reaction
%  it also defines the sign (lost or gained) of particular molecule involved for a given reaction
sign_value_reaction = zeros(num_reactions,num_molecules);

%  This array defines the reaction_constant, h_mu*c_mu (Gillespie,1976), for a reaction
%  due to concentration levels changing the values are always changing.
%reaction_constant = zeros(num_reactions,1);
propensities = zeros(num_reactions,1);

c_mu = zeros(num_reactions,1);


last_reaction = 0;  % start at zero
%-----------------------------------------------
% REACTIONS:
%-----------------------------------------------

if (which_pathway == 0)


          % ii_D_A = 1;
          % ii_D_R = 2;
          % ii_D_prime_A = 3;
          % ii_D_prime_R = 4;
          % ii_M_A = 5;
          % ii_M_R = 6;
          % ii_A = 7;
          % ii_R = 8;
          % ii_C = 9; which_pathway==9
          % ii_A_repressed = 9; which_pathway==9

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 %  oscillator circuit in each cell         
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 for ii = 1:num_cells
    
   % reaction 1:  theta_A D_prime_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_A switches to D_A
     reaction_type(which_reaction) = 2;
   % D_prime_A is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 D_A,A molecule gained, 1 D_prime_A molecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = theta_A;

   % reaction 2:  gamma_A D_A A -> D_prime_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_A, A -> D_prime_A
     reaction_type(which_reaction) = 3;
   % D_A and A the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_A;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 D_prime_A molecule gained, 1 D_A molecule lost, 1 A molecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
        c_mu(which_reaction) = gamma_A;

   % reaction 3:  theta_R D_prime_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_R switches to D_R
     reaction_type(which_reaction) = 2;
   % D_prime_R is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 D_R,A molecule gained, 1 D_prime_R moleecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = theta_R;

   % reaction 4:  gamma_R D_R A -> D_prime_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_R A -> D_prime_R
     reaction_type(which_reaction) = 3;
   % D_R and A the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_R;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 D_prime_R molecule gained, 1 D_R molecule lost, 1 A molecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_R;

   % reaction 5:  alpha_prime_A D_prime_A produce M_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_A transcribes M_A
     reaction_type(which_reaction) = 2;
   % D_prime_A is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_A molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_prime_A;

   % reaction 6:  alpha_A D_A produce M_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_A transcribes M_A
     reaction_type(which_reaction) = 2;
   % D_A is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_A molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_A;


   % reaction 7:  delta_MA M_A  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_A decays
     reaction_type(which_reaction) = 2;
   % M_A is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_A molecule lost 
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_MA;
     
   % reaction 8:  alpha_prime_R D_prime_R transcribes M_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_R transcribes M_R
     reaction_type(which_reaction) = 2;
   % D_prime_R is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_prime_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_R molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_prime_R;

   % reaction 9:  alpha_R D_R transcribes M_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_R transcribes M_R
     reaction_type(which_reaction) = 2;
   % D_R is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_D_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_R molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_R;

   % reaction 10:  delta_MR M_R  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_R decays
     reaction_type(which_reaction) = 2;
   % M_R is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_R molecule lost 
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_MR;

   % reaction 11:  beta_A M_A produce A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_A translates A
     reaction_type(which_reaction) = 2;
   % M_A is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 A molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_A;

       % reaction 12:  gamma_C A R produces C
          which_reaction = last_reaction+1;
          last_reaction = last_reaction+1; 
       % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
         stochasticity(which_reaction) = 1;
       % type of reaction: A,R produce C 
         reaction_type(which_reaction) = 3;
       % A,R is the input species 
         which_mol = ((ii-1)*num_molecules_cell)+ii_A;
         reaction_molecules(which_reaction,species1) = which_mol;
         which_mol = ((ii-1)*num_molecules_cell)+ii_R;
         reaction_molecules(which_reaction,species2) = which_mol;
       % 1 C molecule gained, 1 A, 1 R lost
         which_mol = ((ii-1)*num_molecules_cell)+ii_C;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
         which_mol = ((ii-1)*num_molecules_cell)+ii_A;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
         which_mol = ((ii-1)*num_molecules_cell)+ii_R;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % reaction_constant
         c_mu(which_reaction) = gamma_C;

   % reaction 13:  delta_A A  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: A decays
     reaction_type(which_reaction) = 2;
   % A is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 A molecule lost 
     which_mol = ((ii-1)*num_molecules_cell)+ii_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_A;

   % reaction 14:  beta_R M_R produce R 
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_R translates R
     reaction_type(which_reaction) = 2;
   % M_R is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_M_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 R molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_R;

       % reaction 15:  delta_A C  (decay)  produces only R (A decays)
          which_reaction = last_reaction+1;
          last_reaction = last_reaction+1; 
       % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
         stochasticity(which_reaction) = 1;
       % type of reaction: A decays
         reaction_type(which_reaction) = 2;
       % C is the input species 
         which_mol = ((ii-1)*num_molecules_cell)+ii_C;
         reaction_molecules(which_reaction,species1) = which_mol;
       % 1 C molecule lost , 1 R is gaines
         which_mol = ((ii-1)*num_molecules_cell)+ii_C;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
         which_mol = ((ii-1)*num_molecules_cell)+ii_R;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % reaction_constant
         c_mu(which_reaction) = delta_A;

   % reaction 16:  delta_R R  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: R decays
     reaction_type(which_reaction) = 2;
   % R is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 R molecule lost 
     which_mol = ((ii-1)*num_molecules_cell)+ii_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_R;

     
     
     
 end; % for ii = 1:num_cells

 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  cell-to-cell coupling         
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   do_differential_flux = 0; % 0-no,1-yes

 for ii = 1:num_cells
     
     for jj = 1:num_cells
         
         if (mat_A_gap(ii,jj) == 1)
             
          if (do_differential_flux == 1)
           % reaction 17:  an A molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1; 
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an A molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 80;
           % an A from both cells ii and jj ,and I are is the input species 
             which_mol = (ii-1)*(num_molecules_cell) + ii_A;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_A;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = ii_I_A;  
             reaction_molecules(which_reaction,species3) = which_mol;
           % 1 A molecule from cell ii lost, 1 A molecule from cell jj gained 
             which_mol = (ii-1)*(num_molecules_cell) + ii_A;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_A;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = beta_gap_A;

          elseif (do_differential_flux == 0)

           % reaction 17:  an A molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1; 
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an A molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 80;
           % an A from both cells ii and jj ,and I are is the input species 
             which_mol = (ii-1)*(num_molecules_cell) + ii_A;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_A;  
             reaction_molecules(which_reaction,species2) = which_mol;
           % 1 A molecule from cell ii lost, 1 A molecule from cell jj gained 
             which_mol = (ii-1)*(num_molecules_cell) + ii_A;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_A;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = beta_gap_A;


%           % reaction 17:  an A molecule from cell jj diffuses to cell ii
%              which_reaction = last_reaction+1;
%              last_reaction = last_reaction+1; 
%           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
%             stochasticity(which_reaction) = 1;
%           % type of reaction: an A molecule from cell ii diffuses to cell jj
%             reaction_type(which_reaction) = 80;
%           % an A from both cells jj and ii ,and I are is the input species 
%             which_mol = (jj-1)*(num_molecules_cell) + ii_A;
%             reaction_molecules(which_reaction,species1) = which_mol;
%             which_mol = ii_I_A;  
%             reaction_molecules(which_reaction,species2) = which_mol;
%           % 1 A molecule from cell jj lost, 1 A molecule from cell ii gained 
%             which_mol = (jj-1)*(num_molecules_cell) + ii_A;
%             sign_value = -1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%             which_mol = (ii-1)*(num_molecules_cell) + ii_A;
%             sign_value = 1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%           % reaction_constant
%             c_mu(which_reaction) = beta_gap_A;

          end;
                                     
         end;
         
         if (mat_R_gap(ii,jj) == 1)
             
          if (do_differential_flux == 1)

           % reaction 17:  an R molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1; 
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 80;
           % an R from both cells ii and jj ,and I are is the input species 
             which_mol = (ii-1)*(num_molecules_cell) + ii_R;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_R;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = ii_I_R;  
             reaction_molecules(which_reaction,species3) = which_mol;
           % 1 R molecule from cell ii lost, 1 R molecule from cell jj gained 
             which_mol = (ii-1)*(num_molecules_cell) + ii_R;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_R;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = beta_gap_R;

          elseif (do_differential_flux == 0)

           % reaction 17:  an R molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1; 
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 80;
           % an R from both cells ii and jj ,and I are is the input species 
             which_mol = (ii-1)*(num_molecules_cell) + ii_R;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_R;  
             reaction_molecules(which_reaction,species2) = which_mol;
           % 1 R molecule from cell ii lost, 1 R molecule from cell jj gained 
             which_mol = (ii-1)*(num_molecules_cell) + ii_R;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_R;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = beta_gap_R;

%           % reaction 17:  an R molecule from cell jj diffuses to cell ii
%              which_reaction = last_reaction+1;
%              last_reaction = last_reaction+1; 
%           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
%             stochasticity(which_reaction) = 1;
%           % type of reaction: an R molecule from cell jj diffuses to cell ii
%             reaction_type(which_reaction) = 80;
%           % an R from both cells jj and ii ,and I are is the input species 
%             which_mol = (jj-1)*(num_molecules_cell) + ii_R;
%             reaction_molecules(which_reaction,species1) = which_mol;
%             which_mol = ii_I_R;  
%             reaction_molecules(which_reaction,species2) = which_mol;
%           % 1 R molecule from cell jj lost, 1 R molecule from cell ii gained 
%             which_mol = (jj-1)*(num_molecules_cell) + ii_R;
%             sign_value = -1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%             which_mol = (ii-1)*(num_molecules_cell) + ii_R;
%             sign_value = 1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%           % reaction_constant
%             c_mu(which_reaction) = beta_gap_R;

          end;
                                     
         end;

     end; % for jj = 1:num_cells
 end; % for ii = 1:num_cells



           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %  time dependent inputs
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         
           % reaction 17:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1; 
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species 
             which_mol = ii_I_A;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;
         
           % reaction 17:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1; 
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species 
             which_mol = ii_I_R;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;
         
 
 
 
elseif (which_pathway == 1)  % MDCK circuits
    

if (which_cAMP_circuit == 0) % andrewss
setup_cAMP_circuit_andrew
elseif (which_cAMP_circuit == 1) % recent (mike)
 if (do_GJ2 == 0)
   setup_cAMP_circuit_mike
 elseif (do_GJ2 == 1)
   setup_cAMP_circuit_mike_GJ2
 end;   
end;

     if (last_reaction ~= num_reactions)
       str_last_reaction = 'last_reaction does not equal num_reactions'
         last_reaction
         num_reactions
       pause;
     end;

end;  % end of if (which_pathway== )



     

do_read_inputs_data = 0;   % allows the input species' to be updated over time from a file or array
map_inputs_data_sampled = [];
for jj = 1:num_reactions
    if (reaction_type(jj) == 100)
        do_read_inputs_data = 1;
        map_inputs_data_sampled = [map_inputs_data_sampled;reaction_molecules(jj,1)];
    end;
end;
     
     
% initialize the stochasticity_conj array

for ii = 1:length(stochasticity)
  if (stochasticity(ii)==1)
      stochasticity_conj(ii)=0;
  else
      stochasticity_conj(ii)=1;
  end;
end;

%  1st 2nd derivative matrix:  NOTE THIS NEEDS TO BE SET AS GLOBAL AND
%  TRANSFERED TO AN INITIALIZATION FUNCTION
der_1_r = zeros(num_reactions, num_molecules);
der_1_unr = zeros(num_reactions, num_molecules);
der_2_r = zeros(num_molecules, num_molecules);
der_2_unr = zeros(num_molecules, num_molecules);

species_restricted = ones(num_molecules,1);
species_restricted_conj = zeros(num_molecules,1);
species_cov = ones(num_molecules,1);
species_cov_conj = zeros(num_molecules,1);

x_ref = zeros(num_molecules,1);

%  This setups the propensity derivative maps, used for the moment calculations in the hybrid code
setup_propensity_map;

         % GAUSSIAN setup
              x_cdf_norm = zeros(length_cdf_norm,1);
              cdf_norm = zeros(length_cdf_norm,1);
              delx_cdf_norm = 2.0*abs(x_cdf_norm_min)/(length_cdf_norm-1);
             for ii=1:length_cdf_norm
              x_cdf_norm(ii) = x_cdf_norm_min+(ii-1)*delx_cdf_norm;
              cdf_norm(ii) = 1.0-erfc(x_cdf_norm(ii))/2.0;
             end;
