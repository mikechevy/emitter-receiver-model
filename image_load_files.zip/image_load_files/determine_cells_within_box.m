

set_globals;

get_movie_info_for_processing  % which_movie must already be set
str_movie_write = str_movie;
str_movie = strcat('C:\Users\Mike\Desktop\Multi-cellular\multicellular_movie_processing\',str_movie);
str_movie_processed = strcat(str_movie,'_processed')
  

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);

file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
load(file_track);



which_frames = 1:numFr;


% load in the thresholded nuclei information from all frames 
%file_nucleus_tot = strcat(str_movie_processed,'\Cell_nucleus_structs_tot');
%load(file_nucleus_tot);
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
load(file_nucleus_tot_FINAL);

% load time series file foor tracking the cells
file_track_cells = strcat(str_movie_processed,'\track_cells_time_series');
load(file_track_cells);

  
 

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN:  setup some arrays
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
 num_pixels_tot_CYTOSOL_time = zeros(num_nuclei_max, length(which_frames));
 nuclear_FITC_tot_time = zeros(num_nuclei_max, length(which_frames));
 nuclear_CY3_tot_time = zeros(num_nuclei_max, length(which_frames));
 cytosolic_FITC_tot_time = zeros(num_nuclei_max, length(which_frames));
 cytosolic_CY3_tot_time = zeros(num_nuclei_max, length(which_frames)); 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % END:  setup some arrays
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

 x_coord_min_tot_CYTOSOL_time_mapped_t0 = 0*x_coord_min_tot_NUCLEUS_time_mapped_t0;
 x_coord_max_tot_CYTOSOL_time_mapped_t0 = 0*x_coord_max_tot_NUCLEUS_time_mapped_t0;
 y_coord_min_tot_CYTOSOL_time_mapped_t0 = 0*y_coord_min_tot_NUCLEUS_time_mapped_t0;
 y_coord_max_tot_CYTOSOL_time_mapped_t0 = 0*y_coord_max_tot_NUCLEUS_time_mapped_t0;
 num_pixels_tot_CYTOSOL_time_mapped_t0 = num_pixels_tot_NUCLEUS_time_mapped_t0; 
  
   



%
%  eventually we'll gather specific events that have interesting behaviors
%  capture in 'load_and_analyze_cellular_signals.m'
%

                       do_examine_local_cells = 1;
                   if (do_examine_local_cells == 1)
                     %x_coord_min_local = max(x_coord_min_local-40,1)
                     %x_coord_max_local = min(x_coord_max_local+40,xLength);
                     %y_coord_min_local = max(y_coord_min_local-40,1)
                     %y_coord_max_local = min(y_coord_max_local+40,yLength);
                     obtain_and_plot_localized_cells_within_box                    
                   end;

