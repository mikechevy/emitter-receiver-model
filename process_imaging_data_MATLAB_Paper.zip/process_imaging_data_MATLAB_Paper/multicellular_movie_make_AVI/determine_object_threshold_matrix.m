function threshold_array = determine_object_threshold_matrix(I,xDim,yDim,do_threshold_fac_adjust)

global delta_xDim;
global delta_yDim;

global delta_xDim_step;
global delta_yDim_step;


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % the method is simply an extrapolation of the noise floor at the xDIM, which should always be well below the real signal 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

threshold_array = 0*I;
 
 
% Segment array into local blocks and xort each block into ascending order to separate noise from signal
  
do_new = 1;  % 0 - piece wise constant threshold over block (delta_xDim by delta_yDim), delta_xDim = delta_xDim_setp, 1  0 - piece wise constant threshold over block (delta_xDim by delta_yDim), delta_xDim != delta_xDim_setp ,2 - calculate for every pixel

if (do_new == 0)

ii_max = ceil(xDim/delta_xDim);
jj_max = ceil(yDim/delta_yDim);    
    
for ii = 1:ii_max
for jj = 1:jj_max

    
  x_coord_min = (ii-1)*delta_xDim+1;
  x_coord_max = min(ii*delta_xDim,xDim);
  y_coord_min = (jj-1)*delta_yDim+1;
  y_coord_max = min(jj*delta_yDim,yDim);
    
  
  length_reshape = (x_coord_max-x_coord_min+1)*(y_coord_max-y_coord_min+1);
  
  I_sort = sort(reshape(I(x_coord_min:x_coord_max,y_coord_min:y_coord_max),length_reshape,1));
  
  
  index_min = floor(length_reshape/4);
  index_max = floor(length_reshape/3);
  
  slope = (I_sort(index_max)-I_sort(index_min))/(index_max-index_min);
  
  threshold = I_sort(index_min) + slope*(length_reshape-index_min);

  
  
  
  %% adjust by fac_adjust
  fac_adjust = do_threshold_fac_adjust*.1;
  %fac_adjust = 0;
  threshold = threshold + fac_adjust*(max(I_sort)-threshold);
  
  
   
  
       do_plot_sorted_image = 0;  % 1 - yes, 0 - no
   if (do_plot_sorted_image == 1) 
   figure(101)   
   hold on;
   plot(I_sort(:));
    plot([index_min length_reshape],[I_sort(index_min,:) threshold],'r');
   hold off;
   pause
   end;

threshold_array(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = threshold;   
   
end;  % END OF: for jj = 1:jj_max
end;  % END OF: for ii = 1:ii_max



elseif (do_new == 1)


ii_max = ceil(xDim/delta_xDim_step);
jj_max = ceil(yDim/delta_yDim_step);    
    
for ii = 1:ii_max
for jj = 1:jj_max

    
  
  x_coord_min = max(1,(ii-1)*delta_xDim_step+int16(delta_xDim_step/2)-int16(delta_xDim/2));
  x_coord_max = min((ii-1)*delta_xDim_step+int16(delta_xDim_step/2)+int16(delta_xDim/2),xDim);
  y_coord_min = max(1,(jj-1)*delta_yDim_step+int16(delta_yDim_step/2)-int16(delta_yDim/2));
  y_coord_max = min((jj-1)*delta_yDim_step+int16(delta_yDim_step/2)+int16(delta_yDim/2),yDim);
  
     % make sure the averaging area is still delta_xDim x delta_yDim
      if (x_coord_max-x_coord_min < delta_xDim - 2)
          if (x_coord_min == 1)
              x_coord_max = delta_xDim;
          elseif (x_coord_max == xDim)
              x_coord_min = xDim - delta_xDim + 1;
          end;
      end;
      if (y_coord_max-y_coord_min < delta_yDim - 2)
          if y_coord_min == 1
              y_coord_max = delta_yDim;
          elseif (y_coord_max == yDim)
              y_coord_min = yDim - delta_yDim + 1;
          end;
      end;

  
    length_reshape = round(double(x_coord_max-x_coord_min+1)*double(y_coord_max-y_coord_min+1));
  
  I_sort = sort(reshape(I(x_coord_min:x_coord_max,y_coord_min:y_coord_max),length_reshape,1));
  
  
  index_min = floor(length_reshape/4);
  index_max = floor(length_reshape/3);
  
  slope = (I_sort(index_max)-I_sort(index_min))/(index_max-index_min);
  
  threshold = I_sort(index_min) + slope*(length_reshape-index_min);

  
  
  
  %% adjust by fac_adjust
  fac_adjust = do_threshold_fac_adjust*.2;
  %fac_adjust = 0;
  threshold = threshold + fac_adjust*(max(I_sort)-threshold);
  
  
   
  
       do_plot_sorted_image = 0;  % 1 - yes, 0 - no
   if (do_plot_sorted_image == 1) 
   figure(101)   
   hold on;
   plot(I_sort(:));
    plot([index_min length_reshape],[I_sort(index_min,:) threshold],'r');
   hold off;
   pause
   end;

  x_coord_min_step = (ii-1)*delta_xDim_step+1;
  x_coord_max_step = min(ii*delta_xDim_step,xDim);
  y_coord_min_step = (jj-1)*delta_yDim_step+1;
  y_coord_max_step = min(jj*delta_yDim_step,yDim);
     
threshold_array(x_coord_min_step:x_coord_max_step,y_coord_min_step:y_coord_max_step) = threshold;   
   
end;  % END OF: for jj = 1:jj_max
end;  % END OF: for ii = 1:ii_max

elseif (do_new == 2)
   
for ii = 1:xDim
for jj = 1:yDim
    
  x_coord_min = max(1,int16(ii-delta_xDim/2));
  x_coord_max = min(int16(ii+delta_xDim/2),xDim);
  y_coord_min = max(1,int16(ii-delta_yDim/2));
  y_coord_max = min(int16(ii+delta_yDim/2),yDim);
    
  length_reshape = (x_coord_max-x_coord_min+1)*(y_coord_max-y_coord_min+1);
  
  I_sort = sort(reshape(I(x_coord_min:x_coord_max,y_coord_min:y_coord_max),length_reshape,1));
  
  
  index_min = floor(length_reshape/4);
  index_max = floor(length_reshape/3);
  
  slope = (I_sort(index_max)-I_sort(index_min))/(index_max-index_min);
  
  threshold = I_sort(index_min) + slope*(length_reshape-index_min);

  
  
  
  %% adjust by fac_adjust
  fac_adjust = 0*.1;
  %fac_adjust = 0;
  threshold = threshold + fac_adjust*(max(I_sort)-threshold);
  
  
   
  
       do_plot_sorted_image = 0;  % 1 - yes, 0 - no
   if (do_plot_sorted_image == 1) 
   figure(101)   
   hold on;
   plot(I_sort(:));
    plot([index_min length_reshape],[I_sort(index_min,:) threshold],'r');
   hold off;
   pause
   end;

threshold_array(ii,jj) = threshold;   
   
end;  % END OF: for jj = 1:jj_max
ii
jj
end;  % END OF: for ii = 1:ii_max

    
end;