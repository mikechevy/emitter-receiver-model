%  this is the standard SSA/Gillespie algorithm, made before Mike's hybrid paper, coded around October 2007


% initialize some variables
x = y_g;
if (count_reactions==0)
  x_g = y_g;
  time_g = 0.0;
end;


if (use_timeseries==1)  % modal solutions file
  do_markov=0;  % 0-non-markov distribution, 1-create exponential distribution, test to compare with SSA
  do_adsorber_independent = 1; % 0-no, 1-specifice adsorber case where all reactions are independent (adsorber number remains constant);
  setup_P_nr;
  p_r_array = zeros(num_max*2,3);
    tau_start_array = zeros(num_max,1);
    upper_array = zeros(num_max,1);
    lower_array = zeros(num_max,1);
    ii_lower_array = zeros(num_max,1);
    ii_upper_array = zeros(num_max,1);

      if (do_adsorber_independent == 1)
       adsorber_independent_reactions;
      end;
      pause;
 
      propensity_tot_approx = 1e16;  % intialize

    %options = optimset('TolX',1e-8,'TolFun',1e-4)


end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: gillespie reaction loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%while (count_reactions < max_count_reactions)
while (time < max_time)

     x_old = x;  % keep last state
     time_old = time;  % keep time of last state

     

if (use_timeseries==0)  % normal gillespie

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %  BEGIN: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if (do_read_inputs_data == 1)  
            
         for ii = 1:length(map_inputs_data_sampled)
           [val,index_min] = min(abs(time-time_inputs_data_sampled(ii,:)));
              if (time_inputs_data_sampled(ii,index_min) > time)
                  index_lower_data = index_min-1;
              else
                index_lower_data = index_min;
              end;         
            
             if (index_lower_data < length(time_inputs_data_sampled(ii,:)))
              upper_data = (time-time_inputs_data_sampled(ii,index_lower_data))/(time_inputs_data_sampled(ii,index_lower_data+1)-time_inputs_data_sampled(ii,index_lower_data));
              lower_data = 1-upper_data;
             else
              index_lower_data = length(time_moments_data_sampled(ii,:))-1;
              upper_data = 1;
              lower_data = 1-upper_data;
             end;
             
           which_input = map_inputs_data_sampled(ii)
           x(which_input) = lower_data*inputs_data_sampled(ii,index_lower_data) + upper_data*inputs_data_sampled(ii,index_lower_data+1);
         end; % for ii = 1:length(map_inputs_data_sampled)
         
        end; % if (do_read_intputs_data == 1)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %  END: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
             
   %  given the current state x, calculate the reaction constants 
   calculate_reaction_constants(x);     
     propensities_mean_path=propensities;
   %sum_reaction_constants = sum(reaction_constant);
   sum_propensities = sum(propensities);

   %  determine the time of the next reaction by random draw from the cdf
   rand_exp_tau = get_rand_dummy;
      tau = -log(rand_exp_tau)/sum_propensities;       
   
   %  determine which reaction takes place by random draw from the cdf
   rand_which_reaction = get_rand_dummy; 
       cdf_which_reaction(1) = propensities(1)/sum_propensities;
         if (rand_which_reaction <= cdf_which_reaction(1))
             which_reaction = 1;
         end
     for jj = 2:length(propensities)
       cdf_which_reaction(jj) = cdf_which_reaction(jj-1)+propensities(jj)/sum_propensities;
         if (rand_which_reaction <= cdf_which_reaction(jj))&(rand_which_reaction > cdf_which_reaction(jj-1))
             which_reaction = jj;
         end
     end;

   %  update the new state and time and the reaction count  
   x = x + sign_value_reaction(which_reaction,:);        
   time = time+tau
   x
   count_reactions = count_reactions+1;
     
     
elseif  (use_timeseries == 1)&(do_adsorber_independent==0)  % eg. propensity integral for 2D membrane reactions
 

             % calculate the time varying propensities
             calculate_reaction_constants(x);     
             propensities_mean_path=propensities;

              sum_propensities = 0;
               for jj = 1:length(propensities)  % sum markovian propensities
                if (reaction_timeseries(jj)==0)
                 sum_propensities = sum_propensities + propensities(jj);
                else  % set to zero
                 propensities(jj) = 0;
                end;
               end;

            x_timeseries_max = x;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: Determine time of reaction: tau
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

             % generate the random number for generating the time of reaction
             rand_exp_tau = get_rand_dummy;
             log_rand_exp_tau = log(rand_exp_tau);
          
              tau_start_mean = 0;
              sum_int_propensity_P_nr_start = 0;
            
              % Calculate P_nr_start = P_nr(tau-t_ij), the normalizing factor for each particle,
              % where tau = time
              for ii = 1:num_molecules 
               if (species_timeseries(ii)==1)
                 for jj = 1:x_timeseries_max(ii)
                     tau_start = time-x_timeseries_array(ii,jj,index_tau);
                     tau_start_mean = tau_start_mean + tau_start;
                      %if (tau_start < 0)  % temp fix, determine why is goes negative
                      % tau_start = 0;
                      %end;
                  if (tau_start < time_P_nr_max)
                    if (do_log_time==1)
                     ii_lower = find_log_time_index(tau_start);
                     %t = tau_start;
                     %find_log_time_index;
                     dt_P_nr = time_P_nr(ii_lower+1)-time_P_nr(ii_lower);
                    else
                     ii_lower = floor(tau_start/dt_P_nr)+1;
                    end;
                     ii_upper = ii_lower+1;
                           upper = (tau_start-time_P_nr(ii_lower))/dt_P_nr;
                           lower = 1-upper;
                    P_nr_start(ii,jj) = upper*P_nr(ii_upper) + lower*P_nr(ii_lower);
                    int_propensity_P_nr_start(ii,jj) = upper*int_propensity_P_nr(ii_upper) + lower*int_propensity_P_nr(ii_lower);
                  else
                    P_nr_start(ii,jj) = P_nr(length_time_P_nr);
                    int_propensity_P_nr_start(ii,jj) = int_propensity_P_nr(length_time_P_nr);
                  end;
                        exponent_search = x_timeseries_array(ii,jj,index_search);
                        if (exponent_search>0)
                         sum_int_propensity_P_nr_start = sum_int_propensity_P_nr_start+exponent_search*int_propensity_P_nr_start(ii,jj);
                        end;
                 end;
               end;
              end;
         

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Determine time of reaction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               del_tau_approx = -log_rand_exp_tau/propensity_tot_approx;
              %[log_tau,fval] = fzero(@int_pdf_timeseries,time+del_tau_approx);  % time of next reaction  
              % tau = exp(log_tau);
              [tau,fval] = fzero(@int_pdf_timeseries,time+del_tau_approx);  % time of next reaction        
               propensity_tot_approx = -log_rand_exp_tau/(tau-time);

            %tau = fminbnd(@int_pdf_timeseries,time,2*max_time);        
            %tau = count_reactions*1.56e-6;
            %fval
            %tau-time

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: Determine which reaction occurred
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

               %calc_which_reaction;  % should not use anymore
               calc_which_reaction_new;



   %  update the new state and time and the reaction count  
   x = x + sign_value_reaction(which_reaction,:);        
   time = tau;
   count_reactions = count_reactions+1;

   
               for jj = 1:length(propensities)  
                if (reaction_type(jj)==100) % update input values from time series, using interpolation
                    % write code here
                end;
               end;
   

elseif  (use_timeseries == 1)&(do_adsorber_independent==1)  % eg. propensity integral for 2D membrane reactions

    
   which_reaction = reaction_array(count_reactions+1);
   tau = reaction_time_array(count_reactions+1);

   %  update the new state and time and the reaction count  
   x = x + sign_value_reaction(which_reaction,:);        
   time = tau;
   count_reactions = count_reactions+1;

   time
   max_time
   x
            
end;   % end of 'if (use_timeseries==0)

       

       for ii_x = 1:num_molecules
         if (x(ii_x)<0)
           % x(ii_x)=1.0;
            x(ii_x)=0.0;
         end;
       end;

    output_file_stuff_0; % output the states into a file

   %  keep a record of the state of x vs. time
   %time_g = [time_g; time];
   %x_g = [x_g; x];
   time_g = time;
   x_g =  x;


   
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END: gillespie reaction loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

time 
count_reactions
