
global m_delt;
global m_delx;
global m_dely;
global m_delz;
global do_ssa_hybrid;
global do_particles;
global NO_ID_PART;
global NO_ID_SURF;
global collision_x;
global collision_y;
global collision_z;
global check_collisions;
global EPS0;
global m_xdimp;
global m_ydimp;
global m_zdimp;
global GS;
global m_jx;
global m_jy;
global m_jz;
global m_jx_abs;
global m_jy_abs;
global m_jz_abs;
global m_n_static;
global m_cm;
global m_membrane;
global m_subvol;
global m_membrane_0;
global m_bm;
global m_barrier;
global m_barrier_0;
global m_n;
global r_max;
global r_ref;
global shift;
global sign_p;
global eta;
global r0;
global r1;
global r_start;
global r_end;
global rho_old;
global rho_new;
global s0;
global s1;
global ds;
global wx;
global wy;
global wz;
global jx_temp;
global jy_temp;
global jz_temp;
global ACTIVATED;
global ATTACHED;
global HOST;
global FREE;
global GUEST;
global NOT_ACTIVATED;
global Parts;
global Parts_near;
global which_field_minimize;
global iii_field_minimize;
global jjj_field_minimize;
global kkk_field_minimize;
global which_function;
global A_surf;
global b_surf;

% RAND variables

global read_rand;
global count_rand;
global length_array_rand;
global array_rand;


% some particle maps
global reactive_map;
global attach_map;
global decay_map;
global tau_decay_map;
global use_particle_map;
global species_particle_map;
global collision_map;
global Diff_coeff;
global Diff_coeff_real;
global dis_exocytosis;
global attach_endocytosis;

%  Surface diffusion globals

global count_points_surf;
global sum_count_points_surf;
global surface_array_3;
global surface_array_4;
global surface_array_5;
global surface_array_6;
global x_surf_3;
global y_surf_3;
global z_surf_3;
global x_surf_4;
global y_surf_4;
global z_surf_4
global x_surf_5;
global y_surf_5;
global z_surf_5;
global x_surf_6;
global y_surf_6;
global z_surf_6;
global array_iii;
global array_kkk;
global array_jjj;
global do_surfs;
global d_sq;
global d_sq_sum;
global d_sq_sum_old;
global dist_end;
global dist_sum;
global dist_sum_old;
global tol_correct;
global do_tol_correct;
global shift_one;
global surface_functions;
global ii_surf;
global array_surf_area_cell;
global array_surf_area_cell_planes;

global do_inhomogeneous_diffusion;

global num_particle_files;  % this is the number of different randomly generated files for the initial starting positions of the particles



