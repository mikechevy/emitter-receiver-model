
for ii_which_movie = 1:length(movie_array)

which_movie = movie_array(ii_which_movie); 

get_movie_info_for_processing;

str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')


cd(str_movie_processed);
% load file
load('d_cAMP_arrays');
cd(str_processing) 

 if (ii_which_movie == 1)
     
  M_NM_d_cAMP = zeros(xLength,yLength,length(movie_array));    
  M_NM_bPAC_d_cAMP = zeros(xLength,yLength,length(movie_array));    
  M_Erk_d_cAMP = zeros(xLength,yLength,length(movie_array));    

  mean_x_tot_time_mapped_t0_array = zeros(2*num_nuclei_t0, length(movie_array));
  bPAC_NUCLEUS_time_mapped_t0_array = zeros(2*num_nuclei_t0, length(movie_array));
  mean_y_tot_time_mapped_t0_array = zeros(2*num_nuclei_t0, length(movie_array));
  num_nuclei_t0_array = zeros(length(movie_array),1);
  
  num_nuclei_t0_max = num_nuclei_t0;

  num_time_samples_array = zeros(length(movie_array));
  
  bPAC_NUCLEUS_time_mapped_t0_first = zeros(num_nuclei_t0,1);
  bPAC_NUCLEUS_time_mapped_t0_first(1:num_nuclei_t0,1) = bPAC_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,1);
  bPAC_NUCLEUS_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie) = bPAC_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,1);
  
  num_nuclei_t0_first = num_nuclei_t0;
  linked_nuclei_across_movies_array = zeros(num_nuclei_t0_first,length(movie_array));
  
  if (do_last_time_sample == 1)
      %index_time = length(mean_x_tot_time_mapped_t0(1,:))
      index_time = length(time_CH1);
      
        % BEGIN: images of the last acquisition time in the experiments
            kkk = index_time;
            which_frame = kkk;

            eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
            eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
            eval(['M_Erk(:,:) = M_CH',num2str(marker_from_channel(ii_Erk_marker)),'_total(:,:,index_time);']);
            eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
            eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
        % END: images of the last acquisition time in the experiments

      index_time = index_frame;
  else
      index_time = 1;
  end;
  
 else
      index_time = 1;
      bPAC_NUCLEUS_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie) = bPAC_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,1);     
 end;    
      pause(1);

  num_nuclei_t0_max = max(num_nuclei_t0_max, num_nuclei_t0);
  mean_x_tot_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie) = mean_x_tot_time_mapped_t0(1:num_nuclei_t0,index_time);
  mean_y_tot_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie) = mean_y_tot_time_mapped_t0(1:num_nuclei_t0,index_time);
  num_nuclei_t0_array(ii_which_movie) = num_nuclei_t0;

  num_time_samples_array(ii_which_movie) = length(time_Erk);
  
  M_NM_d_cAMP(:,:,ii_which_movie) = M_NM(:,:);    
  M_NM_bPAC_d_cAMP(:,:,ii_which_movie) = M_NM_bPAC(:,:);
  M_Erk_d_cAMP(:,:,ii_which_movie) = M_Erk(:,:); 
  
end;



mean_x_tot_time_mapped_t0_array = mean_x_tot_time_mapped_t0_array(1:num_nuclei_t0_max,:);
mean_y_tot_time_mapped_t0_array = mean_y_tot_time_mapped_t0_array(1:num_nuclei_t0_max,:);
bPAC_NUCLEUS_time_mapped_t0_array =  bPAC_NUCLEUS_time_mapped_t0_array(1:num_nuclei_t0_max,:);




cd('../combined_d_cAMP/')
mkdir(strcat('do_case_',num2str(do_case)));
cd(strcat('do_case_',num2str(do_case)))
copyfile('../saveppt2.m','saveppt2.m');
cd(str_processing) 
    
  plot_nuclei_across_movies_d_cAMP
  %pause;
    
  
    


cd('../combined_d_cAMP/')
mkdir(strcat('do_case_',num2str(do_case)));
cd(strcat('do_case_',num2str(do_case)))
copyfile('../saveppt2.m','saveppt2.m');

length_movie_array = length(movie_array);

save('linked_nuclei_across_movies', 'linked_nuclei_across_movies_array','linked_nuclei_across_movies_success','num_nuclei_t0_first','length_movie_array', 'num_nuclei_t0_max','num_time_samples_array','M_NM_d_cAMP','M_NM_bPAC_d_cAMP','M_Erk_d_cAMP','mean_x_tot_time_mapped_t0_array','mean_y_tot_time_mapped_t0_array');

     %delete(strcat(str_movie,'--Erk_average_d_cAMP.ppt'));
     %s_combine = strcat(str_movie,':average Erk signals (pulsing cells)');
     %saveppt2(strcat(str_movie,'-Erk_average_d_cAMP.ppt'),'figure',[fig1112], 'halign','center','title', s_combine);
     %          print('-depsc',strcat(str_movie,'-Erk_average_d_cAMP.eps'));   

       
cd(str_processing) 

           