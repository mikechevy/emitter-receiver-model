% used to throwout the top 'num_throwout' values, to discuard clusters when
% calculating mean and std pixel number
num_throwout_max = 20;

% default, unless we want to look on mixtures of non-bPAC and bPAC cells
do_location_bPAC_nuclei = 0;

% USED TO DETERMIN IF pixel region is small enough to label as single nucleus: if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
fac_std_nuclear_size = -0.5;  % if mean_pix + fac_std_nuclear_size
fac_std_nuclear_size_recursive = -.5;  % if mean_pix + fac_std_nuclear_size

% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% used for determine_cytosolic_regions_per_frame.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this is the the size of the ring around the nucleus for the cytosolic
% signal
scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   do_max_or_shrink_median = 1; % 0-max, 1-shrink median
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .4;
   end;

do_tranfer_function=0;  % this will mostly be the case

%  these are handed to 'determine_nuclear_locations_adaptive_recursive' for
%  extra processing of the segmenting nuclei
do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;

% percentage a bPAC marked nucleus must appear over the movie, used in
% mixed_bPAC_population_analysis.m
fac_bPAC_percentage = .8;
% ratio of area of bPAC_NM to NM, used in mixed_bPAC_population_analysis.m
bPAC_NM_to_NM_ratio = 1.5;

%  bursting periods
period_burst_Ca = 25;  % seconds
period_burst_Erk = 25*60;
%  bursting thresholds
threshold_burst_Ca = 3;
threshold_burst_Erk = 10;

ii_NM_bPAC = [];


do_illumation_map_normalize = 1;  % 1 - yes, 0 - no 



%setup the array that maps the marker from a particular channel
marker_from_channel = zeros(num_different_markers,1);

if which_movie == 1  
    
    str_movie = '160901_198-117_IBMX_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
do_tranfer_function=1;    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    

elseif which_movie == 2 

    str_movie = '160901_198-117_IBMX_2_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM

do_tranfer_function=1;    
    
    
elseif which_movie == 3 
    
    str_movie = '160902_198_198-117_EA'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
fac_bPAC_percentage = .6;

scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .6;
   end;


elseif which_movie == 4

    str_movie = '160902_198_198-117_18a_EA'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
    
elseif which_movie == 5 

    str_movie = '160922_198-117_JP'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM;
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
    
elseif which_movie == 6
   
    str_movie = '160922_198-117_IBMX_JP'
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM;
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
    
elseif which_movie == 7
    
    
    str_movie = '160926_198-117_IBMX_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    
elseif which_movie == 8 

    str_movie = '160926_198-117_IBMX_2_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    
elseif which_movie == 9


    str_movie = '160926_198-117_IBMX_3_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    
    
elseif which_movie == 10

    str_movie = '160930_198-117_alpha18_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    
    
    
elseif which_movie == 11

    str_movie = '160930_198-117_alpha18_2_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    
    
    

elseif which_movie == 12

    str_movie = '161006_198-117_alpha18_IBMX_tf'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    

elseif which_movie == 13

    str_movie = '161006_198-117_alpha18_transfer_function'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
do_tranfer_function=1;    


elseif which_movie == 14
    
    str_movie = '161007_198-117_JP'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
    
elseif which_movie == 15
    
    str_movie = '161007_198-117_H89_JP'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


elseif which_movie == 16
    
    str_movie = '161004_198_198-117_JP'
    
   numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
fac_bPAC_percentage = .6;

scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .6;
   end;
    
elseif which_movie == 17
    
    str_movie = '161004_198_198-117_H89_JP'
    
   numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
fac_bPAC_percentage = .6;

scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .6;
   end;
    
    
elseif which_movie == 18

        str_movie = '160905_198_198-117_JP'
    
   numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
   
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
fac_bPAC_percentage = .6;

scale_factor_nucleus = 1.3;
      scale_factor_nucleus_shrink = .3;  
   % Important shrink parameters
   shrink_factor_max = 4.0;  % maximum shink factor      
   if (do_max_or_shrink_median == 0)
    threshold_shrink = .75;  % used for 
   elseif (do_max_or_shrink_median == 1)
    threshold_shrink = .6;
   end;


elseif which_movie == 19
    
    str_movie = '160920_198-117_DMSO_EA'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
elseif which_movie == 20
    
    str_movie = '160920_198-117_H89_EA'
    
    numCh=7;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    CH6_str = 'BFZP';  % brightfield
    CH7_str = 'BFZN';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    ii_CH6 = 6;
    ii_CH7 = 7;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 0;
    ii_NM_bPAC = ii_NM
    
    
%%  adaptive threshold local dimensions
%delta_xDim = 200;
%delta_yDim = 200;
%delta_xDim_step = 20;
%delta_yDim_step = 20;
%do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
    
    
elseif which_movie == 21

elseif which_movie == 22

elseif which_movie == 23

elseif which_movie == 24

elseif which_movie == 25

elseif which_movie == 26

elseif which_movie == 27

elseif which_movie == 28

elseif which_movie == 29

elseif which_movie == 30

elseif which_movie == 100  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '031016_mwc_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM
    

elseif which_movie == 101  % mixed MDCK and MDCK+bPAC cells
    
    %str_movie = '031416_mwc_198_198-117'
    str_movie = '031416_mwc_198_198-117_same'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

    
elseif which_movie == 102  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042216_mwc_198_198-117_caroxolene_2'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
% percentage a bPAC marked nucleus must appear over the movie, used in
% mixed_bPAC_population_analysis.m
fac_bPAC_percentage = .5;
% ratio of area of bPAC_NM to NM, used in mixed_bPAC_population_analysis.m
bPAC_NM_to_NM_ratio = 1.8;
    
elseif which_movie == 103  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042216_mwc_198_198-117_caroxolene_1'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    


bPAC_ledvals =  [zeros(1,40) 255*ones(1,40) zeros(1,40)];
time_bPAC = 0:60:7140;
seconds_per_frame;

elseif which_movie == 104  % mixed MDCK and MDCK+bPAC cells
 
    
    
    str_movie = '160421bpac-ERKKTR-PRKACA-H89'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_Pka_marker) = ii_CH2;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;

    
elseif which_movie == 105  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042916_mwc_198_198-117_IBMX_1.3'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

    
    
elseif which_movie == 106  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050316_mwc_198_198-117_IBMX_1.5'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
elseif which_movie == 107  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '160422mixbpac-ERKKTR-PRKACA-H89'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_Pka_marker) = ii_CH2;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;

    
end;    





