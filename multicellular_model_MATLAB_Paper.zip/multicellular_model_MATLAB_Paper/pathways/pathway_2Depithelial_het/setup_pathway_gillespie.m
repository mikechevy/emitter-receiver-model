%  INDEX MAP OF REACTIONS
%   1 - * -> reaction products
%   2 - S_j -> reaction products
%   3 - S_j + S_k -> reaction products (j~=k)
%   4 - 2 S_j -> reaction products
%   5 - S_i + S_j + S_k -> reaction products (i~=j~=k)
%   6 - S_j + 2 S_k -> (j~=k)
%   7 - 3 S_j
%   12 - (S_j0-S_j) -> reaction products, difference between inital value and current
%   13 - (S_j0-S_j)/2 -> reaction products, difference between inital value and current (dimer version)
%   20 - (S_k0/(S_k0+S_i))^2  2 S_j  - competition theory UPR, module 1
%   21 - f(S_i,S_j)   2 S_j - 
%   30 - S_i^n/(a0 + S_i^n)  - gene regulation function #1 (Hill function
%   31 - (S_i0-S_i)^2/(a0 + a1*(S_i0-S_i) + (S_i0-S_i)^2)  - gene regulation function #2
%   32 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #3
%   50 - min((S_i0-S_i)/2, S_j)  - gene regulation function #3


num_molecules = ii_xmax; % total number of molecules (including complexes), i.e. total number of equations in system

stochasticity = zeros(1,num_molecules);  % initialize the stochastic index array
stochasticity_conj = zeros(1,num_molecules);  % initialize the stochastic conjugate index array



  if (which_pathway==0)
    num_reactions = 16;
    
          alpha_A = passed_constants(1);
          alpha_prime_A = passed_constants(2);
          alpha_R = passed_constants(3);
          alpha_prime_R = passed_constants(4);
          beta_A = passed_constants(5);
          beta_R = passed_constants(6);
          delta_MA = passed_constants(7);
          delta_MR = passed_constants(8);
          delta_A = passed_constants(9);
          delta_R = passed_constants(10);
          gamma_A = passed_constants(11);
          gamma_R = passed_constants(12);
          gamma_C = passed_constants(13);
          theta_A = passed_constants(14);
          theta_R = passed_constants(15);
 

%          D_A = y(1);
%          D_R = y(2);
%          D_prime_A = y(3);
%          D_prime_R = y(4);
%          M_A = y(5);
%          M_R = y(6);
%          A = y(7);
%          R = y(8);
%          C = y(9);

          ii_D_A = 1;
          ii_D_R = 2;
          ii_D_prime_A = 3;
          ii_D_prime_R = 4;
          ii_M_A = 5;
          ii_M_R = 6;
          ii_A = 7;
          ii_R = 8;
          ii_C = 9;

%        %  equations
%          y_prime(1) = theta_A*D_prime_A -gamma_A*D_A*A;
%          y_prime(2) = theta_R*D_prime_R -gamma_R*D_R*A;
%
%          y_prime(3) = -theta_A*D_prime_A +gamma_A*D_A*A;
%          y_prime(4) = -theta_R*D_prime_R +gamma_R*D_R*A;
%
%          y_prime(5) = alpha_prime_A*D_prime_A + alpha_A*D_A - delta_MA*M_A;
%          y_prime(6) = alpha_prime_R*D_prime_R + alpha_R*D_R - delta_MR*M_R;
%
%          y_prime(7) =  beta_A*M_A + theta_A*D_prime_A + theta_R*D_prime_R...
%                       -A*(gamma_A*D_A + gamma_R*D_R + gamma_C*R + delta_A);
%
%          y_prime(8) = beta_R*M_R - gamma_C*A*R + delta_A*C - delta_R*R;
%
%          y_prime(9) = gamma_C*A*R - delta_A*C;



  elseif (which_pathway==1)  % to determined
      
    num_reactions = 13+1+2+do_feedback*2+do_global*14 + 6*do_cross_talk;

          ii_X = 1;
          ii_M_Y = 2;
          ii_Y = 3;
          ii_TF_on = 4;
          ii_TF_off = 5;
          ii_I_stress = 6;
    

          beta_M_Y = passed_constants(1);
          n_hill = passed_constants(2);
          X_hill = passed_constants(3);
          gamma_M_Y = passed_constants(4);
          beta_Y = passed_constants(5);
          gamma_Y = passed_constants(6);
          beta_TF_on = passed_constants(7);
          beta_TF_off = passed_constants(8);
          fac_hill_basal = passed_constants(9);
          k_Y_TF_on = passed_constants(10);
          gamma_Y_TF_on = passed_constants(11);
          gamma_Y_stress = passed_constants(12);
          n_hill_stress = passed_constants(13);
          X_hill_stress = passed_constants(14); 
          beta_I_stress = passed_constants(15);
          gamma_I_stress = passed_constants(16);
          beta_TF_on_0 = passed_constants(17);
          gamma_TF_on = passed_constants(18);
          gamma_TF_off = passed_constants(19);

                    

          
          
  elseif (which_pathway==2)  % to determined
      
  end;

  
  
non_stochastic = zeros(1,num_reactions);  % for hybrid, initialize array for reactions that are always non-stochastic reactions
molecule_gene = zeros(1,num_molecules);  % for hybrid, initialize array for molecules that are to be labelled as genes

      % some reaction constants
      kappa = zeros(num_reactions,1);
      a_0_eff = zeros(num_reactions,1);
      a_1_eff = zeros(num_reactions,1);
      eta_0_eff = zeros(num_reactions,1);
      eta_1_eff = zeros(num_reactions,1);
      n_eff = zeros(num_reactions,1);
      a_0 = zeros(num_reactions,1);
      a_1 = zeros(num_reactions,1);
      a_2 = zeros(num_reactions,1);
      a_3 = zeros(num_reactions,1);
      a_4 = zeros(num_reactions,1);
      a_5 = zeros(num_reactions,1);
      a_6 = zeros(num_reactions,1);
      a_7 = zeros(num_reactions,1);
      a_8 = zeros(num_reactions,1);
      a_9 = zeros(num_reactions,1);
  
% species constants
species1 = 1;
species2 = 2;
species3 = 3;
species4 = 4;

%  This array defines the particular molecules involved for a given reaction
reaction_molecules = zeros(num_reactions,num_molecules+2);

%  This array defines the number of a particular molecule involved for a given reaction
%  it also defines the sign (lost or gained) of particular molecule involved for a given reaction
sign_value_reaction = zeros(num_reactions,num_molecules);

%  This array defines the reaction_constant, h_mu*c_mu (Gillespie,1976), for a reaction
%  due to concentration levels changing the values are always changing.
%reaction_constant = zeros(num_reactions,1);
propensities = zeros(num_reactions,1);


last_reaction = 0;  % start at zero
%-----------------------------------------------
% REACTIONS:
%-----------------------------------------------

if (which_pathway == 0)

          % ii_D_A = 1;
          % ii_D_R = 2;
          % ii_D_prime_A = 3;
          % ii_D_prime_R = 4;
          % ii_M_A = 5;
          % ii_M_R = 6;
          % ii_A = 7;
          % ii_R = 8;
          % ii_C = 9; which_pathway==9
          % ii_A_repressed = 9; which_pathway==9

% reactions 1,2,3,4 will always be mass action in the hybrid
   non_stochastic(1) = 0;
   non_stochastic(2) = 0;
   non_stochastic(3) = 0;
   non_stochastic(4) = 0;
% molecules 1,2,3,4 are gene states
   molecule_gene(1) = 1;  % gene 1  - D_A
   molecule_gene(2) = 2;  % gene 2  - D_R
   molecule_gene(3) = 1;  % gene 1  - D_prime_A
   molecule_gene(4) = 2;  % gene 2  - D_prime_R
    if (which_pathway==2)
      molecule_gene(9) = 1;  % gene 2  - D_A_repressed
    end;
   
    
   % reaction 1:  theta_A D_prime_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_A switches to D_A
     reaction_type(which_reaction) = 2;
   % D_prime_A is the input species 
     which_mol = ii_D_prime_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 D_A,A molecule gained, 1 D_prime_A molecule lost
     which_mol = ii_D_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_D_prime_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = theta_A;

   % reaction 2:  gamma_A D_A A -> D_prime_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_A, A -> D_prime_A
     reaction_type(which_reaction) = 3;
   % D_A and A the input species 
     which_mol = ii_D_A;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ii_A;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 D_prime_A molecule gained, 1 D_A molecule lost, 1 A molecule lost
     which_mol = ii_D_prime_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_D_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
        c_mu(which_reaction) = gamma_A;

   % reaction 3:  theta_R D_prime_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_R switches to D_R
     reaction_type(which_reaction) = 2;
   % D_prime_R is the input species 
     which_mol = ii_D_prime_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 D_R,A molecule gained, 1 D_prime_R moleecule lost
     which_mol = ii_D_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_D_prime_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = theta_R;

   % reaction 4:  gamma_R D_R A -> D_prime_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_R A -> D_prime_R
     reaction_type(which_reaction) = 3;
   % D_R and A the input species 
     which_mol = ii_D_R;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ii_A;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 D_prime_R molecule gained, 1 D_R molecule lost, 1 A molecule lost
     which_mol = ii_D_prime_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_D_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ii_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_R;

   % reaction 5:  alpha_prime_A D_prime_A produce M_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_A transcribes M_A
     reaction_type(which_reaction) = 2;
   % D_prime_A is the input species 
     which_mol = ii_D_prime_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_A molecule gained
     which_mol = ii_M_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_prime_A;

   % reaction 6:  alpha_A D_A produce M_A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_A transcribes M_A
     reaction_type(which_reaction) = 2;
   % D_A is the input species 
     which_mol = ii_D_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_A molecule gained
     which_mol = ii_M_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_A;


   % reaction 7:  delta_MA M_A  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_A decays
     reaction_type(which_reaction) = 2;
   % M_A is the input species 
     which_mol = ii_M_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_A molecule lost 
     which_mol = ii_M_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_MA;
     
   % reaction 8:  alpha_prime_R D_prime_R transcribes M_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_prime_R transcribes M_R
     reaction_type(which_reaction) = 2;
   % D_prime_R is the input species 
     which_mol = ii_D_prime_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_R molecule gained
     which_mol = ii_M_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_prime_R;

   % reaction 9:  alpha_R D_R transcribes M_R
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: D_R transcribes M_R
     reaction_type(which_reaction) = 2;
   % D_R is the input species 
     which_mol = ii_D_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_R molecule gained
     which_mol = ii_M_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = alpha_R;

   % reaction 10:  delta_MR M_R  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_R decays
     reaction_type(which_reaction) = 2;
   % M_R is the input species 
     which_mol = ii_M_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_R molecule lost 
     which_mol = ii_M_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_MR;

   % reaction 11:  beta_A M_A produce A
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_A translates A
     reaction_type(which_reaction) = 2;
   % M_A is the input species 
     which_mol = ii_M_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 A molecule gained
     which_mol = ii_A;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_A;

       % reaction 12:  gamma_C A R produces C
          which_reaction = last_reaction+1;
          last_reaction = last_reaction+1; 
       % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
         stochasticity(which_reaction) = 1;
       % type of reaction: A,R produce C 
         reaction_type(which_reaction) = 3;
       % A,R is the input species 
         which_mol = ii_A;
         reaction_molecules(which_reaction,species1) = which_mol;
         which_mol = ii_R;
         reaction_molecules(which_reaction,species2) = which_mol;
       % 1 C molecule gained, 1 A, 1 R lost
         which_mol = ii_C;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
         which_mol = ii_A;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
         which_mol = ii_R;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % reaction_constant
         c_mu(which_reaction) = gamma_C;

   % reaction 13:  delta_A A  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: A decays
     reaction_type(which_reaction) = 2;
   % A is the input species 
     which_mol = ii_A;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 A molecule lost 
     which_mol = ii_A;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_A;

   % reaction 14:  beta_R M_R produce R 
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_R translates R
     reaction_type(which_reaction) = 2;
   % M_R is the input species 
     which_mol = ii_M_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 R molecule gained
     which_mol = ii_R;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_R;

       % reaction 15:  delta_A C  (decay)  produces only R (A decays)
          which_reaction = last_reaction+1;
          last_reaction = last_reaction+1; 
       % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
         stochasticity(which_reaction) = 1;
       % type of reaction: A decays
         reaction_type(which_reaction) = 2;
       % C is the input species 
         which_mol = ii_C;
         reaction_molecules(which_reaction,species1) = which_mol;
       % 1 C molecule lost , 1 R is gaines
         which_mol = ii_C;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
         which_mol = ii_R;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % reaction_constant
         c_mu(which_reaction) = delta_A;

   % reaction 16:  delta_R R  (decay)
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: R decays
     reaction_type(which_reaction) = 2;
   % R is the input species 
     which_mol = ii_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 R molecule lost 
     which_mol = ii_R;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = delta_R;



elseif (which_pathway ==1)|(which_pathway==2)  % Jacob's circuit

   % reaction 1:  0 -> M_Y
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> M_Y
     reaction_type(which_reaction) = 30;
   % TF_on the input species 
     which_mol = ii_TF_on;
     %which_mol = ii_X;  % test
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_Y molecule gained
     which_mol = ii_M_Y;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = fac_hill_basal*beta_M_Y;
     a_0(which_reaction) = n_hill;
     a_1(which_reaction) = X_hill;
     
   % reaction 2:  0 -> M_Y
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> M_Y
     reaction_type(which_reaction) = 1;
   % 1 M_Y molecule gained
     which_mol = ii_M_Y;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = (1-fac_hill_basal)*beta_M_Y;

   % reaction 3:  M_Y -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_Y -> 0
     reaction_type(which_reaction) = 2;
   % M_Y the input species 
     which_mol = ii_M_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_Y molecule lost 
     which_mol = ii_M_Y;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_M_Y;

   % reaction 4:  0 -> Y
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   if (do_global == 1) 
   % type of reaction: 0 -> Y
     reaction_type(which_reaction) = 3;
   % M_Y the input species 
     which_mol = ii_M_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species2) = which_mol;
   else
   % type of reaction: 0 -> Y
     reaction_type(which_reaction) = 2;
   % M_Y the input species 
     which_mol = ii_M_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   end;
   % 1 Y molecule gained
     which_mol = ii_Y;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_Y/G_mean_shift;

   % reaction 5:  Y -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: Y -> 0
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 Y molecule lost
     which_mol = ii_Y;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_Y;

   % reaction 6:  Y -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: Y -> 0
     reaction_type(which_reaction) = 41;
   % Y the input species 
     which_mol = ii_Y
     reaction_molecules(which_reaction,species1) = which_mol;
   % I_stress the input species 
     which_mol = ii_I_stress;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 Y molecule lost
     which_mol = ii_Y;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_Y_stress;
     a_0(which_reaction) = n_hill_stress;
     a_1(which_reaction) = X_hill_stress;     
     
     
   % reaction 7:  TF_off -> TF_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: TF)off -> TF_on
     reaction_type(which_reaction) = 3;
   % X the input species 
     which_mol = ii_X;
     reaction_molecules(which_reaction,species1) = which_mol;
   % TF_off the input species 
     which_mol = ii_TF_off;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 TF_off molecule lost
     which_mol = ii_TF_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % 1 TF_on molecule gained
     which_mol = ii_TF_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_on;

        
     
     
   % reaction 8:  TF_on -> TF_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: Y -> 0
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_TF_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_off molecule gained
     which_mol = ii_TF_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % 1 TF_on molecule lost
     which_mol = ii_TF_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off;

     
 if (do_cross_talk==1)     
   % reaction 7:  R_on + TF_on -> R_on + TF_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: R_on + TF_on -> R_on + TF_off
     reaction_type(which_reaction) = 3;
   % X the input species 
     which_mol = ii_R_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % TF_off the input species 
     which_mol = ii_TF_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 TF_off molecule lost
     which_mol = ii_TF_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % 1 TF_on molecule gained
     which_mol = ii_TF_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off*fac_R_on;
 end;     
     

if (do_global == 0)    

    % reaction 9:  0-> TF_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   if (do_global == 1) 
   % type of reaction: 0->TF_off 
     reaction_type(which_reaction) = 2;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species1) = which_mol;
   else
%% type of reaction: 0->TF_off 
     reaction_type(which_reaction) = 1;
   end;
   % 1 TF_off molecule lost
     which_mol = ii_TF_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off_0/G_mean_shift;

elseif (do_global == 1)
    
   % reaction 2:  0 -> M_TF_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> M_TF_off
     reaction_type(which_reaction) = 1;
   % 1 M_TF_off molecule gained
     which_mol = ii_M_TF_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_M_TF_off;

   % reaction 3:  M_TF_off -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_TF_off -> 0
     reaction_type(which_reaction) = 2;
   % M_TF_off the input species 
     which_mol = ii_M_TF_off;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_TF_off molecule lost 
     which_mol = ii_M_TF_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_M_TF_off;
    
   % reaction 9:  0-> TF_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   if (do_global == 1) 
   % type of reaction: 0->TF_off 
     reaction_type(which_reaction) = 3;
   % G, M_TF_off are the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ii_M_TF_off;
     reaction_molecules(which_reaction,species2) = which_mol;
   else
   % type of reaction: 0->TF_off 
     reaction_type(which_reaction) = 2;
   % M_TF_off are the input species
     which_mol = ii_M_TF_off;
     reaction_molecules(which_reaction,species1) = which_mol;
   end;
   % 1 TF_off molecule gained
     which_mol = ii_TF_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off_0/G_mean_shift;
     
end;     
     
     
     
     
   % reaction 10:  TF_off -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: TF_off -> 0
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_TF_off;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_off molecule gained
     which_mol = ii_TF_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_TF_off;

   % reaction 11:  TF_on -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: TF_on -> 0
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_TF_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_off molecule gained
     which_mol = ii_TF_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_TF_on;
         

     
 if (do_cross_talk==1)     
   % reaction 7:  R_off -> R_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: R_off -> R_on
     reaction_type(which_reaction) = 3;
   % X the input species 
     which_mol = ii_X_R;
     reaction_molecules(which_reaction,species1) = which_mol;
   % TF_off the input species 
     which_mol = ii_R_off;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 TF_off molecule lost
     which_mol = ii_R_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % 1 TF_on molecule gained
     which_mol = ii_R_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_on;

   % reaction 8:  R_on -> R_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction:
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_R_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_off molecule gained
     which_mol = ii_R_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % 1 TF_on molecule lost
     which_mol = ii_R_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off;
     
   % reaction 9:  0-> R_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   if (do_global == 1) 
   % type of reaction: 0->R_off 
     reaction_type(which_reaction) = 2;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species1) = which_mol;
   else
   % type of reaction: 0->R_off 
     reaction_type(which_reaction) = 1;
   end;
   % 1 R_off molecule gained
     which_mol = ii_R_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off_0/G_mean_shift;
     
   % reaction 10:  R_off -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: R_off -> 0
     reaction_type(which_reaction) = 2;
   % R_off the input species 
     which_mol = ii_R_off;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 R_off molecule gained
     which_mol = ii_R_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_TF_off;

   % reaction 11:  R_on -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: R_on -> 0
     reaction_type(which_reaction) = 2;
   % R_on the input species 
     which_mol = ii_R_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_off molecule gained
     which_mol = ii_R_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_TF_on;
         
end      
    
     
if (do_state_irreversible == 0)         
   % reaction 12:  0 -> I_stress
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   if (do_global == 1) 
   % type of reaction: 0 -> Y
     reaction_type(which_reaction) = 3;
   % Y the input species 
     which_mol = ii_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species2) = which_mol;
   else
   % type of reaction: 0 -> Y
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   end;
   % 1 I_stress molecule gained
     which_mol = ii_I_stress;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_I_stress/G_mean_shift;
elseif (do_state_irreversible == 1)
   % reaction :  0 -> I_stress
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> I_stress
     reaction_type(which_reaction) = 60;   % hill function-activator (2 species sum)
   % Y the input species 
     which_mol = ii_Y
     reaction_molecules(which_reaction,species1) = which_mol;
   % I_stress the input species 
     which_mol = ii_I_stress;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 I_stress molecule gained
     which_mol = ii_I_stress;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_I_stress;
     a_0(which_reaction) = n_I_stress;
     a_1(which_reaction) = X_I_stress;         
end;

     
     
     
   % reaction 13:  I_stress -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: I_stress -> 0
     reaction_type(which_reaction) = 2;
   % I_stress the input species 
     which_mol = ii_I_stress;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 I_stress molecule lost
     which_mol = ii_I_stress;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_I_stress;
     
   % reaction 14:  dX/dt
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: I_stress -> 0
     reaction_type(which_reaction) = 1;
   % I_stress the input species 
     which_mol = ii_X;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 I_stress molecule lost
     which_mol = ii_X;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = 0;  % this is altered in pathway specific function
         ii_reaction_dX_dt = which_reaction;

         
   if (do_global==1)  
       
       
   % reaction 2:  0 -> M_TF_GFP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> M_TF_GFP
     reaction_type(which_reaction) = 1;
   % 1 M_TF_GFP molecule gained
     which_mol = ii_M_TF_GFP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_M_TF_off;

   % reaction 3:  M_TF_GFP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_TF_GFP -> 0
     reaction_type(which_reaction) = 2;
   % M_TF_GFP the input species 
     which_mol = ii_M_TF_GFP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_TF_GFP molecule lost 
     which_mol = ii_M_TF_GFP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_M_TF_off;
    
   % reaction 9:  0-> TF_GFP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0->TF_GFP 
     reaction_type(which_reaction) = 3;
   % G, M_TF_GFP the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ii_M_TF_GFP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 TF_off molecule lost
     which_mol = ii_TF_GFP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off_0/G_mean_shift;
            
   % reaction 10:  TF_GFP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: TF_GFP -> 0
     reaction_type(which_reaction) = 2;
   % TF_GFP the input species 
     which_mol = ii_TF_GFP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_GFP molecule gained
     which_mol = ii_TF_GFP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_TF_FP;
     
   % reaction 2:  0 -> M_TF_RFP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> M_TF_RFP
     reaction_type(which_reaction) = 1;
   % 1 M_TF_RFP molecule gained
     which_mol = ii_M_TF_RFP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_M_TF_off;

   % reaction 3:  M_TF_RFP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: M_TF_RFP -> 0
     reaction_type(which_reaction) = 2;
   % M_TF_RFP the input species 
     which_mol = ii_M_TF_RFP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 M_TF_RFP molecule lost 
     which_mol = ii_M_TF_RFP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_M_TF_off;
    
   % reaction 9:  0-> TF_RFP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0->TF_RFP 
     reaction_type(which_reaction) = 3;
   % G, M_TF_RFP the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ii_M_TF_RFP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 TF_off molecule gained
     which_mol = ii_TF_RFP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_TF_off_0/G_mean_shift;

     
     
     
   % reaction 10:  TF_RFP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: TF_RFP -> 0
     reaction_type(which_reaction) = 2;
   % TF_RFP the input species 
     which_mol = ii_TF_RFP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 TF_RFP molecule lost
     which_mol = ii_TF_RFP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_TF_FP;
       
       
   % reaction 4:  0 -> Y_GFP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> Y_GFP
     reaction_type(which_reaction) = 3;
   % M_Y the input species 
     which_mol = ii_M_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 Y_GFP molecule gained
     which_mol = ii_Y_GFP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_Y/G_mean_shift;

   % reaction 5:  Y_GFP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: Y_GFP -> 0
     reaction_type(which_reaction) = 2;
   % Y the input species 
     which_mol = ii_Y_GFP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 Y_GFP molecule lost
     which_mol = ii_Y_GFP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_Y;


   % reaction 4:  0 -> Y_RFP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> Y_RFP
     reaction_type(which_reaction) = 3;
   % M_Y the input species 
     which_mol = ii_M_Y;
     reaction_molecules(which_reaction,species1) = which_mol;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 Y_RFP molecule gained
     which_mol = ii_Y_RFP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_Y/G_mean_shift;

   % reaction 5:  Y_RFP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: Y_RFP -> 0
     reaction_type(which_reaction) = 2;
   % Y_RFP the input species 
     which_mol = ii_Y_RFP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 Y molecule lost
     which_mol = ii_Y_RFP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_Y;
     
     
     
    % reaction 9:  0 -> G
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 0 -> G
     reaction_type(which_reaction) = 1;
   % No input species 
   % 1 G state molecule gained
     which_mol = ii_G;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = beta_G;

   % reaction 10:  G -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: G -> 0
     reaction_type(which_reaction) = 2;
   % G the input species 
     which_mol = ii_G;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 G molecule lost
     which_mol = ii_G;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_G;
   end; % if (do_global==1)     
         
         
     
   if (do_feedback==1)     
       % reaction 8:  Y+T_F_on -> Y_TF_on
          which_reaction = last_reaction+1;
          last_reaction = last_reaction+1; 
       % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
         stochasticity(which_reaction) = 1;
       % type of reaction: Y+T_F_on -> Y_TF_on
         reaction_type(which_reaction) = 3;
       % TF_on the input species 
         which_mol = ii_TF_on;
         reaction_molecules(which_reaction,species1) = which_mol;
       % Y the input species 
         which_mol = ii_Y;
         reaction_molecules(which_reaction,species2) = which_mol;
       % 1 TF_on molecule lost
         which_mol = ii_TF_on;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % 1 Y molecule lost
         which_mol = ii_Y;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % 1 Y_TF_on molecule gained
         which_mol = ii_Y_TF_on;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % reaction_constant
         c_mu(which_reaction) = k_Y_TF_on;

       % reaction 9:  Y_TF_on -> Y+TF_on
          which_reaction = last_reaction+1;
          last_reaction = last_reaction+1; 
       % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
         stochasticity(which_reaction) = 1;
       % type of reaction: Y_TF_on -> Y+TF_on
         reaction_type(which_reaction) = 2;
       % Y_TF_on the input species 
         which_mol = ii_Y_TF_on;
         reaction_molecules(which_reaction,species1) = which_mol;
       % 1 TF_on molecule gained
         which_mol = ii_TF_on;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % 1 Y molecule gained
         which_mol = ii_Y;
         sign_value = 1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % 1 XY molecule lost
         which_mol = ii_Y_TF_on;
         sign_value = -1;
         sign_value_reaction(which_reaction,which_mol) = sign_value;
       % reaction_constant
         c_mu(which_reaction) = gamma_Y_TF_on;
   end;
              
         
    if (which_pathway==2)  % coupling pathway here
   
   
    end;

    
elseif (which_pathway==3)  % 2 input, protein web, transcriptional feedback

         
    
elseif (which_pathway==4)

end;
     
     
     
% initialize the stochasticity_conj array

for ii = 1:length(stochasticity)
  if (stochasticity(ii)==1)
      stochasticity_conj(ii)=0;
  else
      stochasticity_conj(ii)=1;
  end;
end;

%  1st 2nd derivative matrix:  NOTE THIS NEEDS TO BE SET AS GLOBAL AND
%  TRANSFERED TO AN INITIALIZATION FUNCTION
der_1_r = zeros(num_reactions, num_molecules);
der_1_unr = zeros(num_reactions, num_molecules);
der_2_r = zeros(num_molecules, num_molecules);
der_2_unr = zeros(num_molecules, num_molecules);

species_restricted = ones(num_molecules,1);
species_restricted_conj = zeros(num_molecules,1);
species_cov = ones(num_molecules,1);
species_cov_conj = zeros(num_molecules,1);

x_ref = zeros(num_molecules,1);

%  This setups the propensity derivative maps, used for the moment calculations in the hybrid code
setup_propensity_map;

         % GAUSSIAN setup
              x_cdf_norm = zeros(length_cdf_norm,1);
              cdf_norm = zeros(length_cdf_norm,1);
              delx_cdf_norm = 2.0*abs(x_cdf_norm_min)/(length_cdf_norm-1);
             for ii=1:length_cdf_norm
              x_cdf_norm(ii) = x_cdf_norm_min+(ii-1)*delx_cdf_norm;
              cdf_norm(ii) = 1.0-erfc(x_cdf_norm(ii))/2.0;
             end;
