


 M_IF = 0*int16(IM);

 for kk = 1:numFr_CH(ii_IF)

 eval(['M_IF(:,:) = M_IF(:,:) + M_CH',num2str(ii_IF),'_total(:,:,kk);']); 
    
 end;

 M_IF = double(M_IF)/double(max(max(M_IF)));

 figure(100)
 imagesc(M_IF)

 
save(strcat(str_movie_processed,'\illumination_map.mat'),'M_IF');