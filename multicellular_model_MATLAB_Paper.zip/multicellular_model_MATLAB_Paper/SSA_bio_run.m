if (read_rand == 1)
  load_random_file;
end;



% output file stuff
output_file_stuff_open;

total_time = sum(time_u_array);
length_time_u_array = length(time_u_array);
    
for kkk = 1:num_runs  %  number of times to run gillespie
    
% Output file stuff
count_data = 0;
count_data_total = 0;
count_data_sampled = 0;
count_data_sampled_total = 0;
time_data_final = 0;
count_data_mean = 0;
count_data_mean_total = 0;
time_data_mean_final = 0;

% ssa-gillespie variables
time = 0;
max_time = 0;
count_reactions = 0;

   y_0_ma = y_0ss;   % input for mass action equations

      Cov_mat = zeros(num_molecules,num_molecules); % create covariance matrix

      %options = odeset('BDF','on','MaxOrder',5,'AbsTol',1e-4,'RelTol',1e-3);
      options = odeset('AbsTol',1e-6,'RelTol',1e-6);
          if (do_mean_or_full==0)
             calc_mean_ss_initial;
          end;

          
for iii = 1:length_time_u_array  %  loop through the source sequence
kkk
iii

        
    
       max_moment_error = 0;  % initalize moment error before each time step

       % these are used to tranistion the time varying propensities within the ode solver
       which_time_segment = iii;
       which_time_segment_next = iii+1;
        if (do_mean_or_full>=0)&(do_prop_time_vary==1)
         set_time_varying_arrays;  % sets c_mu,c_mu_0, etc
        end;

      % pathway_specific_function call
      if (do_pathway_specific_function==1)
        cd(pathway_str);
         pathway_specific_function
        cd ../../
      end;

    
    t_max = time_u_array(iii);
           
       if (do_mean_or_full>=0)
           
          if (do_mean_or_full==0)
            if (kkk==1)|(do_numerous_mean_runs==1)  % only run once
             just_mean_theory_gillespie;
             x_0_mean = x_mean(length(time_mean),:);
            end;
          else
              if (iii==1)  % initial conditions
                y_g = y_0ss;
              else
                y_g = x_g(length(x_g(:,1)),:);
              end;

                run_gillespie;
          end;
           
        end;

%   Run the equations programmed in fun_pathway.m        
            if (kkk==1)  % only run once, if running gillespie numerous times
                       if (do_mean_or_full==-1)
                            max_time = max_time+t_max;
                       end;
                cd(pathway_str);       
               %[time_ma,y_ma] = ode45(ode_fun_pathway_str,[max_time-t_max max_time],y_0_ma);
               %[time_ma,y_ma] = ode23s(ode_fun_pathway_str,[max_time-t_max max_time],y_0_ma);
              if (do_mean_or_full==-1)
               [time_ma,y_ma] = ode15s('ode_fun_pathway',[max_time-t_max max_time],y_0_ma,options);
              end;
               %[time_ma,y_ma] = ode15s('ode_fun_pathway',[max_time-t_max max_time],y_0_ma);
                cd ../../;;       
            end;     
     
            if (do_mean_or_full==-1)
             y_0_ma = y_ma(length(time_ma),:);  % input for mass action equations
            end;

            if (iii==1)
             if (do_mean_or_full==-1)
              y_ma_t = y_ma;
              time_ma_t = time_ma;
             end;
             if (do_mean_or_full>=0)
              x_mean_t = x_mean;
              time_mean_t = time_mean;
             end; 
            else 
             if (do_mean_or_full==-1)
              y_ma_t = [y_ma_t; y_ma];
              time_ma_t = [time_ma_t; time_ma];
             end;
             if (do_mean_or_full>=0)
              x_mean_t = [x_mean_t; x_mean];
              time_mean_t = [time_mean_t; time_mean];
             end; 
            end;
       

end;  % for iii=1:length(time_u_array)

% output file stuff
output_file_stuff_1;  %  output states into file

% sample y_ma_t
output_file_stuff_mean;

     %  saves the final state of each run
     if (do_mean_or_full==1)
      if (kkk==1)
       y_array = x_g(length(time_g),:);
      else
       y_array = [y_array ;x_g(length(time_g),:)];
      end;
     end;
    
end;  %  kkk - loop for averaging stochastic runs

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
%  END:  Calculating pathway dynamics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         

% Output file stuff
output_file_stuff_close;
