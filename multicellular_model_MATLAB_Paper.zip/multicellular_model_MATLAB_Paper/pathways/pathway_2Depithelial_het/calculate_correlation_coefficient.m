function  corr_Y_X_cond = calculate_correlation_coefficient(P_Y_X,Y_1,Y_2);


mu_Y_1 = 0;
mu_Y_2 = 0;

var_Y_1 = 0;
var_Y_2 = 0;

cov_Y_1_Y_2 = 0;

for ii = 1:length(Y_1)
mu_Y_1 = mu_Y_1 + Y_1(ii)*sum(P_Y_X(ii,:));
end;
for ii = 1:length(Y_1)
var_Y_1 = var_Y_1 + power(Y_1(ii)-mu_Y_1,2)*sum(P_Y_X(ii,:));
end;

for jj = 1:length(Y_2)
mu_Y_2 = mu_Y_2 + Y_2(jj)*sum(P_Y_X(:,jj));
end;
for jj = 1:length(Y_2)
var_Y_2 = var_Y_2 + power(Y_2(jj)-mu_Y_2,2)*sum(P_Y_X(:,jj));
end;


for ii = 1:length(Y_1)
for jj = 1:length(Y_2)
cov_Y_1_Y_2 = cov_Y_1_Y_2 + (Y_1(ii)-mu_Y_1)*(Y_2(jj)-mu_Y_2)*P_Y_X(ii,jj);
end;
end;

mu_Y_1;
mu_Y_2;
cov_Y_1_Y_2;
var_Y_1;
var_Y_2;

corr_Y_X_cond = cov_Y_1_Y_2/sqrt(var_Y_1*var_Y_2);