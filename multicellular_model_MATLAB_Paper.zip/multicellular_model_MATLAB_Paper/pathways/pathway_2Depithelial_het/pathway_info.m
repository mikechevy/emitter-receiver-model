         use_timeseries = 0;  % use cdf-timeseries,  This is the ON/OFF time series for the ON-cdf and OFF-cdf.
       
     do_setup_and_run = 1;  % 0 - just setup, 1 - both
     do_ssa_hybrid = 1;  % This is in preparation for the integration with PIC-BIO. For now it stays 1.
     do_particles = 0;  % This is in preparation for the integration with PIC-BIO. For now it stays 0.
     subgrid_fac = 1;  % this is the number of subgrid timesteps, typically realated to subpart_fac. 
     do_no_particle_overlap = 1;  % 1-particle's initial states do not overlap, 0 doesn't matter
     do_specific_placement = 0;  % 1 - specific particle placement, 0 - no

       num_particle_files = 1;  % this is the number of different randomly generated files for the initial starting positions of the particles
         which_random_walk = 0;   %  0 - piecewise constant, 1 - gaussian (diffusion green's function

     do_read_file = 0;  % 1 - read from a previously setup system
     read_rand = 0;  % 0 - use random number generator,  1 - read from a previously generated random number file
     do_print_debug = 0;  % this prints out variables to the screen for debugging purposes
     do_pathway_specific_function = 1;  % makes a pathway specific functin call in the middle of the time segment stepping

              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%  MOMENT DATA CALCULATIONS Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
do_include_moment_data = 0;  % 0 - no, 1 - yes, include experimental moment data


     if (which_pathway==0) % genetic oscillator
     elseif (which_pathway==1) % Jacob's circuit
     elseif (which_pathway==2) % transcriptional oscillator
     end;
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%  SSA RUN and OUTPUT Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
     do_mean_or_full = 0;   % 1- full gillespie,  0 - mean or just mean (mass-action),  -1 - nothing
     which_gillespie = 0;   %  0 - gillespie.m, 1 - gillespie_hybrid_old.m, 2 - gillespie_hybrid.m, eventually only use gillespie_hybrid.m
     do_adaptive_hybrid = 0;   % 0- Gillespie only, 1- Gillespie/Moments Hybrid
     do_zero_order_hybrid=0;  %  1 - old (Mike's original method), 0 - new hybrid method
     do_covariances_od = 1;  % include the off-diagonal terms of the covariance matrix
     do_cov_nonlin = 1;  %  0 - do not use , 1 - use Covariance nonlinear terms in the covariance equations
     which_distribution = 0; %  0 - only 1st and 2nd moments of P_u are non-zero, 1 - multivariate distribution for P_u
     do_var_prop_thres = 1;  % 0 - max propensity is a constant, 1 - max propensity changes with the state
     do_prop_time_vary = 0;  % 0 - no time-varying propensities, 1 - time-varying propensities
     
     do_ssa_raw_out = 1; % output every new state change
     do_ssa_sampled_out = 1; % output a periodically sampled state

     done_do_initial_conditions = 0;  % always starts at zero



%  not necessary now, maybe in the future
%if (do_include_moment_data == 1)
% do_covariances = 0; % calculate moment equations that we do not have data for
%end;

     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Particle RUN and OUTPUT Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if (do_particles == 1)

         num_timesteps = 3;  % total number of timesteps to run the simulation
         Npartwrite = 1;     % write out particle info every 'Npartwrite' timesteps
         Nfieldwrite = 100;  % write out fields every 'Nfieldwrite' timesteps
         do_inhomogeneous_diffusion=1;  %  homogeneity of membrane diffusion coefficient 
         use_timeseries = 0;  % use cdf-timeseries,  This is the ON/OFF time series for the ON-cdf and OFF-cdf.
        end;      
     

     
       %  NORMALIZED GAUSSIAN DISTRIBUTION
       length_cdf_norm = 501;   % sampled array of the erf always do odd
       x_cdf_norm_min = -4.0;   % min of distribution, symm. about zero


            
if (do_zero_order_hybrid==1)
   do_covariances=0;
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if read_rand ==1 read random numbers from a file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (read_rand == 1)
  load_random_file;
end;

     propensity_threshold = .05; % the propensity value of a reaction must be smaller than for stochastic
     propensity_threshold = 5e10; % the propensity value of a reaction must be smaller than for stochastic
     propensity_threshold = 5e1; % the propensity value of a reaction must be smaller than for stochastic
     propensity_threshold = -.8; % the propensity value of a reaction must be smaller than for stochastic
%     propensity_threshold = .0031; % the propensity value of a reaction must be smaller than for stochastic
     propensity_threshold = .0101; % the propensity value of a reaction must be smaller than for stochastic
     propensity_threshold = .00101; % the propensity value of a reaction must be smaller than for stochastic
     



if (do_read_file==0)
       %  volume, V=1, for these examples
       %  some inital parameters    
       if (which_pathway==0)   % Biological Oscillator 
 


       end;
       

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Setup y_0 and some run parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
if (which_pathway==0)


     num_moments = (num_molecules*num_molecules + num_molecules)/2 + num_molecules;

  source_u_low = 0;  % 
  t_ss = 1e-10;
  

elseif (which_pathway==1) 


     num_moments = (num_molecules*num_molecules + num_molecules)/2 + num_molecules;
  source_u_low = 0;  % 
  t_ss = 1e-10;
  

elseif (which_pathway==2)  % hasty's Bistable Circuit


     num_moments = (num_molecules*num_molecules + num_molecules)/2 + num_molecules;
  source_u_low = 0;  % 
  t_ss = 1e-10;
  


elseif (which_pathway==3)  % Haseltine's Example 1: Simple Crystallization

end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % do_full=1;
            % ss_or_transient = 0;
            % source_u = .1;
            % y_0ss = fminsearch('fun_path_full_ht',y_0) 
            % ss_or_transient = 1;
            % do_full=0;


       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       % BEGIN: Setup reactions and particles
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       if (do_mean_or_full>=0)

           if (do_particles==1)
               setup_particles;
           end;

           
         % call the pathway/gillespie setup function here
          if (do_cell_cycle_effects == 0)
           setup_pathway_gillespie;
          elseif (do_cell_cycle_effects == 1)
           setup_pathway_gillespie_cell_cycle;
          end;
           
           source_u = source_u_low;
           y_0ss = y_0;


           if (do_particles==1)
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %  call particle setup functions
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    cd ../../;
                    particle_init_manual;

                    write_petsc_bio_no_part  % simulation info other than the particle info

                   for ii_particles = 1:num_particle_files
                      particle_state_initialize;  % sets particle positions and initial states for each file
                      %  write all particle parameters out for PETSC
                      write_petsc_bio_part  % simulation particle info
                    y_0ss
                   end;
             
                     load_pdf_info;  % if precalcuated pdf are to be used with the particles

                    cd(pathway_str);
           end;
       end;
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       % END: Setup reactions and particles
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


   if (do_mean_or_full>=0)
        cd ../../;
            % commented out to not affect particle simulations , remove to use pic_bio SSA
            write_ssa_hybrid_bio  % save the system, for further use, such as PIC-BIO
        cd(pathway_str);
   end;

else  %  read in the input file

       cd ../../;
        read_ssa_hybrid_bio
         if (do_particles==1)
           read_petsc_bio;  % particle_info
           space_setup_readin;
         end;
       cd(pathway_str);

end;  % end of 'if do_read_file




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SIMULATION RUNS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (do_setup_and_run == 1)

              if (which_pathway==0)  % oscillator

                  index_time_0 = 1;
                    source_u_array = [source_u_low];
                  %time_u_array = [3600*150];
                  time_u_array = [3600*400];
                  time_u_array = [3600*200 3600*100];
                  source_u_array = [0 0];
       %             source_u_array = [source_u_low source_u_low];
       %           time_u_array = [3600*200 3600*200];
                  plot_which_time = 2;  %0 - seconds, 1 - minutes, 2 - hours

                 propensity_threshold = 1.0e8;
                 propensity_threshold_min = .014;
 
                 stiffness_threshold = 40;

              elseif (which_pathway>=1)

                  index_time_0 = 1;
                  time_u_array = tau_sequence*60*ones(num_X_sequences,1);
                  source_u_array = 0*time_u_array;
                  plot_which_time = 2;  %0 - seconds, 1 - minutes, 2 - hours

                 propensity_threshold = 1.0e8;
                 propensity_threshold_min = .014;
 
                 stiffness_threshold = 40;


              end;


          cd ../../;
          setup_time_varying_arrays
          cd(pathway_str);

                   if (do_particles==1)
                    %time_u_array = dt*num_timesteps;
                    %source_u_array = source_u_low;
                   end;

            % used when 'do_prop_time_vary==1'
                   c_mu_0 = zeros(num_reactions,1);
                   c_mu_0 = c_mu;


tic % start measuring the run time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
%  BEGIN:  calculate pathway dynamics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 cd ../../;
if (do_particles==0)
  SSA_bio_run
else
end;
 cd(pathway_str);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
%  END:  Calculating pathway dynamics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
stop_time = toc  % stop measuring the run time

count_reactions


         
end; % if (do_setup_and_run == 1)
