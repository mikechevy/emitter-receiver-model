global state_cme_to;
global state_cme_propensity_array;
global num_states;
global y_prime;




propensities_genes = zeros(num_reactions,1);




if (which_pathway == 0)  % Genetic oscillator

% multiplication of each genes total states.
num_states = 4;


reaction1 = 1;
reaction2 = 2;
reaction3 = 3;
reaction4 = 4;

%//  SPECIES MAP
%        // D_A - molecule 1
%        // D_R - molecule 2
%        // D_A_prime - molecule 3
%        // D_R_prime - molecule 4
%        // A - molecule 7
%//  STATE MAP
%        // state 1:  D_A = 1, D_prime_A = 0,  D_R = 1, D_prime_R = 0, A = N
%        // state 2:  D_A = 0, D_prime_A = 1,  D_R = 1, D_prime_R = 0, A = N-1
%        // state 3:  D_A = 1, D_prime_A = 0,  D_R = 0, D_prime_R = 1, A = N-1
%        // state 4:  D_A = 0, D_prime_A = 1,  D_R = 0, D_prime_R = 1, A = N-2
%//  MAP THE STATE TRANSITIONS for reactions 1:4
%        // reaction 1:  theta_A D_prime_A -> D_A,    state 2 to state 1,   state 4 to state 3
%        // reaction 2:  gamma_A D_A A -> D_prime_A,  state 1 to state 2,   state 3 to state 4
%        // reaction 3:  theta_R D_prime_R -> D_R,    state 3 to state 1,   state 4 to state 2
%        // reaction 4:  gamma_R D_R A -> D_prime_R,  state 1 to state 3,   state 2 to state 4

        gene_state_cme_state_map = zeros(num_states,num_molecules);
             which_state = 1;
             gene_state_cme_state_map(which_state,ii_D_A) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_A) = 0;
             gene_state_cme_state_map(which_state,ii_D_R) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_R) = 0;
             which_state = 2;
             gene_state_cme_state_map(which_state,ii_D_A) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_A) = 1;
             gene_state_cme_state_map(which_state,ii_D_R) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_R) = 0;
             which_state = 3;
             gene_state_cme_state_map(which_state,ii_D_A) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_A) = 0;
             gene_state_cme_state_map(which_state,ii_D_R) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_R) = 1;
             which_state = 4;
             gene_state_cme_state_map(which_state,ii_D_A) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_A) = 1;
             gene_state_cme_state_map(which_state,ii_D_R) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_R) = 1;


         x_dummy = zeros(num_molecules,1);
         x_state = zeros(num_molecules,1);
state_cme_vector = zeros(num_states,num_molecules);  
state_cme_array = zeros(num_states,num_molecules);;
state_cme_to = zeros(num_states,num_reactions); %// given the state, this matrix maps out the new state resulting from a given reaction
state_cme_propensity_array = zeros(num_states,num_reactions); %// given the state, this matrix maps out the new state resulting from a given reaction


num_reactions_genes = 4;
  reaction_genes_map = [1 2 3 4];

which_state = 1;
state_cme_to(which_state,reaction1) = 0;
state_cme_to(which_state,reaction2) = 2;
state_cme_to(which_state,reaction3) = 0;
state_cme_to(which_state,reaction4) = 3;
   state_cme_vector(which_state,ii_D_A) = 1;  
   state_cme_vector(which_state,ii_D_prime_A) = 0;  
   state_cme_vector(which_state,ii_D_R) = 1;  
   state_cme_vector(which_state,ii_D_prime_R) = 0;  
   state_cme_vector(which_state,ii_A) = 0;  
which_state = 2;
state_cme_to(which_state,reaction1) = 1;
state_cme_to(which_state,reaction2) = 0;
state_cme_to(which_state,reaction3) = 0;
state_cme_to(which_state,reaction4) = 4;
   state_cme_vector(which_state,ii_D_A) = 0;  
   state_cme_vector(which_state,ii_D_prime_A) = 1;  
   state_cme_vector(which_state,ii_D_R) = 1;  
   state_cme_vector(which_state,ii_D_prime_R) = 0;  
   state_cme_vector(which_state,ii_A) = -1;  
which_state = 3;
state_cme_to(which_state,reaction1) = 0;
state_cme_to(which_state,reaction2) = 4;
state_cme_to(which_state,reaction3) = 1;
state_cme_to(which_state,reaction4) = 0;
   state_cme_vector(which_state,ii_D_A) = 1;  
   state_cme_vector(which_state,ii_D_prime_A) = 0;  
   state_cme_vector(which_state,ii_D_R) = 0;  
   state_cme_vector(which_state,ii_D_prime_R) = 1;  
   state_cme_vector(which_state,ii_A) = -1;  
which_state = 4;
state_cme_to(which_state,reaction1) = 3;
state_cme_to(which_state,reaction2) = 0;
state_cme_to(which_state,reaction3) = 2;
state_cme_to(which_state,reaction4) = 0;
   state_cme_vector(which_state,ii_D_A) = 0;  
   state_cme_vector(which_state,ii_D_prime_A) = 1;  
   state_cme_vector(which_state,ii_D_R) = 0;  
   state_cme_vector(which_state,ii_D_prime_R) = 1;  
   state_cme_vector(which_state,ii_A) = -2;  

    num_t_factors = 1;
    index_t_factors(1) = ii_A 
     vector_t_factors = zeros(num_t_factors,num_molecules);  
       vector_t_factors(1,ii_A) = 1;
       vector_t_factors(1,ii_D_prime_A) = 1;
       vector_t_factors(1,ii_D_prime_R) = 1;
         x_cme_0 =  zeros(num_states,1);
         x_cme_0(1) = 1;  % initial state 



elseif (which_pathway == 1)  % Jacobs circuit

% multiplication of each genes total states.
num_states = 4;  % 4 cme states that well calculate.
                  % in addition the state of D_A, 


reaction1 = 1;
reaction2 = 2;
reaction3 = 3;
reaction4 = 4;

%//  SPECIES MAP
%        // D_A - molecule 1
%        // D_B - molecule 2
%        // D_C - molecule 3
%        // D_A_prime - molecule 4
%        // D_B_prime - molecule 5
%        // D_C_prime - molecule 7
%        // C_A - molecule 7
%        // C_B - molecule 7
%//  STATE MAP
%        // state 1:  D_B = 1, D_prime_B = 0,  D_C = 1, D_prime_C = 0, C_A = N   , C_B = M
%        // state 2:  D_B = 0, D_prime_B = 1,  D_C = 1, D_prime_C = 0, C_A = N-1 , C_B = M
%        // state 3:  D_B = 1, D_prime_B = 0,  D_C = 0, D_prime_C = 1, C_A = N , C_B = M-1
%        // state 4:  D_B = 0, D_prime_B = 1,  D_C = 0, D_prime_C = 1, C_A = N-1 , C_B = M-1
%//  MAP THE STATE TRANSITIONS for reactions 1:4
%        // reaction 1 (2):  theta_B D_prime_B -> D_B,    state 2 to state 1,   state 4 to state 3
%        // reaction 2 (3):  gamma_C_A D_B C_A -> D_prime_B,  state 1 to state 2,   state 3 to state 4
%        // reaction 3 (4):  theta_C D_prime_C -> D_C,    state 3 to state 1,   state 4 to state 2
%        // reaction 4 (5):  gamma_C_B D_C C_B -> D_prime_C,  state 1 to state 3,   state 2 to state 4

        gene_state_cme_state_map = zeros(num_states,num_molecules);
             which_state = 1;
             gene_state_cme_state_map(which_state,ii_D_B) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_B) = 0;
             gene_state_cme_state_map(which_state,ii_D_C) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_C) = 0;
             which_state = 2;
             gene_state_cme_state_map(which_state,ii_D_B) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_B) = 1;
             gene_state_cme_state_map(which_state,ii_D_C) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_C) = 0;
             which_state = 3;
             gene_state_cme_state_map(which_state,ii_D_B) = 1;
             gene_state_cme_state_map(which_state,ii_D_prime_B) = 0;
             gene_state_cme_state_map(which_state,ii_D_C) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_C) = 1;
             which_state = 4;
             gene_state_cme_state_map(which_state,ii_D_B) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_B) = 1;
             gene_state_cme_state_map(which_state,ii_D_C) = 0;
             gene_state_cme_state_map(which_state,ii_D_prime_C) = 1;


         x_dummy = zeros(num_molecules,1);
         x_state = zeros(num_molecules,1);
state_cme_vector = zeros(num_states,num_molecules);  
state_cme_array = zeros(num_states,num_molecules);;
state_cme_to = zeros(num_states,num_reactions); %// given the state, this matrix maps out the new state resulting from a given reaction
state_cme_propensity_array = zeros(num_states,num_reactions); %// given the state, this matrix maps out the new state resulting from a given reaction

C_A_threshold = 50;%10;  % minimum number of transcription factors to consider gene A to be ON

num_reactions_genes = 4;
  reaction_genes_map = [2 3 4 5];

which_state = 1;
state_cme_to(which_state,reaction1) = 0;
state_cme_to(which_state,reaction2) = 2;
state_cme_to(which_state,reaction3) = 0;
state_cme_to(which_state,reaction4) = 3;
   state_cme_vector(which_state,ii_D_B) = 1;  
   state_cme_vector(which_state,ii_D_prime_B) = 0;  
   state_cme_vector(which_state,ii_D_C) = 1;  
   state_cme_vector(which_state,ii_D_prime_C) = 0;  
   state_cme_vector(which_state,ii_C_A) = 0;  
   state_cme_vector(which_state,ii_C_B) = 0;  
which_state = 2;
state_cme_to(which_state,reaction1) = 1;
state_cme_to(which_state,reaction2) = 0;
state_cme_to(which_state,reaction3) = 0;
state_cme_to(which_state,reaction4) = 4;
   state_cme_vector(which_state,ii_D_B) = 0;  
   state_cme_vector(which_state,ii_D_prime_B) = 1;  
   state_cme_vector(which_state,ii_D_C) = 1;  
   state_cme_vector(which_state,ii_D_prime_C) = 0;  
   state_cme_vector(which_state,ii_C_A) = -1;  
   state_cme_vector(which_state,ii_C_B) = 0;  
which_state = 3;
state_cme_to(which_state,reaction1) = 0;
state_cme_to(which_state,reaction2) = 4;
state_cme_to(which_state,reaction3) = 1;
state_cme_to(which_state,reaction4) = 0;
   state_cme_vector(which_state,ii_D_B) = 1;  
   state_cme_vector(which_state,ii_D_prime_B) = 0;  
   state_cme_vector(which_state,ii_D_C) = 0;  
   state_cme_vector(which_state,ii_D_prime_C) = 1;  
   state_cme_vector(which_state,ii_C_A) = 0;  
   state_cme_vector(which_state,ii_C_B) = -1;  
which_state = 4;
state_cme_to(which_state,reaction1) = 3;
state_cme_to(which_state,reaction2) = 0;
state_cme_to(which_state,reaction3) = 2;
state_cme_to(which_state,reaction4) = 0;
   state_cme_vector(which_state,ii_D_B) = 0;  
   state_cme_vector(which_state,ii_D_prime_B) = 1;  
   state_cme_vector(which_state,ii_D_C) = 0;  
   state_cme_vector(which_state,ii_D_prime_C) = 1;  
   state_cme_vector(which_state,ii_C_A) = -1;  
   state_cme_vector(which_state,ii_C_B) = -1;  

    num_t_factors = 2;
    index_t_factors(1) = ii_C_A 
    index_t_factors(2) = ii_C_B 
     vector_t_factors = zeros(num_t_factors,num_molecules);  
       vector_t_factors(1,ii_C_A) = 1;
       vector_t_factors(1,ii_D_prime_B) = 1;
       vector_t_factors(2,ii_C_B) = 1;
       vector_t_factors(2,ii_D_prime_C) = 1;
         x_cme_0 =  zeros(num_states,1);
         x_cme_0(1) = 1;  % initial state 


end;



num_moments = 2;
for which_moment = 1:num_moments


fids_sampled_data_gene = fopen(strcat(path_data,'/data/ssa_data_sampled.out'),'r');

      %// write the number of runs into the info file
      do_ssa_sampled_out_gene = fread(fids_sampled_data_gene,1,'int');
      num_sampled_ssa_gene = fread(fids_sampled_data_gene,1,'int');
      num_molecules_gene = fread(fids_sampled_data_gene,1,'int');
      num_runs_gene = fread(fids_sampled_data_gene,1,'int');
      time_data_sampled_gene = fread(fids_sampled_data_gene,num_sampled_ssa_gene+1,'double');



%%open_ssa_run_info



if (which_moment==1)
% setup the sampling arrays here
dt_gene = time_data_sampled_gene(2)-time_data_sampled_gene(1);
X_data_sampled_gene = zeros(num_sampled_ssa_gene+1,num_molecules);

A_cme = zeros(num_states+1,num_states);
A_cme_m1 = zeros(num_states,num_states-1);
A_cme_m2 = zeros(num_states-1,num_states-2);
b_cme = zeros(num_states+1,1);
b_cme(num_states+1) = 1;  % probability adds up to 1;
b_cme_m1 = zeros(num_states,1);
b_cme_m1(num_states) = 1;  % probability adds up to 1;
b_cme_m2 = zeros(num_states-1,1);
b_cme_m2(num_states-1) = 1;  % probability adds up to 1;
num_moments = (num_molecules*num_molecules + num_molecules)/2 + num_molecules;
               moments_data_sampled = zeros(num_sampled_ssa_gene+1,num_moments);

     covariance_map = zeros(num_moments-num_molecules,2);

     count_cov_map = 0;
     for jj = 1:num_molecules
        for ii = jj:num_molecules
                 covariance_map(count_cov_map+1,:) = [jj ii];
                 count_cov_map = count_cov_map + 1;
        end;
     end;
end;  % end of 'if (which_moment==1)'




for ii_run = 1:num_runs_gene
which_run = ii_run

      X_dummy_gene=fread(fids_sampled_data_gene,[num_molecules,num_sampled_ssa_gene+1],'double');

          if (which_pathway==1) % Jacobs circuit convert A to C_A,A, B to C_B,B
                  for jj_sampled = 1:num_sampled_ssa_gene+1
                     A_total = X_dummy_gene(ii_A,jj_sampled);
                     B_total = X_dummy_gene(ii_B,jj_sampled);
                     if (do_monomer_t_factor==0)
                      %  A*(A-1)/(A_total-A) = k_pc_pc/theta_C_A  ~ A^2/(A_total) (we'll use this)
                       X_dummy_gene(ii_A,jj_sampled)  = sqrt(A_total*theta_C_A/gamma_A);
                       X_dummy_gene(ii_C_A,jj_sampled)  = (A_total - sqrt(A_total*theta_C_A/gamma_A))/2.0;
                      %  B*(B-1)/(B_total-B) = k_pc_pc/theta_C_B  ~ B^2/(B_total) (we'll use this)
                       X_dummy_gene(ii_B,jj_sampled)  = sqrt(B_total*theta_C_B/gamma_B);
                       X_dummy_gene(ii_C_B,jj_sampled)  = (B_total - sqrt(B_total*theta_C_B/gamma_B))/2.0;
                     elseif (do_monomer_t_factor==1)
                       if (jj_sampled==1) % time = 0
                        X_dummy_gene(ii_C_A,jj_sampled)  = 0*A_total;
                       else
                        X_dummy_gene(ii_C_A,jj_sampled)  = A_total;
                       end;
                       X_dummy_gene(ii_C_B,jj_sampled)  = B_total;
                     end;
                  end;
                      %X_dummy_gene(ii_A,:)
                      %X_dummy_gene(ii_C_A,:)
                      %X_dummy_gene(ii_B,:)
                      %X_dummy_gene(ii_C_B,:)
                      %pause;
          end;


      X_data_sampled_gene = X_dummy_gene';
 
%      size(X_data_sampled_gene)

for jj_sampled = 1:num_sampled_ssa_gene+1

       x_ssa = floor(X_data_sampled_gene(jj_sampled,:)');

                  for kk = 1:num_t_factors
                     index_dummy = index_t_factors(kk);
                     x_state(index_dummy) = vector_t_factors(kk,:)*x_ssa(:);  
                  end;

                   % set the states of the gene-cme
                   for kk = 1:num_states
                   state_cme_array(kk,:) = x_state' + state_cme_vector(kk,:);
                   end;

                   for kk=1:num_states

                       negative_species = 0;
                           x_dummy = state_cme_array(kk,:);
                           if (min(x_dummy)<0.0)
                             negative_species = 1;
                           end;

                          if (negative_species==0)
                           %calculate_reaction_constants(x_dummy);
                             % calculate the propensities for the gene reactions
                             for mm = 1:num_reactions_genes

                               jj = reaction_genes_map(mm);
        
                              if (reaction_type(jj)==1)  

                                    propensities_genes(jj) = c_mu(jj);  % propensity
           
                              elseif (reaction_type(jj)==2)
         
                                     propensities_genes(jj) = c_mu(jj)*x_dummy(reaction_molecules(jj,1));  % propensity
            
                              elseif (reaction_type(jj)==3)
         
                                     propensities_genes(jj) = c_mu(jj)*x_dummy(reaction_molecules(jj,1))*x_dummy(reaction_molecules(jj,2));  % propensity
            
                              elseif (reaction_type(jj)==4) 
         
                                     propensities_genes(jj) = c_mu(jj)*x_dummy(reaction_molecules(jj,1))*(x_dummy(reaction_molecules(jj,1))-1)/2;   % propensity
            
                              end;
        
                              %reaction_type_dummy =  reaction_type(jj)
                              %propensities_dummy =  propensities_genes(jj)
                              %x_dummy

                             end; % end of 'for mm = 1:num_reactions_genes'

                           state_cme_propensity_array(kk,:) = propensities_genes(:);
                          else
                           state_cme_propensity_array(kk,:) = 0.0;
                          end;

                   end; % end of 'for kk=1:num_states'

%do_cme_inversion=1;
%if (do_cme_inversion==1)
        %[time_cme, x_cme] = ode15s('fun_cme_genes',[0 1.0 100 1000],x_cme_0',options); 

A_cme = 0*A_cme;
for ii=1:num_states
for which_reaction=1:num_reactions_genes
           state_to = state_cme_to(ii,which_reaction);
           jj = reaction_genes_map(which_reaction);
if (state_to > 0)
A_cme(ii,ii) = A_cme(ii,ii)-state_cme_propensity_array(ii,jj);
A_cme(state_to,ii) = A_cme(state_to,ii)+state_cme_propensity_array(ii,jj);
end;

end;
end;
A_cme(num_states+1,:) = 1;


  % adjust matrix based on amount of transcription factors
  if (which_pathway==0)  % oscillator
     if (sum(x_state)>=2)
      num_states_current = num_states;
      x_cme = pinv(A_cme)*b_cme;
     elseif (sum(x_state)==1)
      num_states_current = num_states-1;
      A_cme_m1(1:num_states_current,:) = A_cme(1:num_states_current,1:num_states_current);
      A_cme_m1(num_states_current+1,:) = A_cme(num_states+1,1:num_states_current);
      x_cme = pinv(A_cme_m1)*b_cme_m1;
      x_cme(num_states) = 0; % last state is zero
     else
      num_states_current = 1;
      x_cme = x_cme_0;
     end;
  elseif (which_pathway==1)  % Jacob's circuit
    if (do_hidden_t_factor==0)
     if (x_state(ii_C_A)>0)&(x_state(ii_C_B)>0)
      num_states_current = num_states;
      x_cme = pinv(A_cme)*b_cme;
         %A_cme
         %pause
     elseif (x_state(ii_C_A)>0)  % states 1 and 2 are accessible
      num_states_current = num_states-2;
      A_cme_m2(1:num_states_current,:) = A_cme(1:num_states_current,1:num_states_current);
      A_cme_m2(num_states_current+1,:) = A_cme(num_states+1,1:num_states_current);
      x_cme_dummy = pinv(A_cme_m2)*b_cme_m2;
      x_cme(1) = x_cme_dummy(1);
      x_cme(2) = x_cme_dummy(2);
      x_cme(3) = 0; % state 3 is zero
      x_cme(4) = 0; % state 4 state is zero
         %A_cme
         %A_cme_m2
         %x_cme
         %pause
     elseif (x_state(ii_C_B)>0)
      num_states_current = num_states-2;
        A_cme_m2(1,1) = A_cme(1,1);
        A_cme_m2(1,2) = A_cme(1,3);
        A_cme_m2(2,1) = A_cme(3,1);
        A_cme_m2(2,2) = A_cme(3,3);
        A_cme_m2(num_states_current+1,:) = A_cme(num_states+1,1:num_states_current);
      x_cme_dummy = pinv(A_cme_m2)*b_cme_m2;
      x_cme(1) = x_cme_dummy(1);
      x_cme(2) = 0; % state 2 is zero
      x_cme(3) = x_cme_dummy(2);
      x_cme(4) = 0; % state 4 state is zero
         %A_cme
         %A_cme_m2
         %x_cme
         %pause
     else  % only state 1 is accessible
      num_states_current = 1;
      x_cme = x_cme_0;
         %A_cme
         %x_cme
         %pause
     end;
    elseif (do_hidden_t_factor==1)
      cme_ss_with_hidden_t_factor;
    end;
  end;



%end;  % end of 'if (do_cme_inversion==1)'

    % stick in the results of the CME calculations into X_data_sampled
    for kk = 1:num_molecules  % first set to zero
     if (molecule_gene(kk)>0)
      X_data_sampled_gene(jj_sampled,kk) = 0;
     end;
    end;
    for kk = 1:num_molecules
    for jj = 1:num_states
         
                if (gene_state_cme_state_map(jj,kk)==1)  % probability that a given alosteric state of a gene is ON, i.e. equals 1
                 X_data_sampled_gene(jj_sampled,kk) = X_data_sampled_gene(jj_sampled,kk)+x_cme(jj);
                end;
              
    end;
    end;

         if (which_pathway==1)  % Jacobs Circuit, GENE A threshold test
                 if (X_data_sampled_gene(jj_sampled,ii_C_A) > C_A_threshold)&(jj_sampled>1)
                   X_data_sampled_gene(jj_sampled,ii_D_prime_A) = X_data_sampled_gene(jj_sampled,ii_D_prime_A) + 1;
                 else
                   X_data_sampled_gene(jj_sampled,ii_D_A) = X_data_sampled_gene(jj_sampled,ii_D_A) + 1;
                 end;
         end;


    if (which_moment==2)  % calculate covariances between the gene states, other covariance calculated later
           for kk = 1:count_cov_map
            for jj = 1:num_states
                ii_species1 = covariance_map(kk,1);
                ii_species2 = covariance_map(kk,2);
              if (molecule_gene(ii_species1)>0)&(molecule_gene(ii_species2)>0)
                state_species1 = gene_state_cme_state_map(jj,ii_species1);
                state_species2 = gene_state_cme_state_map(jj,ii_species2);
               sample_dummy1 = (state_species1-moments_data_sampled(jj_sampled,ii_species1));
               sample_dummy2 = (state_species2-moments_data_sampled(jj_sampled,ii_species2));
               moments_data_sampled(jj_sampled,num_molecules+kk) = moments_data_sampled(jj_sampled,num_molecules+kk) + sample_dummy1*sample_dummy2*x_cme(jj);
              end;
            end;
           end;
    end;

%A_cme
%num_states_current
%x_cme
%sum(x_cme)
%pause

end; % end of 'for jj_sampled = 1:num_sampled_ssa_gene+1'

    if (which_moment==1)
               moments_data_sampled(:,1:num_molecules) = moments_data_sampled(:,1:num_molecules) + X_data_sampled_gene;
    elseif (which_moment==2)
           for kk = 1:count_cov_map
                ii_species1 = covariance_map(kk,1);
                ii_species2 = covariance_map(kk,2);
                if (molecule_gene(ii_species1)==0)|(molecule_gene(ii_species2)==0)
               sample_dummy1 = (X_data_sampled_gene(:,ii_species1)-moments_data_sampled(:,ii_species1));
               sample_dummy2 = (X_data_sampled_gene(:,ii_species2)-moments_data_sampled(:,ii_species2));
               moments_data_sampled(:,num_molecules+kk) = moments_data_sampled(:,num_molecules+kk) + sample_dummy1.*sample_dummy2;
                end;
               %X_data_mom2 = X_data_mom2 + X_data_sampled_gene.*X_data_sampled_gene;
           end;
    elseif (which_moment==3)
    end;


end;  % end of 'for ii_run = 1:num_runs_gene'


    if (which_moment==1)
      moments_data_sampled(:,1:num_molecules) = moments_data_sampled(:,1:num_molecules)/num_runs_gene;
    elseif (which_moment==2)
      moments_data_sampled(:,num_molecules+1:num_molecules+count_cov_map) = moments_data_sampled(:,num_molecules+1:num_molecules+count_cov_map)/num_runs_gene;
    elseif (which_moment==3)
    end;



fclose(fids_sampled_data_gene);


end;  % end of 'for which_moment = 1:num_moments'


time_moments_data_sampled = time_data_sampled_gene;
dt_moments_data_sampled = time_data_sampled_gene(2) - time_data_sampled_gene(1);

covariance_map_moments = covariance_map;
num_cov_moments_data = count_cov_map;

save time_dependent_moments_w_gene_cme moments_data_sampled time_moments_data_sampled dt_moments_data_sampled covariance_map_moments num_cov_moments_data;


