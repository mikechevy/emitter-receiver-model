
fac_max = 2;  % factor the cell nucleus edge signal is above the highest marker signal
pixel_border = 20;  %  extra pixels around the cluster

max_pixel_FITC_tot = zeros(num_clusters,1);
max_pixel_CY3_tot = zeros(num_clusters,1);

for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)

  str_movie_processed = strcat(str_movie,'_processed')
  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus);
  
  
                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                  %%   code for drawing an ellipse
                  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                  %M_dummy = zeros(2,2);  
                  %M_dummy(1,1) = var_x_tot(ii); 
                  %M_dummy(2,2) = var_y_tot(ii); 
                  %M_dummy(1,2) = cov_xy_tot(ii); 
                  %M_dummy(2,1) = cov_xy_tot(ii); 
                  %[U_dummy L_dummy] = eig(M_dummy);
                  %%angle_ellipse = angle(U_dummy(1:2));
                  %angle_ellipse = angle([U_dummy(1,2); U_dummy(1:1)])+90;  % might not be correct, CORRECT THIS!!!!
                  %ellipse(sqrt(L_dummy(2,2)), sqrt(L_dummy(1,1)), angle_ellipse, mean_y_tot(iii), mean_x_tot(iii));   
  
  
for which_cluster = 1:num_clusters    
   x_coord_min =  max(box_coords_cluster(which_cluster,1)-pixel_border,1);
   x_coord_max =  min(box_coords_cluster(which_cluster,2)+pixel_border,xLength);
   y_coord_min =  max(box_coords_cluster(which_cluster,3)-pixel_border,1);
   y_coord_max =  min(box_coords_cluster(which_cluster,4)+pixel_border,yLength);
  max_pixel_FITC_tot(which_cluster) = max(max_pixel_FITC_tot(which_cluster),max(max(M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max))));
  max_pixel_CY3_tot(which_cluster) = max(max_pixel_CY3_tot(which_cluster),max(max(M_CY3(x_coord_min:x_coord_max,y_coord_min:y_coord_max))));  
end; % END OF:  for which_cluster = 1:num_clusters

  
end;
  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   generate movies here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for which_cluster = 1:num_clusters    
   x_coord_min =  max(box_coords_cluster(which_cluster,1)-pixel_border,1);
   x_coord_max =  min(box_coords_cluster(which_cluster,2)+pixel_border,xLength);
   y_coord_min =  max(box_coords_cluster(which_cluster,3)-pixel_border,1);
   y_coord_max =  min(box_coords_cluster(which_cluster,4)+pixel_border,yLength);


num_clusters = length(size_xcorr_group);
size_cluster = size_xcorr_group;
cluster = xcorr_group;

label_cluster_only = 1; % 1 - yes, 0 - no
if (label_cluster_only == 1)
    index_group = zeros(length(size_cluster(which_cluster)),1);
for iii = 1:size_cluster(which_cluster)
      index_group(iii) = cluster(which_cluster,iii); 
end;
else % label all cells within the box
  ii_count = 0;
index_group = [];
 for iii = 1:num_nuclei_tot(which_frame)
    if (mean_x_tot_time(iii,which_frame) >= x_coord_min)&(mean_x_tot_time(iii,which_frame) <= x_coord_max)& (mean_y_tot_time(iii,which_frame) >= y_coord_min)&(mean_y_tot_time(iii,which_frame) <= y_coord_max)
      index_group = [index_group ; iii]; 
      ii_count = ii_count+1;
    end;% end;
end;
end;





          filename_movie = strcat(str_movie,'_processed\cluster',num2str(which_cluster));
          delete(strcat(filename_movie,'.avi'));
          mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',.5);


for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)

  str_movie_processed = strcat(str_movie,'_processed')
  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus);
  
  M_marker_threshold = M_DAPI_threshold_FILL;
  
M_marker_threshold_nuclear = 0*M_marker_threshold;
M_marker_threshold_cell = 0*M_marker_threshold;
M_marker_threshold_edge = 0*M_marker_threshold;

 %for jjj = 1:length(index_group)
 %    idx = index_group(jjj);
 %    idx_map = index_map_nuclei_t0(idx,which_frame);
 %      if (idx_map > 0)
 %      M_marker_threshold_TEST(Cell_DAPI_FILL.PixelIdxList{idx_map}) = 1;         
 %      end;
 %end;
%M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) =  edge(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'prewitt');


M_marker_threshold_edge(x_coord_min:x_coord_max,y_coord_min:y_coord_max) =  edge(M_marker_threshold(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'prewitt');
%M_marker_threshold_TEST =  edge(M_marker_threshold_TEST,'canny');

figure(1)
subplot(1,2,1)
imagesc(max(M_FITC,fac_max*max_pixel_FITC_tot(which_cluster)*M_marker_threshold_edge))
%imagesc(max(M_CY3,fac_max*max_pixel_CY3_tot(which_cluster)*M_marker_threshold_edge))
   hold on;                 
    for jjj = 1:length(index_group)
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');

             
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)),'TextColor','w');                    
             tt =  text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)));                   
             set(tt,'Color','y');
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);


 ii_count = 0;
index_group_box = [];
 for iii = 1:num_nuclei_time(which_frame)
    if (mean_x_tot_time(iii,which_frame) >= x_coord_min)&(mean_x_tot_time(iii,which_frame) <= x_coord_max)& (mean_y_tot_time(iii,which_frame) >= y_coord_min)&(mean_y_tot_time(iii,which_frame) <= y_coord_max)
      index_group_box = [index_group_box ; iii]; 
      ii_count = ii_count+1;
    end;% end;
end;
 for iii = 1:length(index_group_box)
     idx = index_group_box(iii);
       M_marker_threshold_nuclear(eval('[Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}]')) = nuclear_FITC_tot_time(idx,which_frame);         
       M_marker_threshold_nuclear(eval('[Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx}]')) = cytosolic_FITC_tot_time(idx,which_frame);         
 end;

 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   plot of average nuclear signals (over the nucleus) and average
%   cytosolic signals (over the cytosol).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M_FITC_no_nucleus = M_FITC.*(1-M_marker_threshold) + M_marker_threshold_nuclear; 
subplot(1,2,2)
imagesc(max(M_FITC_no_nucleus,fac_max*max_pixel_FITC_tot(which_cluster)*M_marker_threshold_edge))
%imagesc(max(M_CY3,fac_max*max_pixel_CY3_tot(which_cluster)*M_marker_threshold_edge))
   hold on;                 
    for jjj = 1:length(index_group)
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');

             
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)),'TextColor','w');                    
             tt =  text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)));                   
             set(tt,'Color','y');
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

    
    
    H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
        
end;  % end of  'for kkk = 1:length(which_frames)



             mov = close(mov)


             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plot the signals of the cells within the cluster
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    num_plots_max_0 = 3;
    ii_figure_count = 1;
    ii_plot_count = 0;
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
        num_plots_max = min(length(index_group),num_plots_max_0)
       
     figure(1000+ii_figure_count)  
     title('nuclear FITC signal');
     subplot(num_plots_max,1,ii_plot_count+1) 
     plot(which_frames,nuclear_FITC_tot_time_mapped_t0(idx,:));
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');

     figure(2000+ii_figure_count)  
     title('nuclear CY3 signal');
     subplot(num_plots_max,1,ii_plot_count+1) 
     plot(which_frames,nuclear_CY3_tot_time_mapped_t0(idx,:));
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');
     
     
     ii_plot_count = ii_plot_count+1;
     if (ii_plot_count == num_plots_max)
         ii_figure_count = ii_figure_count+1;
         ii_plot_count = 0;
     end;
         
    end    
             
    pause
             

end; % END OF:  for which_cluster = 1:num_clusters
             
             
