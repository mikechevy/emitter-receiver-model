function [hot_spot_groups,size_hot_spot_groups] = find_bPAC_clusters(r_event,numEvents,length_max,which_metric,bPAC_events)


global ii_physical_distance;
global ii_xcorr;
global length_per_pixel;
global seconds_per_frame;
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
%  Begin: Cluster events
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

matrix_hot_spot = zeros(numEvents,numEvents);
hot_spot_groups = zeros(numEvents,numEvents);


if (which_metric == ii_physical_distance) 
   z = length_per_pixel*pdist(r_event); % micrometers
elseif (which_metric == ii_xcorr)
       
end;


count_z = 0;
count_groups = 0;

%  Clustering loop
for jj = 1:numEvents-1
for kk = jj+1:numEvents % N*(N-1)/2, where N = numEvents
    if (bPAC_events(jj) == 1)&(bPAC_events(kk)==1)   
    if (z(count_z+1) <= length_max)  % length_max is a passed argument
        matrix_hot_spot(jj,kk) = 1;
        matrix_hot_spot(kk,jj) = 1;   
    end;
    end;
count_z = count_z+1;    
end;
end;

matrix_hot_spot_test = matrix_hot_spot;
nnz_matrix = zeros(numEvents,1);
nnz_matrix_next = nnz_matrix;



for jj = 1:numEvents

    indexGroup = find(matrix_hot_spot_test(jj,:)>0);
    
  if (length(indexGroup) > 0)  % determine the whole cluster

    nnz_matrix(jj) = 1;
      
    while (sum(abs(nnz_matrix_next-nnz_matrix))~=0)        

      indexGroup_nnz = find(nnz_matrix>0); 
%      indexGroup_nnz_next = find(nnz_matrix>0); 
        
      for kk = 1:length(indexGroup_nnz)
         row = indexGroup_nnz(kk);
        %if (nnz_matrix(row)~=1)&(nnz_matrix_next(row)~=1)
        if (nnz_matrix(row)~=nnz_matrix_next(row))
          indexGroup = find(matrix_hot_spot_test(row,:)>0);
         if length(indexGroup>0)
          for mm=1:length(indexGroup)
           nnz_matrix(indexGroup(mm)) = 1;
          end;
         end;
        nnz_matrix_next(row) = 1;
        end;
      end;
                
    end;
    
          indexGroup_nnz = find(nnz_matrix>0);
          hot_spot_groups(count_groups+1,1:length(indexGroup_nnz)) = indexGroup_nnz;
          size_hot_spot_groups(count_groups+1) = length(indexGroup_nnz);
          count_groups = count_groups+1;
          for kk = 1:length(indexGroup_nnz)
            matrix_hot_spot_test(indexGroup_nnz(kk),:) = 0; % remove clustered events
          end;
          
          %indexGroup_nnz
        %pause;
          nnz_matrix = 0*nnz_matrix;
          nnz_matrix_next = 0*nnz_matrix_next;
  end;
    
end;

if (count_groups>0)
  hot_spot_groups = hot_spot_groups(1:count_groups,1:max(size_hot_spot_groups(1:count_groups)));
  size_hot_spot_groups = size_hot_spot_groups(1:count_groups);
  %hot_spot_groups
  %count_groups
  %pause
else
    hot_spot_groups = [];
    size_hot_spot_groups = [];
end;

