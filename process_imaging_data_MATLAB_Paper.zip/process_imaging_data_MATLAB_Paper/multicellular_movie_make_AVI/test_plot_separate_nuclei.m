


             figure(99)
             %imagesc(M_marker_id_threshold)            
             imagesc(M_marker_threshold)            
             title(strcat('M marker threshold'));
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              
            
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              
             figure(100)
             %imagesc(M_marker_id_threshold)            
             imagesc(M_marker_threshold_FILL)            
             title(strcat('M Marker theshold FILL'));
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              
            
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);

             figure(101)
             %imagesc(M_marker_id_threshold)            
             imagesc(M_marker_threshold_TEST)            
             title(strcat('number of separate nucleus: ',num2str(num_nuclei_separate)));
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              
            
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);              
