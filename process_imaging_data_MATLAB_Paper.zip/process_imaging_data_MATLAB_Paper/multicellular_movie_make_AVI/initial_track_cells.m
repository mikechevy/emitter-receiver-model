%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  1.  Map all nuclei that have unique trajectories.
%  2.  Fill in nuclei that have intermittent signal (due to tresholding),
%  either that disappear for some images or merge with nuclei in other
%  images.
%  3.  Remaining cells should be new cells, either daughter of from border
%  of the image
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


delta_move_threshold = 10;
%delta_move_threshold = max(xLength,yLength);
       
% Can capture more than one cell whos distance is closest to a prior cell
% location
% num_index_m1_mapped(index_min) = num_index_m1_mapped(index_min)+1; 
% index_m1_mapped(index_min,num_index_m1_mapped(index_min)) = ii;
    


tic
for kkk = 2:numFr_NM
    which_frame = kkk;
    mean_x_tot = mean_x_tot_time(1:num_nuclei_time(which_frame),which_frame);
    mean_y_tot = mean_y_tot_time(1:num_nuclei_time(which_frame),which_frame);
    mean_x_tot_m1 = mean_x_tot_time(1:num_nuclei_time(which_frame-1),which_frame-1);
    mean_y_tot_m1 = mean_y_tot_time(1:num_nuclei_time(which_frame-1),which_frame-1);
for iii = 1:num_nuclei_time(which_frame)
     [val_min,index_min] =  sort(sqrt(power(mean_x_tot(iii)-mean_x_tot_m1,2) + power(mean_y_tot(iii)-mean_y_tot_m1,2)));
       index_map_backward(iii,:) = index_min(1:num_mapped);
       dist_map_backward(iii,:) = val_min(1:num_mapped);
       index_map_backward_tot(iii,which_frame) = index_map_backward(iii,1);
       dist_map_backward_tot(iii,which_frame) = dist_map_backward(iii,1);
end;
for iii = 1:num_nuclei_time(which_frame-1)
     [val_min,index_min] =  sort(sqrt(power(mean_x_tot_m1(iii)-mean_x_tot,2) + power(mean_y_tot_m1(iii)-mean_y_tot,2)));
     
      %if (val_min(1) < delta_move_threshold)
       index_map_forward(iii,:) = index_min(1:num_mapped);
       dist_map_forward(iii,:) = val_min(1:num_mapped);
       index_map_forward_tot(iii,which_frame-1) = index_map_forward(iii,1);
       dist_map_forward_tot(iii,which_frame-1) = dist_map_forward(iii,1);
       
       index_map_backward_tot_f(index_map_forward(iii,1),which_frame) = iii;
       dist_map_backward_tot_f(iii,which_frame-1) = dist_map_forward(iii,1);
      %else  % forward case where the nucleus exists at time 0
          %num_nuclei_time(which_frame) = num_nuclei_time(which_frame)+1;
          %mean_x_tot_time(num_nuclei_time(which_frame),which_frame) = mean_x_tot_m1(iii);
          %mean_y_tot_time(num_nuclei_time(which_frame),which_frame) = mean_y_tot_m1(iii);
          %num_pixels_tot_NUCLEUS_time(num_nuclei_time(which_frame),which_frame) = num_pixels_tot_NUCLEUS_time(iii,which_frame-1);
          %  index_map_forward_tot(iii,which_frame-1) = num_nuclei_time(which_frame);
          %  dist_map_forward_tot(iii,which_frame-1) = 0;
      % 
      %    index_map_backward_tot_f(num_nuclei_time(which_frame),which_frame) = iii;
      %    dist_map_backward_tot_f(iii,which_frame-1) = 0;
      %end;
       
end;
end;
toc


 num_nuclei_t0 = num_nuclei_max;
 num_nuclei_t0 = num_nuclei_time(1);
 
  % mapping of nuclei that existed at time 0 
 index_map_tot_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
 mean_x_tot_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
 mean_y_tot_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
 dist_map_tot_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
 num_pixels_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM);
 num_pixels_tot_CELL_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM);
  x_coord_min_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
  x_coord_max_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
  y_coord_min_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 
  y_coord_max_tot_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_max,numFr_NM); 

 for iii = 1:length(signal_channels)
 eval(['cytosolic_CH',num2str(iii),'_tot_time_mapped_t0 = zeros(num_nuclei_max,length(time_CH',num2str(ii_NM),'));']);
 eval(['nuclear_CH',num2str(iii),'_tot_time_mapped_t0 = zeros(num_nuclei_max,length(time_CH',num2str(ii_NM),'));']);
 end;       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% map the nucleus movements between frames, including mean positions and
% pixels number (size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for iii = 1:num_nuclei_t0
    ii_map = iii;  % points to the normal order for the first frame only
for kkk = 1:numFr_NM
  which_frame = kkk;
     if (kkk < numFr_NM)
      index_map_tot_time_mapped_t0(iii,which_frame+1) = index_map_forward_tot(ii_map,which_frame);
      dist_map_tot_time_mapped_t0(iii,which_frame+1) = dist_map_forward_tot(ii_map,which_frame);
     end;
    mean_x_tot_time_mapped_t0(iii,which_frame) = mean_x_tot_time(ii_map,which_frame);
    mean_y_tot_time_mapped_t0(iii,which_frame) = mean_y_tot_time(ii_map,which_frame);
    num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = num_pixels_tot_NUCLEUS_time(ii_map,which_frame);
    x_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = x_coord_min_tot_time(ii_map,which_frame);
    x_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = x_coord_max_tot_time(ii_map,which_frame);
    y_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = y_coord_min_tot_time(ii_map,which_frame);
    y_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame) = y_coord_max_tot_time(ii_map,which_frame);
     
    if (kkk == 1)
      index_map_tot_time_mapped_t0(iii,which_frame) = iii;  
    end;
    ii_map = index_map_forward_tot(ii_map,which_frame);  % points to the index of the properly mapped nuclues in the next frame
end;
end; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Determine the number of nuclei that are uniquely mapped throughout the whole 
% movie.  And those that formed (converged, at least two cells) to a
% degenerate (the same) mapping
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%test_for_and_fix_degenerate_mappings;  % code as of 04/26/20, calls test_for_convergence_events.m

test_for_and_fix_degenerate_mappings_TEST  % debugging for the paper, calls test_for_convergence_events_TEST.m



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LAST STEP: Identify and string togeth nuclei that were not present 
% in the first image, either by the threshold test or a new daughter or mobile border cell
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate the number of unused nuclei (those not part of a sequence so far)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

check_for_unused_nuclei = 0;
if (check_for_unused_nuclei == 1)


used_nuclei_tot_time = zeros(numFr_NM,1);
used_nuclei_tot_time_INITIAL = zeros(numFr_NM,1);
for kkk = 1:numFr_NM
    which_frame = kkk;
    used_nuclei_tot_time(which_frame) = sum(used_nuclei_track_time(1:num_nuclei_time(which_frame),which_frame));
    used_nuclei_tot_time_INITIAL(which_frame) = sum(used_nuclei_track_time_INITIAL(1:num_nuclei_time(which_frame),which_frame));
end;

unused_nuclei_tot_time = (num_nuclei_time-used_nuclei_tot_time)'
unused_nuclei_tot_time_INITIAL = (num_nuclei_time-used_nuclei_tot_time_INITIAL)'

end; % if (check_for_unused_nuclei == 1)






check_for_daughters = 0;
if (check_for_daughters == 1)

  %  TO DO:  daugher and mother must get the same prior signal
  % add new cell here
  %index_map_forward_daughter(index_map_forward(jj),jj) = index_new_cell;
  
  
  
  num_daughters_current = 0;
  
  
  

for ii = 1:num_nuclei
    
    cell_divided = 0;
    
    %  only signals that exist over the whole duration will be counted
    
    
    signal_nucleus_FITC_time(ii,1) = signal_nucleus_FITC(ii);     
    
    for jj = 1:numFr_NM-1        
       signal_nucleus_FITC_time(ii,jj) = signal_nucleus_FITC(index_map_forward(jj));
        if (index_map_forward_daughter(index_map_forward(jj),jj) > 0)
           cell_divided = 1;
           num_daughter_current = num_daughter_current + 1; 
           signal_nucleus_FITC_time_daughter(num_daughter_current,1:jj-1) = signal_nucleus_FITC(ii,1:jj-1); 
             index_daughter_current(num_daughter_current) = index_map_forard_daughter(index_map_forward(jj),jj);
             signal_nucleus_FITC_time_daughter(ii,jj) = signal_nucleus_FITC(index_map_forward(index_daughter_current(num_daughter_current)));
        elseif (cell_divided == 1)
            index_daughter_current(num_daughter_current) = index_map_forward(index_daughter_current(num_daughter_current));   
            signal_nucleus_FITC_time_daughter(ii,jj) = signal_nucleus_FITC(index_map_forward(index_daughter_current(num_daughter_current)));
        end;
    end;
    
end;


end;  % END OF: if (check_for_daugthers == 1)
