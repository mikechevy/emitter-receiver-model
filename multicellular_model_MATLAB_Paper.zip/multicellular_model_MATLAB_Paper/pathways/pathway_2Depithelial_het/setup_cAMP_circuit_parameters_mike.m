%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%  Andrew's Python Code, uncommented variables are used in setup_gillespie_pathway_multicellular.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

scale_time_rates = 5/(40*60);  % scales a 5 second time window to a 40 minute time window

if (do_transfer_function_pulse == 0)
%pulse_start_effective = 10;
shift_zero_value = 20;
pulse_start_effective = shift_zero_value + 5;
pulse_width_effective = 5;
time_to_off_effective = 5;
elseif (do_transfer_function_pulse == 1)   
%pulse_start_effective = 5 + 5*15/40;
shift_zero_value = 15 +2 + (do_IBMX*.3);
pulse_start_effective = shift_zero_value + 5*15/40;
pulse_width_effective = 5*(6+do_bPAC_turnoff_finite*.5)/40;
time_to_off_effective = 5;
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  binary factors (0 or 1), turns on or off various inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fac_I_bPAC = 1;  % 0-no, 1-yes
fac_I_cAMP_gap = do_GJ_inhibition;  % 0-no, 1-yes (inihbition)
fac_I_Calcium_gap = 0;  % 0-no, 1-yes
fac_I_IBMX = do_IBMX;  % 0-no, 1-yes
fac_I_H89 = do_H89;  % 0-no, 1-yes


      % if do_CX43_NGFP == 1    % broken gap-junctions, weaker fluxe
      %   fac_I_cAMP_gap = 1;  % 0-no, 1-yes
      % end;



if (do_ALL_bPAC == 1)
bPAC_NUCLEUS_time_mapped_t0(:,:) = 1;
end;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  binary factors (0 or 1), turns on or off various regulatory connections
%  between pathway elements
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fac_ac_pk = do_PKA_reg_AC; %#Turns on feedback from PKA to AC
fac_c_pd = do_PKA_PDE_reg_cAMP; %#turns on feedback from PDE (upregulated by PKA) to cAMP
fac_pk_pd = 0; %#turns on feedback from PDE to PKA
fac_gj_pk = do_PKA_reg_GJ; %#  1 - pka regulated gap junctions (our model), 0 - constant gap junction activity


if (fac_ac_pk == 1)&(fac_c_pd == 1)&(fac_pk_pd == 1)&((fac_gj_pk == 1)|(fac_gj_pk == 0))
     num_gjc_minute_delay = 10;
     num_gjc_delay_steps = 5;  % the delay of pka related gap-junction formation
     amp_bPAC = 1;
     do_basal_gap = 1;
     alpha_bPAC_basal = 0% can be -1 to N (positivive), 0 if no difference in basal cAMP rates between bPAC/non-bPAC;
     setup_cAMP_circuit_parameters_fac_1111
     %setup_cAMP_circuit_parameters_fac_012717
%elseif (fac_ac_pk == 1)&(fac_pk_pd == 0)&(fac_c_pd == 1)&(fac_gj_pk == 1)
%     num_gjc_delay_steps = 2;  % the delay of pka related gap-junction formation
%     setup_cAMP_circuit_parameters_fac_1011
elseif ((fac_ac_pk == 1)|(fac_ac_pk == 0))&((fac_c_pd == 0)|(fac_c_pd == 1))&(fac_pk_pd == 0)&((fac_gj_pk == 1)|((fac_gj_pk == 0)))
     num_gjc_minute_delay = time_gj_delay;
     num_gjc_delay_steps = step_gj_delay;  % the delay of pka related gap-junction formation
     if (do_GJ2 == 1)
       num_gjc2_minute_delay = time_gj2_delay;
       num_gjc2_delay_steps = step_gj2_delay;  % the delay of pka related gap-junction formation
     end;
     %num_gjc_minute_delay = 25;
     %num_gjc_delay_steps = 2;  % the delay of pka related gap-junction formation
     alpha_bPAC_basal = N_alpha_bPAC_basal %10;% can be -1 to N (positivive), 0 if no difference in basal cAMP rates between bPAC/non-bPAC;
     amp_bPAC = bPAC_amplitude; %  0 <= amp_bPAC <= 1
       if (fac_gj_pk == 0)
        do_basal_gap = 1;
       else
        %%do_basal_gap = 0;
        do_basal_gap = 1;
       end;
           if (fac_I_H89 == 1)  % no cell-cell coupling
               do_basal_gap = 0;
           end;
     setup_cAMP_circuit_parameters_fac_1001
%elseif (fac_ac_pk == 1)&(fac_pk_pd == 0)&(fac_c_pd == 0)&(fac_gj_pk == 0)
%     num_gjc_delay_steps = 2;  % the delay of pka related gap-junction formation
%     setup_cAMP_circuit_parameters_fac_1000
end;
    



ii_cAMP = 1;
ii_PKA_off = 2;
ii_PKA_on = 3;
ii_PDE_off = 4;
ii_PDE_on = 5;
ii_ERK_off = 6;
ii_ERK_on = 7;
ii_ERKKTR_n = 8;
ii_ERKKTR_c = 9;
 ii_GJ_complex_off = 10;
 ii_GJ_complex_on = 11;
 ii_GJ_complex_on_1 = 12;
 ii_GJ_complex_on_2 = 13;
 ii_GJ_complex_on_3 = 14;
 ii_GJ_complex_on_4 = 15;
 ii_GJ_complex_on_5 = 16;
 ii_GJ_complex_on_6 = 17;
 ii_GJ_complex_on_7 = 18;
 ii_GJ_complex_on_8 = 19;
 ii_GJ_complex_on_9 = 20;
 ii_GJ_complex_on_10 = 21;
 ii_GJ_complex_on_11 = 22;
 ii_GJ_complex_on_12 = 23;
 ii_GJ_complex_on_13 = 24;
 ii_GJ_complex_on_14 = 25;
 ii_GJ_complex_on_15 = 26;
 ii_GJ_complex_on_16 = 27;
 if (do_GJ2 == 1)
  ii_GJ2_complex_off = 10 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on = 11 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_1 = 12 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_2 = 13 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_3 = 14 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_4 = 15 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_5 = 16 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_6 = 17 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_7 = 18 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_8 = 19 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_9 = 20 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_10 = 21 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_11 = 22 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_12 = 23 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_13 = 24 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_14 = 25 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_15 = 26 + num_gjc_delay_steps + 2;
  ii_GJ2_complex_on_16 = 27 + num_gjc_delay_steps + 2;
 end;

 if (do_GJ2==0)     
   num_molecules_cell = 11+num_gjc_delay_steps;
 elseif (do_GJ2==1)
   num_molecules_cell = 11+num_gjc_delay_steps + do_GJ2*(2+num_gjc2_delay_steps);
 end;
 num_inputs = 5;  % global inputs 
 num_molecules = num_molecules_cell*num_cells + num_inputs;

ii_I_bPAC = num_molecules_cell*num_cells + 1;
ii_I_cAMP_gap = num_molecules_cell*num_cells + 2;
ii_I_Calcium_gap = num_molecules_cell*num_cells + 3;
ii_I_IBMX = num_molecules_cell*num_cells + 4;  % gap junction inhibitor
ii_I_H89 = num_molecules_cell*num_cells + 5;   %


num_inputs_plot = fac_I_bPAC + fac_I_cAMP_gap + fac_I_Calcium_gap + fac_I_IBMX + fac_I_H89

 if (num_inputs_plot == 1)&(fac_I_bPAC==1)
  str_input_plot1 = 'bPAC';
  which_inputs_plot = [ii_I_bPAC]; 
 elseif (num_inputs_plot == 2)&(fac_I_bPAC==1)
  if (fac_I_cAMP_gap == 1)   
    str_input_plot1 = 'gap junction inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_cAMP_gap ii_I_bPAC]; 
  elseif (fac_I_IBMX == 1)   
    str_input_plot1 = 'PDE inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_IBMX ii_I_bPAC]; 
  elseif (fac_I_H89 == 1)   
    str_input_plot1 = 'PKA inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_H89 ii_I_bPAC]; 
  end;
 elseif (num_inputs_plot == 3)&(fac_I_bPAC==1)&(fac_I_cAMP_gap == 1)
  if (fac_I_IBMX == 1)   
    str_input_plot1 = 'gap junction inhibitor';
    str_input_plot2 = 'PDE inhibitor';
    str_input_plot3 = 'bPAC';
    which_inputs_plot = [ii_I_cAMP_gap ii_I_IBMX ii_I_bPAC]; 
  elseif (fac_I_H89 == 1)   
    str_input_plot1 = 'gap junction inhibitor';
    str_input_plot1 = 'PKA inhibitor';
    str_input_plot2 = 'bPAC';
    which_inputs_plot = [ii_I_cAMP_gap ii_I_H89 ii_I_bPAC]; 
  end;
 end;

    
    
 
  for ii = 1:num_cells
  y_0(num_molecules_cell*(ii-1)+ii_cAMP) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_PKA_off) = num_PKA;
  y_0(num_molecules_cell*(ii-1)+ii_PKA_on) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_PDE_off) = num_PDE;
  y_0(num_molecules_cell*(ii-1)+ii_PDE_on) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_ERK_off) = num_ERK;
  y_0(num_molecules_cell*(ii-1)+ii_ERK_on) = 0;
  y_0(num_molecules_cell*(ii-1)+ii_ERKKTR_n) = num_ERKKTR;
  y_0(num_molecules_cell*(ii-1)+ii_ERKKTR_c) = 0;
    if (do_GJ2 == 0)
     y_0(num_molecules_cell*(ii-1)+ii_GJ_complex_off) = num_GJ_complex;
     y_0(num_molecules_cell*(ii-1)+ii_GJ_complex_on) = 0;
    elseif (do_GJ2 == 1)
     y_0(num_molecules_cell*(ii-1)+ii_GJ_complex_off) = (1-frac_gj2)*num_GJ_complex;
     y_0(num_molecules_cell*(ii-1)+ii_GJ_complex_on) = 0;
     y_0(num_molecules_cell*(ii-1)+ii_GJ2_complex_off) = frac_gj2*num_GJ_complex;
     y_0(num_molecules_cell*(ii-1)+ii_GJ2_complex_on) = 0;
    end
  end;

  
  
 
 
%tt1 = arange(0,10,1e-2)
%tt2 = arange(10,15,1e-2)
%tt3 = arange(15,20,1e-2)
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % setup input time array
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      num_inputs_time_samples = 6;  % number of times samples to construct the input time signal
      map_inputs_data_sampled = zeros(num_inputs,1);
      time_inputs_data_sampled = zeros(num_inputs,num_inputs_time_samples);
      inputs_data_sampled = zeros(num_inputs,num_inputs_time_samples);

      time_max = 20;

      %  initialize, and adjust below for specific inputs
      for ii = 1:num_inputs
      time_inputs_data_sampled(ii,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii,2) = 12.5/scale_time_rates;
      time_inputs_data_sampled(ii,3) = (12.5+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii,4) = (20-2e-6)/scale_time_rates;
      time_inputs_data_sampled(ii,5) = (20-1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii,6) = (20)/scale_time_rates;
      end;
 
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_I_bPAC
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_bPAC == 1)
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      
      
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,1) = 0;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,2) = 0;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,3) = amp_bPAC;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,4) = amp_bPAC;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,5) = 0;
      inputs_data_sampled(ii_I_bPAC-num_molecules_cell*num_cells,6) = 0;
      end;  % if (fac_I_bPAC == 1)


      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_cAMP_gap
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_cAMP_gap == 1)
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = 12.5/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = (12.5+1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = (20-2e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = (20-1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = (20)/scale_time_rates;      
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = 1; %1;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = 1; %1;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = 1; %0;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = 1; %0;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = 1; %0;
      inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = 1; %0;
      
       %if do_CX43_NGFP == 1   % broken gap-junctions, weaker fluxe  
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,1) = fac_CX43_NGFP; %1;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,2) = fac_CX43_NGFP; %1;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,3) = fac_CX43_NGFP; %0;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,4) = fac_CX43_NGFP; %0;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,5) = fac_CX43_NGFP; %0;
       % inputs_data_sampled(ii_I_cAMP_gap-num_molecules_cell*num_cells,6) = fac_CX43_NGFP; %0;
       %end;
      
      
      end;
      
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_I_IBMX
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_IBMX == 1)
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,2) = 12.5/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,3) = (12.5+1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,4) = (20-2e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,5) = (20-1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,6) = (20)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,1) = 1; 
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,2) = 1; 
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,3) = 1;
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,4) = 1;
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,5) = 1;
      inputs_data_sampled(ii_I_IBMX-num_molecules_cell*num_cells,6) = 1;
      end;
      
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      % ii_I_H89
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      if (fac_I_H89 == 1)
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,2) = 12.5/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,3) = (12.5+1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,4) = (20-2e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,5) = (20-1e-6)/scale_time_rates;
      %time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,6) = (20)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,1) = 0/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,2) = pulse_start_effective/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,3) = (pulse_start_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,4) = (pulse_start_effective+pulse_width_effective)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,5) = (pulse_start_effective+pulse_width_effective+1e-6)/scale_time_rates;
      time_inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,6) = (pulse_start_effective+pulse_width_effective+time_to_off_effective)/scale_time_rates;

      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,1) = 1; 
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,2) = 1; 
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,3) = 1;
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,4) = 1;
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,5) = 1;
      inputs_data_sampled(ii_I_H89-num_molecules_cell*num_cells,6) = 1;
      end;
      

      time_max = max(time_inputs_data_sampled(1,length(time_inputs_data_sampled(1,:))));


  for ii = 1:num_inputs
   y_0(num_molecules_cell*num_cells+ii) = inputs_data_sampled(ii,1);  % inhibitor input;
  end;
