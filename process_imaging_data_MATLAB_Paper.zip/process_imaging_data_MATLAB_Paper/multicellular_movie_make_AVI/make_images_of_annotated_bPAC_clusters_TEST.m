%  spatial analyze of cells and their signals within a bPAC cluster and
%  non-bPAC cells outside the cluster

length_max_bPAC = 120;
%[bPAC_groups,size_bPAC_groups] = find_bPAC_clusters([mean_x_tot_SHRINK_time_mapped_t0(:,1) mean_y_tot_SHRINK_time_mapped_t0(:,1)],num_nuclei_t0,length_max_bPAC,ii_physical_distance,bPAC_NUCLEUS_time_mapped_t0(:,1));


M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_Erk = zeros(xLength,yLength);
M_BF = zeros(xLength,yLength);








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calculate_averaged signtures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mkdir(strcat(str_movie_processed_figures,'\annotated_bPAC_clusters'));
cd(strcat(str_movie_processed_figures,'\annotated_bPAC_clusters'));
     
           delete(strcat('map-annotated_cluster_BF-',str_movie,'_TEST.ppt'));
           delete(strcat('map-annotated_cluster-',str_movie,'_TEST.ppt'));
           

kkk = 1;
which_frame = kkk;

for jjj = 1:length(size_bPAC_clusters)     
fig110 = figure(110+jjj)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
     if (do_BF_channel ==0)  
         index_frame = 1;
        eval(['M_Erk(:,:) = M_CH',num2str(marker_from_channel(ii_Erk_marker)),'_total(:,:,index_frame);']);
     elseif (do_BF_channel ==1)    
       %eval(['[val,index_frame_BF]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_BF),'));']);    
       eval(['[val,index_frame_BF]= max(time_CH',num2str(ii_BF),');']);     
        eval(['M_BF(:,:) = M_CH',num2str(ii_BF),'_total(:,:,index_frame_BF);']);
     end;
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %imshow(mat2gray(M_NM));
    %%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
     if (do_BF_channel ==0)    
         filt = [-1 -1 -1;0 0 0;1 1 1];
         edgeG = filter2(filt,M_Erk);
         %edgeG = edge(M_Erk,'sobel');
      image_RGB(:,:,2) = scale_Erk_channel*edgeG(:,:)/max(max(edgeG));
      %image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
      image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
      imshow(image_RGB,[])
     elseif (do_BF_channel ==1)    
      %image_RGB(:,:,2) = scale_BF_channel*M_BF(:,:)/max(max(M_BF));
      %image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
      %imshow(image_RGB)
      image_BF = scale_BF_channel*M_BF(:,:)/max(max(M_BF));;
      imshow(image_BF)
      imagesc(image_BF)
     end;
    
    title(strcat(str_movie,', annotated bPAC cluster:',num2str(jjj)));
      for iii = 1:size_bPAC_clusters(jjj)
         idx = bPAC_clusters(jjj,iii);   
         which_frame = kkk;
          if (bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));           
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
          end;
         set(tt,'Color','w');
      end;
      for iii = 1:size_non_bPAC_clusters(jjj)
         idx = non_bPAC_clusters(jjj,iii);   
         tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
         if (min(abs(idx-non_bPAC_clusters_inner))==0)
          set(tt,'Color','y');
         else
          set(tt,'Color','m');
         end;
      end;
      
                             s_combine = 'bPAC cells around in a bPAC cluster';

   set(gcf,'inverthardcopy','off')   
     if (do_BF_channel ==0)    
      print('-depsc',strcat('map-annotated_cluster_',num2str(jjj),'-',str_movie,'_TEST.eps'));
      saveppt2(strcat('map-annotated_cluster-',str_movie,'_TEST.ppt'),'figure',[fig110], 'halign','center','title', s_combine);
     elseif (do_BF_channel ==1)    
      print('-depsc',strcat('map-annotated_cluster_BF_',num2str(jjj),'-',str_movie,'_TEST.eps'));
      saveppt2(strcat('map-annotated_cluster_BF-',str_movie,'_TEST.ppt'),'figure',[fig110], 'halign','center','title', s_combine);
     end;
      
end;

     

  
cd(str_processing);