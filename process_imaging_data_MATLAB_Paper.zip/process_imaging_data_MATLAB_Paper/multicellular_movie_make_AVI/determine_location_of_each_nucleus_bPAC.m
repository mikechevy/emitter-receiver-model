 
which_frame_bPAC
tic  
[mean_x_tot_NM_bPAC,mean_y_tot_NM_bPAC,var_x_tot_NM_bPAC,var_y_tot_NM_bPAC,cov_xy_tot_NM_bPAC,box_coords_NM_bPAC,num_pixels_tot_NM_bPAC,num_NM_bPAC,M_NM_bPAC_threshold,M_NM_bPAC_id_threshold,M_NM_bPAC_threshold_FILL,Cell_NM_bPAC_FILL,threshold_NM_bPAC] = determine_nuclear_locations_adaptive_recursive(M_NM_bPAC,which_frame_bPAC,xLength,yLength,nucleus_min_pixels,M_S1,M_S2,do_threshold_fac_adjust_bPAC);

 if which_frame_bPAC == 1
    num_pixels_tot_NUCLEUS_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
    mean_x_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
    mean_y_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
    var_x_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
    var_y_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
    cov_xy_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
    num_nuclei_time_bPAC = zeros(numFr_NM,1);         
     x_coord_min_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
     x_coord_max_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
     y_coord_min_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
     y_coord_max_tot_time_bPAC = zeros(2*num_NM_bPAC, numFr_NM);
 end;
num_nuclei_max_bPAC = max(num_nuclei_max_bPAC,num_NM_bPAC);
toc

     num_pixels_tot_NUCLEUS_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = num_pixels_tot_NM_bPAC(1:num_NM_bPAC);
     mean_x_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = mean_x_tot_NM_bPAC(1:num_NM_bPAC);
     mean_y_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = mean_y_tot_NM_bPAC(1:num_NM_bPAC);
     var_x_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = var_x_tot_NM_bPAC(1:num_NM_bPAC);
     var_y_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = var_y_tot_NM_bPAC(1:num_NM_bPAC);
     cov_xy_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = cov_xy_tot_NM_bPAC(1:num_NM_bPAC);
     num_nuclei_time_bPAC(which_frame_bPAC) = num_NM_bPAC;         
     x_coord_min_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = box_coords_NM_bPAC(1:num_NM_bPAC,1);
     x_coord_max_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = box_coords_NM_bPAC(1:num_NM_bPAC,2);
     y_coord_min_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = box_coords_NM_bPAC(1:num_NM_bPAC,3);
     y_coord_max_tot_time_bPAC(1:num_NM_bPAC,which_frame_bPAC) = box_coords_NM_bPAC(1:num_NM_bPAC,4);
     


    figure(105)
    imagesc(M_NM_bPAC_threshold)
    title('data-bPAC (binary)');
    figure(106)
    imagesc(M_NM_bPAC_threshold_FILL)
    title('data-bPAC (binary,fill)');
    figure(107)
    imagesc(M_NM_bPAC_id_threshold)
    title('data-bPAC (id)');
    
    
    str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
    mkdir(str_movie_processed);
    % Save into a file here
    file_nucleus = strcat(str_movie_processed,'\nucleus_bPAC_locations_frame',num2str(which_frame_bPAC));
    save(file_nucleus,'box_coords_NM_bPAC','num_NM_bPAC','M_NM_bPAC','M_NM_bPAC_threshold','M_NM_bPAC_id_threshold','M_NM_bPAC_threshold_FILL','Cell_NM_bPAC_FILL');
    for jj = 1:length(signal_channels)
      save(file_nucleus,strcat('M_S',num2str(jj)),'-append');
    end;
       Cell_FILL_dummy = genvarname(['Cell_nucleus_bPAC_FILL_',num2str(which_frame_bPAC)]);
       eval([Cell_FILL_dummy '=Cell_NM_bPAC_FILL']);
       Cell_FILL_dummy
      file_nucleus_tot = strcat(str_movie_processed,'\Cell_nucleus_bPAC_structs_tot');
     if (which_frame_bPAC == 1)
       save(file_nucleus_tot,strcat('Cell_nucleus_bPAC_FILL_',num2str(which_frame_bPAC)));
     else
       save(file_nucleus_tot,strcat('Cell_nucleus_bPAC_FILL_',num2str(which_frame_bPAC)),'-append');
     end;

