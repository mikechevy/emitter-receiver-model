
 c_mu = c_mu_0_time_array(:,which_time_segment);
 c_mu_0 = c_mu_0_time_array(:,which_time_segment);
 if (do_prop_time_vary == 1) 
   c_mu_tv = c_mu_tv_time_array(:,which_time_segment);
   phase_c_mu_tv = phase_c_mu_tv_time_array(:,which_time_segment);
   freq_tv = freq_tv_time_array(which_time_segment);
   time_constant_tv = time_constant_tv_time_array(which_time_segment);
 end;
