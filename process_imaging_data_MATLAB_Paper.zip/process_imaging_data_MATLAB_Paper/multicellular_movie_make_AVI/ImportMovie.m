function [ md ] = ImportMovie( path, numCh, numFr )
%UNTITLED2 Summary of this function goes here
%   Creates cell strucure of images, with dimensions (frames, channels)
% path is direction to one saved tif files, usually saved as sequence of
% single files

% MD=bfopen('C:\Users\JoaoPedro\Documents\UCSF\Microscopy
% data-large\150205-calcium-frettest\calcium-noinput_1\Pos0\img_000000000_C
% y3_000.tif');%
% numCh=3;
% numFr=120;

MD=bfopen(path);
MD=MD{1,1};
MD(:,2)=[];
md=cell(numFr, numCh);
for aa= 1:numCh    
for ii =aa:numCh:numCh*numFr;   
% eval(['Ch',
% num2str(aa),'(:,:,(',num2str(ii),'+',num2str(numCh),'-',num2str(aa),')/',
% num2str(numCh),') =(MD{',num2str(ii),'})']); % alternative and VERY slow
% way of getting data
md{(ii+numCh-aa)/numCh,aa}=MD{ii};
end
end
end

