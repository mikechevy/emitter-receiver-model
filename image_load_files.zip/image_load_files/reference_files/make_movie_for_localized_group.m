
fac_max = 2;  % factor the cell nucleus edge signal is above the highest marker signal
pixel_border = 20;  %  extra pixels around the cluster


num_clusters = 1;
max_pixel_FITC_tot = zeros(num_clusters,1);
max_pixel_CY3_tot = zeros(num_clusters,1);

  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   generate movies here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  max_max_max_FITC = max(max(max(M_FITC_total(x_coord_min_local:x_coord_max_local,y_coord_min_local:y_coord_max_local,:))));
  min_min_min_FITC = max(max(max(M_FITC_total(x_coord_min_local:x_coord_max_local,y_coord_min_local:y_coord_max_local,:))));


for which_cluster = 1:num_clusters    

                 x_coord_min = x_coord_min_local;
                 x_coord_max = x_coord_max_local;
                 y_coord_min = y_coord_min_local;
                 y_coord_max = y_coord_max_local;
   
   
label_cluster_only = 0; % 1 - yes, 0 - no
if (label_cluster_only == 1)
    index_group = zeros(length(size_cluster(which_cluster)),1);
for iii = 1:size_cluster(which_cluster)
      index_group(iii) = cluster(which_cluster,iii); 
end;
else % label all cells within the box
  ii_count = 0;
index_group = [];
which_frame = 1;
 for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,which_frame) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,which_frame) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,which_frame) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,which_frame) <= y_coord_max)
      index_group = [index_group ; iii]; 
      ii_count = ii_count+1;
    end;% end;
end;
end;



          do_make_movie = 1;  % 1 - yes, 0 - no
          if (do_make_movie == 1)
          filename_movie = strcat(str_movie,'_processed\cluster',num2str(which_cluster));
          delete(strcat(filename_movie,'.avi'));
          mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',2);
          end;
          
M_FITC = int16(zeros(xLength,yLength));
M_marker_threshold = int16(zeros(xLength,yLength));
M_marker_threshold_nuclear = int16(zeros(xLength,yLength));
          
for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)

  M_FITC = min(M_FITC_total(:,:,which_frame),1.0*max_max_max_FITC);
  %M_FITC(x_coord_min,y_coord_min) = max_max_max_FITC;  
  %M_FITC(x_coord_max,y_coord_max) = min_min_min_FITC;  
  
%M_marker_threshold_nuclear = 0*M_marker_threshold;
%M_marker_threshold_cell = 0*M_marker_threshold;
%M_marker_threshold_edge = 0*M_marker_threshold;

 %for jjj = 1:length(index_group)
 %    idx = index_group(jjj);
 %    idx_map = index_map_nuclei_t0(idx,which_frame);
 %      if (idx_map > 0)
 %      M_marker_threshold_TEST(Cell_DAPI_FILL.PixelIdxList{idx_map}) = 1;         
 %      end;
 %end;
%M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) =  edge(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'prewitt');


%M_marker_threshold_edge(x_coord_min:x_coord_max,y_coord_min:y_coord_max) =  edge(M_marker_threshold(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'prewitt');
%M_marker_threshold_TEST =  edge(M_marker_threshold_TEST,'canny');

figure(1)
%subplot(1,2,1)
%imagesc(max(M_FITC,fac_max*max_pixel_FITC_tot(which_cluster)*M_marker_threshold_edge))
imagesc((M_FITC))
%imagesc(max(M_CY3,fac_max*max_pixel_CY3_tot(which_cluster)*M_marker_threshold_edge))
   hold on;                 
    for jjj = 1:length(index_group)
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             %set(ll,'Color','m');

             
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('cell:',num2str(idx)));
             set(tt,'Color','y');
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);


%  ii_count = 0;
% index_group_box = [];
%  for iii = 1:num_nuclei_time(which_frame)
%     if (mean_x_tot_time(iii,which_frame) >= x_coord_min)&(mean_x_tot_time(iii,which_frame) <= x_coord_max)& (mean_y_tot_time(iii,which_frame) >= y_coord_min)&(mean_y_tot_time(iii,which_frame) <= y_coord_max)
%       index_group_box = [index_group_box ; iii]; 
%       ii_count = ii_count+1;
%     end;% end;
% end;
%  for iii = 1:length(index_group_box)
%      idx = index_group_box(iii);
%        M_marker_threshold_nuclear(eval('[Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}]')) = nuclear_FITC_tot_time_mapped_t0(idx,which_frame);         
%        M_marker_threshold_nuclear(eval('[Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx}]')) = cytosolic_FITC_tot_time_mapped_t0(idx,which_frame);         
%  end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   plot of average nuclear signals (over the nucleus) and average
%   cytosolic signals (over the cytosol).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M_FITC_no_nucleus = M_FITC.*(1-M_marker_threshold) + M_marker_threshold_nuclear; 
% subplot(1,2,2)
% imagesc(max(M_FITC_no_nucleus,fac_max*max_pixel_FITC_tot(which_cluster)*M_marker_threshold_edge))
% %imagesc(max(M_CY3,fac_max*max_pixel_CY3_tot(which_cluster)*M_marker_threshold_edge))
%    hold on;                 
%     for jjj = 1:length(index_group)
%        idx = index_group(jjj);
%        idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
%        
%              ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
%              set(ll,'Color','m');
% 
%              
%             if (idx_map > 0)
%               %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
%               %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)),'TextColor','w');                    
%              tt =  text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)));                   
%              set(tt,'Color','y');
%             end;        
%     end;
%    hold off;
%     xlim([y_coord_min y_coord_max]);
%     ylim([x_coord_min x_coord_max]);

    
    
    if (do_make_movie == 1)
    H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
    end;
    
    pause(.2)
end;  % end of  'for kkk = 1:length(which_frames)



             if (do_make_movie == 1)
             mov = close(mov)
             end;


end; % END OF:  for which_cluster = 1:num_clusters
             
             
