M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_Erk = zeros(xLength,yLength);

    % Default for now, but movie specific later
    scale_Erk_channel = 0.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels


kkk = 1;
which_frame = kkk;

    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    eval(['M_Erk(:,:) = M_CH',num2str(marker_from_channel(ii_Erk_marker)),'_total(:,:,index_frame_bPAC);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %imshow(mat2gray(M_NM));
    %%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    figure(10000)
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
    image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)


which_frame_NM = 1;
    
    
for kkk = 1:num_nuclei_t0

             tt = text(mean_y_tot_time_mapped_t0(kkk,which_frame_NM),mean_x_tot_time_mapped_t0(kkk,which_frame_NM),strcat(num2str(kkk)));
             %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),'.');
             if ii_NM == ii_NM_bPAC  % all bPAC cells
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
               str_emitter = 'm';
               set(tt,'Color',str_emitter);
               %set(tt,'fontsize',12);
             else
               if (bPAC_NUCLEUS_time_mapped_t0(kkk,1) == 1)    
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
                   str_emitter = 'c';
                 set(tt,'Color',str_emitter);
               else
               set(tt,'Color','y');
               end;
             end;
             
                 if (idx == kkk)  % (place circle around specified nucleus) 
                      %e
                      %r= desired radius
                      %x = x coordinates of the centroid
                      %y = y coordinates of the centroid
                      r = 20;   %pixels
                      th = 0:pi/50:2*pi;
                      xunit = r * cos(th) + mean_x_tot_time_mapped_t0(kkk,which_frame_NM);
                      yunit = r * sin(th) + mean_y_tot_time_mapped_t0(kkk,which_frame_NM);
                      hold on;
                       if (bPAC_NUCLEUS_time_mapped_t0(kkk,1) == 1)    
                        xx = plot(yunit, xunit,strcat(str_emitter,'--'));
                       else
                        xx = plot(yunit, xunit,'y--');
                       end;
                       set(xx,'LineWidth',2);
                       hold off;
                 end;


end;             

             
% if (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)



if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 

do_just_nuclear_signal = 0;  % 0-ratio of nuclear to cytosol, 1-nuclear signal/min(nuclear signal);  For powerpoint stuff

  if (which_nuclei_signal_type == 1) % shrink
      str_nuclei_signal_type = 'SHRINK_';
  elseif (which_nuclei_signal_type == 2) % intersect
      str_nuclei_signal_type = 'INTERSECT_';
  elseif (which_nuclei_signal_type == 3) % circle
      str_nuclei_signal_type = 'CIRCLE_';
  end;
      
if (do_just_nuclear_signal == 1)
  str_just_nuclear = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
elseif (do_just_nuclear_signal == 0)
  str_just_nuclear = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
end;
  mkdir(strcat(str_movie_processed_figures,'\cellular_signals_eps_statistics'));
  
M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);

sig_dummy_average_bPAC_pulse_cell = zeros(1, length(time_Erk));
count_pulse_cell = 0;

s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
      
          % plots average signals
          sig_dummy_nuclear_average = zeros(1, length(time_Erk));
          sig_dummy_ratio_average = sig_dummy_nuclear_average;          
          ratio_signal = zeros(num_nuclei_t0,length(time_Erk));
     


%for idx = 1:num_nuclei_t0
idx 
    


          
    
   
     do_plot_stuff = 1; % 0 - no, 1 - yes
     if (do_plot_stuff == 1)
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Make plot of result 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     ii_plot_count = 0;
     figure(200)
     title(strcat('nuclear Erk signal (',Erk_str,')'));
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
     subplot(3,1,1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(ii_plot_count+1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     ylabel(strcat('(nuc-min(nuc))/max(nuc-min(nuc))'));
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+1.1*(max(sig_dummy/min_sig)-1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
           
       if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
           str_bPAC = ' (bPAC)';
           str_bPAC_eps = '-bPAC';
       else
           str_bPAC = ' (non-bPAC)';
           str_bPAC_eps = '-non-bPAC';
       end;
            
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str));
                  
     
     subplot(3,1,2) 
     hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     
     ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*max((max(sig_dummy)-min(sig_dummy)),.1)]);
     xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;



     d_cAMP_conc = 50;

          subplot(3,1,3)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*d_cAMP_conc]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          
          
     
          %pause
          %figure(200)
          %cd(strcat('figures-',str_movie,'\cellular_signals_eps_statistics'));          
          %print('-depsc',strcat('nuc_',num2str(idx),str_bPAC_eps,'-Erk-',str_movie,'.eps'));   
          %cd ../../;
          %close(200)

           
     end; % end of 'if (do_plot_stuff == 1)'
%end; % for idx = 1:num_nuclei_t0






   
end;   % if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)
   
%end; % if (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)




