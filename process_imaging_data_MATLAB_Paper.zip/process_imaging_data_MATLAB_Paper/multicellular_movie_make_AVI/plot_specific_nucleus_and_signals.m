function plot_specific_nucleus_and_signals(which_nucleus,M_NM_id_threshold,M_NM,M_S1,M_S2,box_coords)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Divide and conquer:  threshold into two pieces at a time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


box_coords_new = zeros(10,4);
num_pixels_new = zeros(10,1);
signal_tot_new = zeros(10,1);
signal_std_tot_new = zeros(10,1);

    M_S1_TEST = M_S1;    
    M_NM_TEST = M_NM;    
    M_S2_TEST = M_S2;    
    M_NM_id_threshold_TEST = M_NM_id_threshold;    

   matrix_nucleus_SCRAP = 0*M_NM;             

                 x_coord_min = box_coords(which_nucleus,1);
                 x_coord_max = box_coords(which_nucleus,2);
                 y_coord_min = box_coords(which_nucleus,3);
                 y_coord_max = box_coords(which_nucleus,4);


                 
                 
matrix_id = 0*M_NM_id_threshold;                  
Val_threshold_max = max(max(M_NM(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
Val_threshold_min = Val_threshold_max;        
for ii = x_coord_min:x_coord_max                 
for jj = y_coord_min:y_coord_max                 

     if (M_NM_id_threshold(ii,jj) == which_nucleus)
       Val_threshold_min = min(M_NM(ii,jj), Val_threshold_min);
     end;
end;
end;



upper = .16;
lower = 1-upper;
Val_threshold_test = lower*Val_threshold_min + upper*Val_threshold_max;

for ii = x_coord_min:x_coord_max                 
for jj = y_coord_min:y_coord_max                 

     if (M_NM_id_threshold(ii,jj) == which_nucleus)&(M_NM(ii,jj) > Val_threshold_test)
       matrix_id(ii,jj) = 1;
     end;
    M_NM_id_threshold_TEST(ii,jj) = M_NM_id_threshold(ii,jj)*matrix_id(ii,jj);    
    M_S1_TEST(ii,jj) = M_S1(ii,jj)*matrix_id(ii,jj);    
    M_NM_TEST(ii,jj) = M_NM(ii,jj)*matrix_id(ii,jj);    
    M_S2_TEST(ii,jj) = M_S2(ii,jj)*matrix_id(ii,jj);    
end;
end;

Val_threshold_max = max(max(M_NM_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));

num_boxes_new = 0;
for ii = x_coord_min:x_coord_max                 
for jj = y_coord_min:y_coord_max    
  if (M_NM_id_threshold_TEST(ii,jj) > 1)        
        FSTEP = 'W';
        if (ii == 1)
          FSTEP = 'S';
        end;      
      B = bwtraceboundary(M_NM_id_threshold_TEST,[ii jj],FSTEP);
         box_coords_new(num_boxes_new+1,1) = min(B(:,1));
         box_coords_new(num_boxes_new+1,2) = max(B(:,1));
         box_coords_new(num_boxes_new+1,3) = min(B(:,2));
         box_coords_new(num_boxes_new+1,4) = max(B(:,2));
         num_boxes_new = num_boxes_new+1;
         for iii = 1:length(B)
           matrix_nucleus_SCRAP(B(iii,1),B(iii,2)) = num_boxes_new;
         end;
           matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');
                 x_coord_min_new = box_coords_new(num_boxes_new,1);
                 x_coord_max_new = box_coords_new(num_boxes_new,2);
                 y_coord_min_new = box_coords_new(num_boxes_new,3);
                 y_coord_max_new = box_coords_new(num_boxes_new,4);
                 
                num_pixels_dummy = 0;
                signal_tot_dummy = 0;
                signal_sqr_tot_dummy = 0;
                for iii = x_coord_min_new:x_coord_max_new                 
                for jjj = y_coord_min_new:y_coord_max_new 
                    if (matrix_nucleus_SCRAP(iii,jjj) == num_boxes_new)
                        M_NM_id_threshold_TEST(iii,jjj) = 0;
                        num_pixels_dummy = num_pixels_dummy + 1;
                        signal_tot_dummy = signal_tot_dummy + M_S1(iii,jjj);
                        signal_sqr_tot_dummy = signal_sqr_tot_dummy + power(M_S1(iii,jjj),2);
                    end;                     
                end;
                end;
                
              num_pixels_new(num_boxes_new) = num_pixels_dummy;  
              signal_tot_new(num_boxes_new) = signal_tot_dummy/num_pixels_dummy
              signal_std_tot_new(num_boxes_new) = sqrt(signal_sqr_tot_dummy/num_pixels_dummy-power(signal_tot_new(num_boxes_new),2))
                
         
  end;
end;
end;


num_nuclei_new = num_boxes_new;

mean_x_tot = zeros(num_nuclei_new,1);
mean_y_tot = zeros(num_nuclei_new,1);
var_x_tot = zeros(num_nuclei_new,1);
var_y_tot = zeros(num_nuclei_new,1);
cov_xy_tot = zeros(num_nuclei_new,1);
num_pixels_tot = zeros(num_nuclei_new,1);

for ii = x_coord_min:x_coord_max                 
    for jj = y_coord_min:y_coord_max 
         val_dummy = matrix_nucleus_SCRAP(ii,jj);
        if (val_dummy > 0)
            mean_x_tot(val_dummy) = mean_x_tot(val_dummy) + ii;
            mean_y_tot(val_dummy) = mean_y_tot(val_dummy) + jj;
            var_x_tot(val_dummy) = var_x_tot(val_dummy) + ii*ii;
            var_y_tot(val_dummy) = var_y_tot(val_dummy) + jj*jj;
            cov_xy_tot(val_dummy) = cov_xy_tot(val_dummy) + ii*jj;
            num_pixels_tot(val_dummy) = num_pixels_tot(val_dummy) + 1;
        end;
    end;
end;

for ii = 1:num_nuclei_new
    mean_x_tot(ii) = mean_x_tot(ii)/num_pixels_tot(ii); 
    mean_y_tot(ii) = mean_y_tot(ii)/num_pixels_tot(ii); 
    var_x_tot(ii) = var_x_tot(ii)/num_pixels_tot(ii) - power(mean_x_tot(ii),2); 
    var_y_tot(ii) = var_y_tot(ii)/num_pixels_tot(ii) - power(mean_y_tot(ii),2); 
    cov_xy_tot(ii) = cov_xy_tot(ii)/num_pixels_tot(ii) - power(mean_x_tot(ii)*mean_y_tot(ii),1); 
end;


x_test = (mean_x_tot(1)+mean_x_tot(2))/2;
y_test = (mean_y_tot(1)+mean_y_tot(2))/2;
x_test_m1 = mean_x_tot(1);
y_test_m1 = mean_y_tot(1);
while (matrix_nucleus_SCRAP(ceil(x_test),ceil(y_test)) ~= 0 )&(matrix_nucleus_SCRAP(ceil(x_test),floor(y_test)) ~= 0 )&(matrix_nucleus_SCRAP(floor(x_test),ceil(y_test)) ~= 0 )&(matrix_nucleus_SCRAP(floor(x_test),floor(y_test)) ~= 0 )

      x_test_m1 = x_test;
      y_test_m1 = y_test;
  if (matrix_nucleus_SCRAP(round(x_test),round(y_test)) == 1)
       x_test = x_test + abs((x_test-x_test_m1)/2)*(mean_x_tot(2)-mean_x_tot(1))/abs(mean_x_tot(2)-mean_x_tot(1));
       y_test = y_test + abs((y_test-y_test_m1)/2)*(mean_y_tot(2)-mean_y_tot(1))/abs(mean_y_tot(2)-mean_y_tot(1));
  else
       x_test = x_test + abs((x_test-x_test_m1)/2)*(mean_x_tot(1)-mean_x_tot(2))/abs(mean_x_tot(1)-mean_x_tot(2));
       y_test = y_test + abs((y_test-y_test_m1)/2)*(mean_y_tot(1)-mean_y_tot(2))/abs(mean_y_tot(1)-mean_y_tot(2));
  end;
       
    
end;

if (matrix_nucleus_SCRAP(ceil(x_test),ceil(y_test)) == 0 )
    x_test = ceil(x_test);
    y_test = ceil(y_test);
elseif (matrix_nucleus_SCRAP(ceil(x_test),floor(y_test)) == 0 )
    x_test = ceil(x_test);
    y_test = floor(y_test);
elseif (matrix_nucleus_SCRAP(floor(x_test),ceil(y_test)) == 0 )
    x_test = floor(x_test);
    y_test = ceil(y_test);
elseif (matrix_nucleus_SCRAP(floor(x_test),floor(y_test)) == 0 )
    x_test = floor(x_test);
    y_test = floor(y_test);
end;

                r_max = 15;
            for kkk = 1:num_boxes_new    
                num_pixels_dummy = 0;
                signal_tot_dummy = 0;
                signal_sqr_tot_dummy = 0;
                 x_coord_min_new = box_coords_new(kkk,1);
                 x_coord_max_new = box_coords_new(kkk,2);
                 y_coord_min_new = box_coords_new(kkk,3);
                 y_coord_max_new = box_coords_new(kkk,4);
                for iii = x_coord_min_new:x_coord_max_new                 
                for jjj = y_coord_min_new:y_coord_max_new 
                    if (matrix_nucleus_SCRAP(iii,jjj) == kkk)&(power(iii-x_test,2)+power(jjj-y_test,2) < power(r_max,2))
                        M_NM_id_threshold_TEST(iii,jjj) = 0;
                        num_pixels_dummy = num_pixels_dummy + 1;
                        signal_tot_dummy = signal_tot_dummy + M_S1(iii,jjj);
                        signal_sqr_tot_dummy = signal_sqr_tot_dummy + power(M_S1(iii,jjj),2);
                    end;                     
                end;
                end;
                
              num_pixels_new_r_max(kkk) = num_pixels_dummy;
              signal_tot_new_r_max(kkk) = signal_tot_dummy/num_pixels_dummy;
              signal_std_tot_new_r_max(kkk) = sqrt(signal_sqr_tot_dummy/num_pixels_dummy-power(signal_tot_new_r_max(kkk),2));
            end;

            signal_tot_new_r_max
            signal_std_tot_new_r_max
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%  M_NM_id_threshold              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             

             figure(99)
             imagesc(M_NM_id_threshold)             
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
              
            
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%  M_NM_id_threshold_TEST              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
              
             figure(100)
             imagesc(M_NM_id_threshold_TEST)             
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
              
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%  matrix_nucleus_SCRAP              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
              
             figure(101)
             imagesc(matrix_nucleus_SCRAP)             
             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
              
                for ii = 1:num_nuclei_new
                 text(mean_y_tot(ii),mean_x_tot(ii),'X');
                end;
                 text(y_test,x_test,'O');
            
                line([mean_y_tot(1) mean_y_tot(2)], [mean_x_tot(1) mean_x_tot(2)]);
                ellipse(r_max,r_max,pi/2,y_test,x_test);
                
                
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);

              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%  S1              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
             figure(102)
             imagesc(M_S1_TEST)             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('S1')
              
                for ii = 1:num_nuclei_new
                 text(mean_y_tot(ii),mean_x_tot(ii),'X');
                end;
                 text(y_test,x_test,'O');
            
                line([mean_y_tot(1) mean_y_tot(2)], [mean_x_tot(1) mean_x_tot(2)]);
                ellipse(r_max,r_max,pi/2,y_test,x_test);
              
              
              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             
%  S2              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%             

              figure(103)
             imagesc(M_S2_TEST)             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('S2')
              
              do_plot_signals = 0;
              
            if (do_plot_signals == 1)
             figure(101)
             imagesc(M_S1)             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('S1')
                    
             figure(101)
             surf(M_S1)             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('S1 (surf)')

             figure(103)
             imagesc(double(M_NM))             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('NM')
              
             figure(104)
             surf(double(M_NM))             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('NM (surf)')


             figure(105)
             imagesc(double(M_S2))             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('S2')
              
             figure(106)
             surf(double(M_S2))             
              xlim([y_coord_min y_coord_max]);
              ylim([x_coord_min x_coord_max]);
              title('S2 (surf)')
            end; % end of 'if (do_plot_signals == 1)'

