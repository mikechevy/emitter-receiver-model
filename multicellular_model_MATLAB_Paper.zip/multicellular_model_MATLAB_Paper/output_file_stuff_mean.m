
if (do_mean_or_full == -1)&(do_particles==0)
time_mean_t = time_ma_t;
x_mean_t = y_ma_t;
end;

 if (do_cell_cycle_effects==1)
  if (do_covariances == 1)
    num_moment_terms = (num_molecules*num_molecules + num_molecules)/2 + num_molecules_volume + do_cell_cycle_effects*(num_volumes+1);
  else
    num_moment_terms = num_molecules + do_cell_cycle_effects*(num_volumes+1);
  end;
 elseif (do_multicellular==1)
    num_moment_terms = num_molecules;  % mean only
 else
  if (do_covariances == 1)
    num_moment_terms = (num_molecules*num_molecules + num_molecules)/2 + num_molecules;
  else
    num_moment_terms = num_molecules;
  end;     
 end;

  
if (kkk==1)  
  fids_data_mean = fopen('data/ssa_data_mean.out','wb');
              fwrite(fids_data_mean,num_moment_terms,'int');
              fwrite(fids_data_mean,length(time_mean_t),'int');
              fwrite(fids_data_mean,time_mean_t,'double');
            for ii = 1:length(time_mean_t)
              fwrite(fids_data_mean,x_mean_t(ii,1:num_moment_terms),'double');
            end;
  fclose(fids_data_mean);
end; 

  if (kkk==1)
  fids_data_mean_sampled = fopen('data/ssa_data_mean_sampled.out','wb');
              fwrite(fids_data_mean_sampled,do_ssa_sampled_out,'int');
              fwrite(fids_data_mean_sampled,num_sampled_ssa,'int');
              fwrite(fids_data_mean_sampled,num_molecules,'int');
              fwrite(fids_data_mean_sampled,do_numerous_mean_runs,'int');
              for ii = 1:num_sampled_ssa+1
                 d_dummy = (ii-1)*dt_sampled;
               fwrite(fids_data_mean_sampled,d_dummy,'double');
              end;
    x_mean_t_sampled = zeros(1,num_moment_terms);
  end;

  
    x_mean_t_sampled = 0*x_mean_t_sampled;
  
       for ii_sampled = 1:num_sampled_ssa+1
         count_mean_t = 1;
         while (time_mean_t(count_mean_t)<(ii_sampled-1)*dt_sampled)&(count_mean_t<length(time_mean_t))
           count_mean_t = count_mean_t+1;
         end;

         if (count_mean_t ==1)|(count_mean_t==length(time_mean_t))
              x_mean_t_sampled(:) = x_mean_t(count_mean_t,1:num_moment_terms);
         else
             weight_lo = (time_mean_t(count_mean_t)-(ii_sampled-1)*dt_sampled)/(time_mean_t(count_mean_t)-time_mean_t(count_mean_t-1));
             weight_hi = ((ii_sampled-1)*dt_sampled-time_mean_t(count_mean_t-1))/(time_mean_t(count_mean_t)-time_mean_t(count_mean_t-1));
              x_mean_t_sampled(:) = weight_hi*x_mean_t(count_mean_t,1:num_moment_terms)+weight_lo*x_mean_t(count_mean_t-1,1:num_moment_terms);
         end;

            fwrite(fids_data_mean_sampled,x_mean_t_sampled,'double');

       end;
    
   if (kkk==num_runs)|((do_numerous_mean_runs == 0)&(kkk==1))
    fclose(fids_data_mean_sampled);
   end;
   