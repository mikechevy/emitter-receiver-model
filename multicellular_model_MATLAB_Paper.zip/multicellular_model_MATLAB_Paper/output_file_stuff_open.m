
                max_count_data_sampled = num_sampled_array_max;
               % output file stuff: setup the time sampling array
                 X_data_sampled = zeros(max_count_data_sampled,num_molecules);
                 total_time = sum(time_u_array);
                 dt_sampled = total_time/(num_sampled_ssa*1.0);

%  Output file stuff: state vectors vs time
 max_count_data = floor(20000/(num_molecules+1));
 max_count_data = floor(100/(num_molecules+1));
 X_data = zeros(max_count_data,num_molecules);
 species_restricted_data = zeros(max_count_data,num_molecules);
 time_data = zeros(max_count_data,1);
 propensities_partition_data = zeros(max_count_data,num_reactions);
 stochasticity_partition_data = zeros(max_count_data,num_reactions);
 moment_error_data = zeros(max_count_data,1);
 X_data_mean = zeros(max_count_data,num_molecules);
 time_data_mean = zeros(max_count_data,1);

fids_prop_fd_info = fopen('data/prop_fd.info','wb');
      fwrite(fids_prop_fd_info,do_prop_time_vary,'int');
      fwrite(fids_prop_fd_info,num_molecules,'int');
      fwrite(fids_prop_fd_info,num_reactions,'int');
      fwrite(fids_prop_fd_info,freq_tv,'double');
      fwrite(fids_prop_fd_info,time_constant_tv,'double');
      fwrite(fids_prop_fd_info,c_mu,'double');
      fwrite(fids_prop_fd_info,c_mu_0,'double');
      fwrite(fids_prop_fd_info,c_mu_tv,'double');
      fwrite(fids_prop_fd_info,phase_c_mu_tv,'double');
fclose(fids_prop_fd_info);

%if (do_mean_or_full==1)
if (do_mean_or_full>=0)
fids_state_data = fopen('data/state.out','wb');
fids_restricted_data = fopen('data/species_restricted.out','wb');
fids_data_sampled = fopen('data/ssa_data_sampled.out','wb');
fids_time_data = fopen('data/time_of_state.out','wb');
fids_propensities_partition_data = fopen('data/propensities_of_state.out','wb');
fids_stochasticity_partition_data = fopen('data/stochasticity_of_state.out','wb');
fids_moment_error_data = fopen('data/moment_error_of_state.out','wb');
fids_run_data = fopen('data/ssa_run_info.out','wb');
      %// write the number of runs into the info file
      fwrite(fids_run_data,num_runs,'int');
      fwrite(fids_run_data,num_molecules,'int');
      fwrite(fids_run_data,do_ssa_sampled_out,'int');
      fwrite(fids_run_data,do_ssa_raw_out,'int');
      fwrite(fids_run_data,num_reactions,'int');
      fwrite(fids_run_data,do_covariances,'int');
      fwrite(fids_run_data,do_covariances_od,'int');
      fwrite(fids_run_data,do_cov_nonlin,'int');
      fwrite(fids_run_data,do_var_prop_thres,'int');
      fwrite(fids_run_data,propensity_threshold,'double');
      fwrite(fids_run_data,stiffness_threshold,'double');
      fwrite(fids_run_data,propensity_threshold_min,'double');
      fwrite(fids_run_data,which_random_walk,'int');

       fwrite(fids_run_data,length(source_u_array),'int');
       fwrite(fids_run_data,source_u_array,'double');
       fwrite(fids_run_data,time_u_array,'double');
       fwrite(fids_run_data,do_cell_cycle_effects,'int');
       fwrite(fids_run_data,num_volumes,'int');

      %// write some info for the sampled_data file
             % data sampled
              fwrite(fids_data_sampled,do_ssa_sampled_out,'int');
              fwrite(fids_data_sampled,num_sampled_ssa,'int');
              fwrite(fids_data_sampled,num_molecules,'int');
              fwrite(fids_data_sampled,num_runs,'int');
              for ii = 1:num_sampled_ssa+1
                 d_dummy = (ii-1)*dt_sampled;
               fwrite(fids_data_sampled,d_dummy,'double');
              end;


end;
