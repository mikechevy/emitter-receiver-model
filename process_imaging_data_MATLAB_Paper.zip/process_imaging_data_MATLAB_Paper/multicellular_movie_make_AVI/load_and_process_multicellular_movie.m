close all;
clear all;

set_globals;

do_make_movie_BOX = 0; % make movie within a chosen box,  0 - process movie

% movie is chosen here, must alter this file
which_movie = input('which movie number do you want, e.g. 1 ,2, etc. ? ');
get_movie_info_for_processing;


% Setup path and directory
str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
mkdir(str_movie_processed);


found_file = fileattrib(strcat(str_movie_processed,'\movie_arrays.mat'))

if (found_file == 1)  % movie already processed
    
  load(strcat(str_movie_processed,'\movie_arrays'));  
else    

if (do_elsamad_microscope == 1)

      
 setup_image_arrays_elsamad_microscope

 
 found_file_im = fileattrib(strcat(str_movie_processed,'\illumination_map.mat'))

 if (do_illumation_map_normalize == 1)
  if (found_file_im == 1)
   load(strcat(str_movie_processed,'\illumination_map.mat'));
  else
   setup_illumination_map;
  end; 
  for ii = 1:numCh
  for which_frame = 1:numFr_CH(ii)     
  eval(['M_CH',num2str(ii),'_total(:,:,which_frame) = int16(double(M_CH',num2str(ii),'_total(:,:,which_frame))./M_IF(:,:));']);
  end;
  end;
 end;
 
else
    
MD=ImportMovie(path_movie,numCh,numFr);%

 for which_frame = 1:numFr     
     
  M_CH1 = double(cell2mat(MD(which_frame,ii_CH1_map)));
    if (which_frame == 1)
      M_CH1_total = int16(zeros(length(M_CH1(:,1)),length(M_CH1(1,:)),numFr));
    end;
      M_CH1_total(:,:,which_frame) = int16(M_CH1(:,:));

  M_CH2 = double(cell2mat(MD(which_frame,ii_CH2_map)));
    if (which_frame == 1)
      M_CH2_total = int16(zeros(length(M_CH2(:,1)),length(M_CH2(1,:)),numFr));
    end;
      M_CH2_total(:,:,which_frame) = int16(M_CH2(:,:));

  if (numCh > 2)      
   M_CH3 = double(cell2mat(MD(which_frame,ii_CH3_map)));
     if (which_frame == 1)
       M_CH3_total = int16(zeros(length(M_CH3(:,1)),length(M_CH3(1,:)),numFr));
     end;
       M_CH3_total(:,:,which_frame) = int16(M_CH3(:,:));
  end;
  
  if (numCh > 3)      
   M_CH4 = double(cell2mat(MD(which_frame,ii_CH4)));
     if (which_frame == 1)
       M_CH4_total = int16(zeros(length(M_CH4(:,1)),length(M_CH4(1,:)),numFr));
     end;
       M_CH4_total(:,:,which_frame) = int16(M_CH4(:,:));
  end; 
    
    
 end;

 
xLength = length(M_CH1(:,1));
yLength = length(M_CH1(1,:));
 
clear MD;

end;

    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  generate pulse representations for each channel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   error_dt = 1;  % 1 second error, sample periods will ALWAYS be slower than this for MDCK tissues
 for jj = 1:numCh
     eval(['dt_CH',num2str(jj),' = diff(time_CH',num2str(jj),');']);     
     eval(['pulse_sequence_index_end_CH',num2str(jj),'=[];']);
   for kk = 1:length(eval(['dt_CH',num2str(jj)]))-1
       if (eval(['abs(dt_CH',num2str(jj),'(kk+1)-dt_CH',num2str(jj),'(kk)) > error_dt']))
         eval(['pulse_sequence_index_end_CH',num2str(jj),'=[pulse_sequence_index_end_CH',num2str(jj),';kk+1];']);
       end;
   end;
         eval(['pulse_sequence_index_end_CH',num2str(jj),'=[pulse_sequence_index_end_CH',num2str(jj),';length(time_CH',num2str(jj),')];']);
         
         eval(['pulse_sequence_index_start_CH',num2str(jj),'=1;']);
         eval(['tau_sequence_CH',num2str(jj),'=dt_CH',num2str(jj),'(1)']);
   for kk = 2:length(eval(['pulse_sequence_index_end_CH',num2str(jj)]))
         eval(['pulse_sequence_index_start_CH',num2str(jj),'=[pulse_sequence_index_start_CH',num2str(jj),';pulse_sequence_index_end_CH',num2str(jj),'(kk)];']);        
         eval(['tau_sequence_CH',num2str(jj),'=[tau_sequence_CH',num2str(jj),';dt_CH',num2str(jj),'(pulse_sequence_index_start_CH',num2str(jj),'(kk)-1)];']);        
   end;             
 end;

save(strcat(str_movie_processed,'\movie_arrays'), 'numFr_CH', 'numFr_NM' , 'xLength', 'yLength','ii_NM','path_movie','numCh','signal_channels');

for jj = 1:numCh
save(strcat(str_movie_processed,'\movie_arrays'), strcat('M_CH',num2str(jj),'_total'),strcat('ii_CH',num2str(jj)),strcat('image_index_CH',num2str(jj)),strcat('time_CH',num2str(jj)),strcat('dt_CH',num2str(jj)),strcat('pulse_sequence_index_start_CH',num2str(jj)),strcat('pulse_sequence_index_end_CH',num2str(jj)),strcat('tau_sequence_CH',num2str(jj)), '-append');
end;


time_bPAC = 1:length(bPAC_ledvals);
time_bPAC = time_bPAC*seconds_per_frame;

save(strcat(str_movie_processed,'\movie_arrays'), 'time_bPAC', 'bPAC_ledvals','-append');


end;  % end of 'if (found_file == 1)'  % movie already processed


if (do_make_movie_BOX == 1)
make_movie_BOX
else
process_multicellular_movie
end;


