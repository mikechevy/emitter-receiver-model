GS = 2;  %  number of ghostcells

EPS0 = 1.0;
MU0 = 1.0;
charge = 1.0;
n_part = 1.0;

%  particle parameters
PART_N = 1;
PART_VX = 2;
PART_VY = 3;
PART_VZ = 4;
PART_X = 5;
PART_Y = 6;
PART_Z = 7;
PART_MASS = 8;
PART_CHARGE = 9;
WHICH_POP = 10;
PART_VX_AD = 11;
PART_VY_AD = 12;
PART_VZ_AD = 13;
PART_X_AD = 14;
PART_Y_AD = 15;
PART_Z_AD = 16;
ACTIVATED = 17;
LOCATION  = 18;
COLLISION = 19;
TIMER = 20;
ATTACHED = 21;
WHICH_RUN = 22;
RANK = 23;
SURF_TYPE = 24;
WHICH_PLANE = 25;
WHICH_SURF = 26;
III_R = 27;
JJJ_R = 28;  %// MIKE, BETTER INTEGRATE THIS LATER
KKK_R = 29;  %// MIKE, BETTER INTEGRATE THIS LATER
PART_LOWER = 30;  %// MIKE, BETTER INTEGRATE THIS LATER
PART_HIGHER = 31;  %// MIKE, BETTER INTEGRATE THIS LATER
NUM_PARTS_NEAR = 32;

PART_THETA_ROT = PART_VX_AD;
PART_PHI_ROT = PART_VY_AD;

PART_NORM_X = PART_VX;
PART_NORM_Y = PART_VY;
PART_NORM_Z = PART_VZ;
PART_SURF_X = PART_VX_AD;
PART_SURF_Y = PART_VY_AD;
PART_SURF_Z = PART_VZ_AD;

NUM_PARTICLE_PARAMS = NUM_PARTS_NEAR;
NUM_PARTS_NEAR_MAX = 26;

PCIC_NUM = 1;  % number of particles in the cell
PCIC_LO = 2;  % lowest index particle in the cell
PCIC_HI = 3;  % highest index particle in the cell
PCIC_CURRENT = 4;  % highest index particle in the cell
PCIC_NUM_SURROUND = 5;  % highest index particle in the cell
PCIC_NUM_MAX = 20;
NUM_PCIC_PARAMS = PCIC_NUM_MAX+1;

NUM_CELLS_P1 = 27+1; % number of cells in a 3x3x3 box, plus 1


order = 2;  % order of the particle form factor

% SOME CONSTANTS RELATED TO PARTICLE LOCATION, INTERACTIONS, ETC.
% ACTIVATED
HOST = 1;
FREE = 0;
GUEST = -1;
NOT_ACTIVATED = -1000;
%LOCATION
MEMBRANE = 1;
CYTOPLASM = 0;
% ID
NO_ID_PART = -1;
% NO SURF ID
NO_ID_SURF = -1;


% some other constants
problem_type = 1;     % 0 - Plasma, 1 - Biology, 2-QM
num_runs_per_proc=1;  %always 1 in MATLAB

% force types - 0 - electromagnetic (Plasma)
%               1 - diffusion  (Biology)
%               2 - potential field (QM)
force_type = problem_type;

shift_one = 1;  % THIS SHOULD STAY 1.   0 - do not shift planes of the membrane surface, 1 - shift the planes of the MATLAB membrane surface to correspond with the Petsc code and the proper range, e.g. (0-xdimp).  

in_subgrid = 0;  % initialize
