%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Andrew's differential equation (emitter/receiver duo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           #Sender cell
%            d x[0]/dt =    Kb*1*on + ACmax*KD_cAMP/(KD_cAMP + factAC * x[2]) - Ka1*x[0]**4*x[1] - fact_Pc*Kdeg_Pc*x[4]/(KD_Pc + x[4])*x[0] - Kdeg_c*x[0] - Kdiff*x[0] + Kdiff*x[5],
%            d x[1]/dt = fact_PP*Kdeg_PP*x[4]/(KD_PP + x[4])*x[2] + KD1 * x[2] - Ka1*x[0]**4*x[1],
%            d x[2]/dt =  Ka1*x[0]**4*x[1] - fact_PP*Kdeg_PP*x[4]/(KD_PP + x[4])*x[2] - KD1 * x[2],
%            d x[3]/dt =   KD2*x[4] - Ka2*x[2]*x[3],
%            d x[4]/dt =   Ka2*x[2]*x[3] - KD2*x[4],
%           #Receiver cell
%            d x[5]/dt =    ACmax*KD_cAMP/(KD_cAMP + factAC * x[7]) - Ka1*x[5]**4*x[6] - fact_Pc*Kdeg_Pc*x[9]/(KD_Pc + x[9])*x[5] - Kdeg_c*x[5] - Kdiff*x[5] + Kdiff*x[0],
%            d x[6]/dt =    fact_PP*Kdeg_PP*x[9]/(KD_PP + x[9])*x[7] + KD1 * x[7] - Ka1*x[5]**4*x[6],
%            d x[7]/dt =    Ka1*x[5]**4*x[6] - fact_PP*Kdeg_PP*x[9]/(KD_PP + x[9])*x[7] - KD1 * x[7],
%            d x[8]/dt =    KD2*x[9] - Ka2*x[7]*x[8],
%            d x[9]/dt =    Ka2*x[7]*x[8] - KD2*x[9]
%
%            x[0] = cAMP
%            x[1] = PKA_off
%            x[2] = PKA_on
%            x[4] = PDE_off
%            x[5] = PDE_on
%
%            EQUATIONS:
%            d [cAMP]/dt =    Kb*[I_bPAC] + ACmax*KD_cAMP/(KD_cAMP + factAC * [PKA_on]) - Ka1*[cAMP]**4*[PKA_off] - fact_Pc*Kdeg_Pc*[PDE_on]/(KD_Pc + [PDE_on])*[cAMP] - Kdeg_c*[cAMP] - Kdiff*[cAMP,this cell] + Kdiff*[cAMP,other cells],
%            d [PKA_off]/dt = fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*x[2] + KD1 * [PKA_on] - Ka1*[cAMP]**4*x[PKA_off],
%            d [PKA_on]/dt =  Ka1*[cAMP]**4*[PKA_off] - fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*[PKA_off] - KD1 * [PKA_on],
%            d [PDE_off]/dt =   KD2*[PDE_on] - Ka2*[PKA_on]*[PDE_off],
%            d [PDE_on]/dt =   Ka2*[PKA_on]*[PDE_off] - KD2*[PDE_on],
%
%            biochemical reactions/ propensities
%            1.  0 -> cAMP ,   Kb*x[ii_I_bPAC]*is_bPAC_cell
%            2.  0 -> cAMP ,   ACmax*KD_cAMP/(KD_cAMP + x[ii_PKA_on]), for PKA feedback  or just ACmax for no PKA feedback 
%            3.  cAMP + PKA_off -> PKA_on ,   Ka1*x[ii_cAMP]^4 * x[ii_PKA_off],     activation of PKA through cAMP
%            4.  cAMP -> 0 ,   fact_Pc*Kdeg_Pc*x[ii_PDE_on]/(KD_Pc + x[ii_PDE_on])*x[ii_cAMP], PDE_on feedback 
%            5.  cAMP -> 0 ,   Kdeg_c*x[ii_cAMP],    basal degradation
%            6.  PKA_on -> PKA_off       fact_PP*Kdeg_PP*[PDE_on]/(KD_PP + [PDE_on])*x[2],  PDE_on dependent inactivation of PKA_on
%            7.  PKA_on -> PKA_off       KD1 * [PKA_on],  basal inactivation of PKA_on
%            8.  PDE_off -> PDE_on       Ka2*[PKA_on]*[PDE_off],
%            9.  PDE_on -> PDE_off       KD2*[PDE_on],
%
%            cell-cell coupling/propensities
%            10.  cAMP (cell i) -> cAMP (cell j) ,  Kdiff*x[ii_cAMP (cell i)], diffusion of cAMP from cell i to cell j
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 %  cAMP/PKA/ERK circuit in each cell         
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
 for ii = 1:num_cells
    
   % reaction 1:  0 -> cAMP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % I_bPAC is the input species 
     which_mol = ii_I_bPAC;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = Kb*bPAC_NUCLEUS_time_mapped_t0(index_group(ii),1);

   if (factAC == 0)
   % reaction 2:  0 -> cAMP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 1;
   % no the input species 
   % 1 caMP molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = ACmax;
   elseif (factAC == 1)
   % reaction 2:  0 -> cAMP
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 31;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = ACmax;
     a_0(which_reaction) = KD_cAMP; 
     a_1(which_reaction) = n_AC; 
    end;

   do_old_PKA_on = 0;
   if (do_old_PKA_on == 1)
   % reaction 3:  cAMP + PKA_off -> PKA_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 81;
   % cAMP,PKA_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 cAMP, PKA_off molecules lost, 1 PKA_on molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = Ka1;
     a_0(which_reaction) = n_cAMP_PKA; 
     %a_1(which_reaction) = KD_cAMP_PKA; 
   elseif (do_old_PKA_on == 0)
   % reaction 3:  cAMP + PKA_off -> PKA_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PKA_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 cAMP, PKA_off molecules lost, 1 PKA_on molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = Ka1*power(KD_cAMP_PKA,n_cAMP_PKA);
     a_0(which_reaction) = n_cAMP_PKA; 
     a_1(which_reaction) = KD_cAMP_PKA; 
     end;

   % reaction 4:  cAMP  -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PDE_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 cAMP lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = fact_Pc*Kdeg_Pc;
     a_0(which_reaction) = n_Pc; 
     a_1(which_reaction) = KD_Pc; 


   % reaction 5:  cAMP -> 0
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % cAMP is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 caMP molecule lost
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = Kdeg_c;

   % reaction 6:  PKA_on -> PKA_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PDE_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 PKA_on lost, 1 PKA_off gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = fact_PP*Kdeg_PP;
     a_0(which_reaction) = n_PP; 
     a_1(which_reaction) = KD_PP; 

   % reaction 7:  PKA_on -> PKA_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = KD1;

   % reaction 8:  PDE_off -> PDE_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 3;
   % PDE_off,PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_off;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PKA_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = Ka2;


   % reaction 9:  PDE_on -> PDE_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_PDE_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = KD2;
     
     
     
     
   % reaction 10:  Erk_on -> Erk_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 40;
   % cAMP,PKA_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_cAMP;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 Erk_on molecules lost, 1 Erk_off molecule gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_e_c;
     a_0(which_reaction) = n_e_c; 
     a_1(which_reaction) = KD_e_c; 
     
   % reaction 11:  Erk_on -> Erk_off
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % ERK_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 ERK_on molecule is lost, 1 ERK_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_e_basal;

   % reaction 12:  Erk_off -> Erk_on
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % ERK_off is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 ERK_off molecule is lost, 1 ERK_on molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_off;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = k_e_basal;
     
   % reaction 13:  ERKKTR_n -> EKRKTR_c
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 3;
   % PDE_off,PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_n;
     reaction_molecules(which_reaction,species1) = which_mol;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERK_on;
     reaction_molecules(which_reaction,species2) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_n;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_c;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = k_ek_e;

     
   % reaction 14:  ERKKTR_c -> ERKKTR_n
      which_reaction = last_reaction+1;
      last_reaction = last_reaction+1; 
   % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
     stochasticity(which_reaction) = 1;
   % type of reaction: 
     reaction_type(which_reaction) = 2;
   % PKA_on is the input species 
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_c;
     reaction_molecules(which_reaction,species1) = which_mol;
   % 1 PKA_on molecule is lost, 1 PKA_off molecule is gained
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_c;
     sign_value = -1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
     which_mol = ((ii-1)*num_molecules_cell)+ii_ERKKTR_n;
     sign_value = 1;
     sign_value_reaction(which_reaction,which_mol) = sign_value;
   % reaction_constant
     c_mu(which_reaction) = gamma_ek_basal;

     

 end; % for ii = 1:num_cells


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  cell-to-cell coupling
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 for ii = 1:num_cells
    
     for jj = 1:num_cells

         if (mat_cAMP_gap(ii,jj) == 1)

           % reaction 15:  a cAMP molecule from cell ii diffuses to cell jj
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction:
             reaction_type(which_reaction) = 80;
           % an cAMP from both cells ii and jj ,and I_cAMP_gap are is the input species
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species1) = which_mol;
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species2) = which_mol;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             reaction_molecules(which_reaction,species3) = which_mol;
           % 1 cAMP molecule from cell ii lost, 1 cAMP molecule from cell jj gained
             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = -1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
             sign_value = 1;
             sign_value_reaction(which_reaction,which_mol) = sign_value;
           % reaction_constant
             c_mu(which_reaction) = k_diff_c_basal;
             %%c_mu(which_reaction) = Kdiff_cAMP;  % same value as k_diff_c_basal
             
             
             a_0(which_reaction) = x_flux_max_basal;
             

%           % reaction 10:  a cAMP molecule from cell ii diffuses to cell jj
%              which_reaction = last_reaction+1;
%              last_reaction = last_reaction+1;
%           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
%             stochasticity(which_reaction) = 1;
%           % type of reaction:
%             reaction_type(which_reaction) = 80;
%           % an cAMP from both cells ii and jj ,and I_cAMP_gap are is the input species
%             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
%             reaction_molecules(which_reaction,species1) = which_mol;
%             which_mol = ii_I_cAMP_gap;
%             reaction_molecules(which_reaction,species2) = which_mol;
%           % 1 cAMP molecule from cell ii lost, 1 cAMP molecule from cell jj gained
%             which_mol = (ii-1)*(num_molecules_cell) + ii_cAMP;
%             sign_value = -1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%             which_mol = (jj-1)*(num_molecules_cell) + ii_cAMP;
%             sign_value = 1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%           % reaction_constant
%             c_mu(which_reaction) = Kdiff_cAMP;



         end;

%         if (mat_Calcium_gap(ii,jj) == 1)
%
%           % reaction 11:  a Calcium molecule from cell ii diffuses to cell jj
%              which_reaction = last_reaction+1;
%              last_reaction = last_reaction+1;
%           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
%             stochasticity(which_reaction) = 1;
%           % type of reaction:
%             reaction_type(which_reaction) = 80;
%           % an cAMP from both cells ii and jj ,and I_Calcium_gap are is the input species
%             which_mol = (ii-1)*(num_molecules_cell) + ii_Calcium;
%             reaction_molecules(which_reaction,species1) = which_mol;
%             which_mol = ii_I_Calcium_gap;
%             reaction_molecules(which_reaction,species2) = which_mol;
%           % 1 Calcium molecule from cell ii lost, 1 Calcium molecule from cell jj gained
%             which_mol = (ii-1)*(num_molecules_cell) + ii_Calcium;
%             sign_value = -1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%             which_mol = (jj-1)*(num_molecules_cell) + ii_Calcium;
%             sign_value = 1;
%             sign_value_reaction(which_reaction,which_mol) = sign_value;
%           % reaction_constant
%             c_mu(which_reaction) = Kdiff_Calcium;
%
%
%
%         end;

     end; % for jj = 1:num_cells
 end; % for ii = 1:num_cells



           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %  time dependent inputs
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

           % reaction 16:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_bPAC;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;

           % reaction 17:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_cAMP_gap;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;

           % reaction 18:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_Calcium_gap;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;


           % reaction 19:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_IBMX;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;


           % reaction 20:  update species number from time-series
              which_reaction = last_reaction+1;
              last_reaction = last_reaction+1;
           % stochasticity of reaction -   0 - Mass-Action, 1 - Gillespie
             stochasticity(which_reaction) = 1;
           % type of reaction: an R molecule from cell ii diffuses to cell jj
             reaction_type(which_reaction) = 100;
           % an R from both cells ii and jj ,and I are is the input species
             which_mol = ii_I_H89;
             reaction_molecules(which_reaction,species1) = which_mol;
           % No molecules change since it is read from a file
           % reaction_constant
             c_mu(which_reaction) = 0;

