function view_movie_of_cluster(which_cluster,str_movie)         

filename_movie = strcat(str_movie,'_processed\cluster',num2str(which_cluster));

mov2 = aviread(strcat(filename_movie,'.avi'));
figure(10000)
movie(mov2)
