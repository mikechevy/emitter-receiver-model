
do_GJ_complex = 1;  % 1-adding delay between PKA and  gap junction activity, 0 - PKA directly regulates gap junction activty

%  Some of Andrews original values
beta_c_b_andrew = 10*scale_time_rates; %#nmol/min/mg Rate of production of cAMP from bPAC
beta_c_ac_andrew = 1*scale_time_rates; %#Rate of production of cAMP from native AC
gamma_c_pd_andrew = 0*3*scale_time_rates; %#Rate of basal cAMP degradation
gamma_c_pd_basal_andrew = 1*scale_time_rates; %#Rate of basal cAMP degradation through PDE
gamma_c_basal_andrew = 0.2*scale_time_rates; %#Rate of basal cAMP degradation through non-PDE means

num_cAMP_0 = (beta_c_b_andrew+beta_c_ac_andrew)/gamma_c_pd_basal_andrew;
num_Calcium_0 = 1;
num_PKA_0 = 1;
num_PDE_0 = 1;
num_ERK_0 = 1;
num_ERKKTR_0 = 1;
num_GJ_complex_0 = 1;


 do_andrew_parameters = 0; % 1-andrews parameters, 0-user defined
if (do_andrew_parameters==1)
    num_PKA = 1;
    num_PDE = 1;
    num_cAMP = num_cAMP_0;    
    num_ERK= 1;
    num_ERKKTR = 1;
    num_GJ_complex = num_PKA;
    num_Calcium = 1;
else
    num_PKA = 10;%100;
    num_PDE = 1;%100;
    num_cAMP = 100;% num_cAMP_0;
    num_ERK= 10;
    num_ERKKTR = 10;
    num_GJ_complex = num_PKA;
    num_Calcium = 1;
end;    


if (num_gjc_delay_steps > 0)
  beta_gjc_delay_steps = num_gjc_delay_steps/(num_gjc_minute_delay*60);
end;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: cAMP regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
beta_c_b = 2*beta_c_b_andrew*num_cAMP/num_cAMP_0; %#nmol/min/mg Rate of production of cAMP from bPAC
beta_c_ac = .5*beta_c_ac_andrew*num_cAMP/num_cAMP_0; %#Rate of production of cAMP from native AC
gamma_c_basal = 4*gamma_c_basal_andrew;  %#Rate of basal cAMP degradation through non-PDE means
gamma_c_pd_basal = 2*gamma_c_pd_basal_andrew; %#Rate of basal cAMP degradation through PDE
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % PDE mediated decay of CAMP,  turned on by fac_c_pd
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   gamma_c_pd = gamma_c_pd_andrew; %#Max rate of degradation of cAMP by PDE
   n_c_pd = 1;  %% order of hill activator for PDE_on regulated decay of cAMP
   KD_c_pd = 0.1*num_PDE; %#Half-max constant for PDE degradation activity of cAMP
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % PKA mediated inhibition of endogenous adenalyal cyclase production of CAMP,  turned on by fac_ac_pk
   % This feedback reduces the affect of the production rate, beta_c_ac (above)
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   n_ac_pk = 1;  %% order of hill repressor on the PKA_on mediated suppression of Adenylil Cyclase
   KD_ac_pk = num_PKA/20;%*num_PKA; %#Half-max constant for rate of cAMP production (through PKA feedback)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  PKA regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
  %  Parameters for activation of PKA through cAMP
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  n_pk_c = 4; % order of PKA activation through cAMP
  KD_pk_c = 10*num_cAMP; %  currently a much larger number than the max value of cAMP through bPAC
  beta_pk_c = 3*0.05*scale_time_rates*power(num_cAMP_0/num_cAMP,n_pk_c); %#Rate of PKA activation by cAMP, reation 81,40 (multiplied out)
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  Parameters for deactivation of PKA through PDE, turned on by fac_pk_pd
  %  (abobe)
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  n_pk_pd = 1;  %% order of hill activator for PDE_on regulated dedactivation of PKA_on
  KD_pk_pd = 0.3*num_PDE; %#Half-max constant for deactivation of PKA by PDE
  gamma_pk_pd = 5*scale_time_rates; %#Rate of deactivation of PKA by PDE

  gamma_pk = 3*2*scale_time_rates; %#Rate of basal PKA deactivation


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  PDE regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  Parameters for activatin of PDE through PKA
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  beta_pd_pk = 1*scale_time_rates*num_PKA_0/num_PKA; %#Rate of PDE activation  through PKA, reaction_type 3

  gamma_pd = 0.5*scale_time_rates; %#Rate of PDE deactivation


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  Gap Junction regulation, basal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     

 if (do_basal_gap == 1)
  if (fac_I_IBMX == 0)
  k_diff_c = 5*scale_time_rates; %#Basal Rate of diffusion of cAMP through gap junctions
  k_diff_c_basal = do_basal_gap*k_diff_c; %#Basal Rate of diffusion of cAMP through gap junctions
  else (fac_I_IBMX == 1)
  k_diff_c = .5*scale_time_rates
  k_diff_c_basal = do_basal_gap*k_diff_c; %#Basal Rate of diffusion of cAMP through gap junctions
  end;
 elseif (do_basal_gap == 0)
  k_diff_c = .5*scale_time_rates; %#Basal Rate of diffusion of cAMP through gap junctions
  k_diff_c_basal = do_basal_gap*4*k_diff_c; %#Basal Rate of diffusion of cAMP through gap junctions
 end;
  x_flux_max_basal = num_cAMP;
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  Gap Junction regulation, PKA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  Parameters for regulation of gap junctions through PKA of PDE through
  %  PKA, turned on by fac_gj_pk (above)
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  n_gj_pk = 1; %% order of hill activator for PKA regulated activation of gap gap junctions
  KD_gj_pk = num_PKA;%/10.0; %% half-max constant for PKA regulated activation of gap gap junctions
  k_diff_c_gj_pk = 10*k_diff_c; %#Rate of diffusion of cAMP through gap junctions
  x_flux_max_gj_pk = num_cAMP;
  
  
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  Gap Junction regulation, GJ_complex,PKA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
  n_gjc_pk = 1; %% order of hill activator for PKA regulated activation of gap gap junctions
  KD_gjc_pk = num_PKA;%/10.0; %% half-max constant for PKA regulated activation of gap gap junctions
  beta_gjc_pk = 1*10*scale_time_rates;

  gamma_gjc_basal = 1*25.0*scale_time_rates % Rate of GJ_complex deactivation
  
  n_gj_gjc = 1; %% order of hill activator for PKA regulated activation of gap gap junctions
  
  if (do_basal_gap == 1)
   if (fac_I_IBMX == 0)
     KD_gj_gjc = num_GJ_complex/10;%/10.0; %% half-max constant for PKA regulated activation of gap gap junctions
     k_diff_c_gj_gjc = 2*10*k_diff_c_basal; %#Rate of diffusion of cAMP through gap junctions
   else (fac_I_IBMX == 1) 
     KD_gj_gjc = num_GJ_complex/5;%/10.0; %% half-max constant for PKA regulated activation of gap gap junctions
     k_diff_c_gj_gjc = 160*k_diff_c_basal; %#Rate of diffusion of cAMP through gap junctions
   end;
  elseif (do_basal_gap == 0)
   KD_gj_gjc = num_GJ_complex;%/10.0; %% half-max constant for PKA regulated activation of gap gap junctions
   k_diff_c_gj_gjc = .5*2*160*k_diff_c; %#Rate of diffusion of cAMP through gap junctions
   %KD_gj_gjc = num_GJ_complex/5.0; %TEST
   %k_diff_c_gj_gjc = .1*160*k_diff_c; % TEST
   %k_diff_c_gj_gjc = 16*160*k_diff_c; %#Rate of diffusion of cAMP through gap junctions
  end;
   x_flux_max_gj_gjc = num_cAMP;
   x_flux_max_basal = 30;
   x_flux_max_gj_gjc = 60;
   x_flux_max_basal = 5;
   x_flux_max_gj_gjc = 5;
   
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  ERK regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
  k_e_basal = 7*scale_time_rates;  % basal activation rate of Erk
  gamma_e_basal = 1*scale_time_rates;  % basal deactivation rate of Erk
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  Parameters for deactivation of ERK through upregulated
  %  deactivation rate at is dependent on EPAC through cAMP
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  n_e_c = 1; %% order of hill activator for cAMP regulated deactivation of Erk
  KD_e_c = num_cAMP; %% half-max constant for cAMP regulated deactivation of Erk
  gamma_e_c =   2*gamma_e_basal;  % maxi deactivation rate for cAMP regulation of Erk

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%   BEGIN:  ERK-KTR regulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
  k_ek_e = 1*scale_time_rates*num_ERK_0/num_ERK;  % basal activation rate (to cytosol) of Erk-KTR through Erk, reaction_type 3
  gamma_ek_basal = 8*scale_time_rates;  % deactivation rate (to nucleus) of Erk-KTR
