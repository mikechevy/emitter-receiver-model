
% save the figures to a powerpoint slide
cd(str_movie_processed);

 if (ii == 1)  % clean slate
   delete(strcat(pptTitle,'.ppt'));
 end;

  s_combine = 'hot spots of correlated activity';
  saveppt2(strcat(pptTitle,'.ppt'),'figure',[fig100 fig1000 fig2000], 'halign','center','stretch','title', s_combine);
  %saveppt2(strcat(pptTitle,'.ppt'),'figure',[fig1000 fig2000], 'halign','center','stretch','title', s_combine);


cd ..\;