

% To start:
num_pixels_tot_CELL = num_pixels_tot_NUCLEUS;




for ii = 1:xLength    
    for jj = 1:yLength
         val_dummy = M_marker_id_threshold(ii,jj);
        if (val_dummy > 0)
            nuclear_FITC_tot_time(val_dummy,which_frame) = nuclear_FITC_tot_time(val_dummy,which_frame) + M_FITC(ii,jj);
            nuclear_CY3_tot_time(val_dummy,which_frame) = nuclear_CY3_tot_time(val_dummy,which_frame) + M_CY3(ii,jj);
        end;
    end;
end;


% convert to average signal per pixel
for ii = 1:num_nuclei
            nuclear_FITC_tot_time(ii,which_frame) = nuclear_FITC_tot_time(ii,which_frame)/num_pixels_tot_NUCLEUS(ii);
            nuclear_CY3_tot_time(ii,which_frame) = nuclear_CY3_tot_time(ii,which_frame)/num_pixels_tot_NUCLEUS(ii);
end;


do_process_cytosolic_signals = 1;
if (do_process_cytosolic_signals == 1)
matrix_nucleus_SCRAP = 0*M_DAPI;
matrix_cytosol_SCRAP = 0*M_DAPI;
M_CELL_id_threshold_TEST = 0*M_DAPI;
M_CELL_id_threshold = 0*M_DAPI; 

box_coords_CELL = zeros(num_DAPI,4);


num_delta_phi = 20;
delta_phi_test = 2*pi/(num_delta_phi);

r_max = 200;

r_cross_section = 0:r_max;

x_boundary = zeros(num_delta_phi,1);
y_boundary = zeros(num_delta_phi,1);

for iii = 1:num_nuclei_t0

for ii_phi = 1:num_delta_phi
  phi_test = delta_phi_test*(ii_phi-1);
   
  
 for r_test = 0:r_max
  xx_r = round(mean_x_tot_time_mapped_t0(iii,which_frame) + r_test*cos(phi_test));   
    if xx_r < 1
        xx_r = 1;
    elseif xx_r > xLength
        xx_r = xLength;
    end;
  yy_r = round(mean_x_tot_time_mapped_t0(iii,which_frame) + r_test*sin(phi_test));   
    if yy_r < 1
        yy_r = 1;
    elseif yy_r > yLength
        yy_r = yLength;
    end;
   
  %signal_cross_section(r_test+1) = M_FITC_max(xx_r,yy_r);    
  FITC_cross_section(r_test+1) = M_FITC(xx_r,yy_r);    
  DAPI_cross_section(r_test+1) = double(M_DAPI_id_threshold(xx_r,yy_r));    
  CY3_cross_section(r_test+1) = double(M_CY3(xx_r,yy_r));    
  x_test(r_test+1) = xx_r;
  y_test(r_test+1) = yy_r;
 end;
 
 %  Here we can fill:  max(signal_cross_section(r_test+1,fill_value),
 %  increasing the fill until we get two fill minimums (or one, not the
 %  nucleus

 r_nucleus = 1;
 nucleus_edge_found = 0;
 next_nucleus_edge_found = 0;
 index_nucleus = 1;
 index_next_nucleus = r_max+1;
 
 for r_test = 0:r_max-1
   if (DAPI_cross_section(r_test+1) > 0)& (DAPI_cross_section(r_test+1+1)==0)&(nucleus_edge_found==0)
       index_nucleus = r_test+1;
       nucleus_edge_found = 1;
   end;
   if (DAPI_cross_section(r_test+1) == 0)& (DAPI_cross_section(r_test+1+1)>0)&(nucleus_edge_found==1)&(next_nucleus_edge_found == 0)
       index_next_nucleus = r_test+1;
       next_nucleus_edge_found = 1;
   end;
   
 end;
 

 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  Using m_DAPI_id_threshold determine edge of nucleus and the beginning of the next
 %  one (otherwise the end of the image
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 do_fill = 0;
if do_fill == 1
   fill_value = floor(min(FITC_cross_section(index_nucleus:index_next_nucleus)));
 
 ii_count_fill = 0;
       

     %signal_cross_section(index_nucleus:index_next_nucleus) = max(signal_cross_section(index_nucleus:index_next_nucleus),fill_value); 

     [val_min,index_min_dummy] =  min(FITC_cross_section(index_nucleus:index_next_nucleus));
     %[val,index_min_dummy] =  min(abs(signal_cross_section - fill_value));
     index_min_dummy = index_min_dummy+index_nucleus-1;
     
     
 
       ii_count = index_nucleus + 2;
     while (FITC_cross_section(ii_count) - val_min > (FITC_cross_section(index_nucleus + 2) - val_min)/2.0)&(ii_count < index_next_nucleus-1)

         ii_count = ii_count+1;
           
     end;
     
       index_cell_boundary  = ii_count;
       
elseif do_fill == 0
       [val_min,index_min_dummy] =  min(FITC_cross_section(index_nucleus:index_next_nucleus));
       index_cell_boundary  = index_nucleus + min(10,index_min_dummy);
end;

x_boundary(ii_phi) = x_test(index_cell_boundary);
y_boundary(ii_phi) = y_test(index_cell_boundary);


       
       do_plot_iterative = 0;  % 0 - no, 1 - yes      
      if (do_plot_iterative == 1)
       figure(1111)
       hold on;
       plot(r_cross_section,FITC_cross_section);
       plot([index_cell_boundary index_cell_boundary], [0 max(FITC_cross_section)],'k--');
       plot([index_min_dummy index_min_dummy], [0 max(FITC_cross_section)],'r--');
       title(strcat('\phi = ',num2str(phi_test)));
       pause
       close 1111;
       

       figure(1112)
       hold on;
       plot(r_cross_section,FITC_cross_section);
       plot(r_cross_section,DAPI_cross_section*max(FITC_cross_section)/max(DAPI_cross_section),'g');
       %plot(r_cross_section,CY3_cross_section*max(FITC_cross_section)/max(CY3_cross_section),'r');
       legend('FITC','DAPI','CY3');
       plot([index_cell_boundary index_cell_boundary], [0 max(FITC_cross_section)],'k--');
       plot([index_min_dummy index_min_dummy], [0 max(FITC_cross_section)],'r--');
       title(strcat('cell: ',num2str(iii),',\phi = ',num2str(phi_test)));
       index_nucleus
       index_next_nucleus
       index_cell_boundary
       pause
       close 1112;
      end;
     
     
end;    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
%   Calculate cytosolic signals           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
            x_coord_min = min(x_boundary);
            x_coord_max = max(x_boundary);

            y_coord_min = min(y_boundary);
            y_coord_max = max(y_boundary);

            
            % cyclical boundary
            x_boundary(num_delta_phi+1) = x_boundary(1); 
            y_boundary(num_delta_phi+1) = y_boundary(1);
            
           %form enclosed cytosolic region surrounding the nucleus
           matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = 0;           
          for ii_phi = 1:num_delta_phi
           matrix_cytosol_SCRAP(x_boundary(ii_phi),y_boundary(ii_phi)) = 1;
          end;
          for ii_phi = 1:num_delta_phi
              max_range = max(abs(x_boundary(ii_phi+1) - x_boundary(ii_phi)), abs(y_boundary(ii_phi+1) - y_boundary(ii_phi)));
              n_range = 2;
             for ii_range = 1:n_range*max_range
               alpha_test = ii_range/(n_range*max_range);
               x_dummy = alpha_test*(x_boundary(ii_phi+1) - x_boundary(ii_phi)) + x_boundary(ii_phi);  
               y_dummy = alpha_test*(y_boundary(ii_phi+1) - y_boundary(ii_phi)) + y_boundary(ii_phi);  
               matrix_cytosol_SCRAP(round(x_dummy),round(y_dummy)) = 1;
             end;
          end;
           
           
           % fill in the enclosed region
           which_nucleus = iii;
           matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = imfill(matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max),'holes');           
           num_pixels_CELL(which_nucleus) = sum(sum(matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
           matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = which_nucleus*matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max);          
           % determine number of pixes in the enclosed regtion.

           
           figure(120)
           imagesc(matrix_cytosol_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max));
           %xlim([x_coord_min x_coord_max]);
           %ylim([y_coord_min y_coord_max]);
           pause;
           
           
           box_coords_CELL(which_nucleus,1) = x_coord_min; 
           box_coords_CELL(which_nucleus,2) = x_coord_max; 
           box_coords_CELL(which_nucleus,3) = y_coord_min; 
           box_coords_CELL(which_nucleus,4) = y_coord_max; 

           for ii = x_coord_min:x_coord_max                 
            for jj = y_coord_min:y_coord_max                 

            M_CELL_id_threshold_TEST(ii,jj) =  which_nucleus*matrix_cytosol_SCRAP(ii,jj);   
            M_FITC_TEST(ii,jj) = M_FITC(ii,jj)*matrix_cytosol_SCRAP(ii,jj);    
            M_CY3_TEST(ii,jj) = M_CY3(ii,jj)*matrix_cytosol_SCRAP(ii,jj); 
    
            end;
           end;

            FITC_cell_sum(which_nucleus) = sum(sum(M_FITC_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
            CY3_cell_sum(which_nucleus) = sum(sum(M_CY3_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));

            M_CELL_id_threshold(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = M_CELL_id_threshold(x_coord_min:x_coord_max,y_coord_min:y_coord_max) + M_CELL_id_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max);
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
%   Calculate nuclear and cytosolic signals           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
x_coord_min = box_coords_DAPI(which_nucleus,1);
x_coord_max = box_coords_DAPI(which_nucleus,2);
y_coord_min = box_coords_DAPI(which_nucleus,3);
y_coord_max = box_coords_DAPI(which_nucleus,4);

matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = 0;

for ii = x_coord_min:x_coord_max                 
for jj = y_coord_min:y_coord_max                 

     if (M_DAPI_id_threshold(ii,jj) == which_nucleus)
       matrix_nucleus_SCRAP(ii,jj) = 1;
     end;
    M_DAPI_id_threshold_TEST(ii,jj) = M_DAPI_id_threshold(ii,jj)*matrix_nucleus_SCRAP(ii,jj);    
    M_FITC_TEST(ii,jj) = M_FITC(ii,jj)*matrix_nucleus_SCRAP(ii,jj);    
    M_DAPI_TEST(ii,jj) = M_DAPI(ii,jj)*matrix_nucleus_SCRAP(ii,jj);    
    M_CY3_TEST(ii,jj) = M_CY3(ii,jj)*matrix_nucleus_SCRAP(ii,jj); 
    
end;
end;

num_pixels_DAPI(which_nucleus) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
FITC_nucleus_sum(which_nucleus) = sum(sum(M_FITC_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
CY3_nucleus_sum(which_nucleus) = sum(sum(M_CY3_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));

%FITC_nucleus_average(which_nucleus) = FITC_nucleus_sum(which_nucleus)/num_pixels_DAPI(which_nucleus);
%CY3_nucleus_average(which_nucleus) = CY3_nucleus_sum(which_nucleus)/num_pixels_DAPI(which_nucleus);


x_coord_min = min(box_coords_DAPI(which_nucleus,1),box_coords_CELL(which_nucleus,1));
x_coord_max = max(box_coords_DAPI(which_nucleus,2),box_coords_CELL(which_nucleus,2));
y_coord_min = min(box_coords_DAPI(which_nucleus,3),box_coords_CELL(which_nucleus,3));
y_coord_max = max(box_coords_DAPI(which_nucleus,4),box_coords_CELL(which_nucleus,4));

           figure(121)
           imagesc(abs(M_CELL_id_threshold(x_coord_min:x_coord_max,y_coord_min:y_coord_max)- ...          
                      -M_DAPI_id_threshold(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
           %xlim([x_coord_min x_coord_max]);
           %ylim([y_coord_min y_coord_max]);
           pause;
           
           %xlim([x_coord_min x_coord_max]);
           %ylim([y_coord_min y_coord_max]);
           pause;



end;   

end;  % END OF: if (do_process_cytosolic_signals == 1)
