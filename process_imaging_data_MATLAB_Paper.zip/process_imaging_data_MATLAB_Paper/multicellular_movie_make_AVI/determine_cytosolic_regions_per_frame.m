  

% To start:
eval(['Cell_cytosol_FILL_',num2str(which_frame),'=Cell_nucleus_FILL_',num2str(which_frame),';']);


matrix_cytosol_SCRAP = 0*M_S1;
matrix_cytosol_TEST = 0*M_S1;
matrix_cytosol_OVERLAP = 0*M_S1;
matrix_nucleus_SCRAP = 0*M_S1;
matrix_shrink_nucleus_SCRAP = 0*M_S1;
matrix_NM_SCRAP = 0*M_S1;
matrix_NM_DUMMY = 0*M_S1;

do_cytosol = 1; % 1 - yes, 0 - no
if (do_cytosol == 1)      
for iii = 1:num_nuclei_t0
    
idx_map = index_map_tot_time_mapped_t0(iii,which_frame);    

                 %x_coord_min = box_coords(idx_map,1);
                 %x_coord_max = box_coords(idx_map,2);
                 %y_coord_min = box_coords(idx_map,3);
                 %y_coord_max = box_coords(idx_map,4); 
                 
                 % MAKE ON FRIDAY
                 x_coord_min = x_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 x_coord_max = x_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_min = y_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_max = y_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame); 


matrix_NM_SCRAP = 0*matrix_nucleus_SCRAP;
    
matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;
matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
matrix_shrink_nucleus_SCRAP = 0*matrix_cytosol_SCRAP;
matrix_nucleus_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
matrix_NM_DUMMY(:,:) = eval(['M_CH',num2str(ii_NM),'_total(:,:,which_frame);']) ;
matrix_NM_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = matrix_NM_DUMMY(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])); 

%  scale_factor_nucleus  is set in get_movie_info_for_processing;

         x_coord_min_shrink_nucleus = max(1,floor(scale_factor_nucleus_shrink*(x_coord_min-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         x_coord_max_shrink_nucleus = min(xLength,ceil(scale_factor_nucleus_shrink*(x_coord_max-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         y_coord_min_shrink_nucleus = max(1,floor(scale_factor_nucleus_shrink*(y_coord_min-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));
         y_coord_max_shrink_nucleus = min(yLength,ceil(scale_factor_nucleus_shrink*(y_coord_max-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));

         
         
 if (do_max_or_shrink_median == 0)
  matrix_NM_SCRAP = matrix_NM_SCRAP/max(max(matrix_NM_SCRAP));        
 elseif (do_max_or_shrink_median == 1)  % this seems to be much more robust!!!
   matrix_NM_SCRAP = matrix_NM_SCRAP/median(median(matrix_NM_SCRAP(x_coord_min_shrink_nucleus:x_coord_max_shrink_nucleus,y_coord_min_shrink_nucleus:y_coord_max_shrink_nucleus)));        
 end;
   
   

%for ii = x_coord_min:x_coord_max
% for jj = y_coord_min:y_coord_max
%    
%     if (matrix_nucleus_SCRAP(ii,jj) == 1)
%         ii_scale = max(2,scale_factor_nucleus*(ii-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame));
%         ii_scale = min(ii_scale,xLength-1);
%         jj_scale = max(2,scale_factor_nucleus*(jj-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame));
%         jj_scale = min(jj_scale,yLength-1);
%         matrix_shrink_nucleus_SCRAP(ceil(ii_scale),ceil(jj_scale)) = 1;
%         matrix_shrink_nucleus_SCRAP(floor(ii_scale),ceil(jj_scale)) = 1;
%         matrix_shrink_nucleus_SCRAP(ceil(ii_scale),floor(jj_scale)) = 1;
%         matrix_shrink_nucleus_SCRAP(floor(ii_scale),floor(jj_scale)) = 1;
%     end;
%     
% end;
%end;        

         %x_coord_min_shrink_nucleus = max(1,floor(scale_factor_nucleus*(x_coord_min-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         %x_coord_max_shrink_nucleus = min(xLength,ceil(scale_factor_nucleus*(x_coord_max-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         %y_coord_min_shrink_nucleus = max(1,floor(scale_factor_nucleus*(y_coord_min-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));
         %y_coord_max_shrink_nucleus = min(yLength,ceil(scale_factor_nucleus*(y_coord_max-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));

                 
    
 
   matrix_shrink_nucleus_SCRAP = im2bw(matrix_NM_SCRAP,threshold_shrink);
    binary_FILL = bwareaopen(matrix_shrink_nucleus_SCRAP, 0);  % remove 
    %binary_FILL = bwareaopen(matrix_shrink_nucleus_SCRAP, nucleus_min_pixels);  % remove 
    Cell_marker_FILL = bwconncomp(binary_FILL);
    
    
    mean_x_dummy = 0;
    mean_y_dummy = 0;

    x_coord_min_shrink_nucleus = xLength;
    x_coord_max_shrink_nucleus = 1;
    y_coord_min_shrink_nucleus = yLength;
    y_coord_max_shrink_nucleus = 1;
    
   for ii = x_coord_min:x_coord_max        
   for jj = y_coord_min:y_coord_max        

       mean_x_dummy = mean_x_dummy + binary_FILL(ii,jj)*ii;
       mean_y_dummy = mean_y_dummy + binary_FILL(ii,jj)*jj;

       if (binary_FILL(ii,jj)==1)
        x_coord_min_shrink_nucleus = min(x_coord_min_shrink_nucleus,ii);
        x_coord_max_shrink_nucleus = max(x_coord_max_shrink_nucleus,ii);
        y_coord_min_shrink_nucleus = min(y_coord_min_shrink_nucleus,jj);
        y_coord_max_shrink_nucleus = max(y_coord_max_shrink_nucleus,jj);
       end
       
   end;
   end;
   
   
   
   if (sum(sum(binary_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))==0)
     mean_x_tot_SHRINK_time_mapped_t0(iii,which_frame) = mean_x_tot_time_mapped_t0(iii,which_frame);
     mean_y_tot_SHRINK_time_mapped_t0(iii,which_frame) = mean_y_tot_time_mapped_t0(iii,which_frame);
        x_coord_min_shrink_nucleus = x_coord_min;
        x_coord_max_shrink_nucleus = x_coord_max;
        y_coord_min_shrink_nucleus = y_coord_min;
        y_coord_max_shrink_nucleus = y_coord_max;
   else
     mean_x_dummy = mean_x_dummy/sum(sum(binary_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
     mean_y_dummy = mean_y_dummy/sum(sum(binary_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
     mean_x_tot_SHRINK_time_mapped_t0(iii,which_frame) = mean_x_dummy;
     mean_y_tot_SHRINK_time_mapped_t0(iii,which_frame) = mean_y_dummy;
   end;
   
   
    if (sum(sum(binary_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max))) == 0)
     eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} =Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};'])
     matrix_shrink_nucleus_SCRAP = matrix_nucleus_SCRAP;            
    elseif length(Cell_marker_FILL.PixelIdxList{1})>eval(['length(Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map})'])/shrink_factor_max
     eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_marker_FILL.PixelIdxList{1};'])
    else
     eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} =Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};'])
     matrix_shrink_nucleus_SCRAP = matrix_nucleus_SCRAP;    
    end;
     
    x_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame) = x_coord_min_shrink_nucleus;
    x_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame) = x_coord_max_shrink_nucleus;
    y_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame) = y_coord_min_shrink_nucleus;
    y_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame) = y_coord_max_shrink_nucleus; 
    
    if (sum(sum(binary_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max))) == 0)
     num_pixels_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame) = num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);           
    else
     num_pixels_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame) = length(Cell_marker_FILL.PixelIdxList{1});           
    end;

    
    
    x_coord_min_cytosol = xLength;
    x_coord_max_cytosol = 1;
    y_coord_min_cytosol = yLength;
    y_coord_max_cytosol = 1;
    
    
%  scale_factor_nucleus  is set in get_movie_info_for_processing;

%for ii = x_coord_min:x_coord_max
% for jj = y_coord_min:y_coord_max
for ii = x_coord_min_shrink_nucleus:x_coord_max_shrink_nucleus
 for jj = y_coord_min_shrink_nucleus:y_coord_max_shrink_nucleus
     
        mean_x_box = (x_coord_min_shrink_nucleus+x_coord_max_shrink_nucleus)/2;
        mean_y_box = (y_coord_min_shrink_nucleus+y_coord_max_shrink_nucleus)/2;
    
     %if (matrix_nucleus_SCRAP(ii,jj) == 1)
     if (matrix_shrink_nucleus_SCRAP(ii,jj) == 1)
         %ii_scale = max(2,scale_factor_nucleus*(ii-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame));
         ii_scale = max(2,scale_factor_nucleus*(ii-mean_x_box) + mean_x_box);
         ii_scale = min(ii_scale,xLength-1);
         %jj_scale = max(2,scale_factor_nucleus*(jj-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame));
         jj_scale = max(2,scale_factor_nucleus*(jj-mean_y_box) + mean_y_box);
         jj_scale = min(jj_scale,yLength-1);
         matrix_cytosol_SCRAP(ceil(ii_scale),ceil(jj_scale)) = 1;
         matrix_cytosol_SCRAP(floor(ii_scale),ceil(jj_scale)) = 1;
         matrix_cytosol_SCRAP(ceil(ii_scale),floor(jj_scale)) = 1;
         matrix_cytosol_SCRAP(floor(ii_scale),floor(jj_scale)) = 1;
         
    
        x_coord_min_cytosol = min(x_coord_min_cytosol,floor(ii_scale));
        x_coord_max_cytosol = max(x_coord_max_cytosol,ceil(ii_scale));
        y_coord_min_cytosol = min(y_coord_min_cytosol,floor(jj_scale));
        y_coord_max_cytosol = max(y_coord_max_cytosol,ceil(jj_scale));
         
         
     end;
     
 end;
end;
        

         %x_coord_min_cytosol = max(1,floor(scale_factor_nucleus*(x_coord_min-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         %x_coord_max_cytosol = min(xLength,ceil(scale_factor_nucleus*(x_coord_max-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         %y_coord_min_cytosol = max(1,floor(scale_factor_nucleus*(y_coord_min-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));
         %y_coord_max_cytosol = min(yLength,ceil(scale_factor_nucleus*(y_coord_max-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));

         x_coord_min_cytosol = max(1,floor(scale_factor_nucleus*(x_coord_min-mean_x_box) + mean_x_box));
         x_coord_max_cytosol = min(xLength,ceil(scale_factor_nucleus*(x_coord_max-mean_x_box) + mean_x_box));
         y_coord_min_cytosol = max(1,floor(scale_factor_nucleus*(y_coord_min-mean_y_box) + mean_y_box));
         y_coord_max_cytosol = min(yLength,ceil(scale_factor_nucleus*(y_coord_max-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));
                 
         
    %matrix_cytosol_SCRAP = max(matrix_cytosol_SCRAP,matrix_nucleus_SCRAP);     
    %binary_FILL = bwareaopen(matrix_cytosol_SCRAP-matrix_nucleus_SCRAP, 0);  % remove 
    matrix_cytosol_SCRAP = max(matrix_cytosol_SCRAP,matrix_shrink_nucleus_SCRAP);     
    binary_FILL = bwareaopen(matrix_cytosol_SCRAP-matrix_shrink_nucleus_SCRAP, 0);  % remove 
    Cell_marker_FILL = bwconncomp(binary_FILL);
    if (sum(sum(binary_FILL)) == 0)
    eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};'])
    else
     for ppp = 1:length(Cell_marker_FILL.PixelIdxList)
        if (ppp == 1)
        eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_marker_FILL.PixelIdxList{ppp};'])
        else
        eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = [Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}; Cell_marker_FILL.PixelIdxList{ppp}];'])
        end;
     end;
    end;
 
    
    
    x_coord_min_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = x_coord_min_cytosol;
    x_coord_max_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = x_coord_max_cytosol;
    y_coord_min_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = y_coord_min_cytosol;
    y_coord_max_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = y_coord_max_cytosol; 
    
    if (sum(sum(binary_FILL)) == 0)
    num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
    else
    num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = length(Cell_marker_FILL.PixelIdxList{1});           
    end;
    
    %for jjj = 1:length(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']))   
    %matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}(jjj)'])) = matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}(jjj)'])) + 1;
    %end;
    matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;

    

            which_nucleus_test = num_nuclei_t0+1;
            %which_nucleus_test = 28;
            
           do_plot_iterative = 1; % 1 - yes, 0 - no        
           if (do_plot_iterative == 1)&(iii == which_nucleus_test)
            figure(100)
            imagesc(matrix_nucleus_SCRAP);
            %imagesc(matrix_cytosol_SCRAP);
            %imagesc(binary_FILL);
            title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
            xlim([y_coord_min_cytosol y_coord_max_cytosol]);
            ylim([x_coord_min_cytosol x_coord_max_cytosol]);
            ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
            set(ll,'Color','y');
            figure(101)
            imagesc(matrix_cytosol_SCRAP-matrix_shrink_nucleus_SCRAP);
            title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
            xlim([y_coord_min_cytosol y_coord_max_cytosol]);
            ylim([x_coord_min_cytosol x_coord_max_cytosol]);
            ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
            set(ll,'Color','y');
           figure(102)
           matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
           matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
           imagesc(matrix_cytosol_SCRAP);
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min_cytosol y_coord_max_cytosol]);
           ylim([x_coord_min_cytosol x_coord_max_cytosol]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');
           figure(103)
           matrix_shrink_nucleus_SCRAP = 0*matrix_shrink_nucleus_SCRAP;
           matrix_shrink_nucleus_SCRAP(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
           imagesc(matrix_shrink_nucleus_SCRAP);
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min_cytosol y_coord_max_cytosol]);
           ylim([x_coord_min_cytosol x_coord_max_cytosol]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');
           pause
           end;


           
           
           
           

end; % END OF: for iii = 1:num_nuclei_t0
end; % END OF: if (do_cytosol == 1)      


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  remove any overlap in cytoslic regions from different cells
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(10000)
imshow(matrix_cytosol_OVERLAP)

if (max(max(matrix_cytosol_OVERLAP)) > 1)  % check for any overlap of cytosolic regions 

   matrix_cytosol_SCRAP = im2bw(matrix_cytosol_OVERLAP/max(max(matrix_cytosol_OVERLAP)),1.1/max(max(matrix_cytosol_OVERLAP)));
   matrix_cytosol_SCRAP = 1-matrix_cytosol_SCRAP;
for iii = 1:num_nuclei_t0
   idx_map = index_map_tot_time_mapped_t0(iii,which_frame);    
   matrix_cytosol_TEST = 0*matrix_cytosol_TEST;
   matrix_cytosol_TEST(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = 1;
    binary_FILL = matrix_cytosol_SCRAP.*matrix_cytosol_TEST;
    %binary_FILL = matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])).*matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
    Cell_marker_FILL = bwconncomp(binary_FILL);
    
     for ppp = 1:length(Cell_marker_FILL.PixelIdxList)
        if (ppp == 1)
        eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_marker_FILL.PixelIdxList{ppp};'])
        else
        eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = [Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}; Cell_marker_FILL.PixelIdxList{ppp}];'])
        end;
     end;


end;

end; % if (max(max(matrix_cytosol_OVERLAP)) > 1)


matrix_cytosol_OVERLAP = 0*matrix_cytosol_OVERLAP;
for iii = 1:num_nuclei_t0
idx_map = index_map_tot_time_mapped_t0(iii,which_frame);    
    matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = matrix_cytosol_OVERLAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
end;


figure(10001)
imshow(matrix_cytosol_OVERLAP)
%pause


