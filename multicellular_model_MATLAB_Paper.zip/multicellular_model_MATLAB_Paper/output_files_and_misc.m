rank = 0;
which_run = 0;
num_dimurs = 0;
for ii_part = 1:m_Np
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  encounters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     dummy1 = Parts_old(ii_part,COLLISION);
       if (dummy1 == ii_part)
         pause(100);
       end;

    if (dummy1>0)
       fwrite(fids_encounters,ii_timestep,'int');
       fwrite(fids_encounters,ii_part,'int');
       fwrite(fids_encounters,dummy1,'int');
       num_encounter_writes = num_encounter_writes+1;
       fwrite(fids_dimurs,rank,'int');
       fwrite(fids_dimurs,which_run,'int');
    end;        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  dimerizations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (Parts(ii_part,ACTIVATED)==1)
       num_dimurs = num_dimurs+1;
    end;


end;
       fwrite(fids_dimurs,rank,'int');
       fwrite(fids_dimurs,which_run,'int');
       fwrite(fids_dimurs,ii_timestep,'int');
       fwrite(fids_dimurs,num_dimurs,'int');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Particle information
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (rem(ii_timestep,Npartwrite)==0)
     fwrite(fids_info,ii_timestep,'int');
     fwrite(fids_part,Parts','double');
    end;
    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Mapping, some of this will become obsolete with the 
%  new membrane surface capabilities
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if ((m_finorinf==1)|(num_dim>1))
      map_N;
      m_n = m_n+m_bm/m_membrane_0;  % place the membranes in the space, this is 
    end;


    %  This is used to represent FCS (fluorescence correlation microscopy)
    %  gauss_vol is the gaussian focal region.  This eventually
    %  should be a 3D region.  This will be useful in examining crowding
    %if (num_dim == 1)
    %F(ii_timestep) = gauss_vol*m_n;
    %end;
