


which_function = 2;




   M_DAPI_NORMALIZED = (M_DAPI-min(min(M_DAPI)))/(max(max(M_DAPI))-min(min(M_DAPI)));
         %set the image boundaroes to zero
      %M_DAPI_NORMALIZED(1:xLength,yLength:yLength) = 0;
      %M_DAPI_NORMALIZED(1:xLength,1:1) = 0;
      %M_DAPI_NORMALIZED(xLength:xLength,1:yLength) = 0;
      %M_DAPI_NORMALIZED(1:1,1:yLength) = 0;

   
   M_DAPI_NORMALIZED_sort = sort(M_DAPI_NORMALIZED);     

      num_max = 10;
  
    do_plot_sorted_image = 0;  % 1 - yes, 0 - no
   if (do_plot_sorted_image == 1)
    for ii_rand = 1:num_max
        column_rand(ii_rand) = ceil(rand*yLength);
    figure(101)   
    subplot(2,1,1)
    hold on;
    plot(M_DAPI_NORMALIZED_sort(:,column_rand(ii_rand)));
    hold off;
    subplot(2,1,2)
    %hold on;
    plot(diff(M_DAPI_NORMALIZED_sort(:,column_rand(ii_rand))));
    %hold off
    end;
   end;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % Thresholds   % COMMENT:  we need to develop the threhsolding based on this SORTED
   % data !!!!!!!
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if (which_movie == 1)
    threshold = .035;  % we should the value of the first maximum on each column, then take the min of those maximums 
   elseif (which_movie == 8)
    threshold = .06;  % we should the value of the first maximum on each column, then take the min of those maximums 
   end;
    %threshold = graythresh(M_DAPI_NORMALIZED)  % ostus gies .0745 which is too HIGH
   
    %  Standard method once we get it working
    threshold = determine_object_threshold(M_DAPI_NORMALIZED,xLength,yLength)
   
if (which_function == 1)  % Mike's threshold code
   
    
   [mean_x_tot_DAPI,mean_y_tot_DAPI,var_x_tot_DAPI,var_y_tot_DAPI,cov_xy_tot_DAPI,box_coords_DAPI,num_pixels_tot_DAPI,num_DAPI,M_DAPI_threshold,M_DAPI_id_threshold,M_DAPI_threshold_FILL,fac_threshold_DAPI,DAPI_threshold_nuclei] = determine_nuclear_locations(M_DAPI,which_frame);


elseif (which_function == 2)  % Matlab tike's threshold code

    
   
   
    nucleus_min_pixels = 50;
    
    M_DAPI_BINARY = im2bw(M_DAPI_NORMALIZED,threshold);   % convert to binary image
    M_DAPI_BINARY = bwareaopen(M_DAPI_BINARY, nucleus_min_pixels);  % removie 
    cc_DAPI_BINARY = bwconncomp(M_DAPI_BINARY);
    
    num_DAPI = length(cellfun(@numel,cc_DAPI_BINARY.PixelIdxList));
    M_DAPI_id_threshold = 0*M_DAPI_BINARY; 
    
    for idx = 1:num_DAPI
       M_DAPI_id_threshold(cc_DAPI_BINARY.PixelIdxList{idx}) = idx;
    end;
       
    figure(102)
    imagesc(M_DAPI_BINARY)
    title('data (binary)');
    figure(103)
    imagesc(M_DAPI_NORMALIZED)
    title('data (normalized)');
    figure(104)
    imagesc(M_DAPI_id_threshold)
    title('data (id)');
    
    
elseif (which_function == 3)  % peak finders, don't seem to work for our purposes
    

   %[pks,locs] =findpeaks(M_DAPI_NORMALIZED,'THRESHOLD',threshold);
     pks = FastPeakFind(M_DAPI_NORMALIZED)
     
     figure(102)
     
elseif (which_function == 4)  % peak finders, don't seem to work for our purposes
    
    threshold = .15;  % we should the value of the first maximum on each column, then take the min of those maximums 
   
   %M_DAPI_EDGE = edge(M_DAPI_NORMALIZED,'sobel');
   M_DAPI_EDGE = edge(M_DAPI_NORMALIZED,'prewitt');
   %M_DAPI_EDGE = edge(M_DAPI_NORMALIZED,'roberts');
   %M_DAPI_EDGE = edge(M_DAPI_NORMALIZED,'log');
   %M_DAPI_EDGE = edge(M_DAPI_NORMALIZED,'zerocross');
    
    figure(102)
    imagesc(M_DAPI_EDGE)
    title('data (edge)');
    figure(103)
    imagesc(M_DAPI_NORMALIZED)
    title('data (normalized)');
    
end;


%pause