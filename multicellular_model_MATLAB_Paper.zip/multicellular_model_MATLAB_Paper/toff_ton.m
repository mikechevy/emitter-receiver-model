%  This M file goes over the argument about the expected time 
%  Ire1p has a Kar2p associated with it and the expected time
%  that it doesn't.

%  We first start with the probability, P_getoff, which is the probility
%  of a Kar2p dissociating from the Ire1p, given a particular Ire1p-Kar2p complex, during
%  the next timestep, dt.

%  Likewise, we hav the probability, P_geton, which is the probability that
%  a Kar2p associates with a particular solo Ire1p, during the next timestep, dt.

%  Therefore T_on = dt/P_getoff, the expected time a particular Ire1p molecule is a Ire1p-Kar2p complex
%  and T_off = dt/P_geton, the expected time a particular Ire1p molecule is a solo Ire1p molecule

%  T_on/T_off = P_geton/P_getoff

% if you sample over time for time>>T_on+T_off you will get a good sampling of the on/off cycle
% that the Ire1p model goes thorough.  

%  Over the time interval dt
%  N_on*P_getoff = Delta N_off
%  N_off*P_geton = Delta N_on

%
%  For dynamic equilibrium where we have relatively constant N_on and N_off
%  Delta N_off = Delta N_on
%  Therefore  N_on/N_off = P_geton/P_getoff = T_on/T_off
%

clear all;

P_getoff = .01;
P_geton = .09;

T_geton = 1/P_geton;
T_getoff = 1/P_getoff;

ire1p = zeros(256,1)

ire1p(1:128) = 1;
time_on_ire1p = 0*ire1p;

time_max = 10000;
for ii = 1:time_max 

  for jj = 1:length(ire1p)
    if (ire1p(jj)==1)
        if (rand < P_getoff)
           ire1p(jj) = 0;
        end;
    elseif (ire1p(jj)==0)
        if (rand < P_geton)
           ire1p(jj) = 1;
        end;
    end;
  end;

      time_on_ire1p = time_on_ire1p + ire1p;
   ratio_on_to_off(ii) = sum(ire1p)/length(ire1p);

end;


figure(1)
subplot(2,1,1)
plot(ratio_on_to_off);
ylabel('on/off');
xlabel('timesteps');
subplot(2,1,2)
plot(time_on_ire1p/time_max);
ylabel('on/off');
xlabel('particle #');

T_on = T_getoff;
T_off = T_geton;


T_on/(T_off+T_on)

