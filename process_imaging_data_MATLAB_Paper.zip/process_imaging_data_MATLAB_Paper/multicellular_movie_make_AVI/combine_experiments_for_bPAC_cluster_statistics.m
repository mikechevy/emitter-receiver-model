%  Script to generate statistics for the paper

str_processing = pwd;  % get processing directory

max_distance_plot = 80; % micrometers, used for do_emitter_reciever_amp_distance = 1




do_case = 3;

if (do_case == 1)  % small emitter cluster movies
    
    %  which_movie = 201, '160902_198_198-117_EA'
    %  which_movie = , ''
    %  which_movie = , ''
    %  which_movie = , ''
    
movie_array = [201];

 
    non_bPAC_clusters_inner = [ 16 22 23 29 30 34 37];

do_non_bPAC_clusters_inner = 1;
do_emitter_statistics = 1;
do_emitter_reciever_amp_distance = 1;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)



bPAC_pulse_start = 1;
bPAC_pulse_stop = 1;

elseif (do_case == 2)  % small emitter cluster movies

    
  %movie_array = [115]; 
  %non_bPAC_clusters_inner = [23 26 30 39 40];

  movie_array = [60]; 
  non_bPAC_clusters_inner = [26 27 28 33 36 38 39 42];

  
do_non_bPAC_clusters_inner = 1;
do_emitter_statistics = 0;
do_emitter_reciever_amp_distance = 1;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

bPAC_pulse_start = 2;
bPAC_pulse_stop = 2;


elseif (do_case == 3)  % combined small (single) emitter cluster movies

  %5)	190625_198-117_198_TEST_MC, movie 60
  %6)	190716_198-117_198_TEST_MC, movie 65, might not use
  %7)	190726_198-117_198_TEST_MC, movie 66
  %8)	190730_198-117_198_TEST_MC, movie 68
  %9)	190823_198-117_198_TEST_MC_2, movie 81
  %10)	190910_198-117_198_TEST_MC, movie 91
  %11)	190912_198-117_198_TEST_MC, movie 93
  %12)	190912_198-117_198_TEST_MC_2, movie 94
  %13)	191213_198-117_198_MC_p23, movie 140
  %14)	191213_198-117_198_MC_p23_2, movie 141
  %15)	191217_198-117_198_MC_p26, movie 142
  %16)	191217_198-117_198_MC_p26_2, movie 143, might not use

%movie_array = [60 65 66 68 81 91 93 94 140 141 142 143];
movie_array = [60 66 68 81 91 93 94 140 141 142];
  
  
do_non_bPAC_clusters_inner = 0;
do_emitter_statistics = 1;
do_emitter_reciever_amp_distance = 0;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

location_vec_array = [];
time_overshoot_whole_dummy_RAND_array = [];
num_samples_array = zeros(length(movie_array),1);


elseif (do_case == 4)  % small emitter cluster movies
    
    
  movie_array = [60]; 
  
    bPAC_clusters = [37];
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [26 28 33 36 38 42 47];
  
do_non_bPAC_clusters_inner = 1;
do_emitter_statistics = 0;
do_emitter_reciever_amp_distance = 1;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

bPAC_pulse_start = 1;
bPAC_pulse_stop = 1;



elseif (do_case == 5)  % small emitter cluster movies

  movie_array = [81];     
    
    count_clusters = 1;
    bPAC_clusters = [39];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    
    non_bPAC_clusters_inner = [34 36 47 48 50];
    non_bPAC_clusters_outer = [];
    %non_bPAC_clusters_outer = [31 46 45 36 26 29];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
  
do_non_bPAC_clusters_inner = 1;
do_emitter_statistics = 0;
do_emitter_reciever_amp_distance = 1;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

bPAC_pulse_start = 1;
bPAC_pulse_stop = 1;


elseif (do_case == 6)  % small emitter cluster movies
    
    
  movie_array = [141]; 
  
    bPAC_clusters = [42];
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [32 38 40 46 48 54];
  
do_non_bPAC_clusters_inner = 1;
do_emitter_statistics = 0;
do_emitter_reciever_amp_distance = 1;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

bPAC_pulse_start = 1;
bPAC_pulse_stop = 2;

elseif (do_case == 7)  % small emitter cluster movies

    
  %movie_array = [115]; 
  %non_bPAC_clusters_inner = [23 26 30 39 40];

  movie_array = [142]; 
  non_bPAC_clusters_inner = [22 23 25 30 40 39 28];

    
  
do_non_bPAC_clusters_inner = 1;
do_emitter_statistics = 0;
do_emitter_reciever_amp_distance = 1;
which_nuclei_signal_combine = 1;  %(1- shrink, 2- intersect (over time), 3 -circles)

bPAC_pulse_start = 1;
bPAC_pulse_stop = 1;

end;



cd('../combined_statistics/')
mkdir(strcat('do_case_',num2str(do_case)));
cd(strcat('do_case_',num2str(do_case)))
str_combined_stats_do_case = pwd;
  delete(strcat('combined_stats_do_case_',num2str(do_case),'-nuclear_Erk_signals_statistics_EMITTERS.ppt'));
cd(str_processing) 


if (length(movie_array) > 1)
   num_rounds = 2;
else
   num_rounds = 1;
end;
    

for ii_round = 1:num_rounds

for ii_which_movie = 1:length(movie_array)

which_movie_array = movie_array(ii_which_movie); 

load_and_plot_bPAC_cluster_statistics;




 if (ii_which_movie == 1)
   str_movies_do_case = str_movie; 
 else
   str_movies_do_case = [str_movies_do_case ',' str_movie]; 
 end;

  if (do_case == 3)
   % TO DO: write code here to combine statistics
   if (ii_round == 1)
   location_vec_array = [location_vec_array ; location_vec];
   time_overshoot_whole_dummy_RAND_array = [time_overshoot_whole_dummy_RAND_array time_overshoot_whole_dummy_RAND];  
   num_samples_array(ii_which_movie) = length(location_vec);
   end;    
  end;



end;  %  for ii_which_movie = 1:length(movie_array)


end;  % for ii_round = 1:num_rounds
    


cd (str_combined_stats_do_case);

if (do_case == 1)     %  which_movie = 201, '160902_198_198-117_EA' 
     figure(100)
     %print('-depsc',strcat('max_receiver_signal_distance','-',str_movie,'.eps'));       
     print('-depsc',strcat('max_receiver_signal_distance_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'-',str_movie,'.eps'));            
elseif (do_case == 2)  
     figure(100)
     print('-depsc',strcat('max_receiver_signal_distance','-',str_movie,'.eps'));       
elseif (do_case == 3)  % combined single emitter cluster movies
     figure(50);  % generated in make_bPAC_statistics_plots.m
                str_dir_dummy = pwd;
                cd(str_combined_stats_do_case);              
                   s_combine = strcat(str_movie,':nuclear Erk signals');
                   % full scatter plot of all combined data
                   figure(50)
                   hold on;
                   %scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
                   scatter(location_vec_array, time_overshoot_whole_dummy_RAND_array,str_plot);
                    ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND_array),std(time_overshoot_whole_dummy_RAND_array),'m');
                    ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND_array),std(time_overshoot_whole_dummy_RAND_array)/sqrt(length(time_overshoot_whole_dummy_RAND_array)),'g');
                    set(ss,'LineWidth',2);
                      cap_width = .2;
                    ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND_array)-std(time_overshoot_whole_dummy_RAND_array) mean(time_overshoot_whole_dummy_RAND_array)-std(time_overshoot_whole_dummy_RAND_array)],'m');
                    set(ss,'LineWidth',2);
                    ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND_array)+std(time_overshoot_whole_dummy_RAND_array) mean(time_overshoot_whole_dummy_RAND_array)+std(time_overshoot_whole_dummy_RAND_array)],'m');
                    set(ss,'LineWidth',2);
                    ss = scatter(location_vec(1),mean(time_overshoot_whole_dummy_RAND_array),'md');
                    set(ss,'LineWidth',5);
                    ss = scatter(location_vec(1),median(time_overshoot_whole_dummy_RAND_array),'yd');
                    set(ss,'LineWidth',5);                   
                   ylabel('time to overshoot (min.)');
                   xlabel('combined movies');
                   title(strcat('combined movies, number of samples: ',num2str( sum(num_samples_array) ),', median:',num2str(median(time_overshoot_whole_dummy_RAND_array)))); 
                   hold off;
                   ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);                   
                   xlim([0 3]);
                fig50 = figure(50)
                saveppt2(strcat('combined_stats_do_case_',num2str(do_case),'-nuclear_Erk_signals_statistics_EMITTERS_fig50.ppt'),'figure',[fig50], 'halign','center','title', s_combine);
                cd(str_dir_dummy)
     
     print('-depsc',strcat('do_case_',num2str(do_case),'-time_to_overshoot.eps')); 
elseif (do_case == 4)  
     figure(100)
     print('-depsc',strcat('max_receiver_signal_distance_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'-',str_movie,'.eps'));            
elseif (do_case == 5)  
     figure(100)
     print('-depsc',strcat('max_receiver_signal_distance_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'-',str_movie,'.eps'));            
elseif (do_case == 6)  
     figure(100)
     print('-depsc',strcat('max_receiver_signal_distance_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'-',str_movie,'.eps'));            
elseif (do_case == 7)  
     figure(100)
     print('-depsc',strcat('max_receiver_signal_distance_pulse',num2str(bPAC_pulse_start),'to',num2str(bPAC_pulse_start),'-',str_movie,'.eps'));            
end;

   if (length(which_movie_array) > 1)
     save(strcat('str_movies_do_case_',num2str(do_case)), 'str_movies_do_case', 'location_vec_array', 'time_overshoot_whole_dummy_RAND_array', 'num_samples_array');
   else
     save(strcat('str_movies_do_case_',num2str(do_case)), 'str_movies_do_case');
   end;

cd(str_processing) 
    