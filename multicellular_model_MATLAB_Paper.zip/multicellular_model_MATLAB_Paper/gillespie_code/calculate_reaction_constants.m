

function calculate_reaction_constants(x)


global num_molecules;
global stochasticity;
global stochasticity_conj;
global num_reactions;
%global reaction_constant;
global propensities;
global sign_reaction;
global reaction_type;
global reaction_molecules;
global c_mu;
global x_ref;
global kappa;
global a_0;
global a_1;
global a_2;
global a_3;
global a_4;
global a_5;
global a_6;
global a_7;
global a_8;
global a_9;
global a_0_eff;
global a_1_eff;
global eta_0_eff;  % constants in the function f_eff
global eta_1_eff;  % constants in the function f_eff
global n_eff; % constants in the function f_eff
global do_Partition;

%  INDEX MAP OF REACTIONS
%   1 - * -> reaction products
%   2 - S_j -> reaction products
%   3 - S_j + S_k -> reaction products (j~=k)
%   4 - 2 S_j -> reaction products
%   5 - S_i + S_j + S_k -> reaction products (i~=j~=k)
%   6 - S_j + 2 S_k -> (j~=k)
%   7 - 3 S_j
%   12 - (S_j0-S_j) -> reaction products, difference between inital value and current
%   13 - (S_j0-S_j)/2 -> reaction products, difference between inital value and current (dimer version)
%   20 - (S_k0/(S_k0+S_i))^2  2 S_j  - competition theory UPR, module 1
%   21 - f(S_i,S_j)   2 S_j - 
%   30 - S_i^n/(a0^n + S_i^n)  - gene regulation function #1 (Hill function) Activation
%   31 - a0^n/(a0^n + S_i^n)  - gene regulation function #2 (Hill function) Repression
%   32 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #3, cooperativity: independent
%   33 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #4, cooperativity: causal
%   34 -  gene regulation  function, activator or repressor, depending on constants
%   40 - decay of species 1 due to species 2 (activation) dependent decay rate
%   41 - decay of species 1 due to species 2 (repression) dependent decay rate
%   50 - min((S_i0-S_i)/2, S_j)  - gene regulation function #3
    
    for jj = 1:num_reactions

        
     if (reaction_type(jj)==1)  

           propensities(jj) = c_mu(jj);  % propensity
           
     elseif (reaction_type(jj)==2)
         
            propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1));  % propensity
            
     elseif (reaction_type(jj)==3)
         
            propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2));  % propensity
            
     elseif (reaction_type(jj)==4) 
         
            propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*(x(reaction_molecules(jj,1))-1)/2;   % propensity
            
     elseif (reaction_type(jj)==5)
         
            propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))*x(reaction_molecules(jj,3));   % propensity
            
     elseif (reaction_type(jj)==6)
         
            propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))*(x(reaction_molecules(jj,2))-1)/2;   % propensity
            
     elseif (reaction_type(jj)==7)
         
            propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*(x(reaction_molecules(jj,1))-1)*(x(reaction_molecules(jj,1))-2)/6;   % propensity
            
     elseif (reaction_type(jj)==12) % c_mu * (x_ref(species1)-x(species1))
         
            propensities(jj) = c_mu(jj)*( (x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)) ));   % propensity
            
     elseif (reaction_type(jj)==13) % c_mu * (x_ref(species1)-x(species1))/2  

            propensities(jj) = c_mu(jj)*(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2;   % propensity

     elseif (reaction_type(jj)==14) % c_mu * ((x_ref(species1)-x(species1))/2 -x(species2)) 

            propensities(jj) = c_mu(jj)*((x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2 - x(reaction_molecule(jj,2)) );   % propensity

     elseif (reaction_type(jj)==20)

            propensities(jj) = c_mu(jj)*power(x_ref(reaction_molecules(jj,1))/(x_ref(reaction_molecules(jj,1))+kappa(jj)*x(reaction_molecules(jj,1))),2)*x(reaction_molecules(jj,2))*(x(reaction_molecules(jj,2))-1)/2; 

     elseif (reaction_type(jj)==21)

     elseif (reaction_type(jj)==30)  % hill function-activator

              n_hill = a_0(jj);
              k_hill = a_1(jj);
              propensities(jj) = c_mu(jj)*power(x(reaction_molecules(jj,1)),n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,1)),n_hill));

     elseif (reaction_type(jj)==31)  %  hill function-repressor


              n_hill = a_0(jj);
              k_hill = a_1(jj);
              propensities(jj) = c_mu(jj)*power(k_hill,n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,1)),n_hill));

     elseif (reaction_type(jj)==32)  % cooperativity-independent

              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))/(a_0(jj) + a_1(jj)*x(reaction_molecules(jj,1)) + a_2(jj)*x(reaction_molecules(jj,2)) + x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)));  % propensity

     elseif (reaction_type(jj)==33)  % cooperativity-causal

              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))/(a_0(jj) + a_1(jj)*x(reaction_molecules(jj,1)) + x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)));  % propensity

     elseif (reaction_type(jj)==34)  % hill function from David's paper on two-entangled feedback loop motifs
% R_star = activate_R*R_tot*power(s/K_R_s,h_s)/(1 + power(s/K_R_s,h_s)) + (1-activate_R)*R_tot/(1 + power(s/K_R_s,h_s));
%A_E = eps_E + activate_E*(1-eps_E)*power(R_star/K_E,h_E)/(1+power(R_star/K_E,h_E)) + (1-activate_E)*(1-eps_E)/(1+power(R_star/K_E,h_E));
   %    c_mu = eps_E;
   %    a_0 = K_R_s;
   %    a_1 = h_s;
   %    a_2 = activate_R;
   %    a_3 = R_tot;
   %    a_4 = K_E;
   %    a_5 = h_E;
   %    a_6 = activate_E;
              dummy1 = power(x(reaction_molecules(jj,1))/a_0(jj),a_1(jj));
              dummy_star = ( a_2(jj)*a_3(jj)*dummy1 + (1-a_2(jj))*a_3(jj) ) / (1+dummy1);
              dummy2 = power(dummy_star/a_4(jj),a_5(jj));
              propensities(jj) = a_7(jj)*( c_mu(jj) + (1-c_mu(jj))*( a_6(jj)*dummy2 + (1-a_6(jj)) ) / (1+dummy2) );  % propensity

      elseif (reaction_type(jj)==35)
                 coop_on = a_0(jj);
                 n_hill_coop = a_1(jj);
                 k_hill_coop = a_2(jj);
                 crowding_on = a_3(jj);
                 n_hill_crowding = a_4(jj);
                 k_hill_crowding = a_5(jj);
                 species_2_same_type_as_1 = a_6(jj);
                 
             if (x(reaction_molecules(jj,1)) == 0)
              propensities(jj) = 0;
             else
              %propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*( (1-coop_on) + coop_on*power(k_hill_coop,n_hill_coop)/(power(k_hill_coop,n_hill_coop) + power(x(reaction_molecules(jj,1)),n_hill_coop))  + crowding_on*power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2)),n_hill_crowding)/(power(k_hill_crowding,n_hill_crowding) + power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2)),n_hill_crowding)) );
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*(1-coop_on + coop_on*power(k_hill_coop,n_hill_coop)/(power(k_hill_coop,n_hill_coop) + power(x(reaction_molecules(jj,1)) + species_2_same_type_as_1*x(reaction_molecules(jj,2)),n_hill_coop))) ;
             end;

        elseif (reaction_type(jj)==36)  % currently used for entering a CCP
                 crowding_on_enter = a_0(jj);
                 n_hill_crowding = a_1(jj);
                 k_hill_crowding = a_2(jj);
                 
                 exclusion_on_enter_1 = a_3(jj); % species 1
                 n_hill_exclusion_2 = a_4(jj);  % species 2
                 k_hill_exclusion_2 = a_5(jj);  % species 2
                 n_hill_exclusion_3 = a_6(jj);  % species 3
                 k_hill_exclusion_3 = a_7(jj);  % species 3

                 diff_12 = max(x(reaction_molecules(jj,1))-x(reaction_molecules(jj,2)),0);
                 diff_13 = max(x(reaction_molecules(jj,1))-x(reaction_molecules(jj,3)),0);
                 
                 if (exclusion_on_enter_1==1)
                   fac_exclusion = power(k_hill_exclusion_2,n_hill_exclusion_2)/(power(k_hill_exclusion_2,n_hill_exclusion_2) + power(diff_12,n_hill_exclusion_2)); 
                   fac_exclusion = fac_exclusion*power(k_hill_exclusion_3,n_hill_exclusion_3)/(power(k_hill_exclusion_3,n_hill_exclusion_3) + power(diff_13,n_hill_exclusion_3));
                 else
                   fac_exclusion = 1.0;
                 end;
                 
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,4))*(1-crowding_on_enter + crowding_on_enter*power(k_hill_crowding,n_hill_crowding)/(power(k_hill_crowding,n_hill_crowding) + power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2))+x(reaction_molecules(jj,3)),n_hill_crowding)) )*fac_exclusion;

     elseif (reaction_type(jj)==39)  %  uses: x_ref(species1)-x(species1), UPRE hill function

              propensities(jj) = c_mu(jj)*power(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)),2)/(a_0(jj) + a_1(jj)*(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1))) + power(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)),2));  % propensity

     elseif (reaction_type(jj)==40) % decay of species 1 due to species 2 (activation) dependent decay rate 

              n_hill = a_0(jj);
              k_hill = a_1(jj);
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(x(reaction_molecules(jj,2)),n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,2)),n_hill));
              
     elseif (reaction_type(jj)==41) % decay of species 1 due to species 2 (repression) dependent decay rate 

              n_hill = a_0(jj);
              k_hill = a_1(jj);
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(k_hill,n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,2)),n_hill));

     elseif (reaction_type(jj)==42) % MI paper: used for global translation effets, plus global estradiol-depednent repression
         
              n_hill = a_0(jj);
              k_hill = a_1(jj);
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(x(reaction_molecules(jj,2)),n_hill)*power(k_hill,n_hill)/(power(k_hill,n_hill) + power(x(reaction_molecules(jj,3)),n_hill));

     elseif (reaction_type(jj)==50) % OLD UPR   %  c_mu * min( (x_ref(species1)-x(species1))/2, x(species2) )*(a_0_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )/(a_1_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )

% NOTE: a_0_eff,a_1_eff have the power n_eff absorbed in it the preprocessing

              propensities(jj) = c_mu(jj)*min(abs(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2,abs(x(reaction_molecules(jj,2))))*( a_0_eff(jj) + power(eta_0_eff(jj)*x(reaction_molecules(jj,3))+eta_1_eff(jj)*x(reaction_molecules(jj,4)),n_eff(jj)) )/( a_1_eff(jj) + power(eta_0_eff(jj)*x(reaction_molecules(jj,3))+eta_1_eff(jj)*x(reaction_molecules(jj,4)),n_eff(jj)) );  % propensity

     elseif (reaction_type(jj)==51) % OLD UPR  %  c_mu * min( (x_ref(species1)-x(species1))/2-x(species2), x(species3) )

              propensities(jj) = c_mu(jj)*min( abs((x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2-x(reaction_molecules(jj,2)) ),abs(x(reaction_molecules(jj,3))));  % propensity

     elseif (reaction_type(jj)==52) % NEW UPR Splicing function   %  c_mu * min( (x(species1)), x(species2) )*(a_0_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )/(a_1_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )

% NOTE: a_0_eff,a_1_eff have the power n_eff absorbed in it the preprocessing
x_u_sum = (x(reaction_molecules(jj,3))+x(reaction_molecules(jj,4))+x(reaction_molecules(jj,5)));

              propensities(jj) = c_mu(jj)*min( abs(x(reaction_molecules(jj,1))),abs(x(reaction_molecules(jj,2))) )*( a_0_eff(jj) + power(eta_0_eff(jj)*x_u_sum+eta_1_eff(jj)*x(reaction_molecules(jj,6)),n_eff(jj)) )/( a_1_eff(jj) + power(eta_0_eff(jj)*x_u_sum+eta_1_eff(jj)*x(reaction_molecules(jj,6)),n_eff(jj)) );  % propensity

     elseif (reaction_type(jj)==53) % NEW UPR Splicing function  %  c_mu * min( (x(species1)+x(species2), x(species3) )

              propensities(jj) = c_mu(jj)*min( ( x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2)) + x(reaction_molecules(jj,3)) ),abs(x(reaction_molecules(jj,4))) );  % propensity

     elseif (reaction_type(jj)==54) % NEW UPR Splicing function  %  c_mu * min( x(species1), x(species2) )

              propensities(jj) = c_mu(jj)*min( abs( x(reaction_molecules(jj,1)) ),abs(x(reaction_molecules(jj,2))) );  % propensity

     elseif (reaction_type(jj)==55) % NEW UPR Splicing function  %  c_mu *( power(x(species1)+x(species2)+x(species3),n) / ( power(x_0,n) + power(x(species1)+x(species2)+x(species3),n) ) * x(species4) 

              x_0  = a_0_eff(jj);
              n_0  = n_eff(jj);

              propensities(jj) = c_mu(jj)*( power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2))+x(reaction_molecules(jj,3)),n_0)/(power(x_0,n_0) + power(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,2))+x(reaction_molecules(jj,3)),n_0)) )*abs(x(reaction_molecules(jj,4))) ;  % propensity
     elseif (reaction_type(jj)==56) % NEW UPR Splicing function  %  c_mu *( power(x(species1),n) / ( power(x_0,n) + power(x(species1),n) ) * x(species2) 

              x_0  = a_0_eff(jj);
              n_0  = n_eff(jj);

              propensities(jj) = c_mu(jj)*( power(x(reaction_molecules(jj,1)),n_0)/(power(x_0,n_0) + power(x(reaction_molecules(jj,1)),n_0)) )*min(abs(x(reacation_molecules(jj,1))),abs(x(reaction_molecules(jj,2))) ) ;  % propensity

     elseif (reaction_type(jj)==57) % NEW UPR Foci decay function  %  c_mu * x(species1)*power(x_0,n) / ( power(x_0,n) + power(x(species1),n) )

              x_0  = a_0_eff(jj);
              n_0  = n_eff(jj);

              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(x_0,n_0)/( power(x_0,n_0) + power(x(reaction_molecules(jj,1)),n_0) );  % propensity

     elseif (reaction_type(jj)==60) %  c_mu * x(species1)/ (1 + k_0*x(species2) )

              k_0  = a_0(jj);

              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))/( 1 + k_0*x(reaction_molecules(jj,2)) );  % propensity          
    
     elseif (reaction_type(jj)==61) %  c_mu * (x(species1)/(1 + k_0*x(species2)))*x(species3)/(x_0 + x(species3)))

              k_0  = a_0(jj);
              x_0  = a_1(jj);

              propensities(jj) = c_mu(jj)*(x(reaction_molecules(jj,1))/( 1 + k_0*x(reaction_molecules(jj,2)) ))...
                                         *(x(reaction_molecules(jj,3))/( x_0 + x(reaction_molecules(jj,3)) ));  % propensity
     elseif (reaction_type(jj)==62) %  c_mu * (x(species1)/(x_tot - x(species2))
         
              x_tot  = a_0(jj);
              x_0  = a_1(jj);

             if ( x_tot-x(reaction_molecules(jj,2)) <= 1.0)
              propensities(jj) = 0.0;
             else
              propensities(jj) = c_mu(jj)*(x(reaction_molecules(jj,1))/( x_tot-x(reaction_molecules(jj,2)) ));
             end;           
              
              
     elseif (reaction_type(jj)==63) %  c_mu * min(x(species1),x(species2))
         
              propensities(jj) = c_mu(jj)*min(x(reaction_molecules(jj,1)),x(reaction_molecules(jj,2)));

     elseif (reaction_type(jj)==64) %  c_mu * (x(species1) - x_tot )
         
              x_tot  = a_0(jj);
     
              propensities(jj) = c_mu(jj)*(x(reaction_molecules(jj,1))-x_tot);
              
              
     elseif (reaction_type(jj)==70) %  Chemotaxis:  propensity to end tumble
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1));  % must be in Tumble state for non zero value;
     elseif (reaction_type(jj)==71) %  Chemotaxis:  propensity to run (discrete small steps)
              propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1));  % must be in Run state for non zero value;
     elseif (reaction_type(jj)==72) %  Chemotaxis:  propensity to end run (currently correct version,OLD:currently varies linearly)
              alpha_low = c_mu(jj);
              alpha_high  = a_0(jj);
              tau_low = 1/alpha_low;
              tau_high = 1/alpha_high;
              x_adapt  = a_1(jj);
              x_low  = a_2(jj);
              if (x(reaction_molecules(jj,2)) <= x_low)
               propensities(jj) = alpha_low;
              elseif (x(reaction_molecules(jj,2)) > x_low)&(x(reaction_molecules(jj,2)) <= x_adapt)
               %propensities(jj) = alpha_low + (alpha_high-alpha_low)*(x(reaction_molecules(jj,2))-x_low)/(x_adapt-x_low);
               tau_interp = tau_low + (tau_high-tau_low)*(x(reaction_molecules(jj,2))-x_low)/(x_adapt-x_low);
               propensities(jj) = 1/tau_interp;
              else
               propensities(jj) = alpha_high;                
              end;
            propensities(jj) = propensities(jj)*x(reaction_molecules(jj,1));  % must be in Run state for non zero value

            
     elseif (reaction_type(jj)==80)  % flux of species 1 through gap junction with inhibitor capability (species 2)
              x_flux_max = a_0(jj);
              x_flux_molecule_dummy = min(x_flux_max, x(reaction_molecules(jj,1))+x(reaction_molecules(jj,3)));                  
               if (x_flux_molecule_dummy == x_flux_max)
                 x_flux_molecule_dummy = x_flux_max*x(reaction_molecules(jj,1))/(x(reaction_molecules(jj,1))+x(reaction_molecules(jj,3)));  % rate limiting, only so many gap junctions
                 %x_flux_molecule_dummy = x_flux_max;
               else
                 x_flux_molecule_dummy = x(reaction_molecules(jj,1));
               end;
         
              %propensities(jj) = c_mu(jj)*(1-x(reaction_molecules(jj,3)))*(x(reaction_molecules(jj,1))-x(reaction_molecules(jj,2)));  % propensity
              propensities(jj) = c_mu(jj)*(1-x(reaction_molecules(jj,2)))*x_flux_molecule_dummy;  % propensity

     elseif (reaction_type(jj)==81)  % andrews PKA activation reaction
         
              n_hill = a_0(jj);
              propensities(jj) = c_mu(jj)*power(x(reaction_molecules(jj,2)),n_hill)*x(reaction_molecules(jj,1));  % propensity
         
     elseif (reaction_type(jj)==82)  % pka (both cells) regulated flux of species 1 through gap junction with inhibitor capability (species 2)
         
              n_hill = a_0(jj);
              k_hill = a_1(jj);
              x_flux_max = a_2(jj);
              fac_flux_MOD = a_3(jj);
              P_i = a_4(jj);
              P_j = a_5(jj);

              
              x_flux_molecule_dummy = x(reaction_molecules(jj,1));                           

              if (do_Partition == 1)
              x_dummy = (x(reaction_molecules(jj,3))/P_i)+(x(reaction_molecules(jj,4))/P_j);
              f_hill_dummy = x_dummy/k_hill;
              propensities(jj) = c_mu(jj)*fac_flux_MOD*(1-x(reaction_molecules(jj,2)))*x_flux_molecule_dummy*f_hill_dummy;  % propensity
              else
              x_dummy = x(reaction_molecules(jj,3))+x(reaction_molecules(jj,4));
              %f_hill_dummy = x_dummy/(x_dummy + k_hill);
              f_hill_dummy = x_dummy/k_hill;
              propensities(jj) = c_mu(jj)*fac_flux_MOD*(1-x(reaction_molecules(jj,2)))*x_flux_molecule_dummy*f_hill_dummy;  % propensity
              end;
                  
 
              

     elseif (reaction_type(jj)==100)  % represents the updateing the input species over time (nothing done here)
         
           % nothing done here, all done in the gillespie code
         
     end;
        

    end;

    
    
    
    
