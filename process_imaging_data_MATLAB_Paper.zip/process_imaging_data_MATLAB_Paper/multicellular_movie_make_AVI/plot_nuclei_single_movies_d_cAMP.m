
  
idx = jj_Erk;  
%for idx = 1:num_nuclei_t0_first


for ii_which_movie = 1:1% length(movie_array)

%  num_nuclei_t0 = num_nuclei_t0_array(ii_which_movie);
    
%  mean_x_tot_time_mapped_t0(1:num_nuclei_t0) = mean_x_tot_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie);
%  mean_y_tot_time_mapped_t0(1:num_nuclei_t0) = mean_y_tot_time_mapped_t0_array(1:num_nuclei_t0,ii_which_movie);

     num_nuclei_t0 = num_nuclei_t0_first;
     mean_x_tot_time_mapped_t0 = mean_x_tot_time_mapped_t0_first;
     mean_y_tot_time_mapped_t0 = mean_y_tot_time_mapped_t0_first;
     bPAC_NUCLEUS_time_mapped_t0 = bPAC_NUCLEUS_time_mapped_t0_first;



  M_NM(:,:) = M_NM_d_cAMP(:,:,ii_which_movie);    
  M_NM_bPAC(:,:) = M_NM_bPAC_d_cAMP(:,:,ii_which_movie);
  M_Erk(:,:) = M_Erk_d_cAMP(:,:,ii_which_movie);
   

    % Default for now, but movie specific later
    scale_Erk_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels


kkk = 1;
which_frame = kkk;

    figure(10000)
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
    image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    title(strcat('nuclei locations'));

which_frame_NM = 1;
delta_min = xLength;
index_min = 0;     
    
for kkk = 1:num_nuclei_t0

             tt = text(mean_y_tot_time_mapped_t0(kkk,which_frame_NM),mean_x_tot_time_mapped_t0(kkk,which_frame_NM),strcat(num2str(kkk)));
             %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),'.');
             if ii_NM == ii_NM_bPAC  % all bPAC cells
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
               str_emitter = 'm';
               set(tt,'Color',str_emitter);
               %set(tt,'fontsize',12);
             else
               if (bPAC_NUCLEUS_time_mapped_t0(kkk,1) == 1)    
                   %str_emitter = 'w';  white does not save in saveppt, it
                   %becomes black
                   str_emitter = 'c';
                 set(tt,'Color',str_emitter);
               else
               set(tt,'Color','y');
               end;
             end;
             
         

end;

                 % (place circle around specified nucleus) 
                      %e
                      %r= desired radius
                      %x = x coordinates of the centroid
                      %y = y coordinates of the centroid
                      radius_pixels = 20;   %pixels
                      th = 0:pi/50:2*pi;
                      xunit = radius_pixels * cos(th) + mean_x_tot_time_mapped_t0_first(idx,which_frame_NM);
                      yunit = radius_pixels * sin(th) + mean_y_tot_time_mapped_t0_first(idx,which_frame_NM);
                      hold on;
                       if (bPAC_NUCLEUS_time_mapped_t0_first(idx,1) == 1)    
                        xx = plot(yunit, xunit,strcat(str_emitter,'--'));
                       else
                        xx = plot(yunit, xunit,'y--');
                       end;
                       set(xx,'LineWidth',2);
                       hold off;

       
             
end; % end of 'for ii_which_movie = 1:length(movie_array)'

 
%end; % end of 'for idx = 1:num_nuclei_t0_first'
