
if (length(ii_NM_bPAC) == 1)
 which_channels = [ii_CH1 ii_NM ii_NM_bPAC];
else
 which_channels = [ii_CH1 ii_NM];
end;
frame_direction = 1;  % start in the up direction
which_frame = 1
%for ii = 1:numFr_CH(ii_CH1)
while which_frame < numFr_CH(ii_CH1)
   
    change_frame = input('change direction (up (1) or down (0)) or hit return. ? ')
    while  (length(frame_direction) == 0)&(frame_direction ~= 0)&(frame_direction ~= 1)
    change_frame = input('change direction (up (1) or down (0)) or hit return. ? ')
    end;

    if (length(change_frame) == 1)
        frame_direction = change_frame;
    end;
    
    if (length(change_frame) == 0)&(frame_direction == 1)
        which_frame = min(which_frame+1,numFr_CH(ii_CH1));
    elseif (length(change_frame) == 0)&(frame_direction == 0)
        which_frame = max(which_frame-1,1);
    elseif (length(change_frame) == 1)&(frame_direction == 1)
        which_frame = min(which_frame+1,numFr_CH(ii_CH1));
    elseif (length(change_frame) == 1)&(frame_direction == 0)
        which_frame = max(which_frame-1,1);
    end;
    
        
for kk = 1:length(which_channels)
    
    which_channel = which_channels(kk);
    

M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(:,:,:)']))))*int16(ones(xLength,yLength));
fac_max = 1;

  
    which_frame
    numFr_CH(which_channel)
    
  figure(1000+which_channel)  
  %imagesc(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame),fac_max*M_max)']));
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame),fac_max*M_max)'])));
  title(strcat(eval(['CH',num2str(which_channel),'_str']),', which frame =',num2str(which_frame)))
  
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx))); 
             
             set(tt,'Color','y');

  end;
  
   
end;
  
end;