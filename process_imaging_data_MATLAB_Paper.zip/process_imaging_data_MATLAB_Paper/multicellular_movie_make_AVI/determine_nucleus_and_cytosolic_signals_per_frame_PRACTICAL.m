
% The following is currently never used so we don't calculate it any more.
% This could change
% %
eval(['M_S',num2str(lll),'=double(M_CH',num2str(lll),'_total(:,:,which_frame_signal));']);


     for ii = 1:num_nuclei
        idx_map = ii;             
         val_dummy = ii;
            if (lll==1)
             signal_array_dummy = M_S1(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
             nuclear_CH1_tot_time(val_dummy,which_frame_signal) = mean(signal_array_dummy);
            elseif (lll==2)
             signal_array_dummy = M_S2(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
             nuclear_CH2_tot_time(val_dummy,which_frame_signal) = mean(signal_array_dummy);
            elseif (lll==3)
             signal_array_dummy = M_S3(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
             nuclear_CH3_tot_time(val_dummy,which_frame_signal) = mean(signal_array_dummy);
            elseif (lll==4)
             signal_array_dummy = M_S3(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
             nuclear_CH3_tot_time(val_dummy,which_frame_signal) = mean(signal_array_dummy);
            end;
     end;


% eval(['M_S',num2str(lll),'=double(M_CH',num2str(lll),'_total(:,:,which_frame_signal));']);
% 
% 
% for ii = 1:xLength    
%     for jj = 1:yLength
%        % ii 
%        % jj
%          val_dummy = M_marker_id_threshold(ii,jj);
%         if (val_dummy > 0)
%             if (lll==1)
%             nuclear_CH1_tot_time(val_dummy,which_frame_signal) = nuclear_CH1_tot_time(val_dummy,which_frame_signal) + M_S1(ii,jj);
%             elseif (lll==2)
%              nuclear_CH2_tot_time(val_dummy,which_frame_signal) = nuclear_CH2_tot_time(val_dummy,which_frame_signal) + M_S2(ii,jj);
%             elseif (lll==3)
%              nuclear_CH3_tot_time(val_dummy,which_frame_signal) = nuclear_CH3_tot_time(val_dummy,which_frame_signal) + M_S3(ii,jj);
%             elseif (lll==4)
%              nuclear_CH4_tot_time(val_dummy,which_frame_signal) = nuclear_CH4_tot_time(val_dummy,which_frame_signal) + M_S4(ii,jj);
%             end;
%         end;
%     end;
% end;
% 
% 
% % convert to average signal per pixel
% for ii = 1:num_nuclei
%             eval(['nuclear_CH',num2str(lll),'_tot_time(ii,which_frame_signal) = nuclear_CH',num2str(lll),'_tot_time(ii,which_frame_signal)/num_pixels_tot_NUCLEUS(ii);']);
% end;


matrix_cytosol_SCRAP = 0*M_S1;
matrix_nucleus_SCRAP = 0*M_S1;

do_cytosol = 1; % 1 - yes, 0 - no
if (do_cytosol == 1)      
for iii = 1:num_nuclei_t0
    
idx_map = index_map_tot_time_mapped_t0(iii,which_frame);    
    
    
                 x_coord_min = x_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 x_coord_max = x_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_min = y_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_max = y_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame); 
      
                 x_coord_min_cytosol = x_coord_min_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
                 x_coord_max_cytosol = x_coord_max_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
                 y_coord_min_cytosol = y_coord_min_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
                 y_coord_max_cytosol = y_coord_max_tot_CYTOSOL_time_mapped_t0(iii,which_frame); 
         
           
           
           matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
           %matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
           %matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  M_S1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));

           
 
do_new_way = 1;  % 1 - faster, 2 - slower (uses more 'eval([])' calls)

 if (do_new_way == 1)
     
    %cytosolic signals
    if (lll==1)
           signal_array_dummy = M_S1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
           cytosolic_CH1_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);    
           cytosolic_CH1_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy); 
    elseif (lll==2)
           signal_array_dummy = M_S2(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
           cytosolic_CH2_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);    
           cytosolic_CH2_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy); 
    elseif (lll==3)
           signal_array_dummy = M_S3(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
           cytosolic_CH3_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);    
           cytosolic_CH3_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy); 
    elseif (lll==4)
           signal_array_dummy = M_S4(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
           cytosolic_CH4_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);    
           cytosolic_CH4_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy); 
    end;
    
    
    %nuclear signals
    if (lll==1)
           if (which_nuclei_signal_type == 1)  % shrink
           signal_array_dummy = M_S1(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 2) % intersect
           signal_array_dummy = M_S1(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 3) % circle
           signal_array_dummy = M_S1(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           end;
           nuclear_CH1_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);
           nuclear_CH1_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy);      
    elseif (lll==2)
           if (which_nuclei_signal_type == 1)  % shrink
           signal_array_dummy = M_S2(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 2) % intersect
           signal_array_dummy = M_S2(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 3) % circle
           signal_array_dummy = M_S2(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           end;
           nuclear_CH2_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);
           nuclear_CH2_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy);      
    elseif (lll==3)
           if (which_nuclei_signal_type == 1)  % shrink
           signal_array_dummy = M_S3(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 2) % intersect
           signal_array_dummy = M_S3(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 3) % circle
           signal_array_dummy = M_S3(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           end;
           nuclear_CH3_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);
           nuclear_CH3_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy);      
    elseif (lll==4)
           if (which_nuclei_signal_type == 1)  % shrink
           signal_array_dummy = M_S4(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 2) % intersect
           signal_array_dummy = M_S4(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           elseif (which_nuclei_signal_type == 3) % circle
           signal_array_dummy = M_S4(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map};']));
           end;
           nuclear_CH4_tot_time_mapped_t0(iii,which_frame_signal) = mean(signal_array_dummy);
           nuclear_CH4_tot_time_mapped_t0_median(iii,which_frame_signal) = median(signal_array_dummy);      
    end;
    
 elseif (do_new_way == 0)
     
    
    if (lll==1)
    %cytosolic_CH1_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol).*M_S1(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  M_S1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
    cytosolic_CH1_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    cytosolic_CH1_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S1(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
    elseif (lll==2)
    %cytosolic_CH2_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol).*M_S2(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  M_S2(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
    cytosolic_CH2_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    cytosolic_CH2_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S2(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
    elseif (lll==3)
    %cytosolic_CH3_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol).*M_S3(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  M_S3(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
    cytosolic_CH3_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    cytosolic_CH3_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S3(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
    elseif (lll==4)
    %cytosolic_CH4_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol).*M_S4(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  M_S4(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}']));
    cytosolic_CH4_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    cytosolic_CH4_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S4(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
    end;
                
           matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;
           
           if (which_nuclei_signal_type == 1)  % shrink
           %matrix_nucleus_SCRAP(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
           %num_pixels_tot_dummy = num_pixels_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame);
           matrix_nucleus_SCRAP(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  eval(['M_S',num2str(lll),'(Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map});']);
           num_pixels_tot_dummy = eval(['length(Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map});']);
           elseif (which_nuclei_signal_type == 2) % intersect
           matrix_nucleus_SCRAP(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  eval(['M_S',num2str(lll),'(Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map});']);
           num_pixels_tot_dummy = eval(['length(Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map});']);
           elseif (which_nuclei_signal_type == 3) % circle
           matrix_nucleus_SCRAP(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  eval(['M_S',num2str(lll),'(Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map});']);
           num_pixels_tot_dummy = eval(['length(Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map});']);
           end;
           
           
    if (lll==1)
    %nuclear_CH1_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_S1(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
    nuclear_CH1_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_dummy;
     if (which_nuclei_signal_type == 1)  % shrink
      nuclear_CH1_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S1(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 2) % intersect
      nuclear_CH1_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S1(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 3) % circle
      nuclear_CH1_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S1(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     end;
    elseif (lll==2)
    %nuclear_CH2_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_S2(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
    nuclear_CH2_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_dummy;
     if (which_nuclei_signal_type == 1)  % shrink
      nuclear_CH2_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S2(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 2) % intersect
      nuclear_CH2_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S2(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 3) % circle
      nuclear_CH2_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S2(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     end;
    elseif (lll==3)
    %nuclear_CH3_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_S3(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
    nuclear_CH3_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_dummy;
     if (which_nuclei_signal_type == 1)  % shrink
      nuclear_CH3_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S3(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 2) % intersect
      nuclear_CH3_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S3(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 3) % circle
      nuclear_CH3_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S3(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     end;
    elseif (lll==4)
    %nuclear_CH4_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_S4(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
    nuclear_CH4_tot_time_mapped_t0(iii,which_frame_signal) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_dummy;
     if (which_nuclei_signal_type == 1)  % shrink
      nuclear_CH4_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S4(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 2) % intersect
      nuclear_CH4_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S4(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     elseif (which_nuclei_signal_type == 3) % circle
      nuclear_CH4_tot_time_mapped_t0_median(iii,which_frame_signal) = median(M_S4(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])));
     end;
    end;

 end;
           
           do_segmentation = 0; % 1 - yes, 0 - no        
           if (do_segmentation == 1)
               if (iii == 1)
                for idx = 1:num_nuclei_t0       
                idx_map   = index_map_tot_time_mapped_t0(idx,which_frame);          
                M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
                end;
                 min_min_FITC = min(min(M_FITC));
                 max_max_FITC = max(max(M_FITC));
                 M_FITC_NORMALIZED = (M_FITC - min_min_FITC)/(max_max_FITC-min_min_FITC);
                 M_FITC_NORMALIZED_adjusted = 0*M_FITC_NORMALIZED;
                 M_FITC_binary = 0*M_FITC_NORMALIZED;
               end;
           segment_cell_boundary      
           end;
           

end; % END OF: for iii = 1:num_nuclei_t0
end; % END OF: if (do_cytosol == 1)      




