
%close all;
clear all;
pathway_str = 'pathways/pathway_2Depithelial_het';  % path of directory relative to MAT_pic_bio

cd ../../;
set_globals_and_initialize;
set_globals_parts;
set_constants_parts;
cd(pathway_str);

global Y_info_index_cov_map;
global Y_info_index;
global scale_Y_info_index;
global X_info_index;
global Cov_mat;
global mu_vec;
global P_Y;
global P_X;
global P_Y_X;
global P_Y_X_properties;
global X;
global Y;
global Y_1;
global Y_2
global X_1;
global X_2
global X_sequence_sample;
global do_Partition;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  cell-cycle and multicellular
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global num_volumes;
global alpha_multicellular;
global theta_multicellular;
global gamma_cell;
global p_daughter;
global p_mother;
global num_cells;


global num_time_samples_multicellular;
global alpha_multicellular_time;

global time_moments_data_sampled_multicellular;


global theta_flux_daughter;
global theta_flux_mother;

global theta_tot;

global V_cells;


choose_figures_to_make
 
 


         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %  which_pathway - indexes pathways to model
         %
         %
         %      0 - Biological Oscillator (Carlos)
         %      1 -  MDCK pathay 
         %      2 -  one input, one gene transcriptional network, 
         %      3 - 
         %
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         do_load_pathway = 0;  % 0 - use given parameter set, 1 - load in a parameter set from file
 
         
     do_mean_or_full = 0;   % 1- full gillespie,  0 - mean or just mean (mass-action),  -1 - nothing
           %if (do_mean_or_full == 1)
           %    do_load_pathway = 1;
           %end;
         
         
               do_cell_cycle_effects = 0; % 0 - no cell cycle, 1 - cell cycle
               do_multicellular = 1;  

 
               
               if (do_multicellular == 0)
                   num_cells = 1;
               elseif (do_multicellular == 1)

                   do_image_load_files = 1; % 0 - no, 1 - yes     

                       
                   if (do_image_load_files == 1)
                       
                      which_pathway = 1;  % MDCK cAMP circuite                      
                      which_cAMP_circuit = 1;  % 1 - current models, 0 - Andrews rotation project 
                                        
                     
                      
                     if (which_modeling_case == 2)
                       str_movie_write = 'imagefile_160902_198_198-117_EA_100_400_150_400';
                     elseif (which_modeling_case == 7)
                        str_movie_write = 'imagefile_160905_198_198-117_JP_100_490_100_400';
                     end;

                      pathway_str_movie_write = strcat('image_load_files/',str_movie_write);
                        load(strcat('image_load_files/',str_movie_write));
                        num_cells = length(index_group);
                        index_group
                   else  % orginal oscillator
                        which_pathway = 0; 
                        num_cells = 2;
                        str_movie_write = 'imagefile_TEST';
                         pathway_str_movie_write = strcat('image_load_files/',str_movie_write);
                        load(strcat('image_load_files/',str_movie_write));
                        num_nuclei_t0 = length(mean_x_tot_time_mapped_t0(:,1))-17;
                        bPAC_NUCLEUS_time_mapped_t0 = zeros(num_nuclei_t0,1);
                        numFr_NM = numFr;
                        str_movie = 'Pos1';
                   end;
                   
                   
                 if (which_modeling_case == 7)
                 x_coord_min_local = 1;
                 x_coord_max_local = 500;
                 y_coord_min_local = 1;
                 y_coord_max_local = 500;
                  index_group = 1:num_nuclei_t0;
                  num_cells = length(index_group);
                 end;
                 
                   plot_localized_cells_within_box

                   %  Spatially averaged groups are set in designate_spatially_averaged_groups
                   designate_spatially_averaged_groups
                   %  Generate the cell-cell coupling connections
                   generate_coupling_matrices;
                   %pause;
               end;
                   
            
            
          do_global = 1; % include translational global noise source.                      
            G_mean = 50;  % global example in paper
            exp_life_G = 10000;  % hours, timescles of fluctuations in extrinsic noise
            %exp_life_G = 100;  % hours, timescles of fluctuations in extrinsic noise
                     do_circuit_ophelia = 1;
                 if (do_circuit_ophelia==1)
                    G_mean = 35;  % global example in paper
                    %G_mean = 35000+1 + do_circuit_ophelia + do_FP_gal10_halflife;  % global example in paper
                    exp_life_G = 100;  % hours, timescles of fluctuations in extrinsic noise
                 end;                  

            do_ramp = 0;       
           
do_quadratic_terms = 0; % 0-no, 1-yes  (covariance terms involving second derivative of propensities) 
do_covariances = 0;  % This is for Mike's hybrid method from the paper; 0 - do not use covariance, 1 - use covariances  


do_numerous_mean_runs = 0; % 0 - only 1 mean run, 1 - numerous mean runs (numerous types of inputs)  

     num_sampled_ssa = 1000;
     num_sampled_array_max = num_sampled_ssa;  % the number of total samples to output, if do_ssa_sampled_out = 1
    
      num_runs = 1;
                
       

 count_parameter_sweep_max = 1;  % if parameter sweep, this gets set in 'which_model_to_run_Specific_Example_Paper.m', otherwise stays zero
 count_parameter_sweep = 1; % stars at zero
 
while (count_parameter_sweep <= count_parameter_sweep_max)        
          
      
if (which_pathway==1)  % cAMP/PKA/ERK

    
 % Inputs, drugs   
 do_GJ_inhibition = 0; % set in setup_cAMP_circuit_parameters_mike.m at  fac_I_cAMP_gap = do_GJ_inhibition;  % 0-no, 1-yes (gap junction inihbition)
 do_H89 = 0;   % set in setup_cAMP_circuit_parameters_mike.m at fac_I_H89 = do_H89;  % 0-no, 1-yes
 
 % constant gap junction activity model (gets set below the default values)
 do_constant_gap_junction_activity = 0;  % 1 - yes, 0 - no

  % turn on feedback of PDE (upregulatied by PKA) on cAMP
  do_PKA_PDE_reg_cAMP = 0; % 1-yes, 0 - no

   % this breaks the cell-cell coupling into partitioned interfaces based
   % on the number of cells a given cell couples to
   do_Partition = 1;  % 1 do partitioning, 0 - don't
     if (do_Partition == 1)
         %%%scale_k_diff_Partition = 7;  % too high for IBMX results
         scale_k_diff_Partition = 5;  % works well
     end;
 
 %do_BrA = ,  Brefeldin A, add info once we have all-emitter data
bPAC_amplitude = .5; % set in setup_cAMP_circuit_parameters_mike.m at  amp_bPAC = bPAC_amplitude; %  0 <= amp_bPAC <= 1

     if (do_transfer_function_pulse == 1)
         do_bPAC_turnoff_finite = 1; % 0 - fast turn-off, 1- 30 second turn off
     end;
  
  if (do_ALL_bPAC == 1)
   bPAC_amplitude = bPAC_amplitude/5; % set in setup_cAMP_circuit_parameters_mike.m at  amp_bPAC = bPAC_amplitude; %  0 <= amp_bPAC <= 1
  end;
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  N_alpha_bPAC_basal and alpha_bPAC_basal
%     alpha_bPAC_basal = N_alpha_bPAC_basal % set in setup_cAMP_circuit_parameters_mike.m at with expression:  
%     c_mu(which_reaction) = beta_c_ac*(1+alpha_bPAC_basal*bPAC_NUCLEUS_time_mapped_t0(index_group(ii),1))
%
%  The larger N_alpha_bPAC_base is, the more potential undershoot
%
%   value prior to 030520: N_alpha_bPAC_basal =  3; % can be -1 to N (positivive), 0 if no difference in basal cAMP rates between bPAC/non-bPAC;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N_alpha_bPAC_basal =  6; % can be -1 to N (positivive), 0 if no difference in basal cAMP rates between bPAC/non-bPAC;

     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     % BEGIN: Classic Gap Junctin model paramters, Don't change!  They get changed for
     % different 'which_GJ_model' values below
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     
       %%%time_gj_delay = 15;  set from FEEDBACK
       %time_gj_delay = .1;
       %time_gj_delay = 2;
       time_gj_delay = 15;

      %%%step_gj_delay = 4; set from FEEDBACK
       step_gj_delay = 4;    
       
      %%%num_GJ_complex_tot = 10; % set from FEEDBACK
        num_GJ_complex_tot = 10;
        %num_GJ_complex_tot = 7;
        %num_GJ_complex_tot =  1;  % gap-junction numbers for emitter/receivers-NGFP
        %num_GJ_complex_tot = 20;  % gap-junction numbers for emitter-70/receivers-70
        
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     % END: Classic Gap Junctin model paramters, Don't change!  They get changed for
     % different 'which_GJ_model' values below
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
%      fac_gamma_c_pd_hetero = 1;  % adjust for different intracellular PDE-decay rate of cAMP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
      %fac_gamma_c_pd_hetero = .150;  % adjust for different intracellular PDE-decay rate of cAMP
      %fac_gamma_c_pd_hetero = .50;  % adjust for different intracellular PDE-decay rate of cAMP

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%  BEGIN: Default: don't change
%        do_GJ_complex = 1;  % 1-adding delay between PKA and  gap junction activity, 0 - PKA directly regulates gap junction activty
%        which_GJ_model = 0;  % 0-single GJ model, >0 for two GJ model, set below for >0.        
%        do_GJ2 = 0;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
%        do_CX43_NGFP = 0;  % 0 - no, 1- reduced flux due to broken gap-junctions
%        fac_flux_MOD_gj_gjc = 1.0;  % modulates the Gap Junction population size 
%        fac_gamma_c_pd_hetero = 1.0;  % adjust for different intracellular PDE-decay rate of cAMP
%        do_PKA_reg_AC = 1; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
%        do_PKA_reg_GJ = 1; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_gj_pk = do_PKA_reg_GJ; %#  1 - pka regulated gap junctions (our model), 0 - constant gap junction activity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
        do_GJ_complex = 1;  % 1-adding delay between PKA and  gap junction activity, 0 - PKA directly regulates gap junction activty
        which_GJ_model = 0;  % 0-single GJ model, >0 for two GJ model, set below for >0.        
        do_GJ2 = 0;  % 1- 2 population of GJ, same function, different delay dynamics, 0 - normal way (1 population)
        do_CX43_NGFP = 0;  % 0 - no, 1- reduced flux due to broken gap-junctions
        fac_flux_MOD_gj_gjc = 1.0;  % modulates the Gap Junction population size 
        fac_gamma_c_pd_hetero = 1.0;  % adjust for different intracellular PDE-decay rate of cAMP
        do_PKA_reg_AC = 1; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_ac_pk = do_PKA_reg_AC # 1- Turns on feedback from PKA to AC, 0 - no feedback
        do_PKA_reg_GJ = 1; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_gj_pk = do_PKA_reg_GJ; %#  1 - pka regulated gap junctions (our model), 0 - constant gap junction activity
        fac_gamma_c_pd_pka = 1.0;  %% scales the pde dependendent (regulated by pka) decay rate for cAMP, fac_c_pd = do_PDE_reg_cAMP must be 1
        fac_gamma_c_basal = 1.0;  % scales the non-pde (when IBMX = 1) decay rate of cAMP #Rate of basal cAMP degradation through non-PDE means
        fac_gamma_e_c = 1.0;  % scales the Epac associated deactivation rate of ERK: maxi deactivation rate for cAMP regulation of Erk
        fac_k_diff_c_basal  = 1.0; % scales the %#Basal Rate of diffusion of cAMP through gap junctions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%  END: Default: don't change
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
      


         if (do_constant_gap_junction_activity == 1)  % set above in model options
          do_PKA_reg_GJ = 0; %#  set in setup_cAMP_circuit_parameters_mike.m at fac_gj_pk = do_PKA_reg_GJ; %#  1 - pka regulated gap junctions (our model), 0 - constant gap junction activity
         end;

     if (do_transfer_function_pulse == 1)&(do_IBMX == 1)
        fac_gamma_c_basal = 1.0;  % scales the non-pde (when IBMX = 1) decay rate of cAMP #Rate of basal cAMP degradation through non-PDE means
     end;

         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
%  Which model to run: calls
%  'which_model_to_run_SUBMIT.m"
%   more to possible come
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     


%which_model_to_run_SUBMIT % old 

do_run_specific_examples = 1;  % 1 - specific examples in paper, 0 - test/try examples

if (do_run_specific_examples == 0)
 TEST_model;
else
 which_model_to_run_Specific_Examples_Paper; 
end;

      
        
        
      
          str_which_GJ_model = 'b';
       if (do_GJ2 == 1)
           str_which_GJ_model = 'b';
         if (which_GJ_model == 1) % classic  gap-junction regulation, emitter/receiver
         time_gj2_delay = time_gj_delay; 
         step_gj2_delay = step_gj_delay;     
         frac_gj2 = .2;
         num_GJ_complex_tot = 10;
           str_which_GJ_model = 'b--';
         elseif (which_GJ_model == 2) % medium  gap-junction regulation, emitter/receiver
         time_gj2_delay = 2; 
         step_gj2_delay = 4;     
         frac_gj2 = .2;
         num_GJ_complex_tot = 10;
           str_which_GJ_model = 'g--';
         elseif (which_GJ_model == 3) %fast gap-junction regulation, emitter/receiver
         time_gj2_delay = 2; 
         step_gj2_delay = 4;     
         frac_gj2 = 1;
         num_GJ_complex_tot = 10;
          str_which_GJ_model = 'r--';
         elseif (which_GJ_model == 4) % classic  gap-junction regulation,  emitter/receiver-NGFP
         time_gj2_delay = time_gj_delay; 
         step_gj2_delay = step_gj_delay;     
         frac_gj2 = 0;
         num_GJ_complex_tot = .1;
           str_which_GJ_model = 'm--';
         elseif (which_GJ_model == 5) % very fast  gap-junction regulation,  emitter-70/receiver-70
         time_gj2_delay = .0002; 
         step_gj2_delay = 4;     
         frac_gj2 = 1;
         num_GJ_complex_tot = 10;
           str_which_GJ_model = 'g--';
         elseif (which_GJ_model == 200) % medium  gap-junction regulation, emitter/receiver
         time_gj2_delay = 5; 
         step_gj2_delay = 4;     
         frac_gj2 = .5;
         num_GJ_complex_tot = 10;
           str_which_GJ_model = 'g--';
         end;
       end;


   if (which_cAMP_circuit == 0)  % Andrews rotation project
 
      setup_cAMP_circuit_parameters_andrew

   elseif (which_cAMP_circuit == 1)  % current models

      setup_cAMP_circuit_parameters_mike
 
   end;
  
end;  %  if (which_pathway==  )`
        
       
     pathway_info_multicellular;
     pathway_specific_function; % one last call
     

     
if (do_multicellular == 1)  
  
    %plot_data_multicellular;    
    %pause

   do_ERK_KTR_N_over_C = 1; % when ii_Species_to_plot = ii_ERKKTR_n, 1 - ERK-KTR N/C, 0 - ERK_KTR_n   
   
   do_propagation_delay = 0; % 0 -default (no), 1- show specific cell results (for Reviewer 2)
   
   do_gap_junction_interface = 1;  % when averaging adj. recievers: 1 - sum of GJ_i/P_i at the emitter/receiver interface, 0 - orignal way: sum of GJ_i  
   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  BEGIN: PLoS Comp. Bio. Paper parameters
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  % Uncomment which group of species to plot, Default is: ii_Species_to_plot_array = [ii_cAMP ii_ERKKTR_n]; % main plots used
    %ii_Species_to_plot_array = ii_cAMP     
    %ii_Species_to_plot_array = ii_ERKKTR_n  % used in paper (propagation)     
    %ii_Species_to_plot_array = ii_GJ_complex_on;  % used in paper     
    %ii_Species_to_plot_array = [ii_GJ_complex_on ii_GJ2_complex_on]; % used in paper
    ii_Species_to_plot_array = [ii_cAMP ii_ERKKTR_n]; % main plots used
    %ii_Species_to_plot_array = [ii_cAMP ii_PDE_on];
    %ii_Species_to_plot_array = [ii_PKA_on];

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  END: PLoS Comp. Bio. Paper parameters
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

    
    signal_average_bPAC_cluster_array = zeros(length(time_mean),length(ii_Species_to_plot_array));    
      if (do_ALL_bPAC == 0)
       signal_average_non_bPAC_cluster_array = zeros(length(time_mean),length(ii_Species_to_plot_array));
       signal_average_non_bPAC_cluster_inner_array = zeros(length(time_mean),length(ii_Species_to_plot_array));
       signal_average_non_bPAC_cluster_outer_array = zeros(length(time_mean),length(ii_Species_to_plot_array));
      end;
    
    
 for ii_plot = 1:length(ii_Species_to_plot_array)
     
     ii_Species_to_plot = ii_Species_to_plot_array(ii_plot)
     
      if (ii_Species_to_plot == ii_cAMP)
          str_Species_to_plot = 'cAMP';
      elseif (ii_Species_to_plot == ii_PKA_on)
          str_Species_to_plot = 'PKA';
      elseif (ii_Species_to_plot == ii_PDE_on)
          str_Species_to_plot = 'PDE (fb on)';
      elseif (ii_Species_to_plot == ii_ERK_on)
          str_Species_to_plot = 'ERK (active)';
      elseif (ii_Species_to_plot == ii_ERK_off)
          str_Species_to_plot = 'ERK (inactive)';
      elseif (ii_Species_to_plot == ii_ERKKTR_n)
          str_Species_to_plot = 'ERK-KTR_n';
      elseif (ii_Species_to_plot == ii_GJ_complex_on)
          str_Species_to_plot = 'GJ (act. membrane)';
      elseif (do_GJ2 == 1)
          if (ii_Species_to_plot == ii_GJ2_complex_on)
          str_Species_to_plot = 'GJ2 (act. membrane)';
          end;
      end;


      
      
   if (do_ALL_bPAC == 0)  % emitter/receiver tissue   
    if (do_propagation_delay == 0)   
     plot_spatially_averaged_signals
    else (do_propagation_delay == 1)
       %index_propagation_line_image = [5 13 24 31];
       index_propagation_line_image = [13 24 31];
       index_propagation_emitter_image = [41];
       sig_propagation_line = zeros(length(time_mean),length(index_propagation_line_image),length(ii_Species_to_plot_array));
     plot_spatially_averaged_signals_propagation
    end;
     signal_average_bPAC_cluster_array(:,ii_plot) =  signal_average_bPAC_cluster;
     signal_average_non_bPAC_cluster_array(:,ii_plot) = signal_average_non_bPAC_cluster;
     signal_average_non_bPAC_cluster_inner_array(:,ii_plot) = signal_average_non_bPAC_cluster_inner;
     signal_average_non_bPAC_cluster_outer_array(:,ii_plot) = signal_average_non_bPAC_cluster_outer;
   elseif (do_ALL_bPAC == 1)  % all emitter tissue 
    plot_averaged_signals
    signal_average_bPAC_cluster_array(:,ii_plot) =  signal_average_bPAC_cluster; 
   end;
    if (do_parameter_sweep == 0)
     pause;
    end;
   close all;
   
 end; % for ii_plot = 1:length(ii_Specties_to_plot_array)

if (min(abs(ii_Species_to_plot_array - ii_cAMP)) == 0)&(min(abs(ii_Species_to_plot_array - ii_ERKKTR_n)) == 0)
  plot_compare_normalized_average_signals
elseif (min(abs(ii_Species_to_plot_array - ii_ERKKTR_n)) == 0)&(do_propagation_delay == 1)
  plot_compare_normalized_average_signals_propagation
end;
 if (do_parameter_sweep == 1)
  close all
 end;

end; 

       count_parameter_sweep = count_parameter_sweep+1; %increase sweep variable by 1
    
end; % while (count_parameter_sweep <= count_parameter_sweep_max)        

    
