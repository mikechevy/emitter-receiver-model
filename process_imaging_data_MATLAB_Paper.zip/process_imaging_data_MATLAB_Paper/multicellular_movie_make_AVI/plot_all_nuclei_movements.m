
  




   x_coord_min =  1;
   x_coord_max =  xLength;
   y_coord_min =  1;
   y_coord_max =  yLength;




for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)

  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus);
  
  M_marker_threshold = M_NM_threshold_FILL;
   



figure(1)
imagesc(M_marker_threshold);
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr)));
   hold on;                 
    for idx = 1:num_nuclei_t0
       
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
       
       
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
             
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)),'TextColor','w');                    
             %tt =  text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t0:',num2str(idx)));                   
             %set(tt,'Color','y');
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

    %pause(1.0)
        
end;  % end of  'for kkk = 1:length(which_frames)





             
             
