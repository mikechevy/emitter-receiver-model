%if (count_clusters>0)
%    
%  size_bPAC_clusters = size_bPAC_clusters(1:count_clusters);
%  bPAC_clusters = bPAC_clusters(1:count_clusters,1:max(size_bPAC_clusters));
%    bPAC_clusters = [];
%    size_bPAC_clusters = [];
%end;
%size_non_bPAC_clusters = size_non_bPAC_clusters(1:count_clusters);
%non_bPAC_clusters = non_bPAC_clusters(1:count_clusters, 1:max(size_non_bPAC_clusters));
%non_bPAC_clusters
%size_non_bPAC_clusters
%bPAC_clusters_location = 0*bPAC_clusters;  % outside bPAC cells
%     if (num_adjacent_non_bPAC>=2)
%         bPAC_clusters_location(jjj,iii) = 1;
%     end;

do_BF_channel = 0;  % when making images: 0-no (use ERK-KTR), 1-yes (use BF) 

do_full_range_ylim = 0;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own
do_shift_signals_to_zero_first_pulse = 0; % 0 - no , 1 - yes

do_SIGMA = 0;   % 1- do zero-shifted mean and standard deviation version, 0 - don't

num_plot_single_pulse = 0;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_shift_plot_single_pulse = 0;
time_begin_plot_single_pulse = 0;
time_end_plot_single_pulse = 0;

num_cells_no_sig = 0;  % cell 37 on the second pulse

do_average_non_bPAC_inner = 1;  % 1- average (total signal dived by number of cells) , 0 - total signal (integral)
  non_bPAC_clusters_outer = [];
  non_bPAC_clusters_inner = [];
  
  size_bPAC_clusters = [];
  size_non_bPAC_clusters = [];
  
num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_begin_plot_single_pulse = 0;
time_end_plot_single_pulse = 120;
  
  
  
if which_movie == 47 % '190326_198-117_207-61_TEST_MC';
    
    count_clusters = 2;
    bPAC_clusters = [21; 67];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    size_bPAC_clusters = [1;1];

    
    non_bPAC_clusters_inner = [13 18 22 25 28 30 0 0 0; 62 53 55 61 69 81 89 80 70];
    %non_bPAC_clusters_outer = [31 46 45 36 26 29];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    %size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    size_non_bPAC_clusters = [6;9];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;
    
elseif  (which_movie == 60) % '190625_198-117_198_TEST'
     
    count_clusters = 1;
    bPAC_clusters = [37];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    
    non_bPAC_clusters_inner = [26 28 33 36 38 42 47];
    non_bPAC_clusters_outer = [];
    %non_bPAC_clusters_outer = [31 46 45 36 26 29];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 65) % '190716_198-117_198_TEST'
     
    count_clusters = 1;
    bPAC_clusters = [32];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    
    non_bPAC_clusters_inner = [35 42 28 20 21];
    non_bPAC_clusters_outer = [];
    %non_bPAC_clusters_outer = [31 46 45 36 26 29];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
 do_full_range_ylim = 1;   
    
 elseif  (which_movie == 66) % '190726_198-117_198_TEST_MC'
     
    count_clusters = 2;
    bPAC_clusters = [19;40];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1];

    
    non_bPAC_clusters_inner = [13 14 18 21 27 29 30; 31 37 39 44 50 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
    size_non_bPAC_clusters = [7;5];
%do_average_non_bPAC_inner = 0;  % 1- average (total signal dived by number of cells) , 0 - total signal (integral)
    
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
 do_full_range_ylim = 1;   
    
 elseif  (which_movie == 68) % '190730_198-117_198_TEST_MC'

    count_clusters = 2;
    bPAC_clusters = [15 0 0;30 33 38];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;3];
 
    
    non_bPAC_clusters_inner = [10 11 12 19 20 25; 24 27 28 29 34 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
    size_non_bPAC_clusters = [6;5];
         
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
 do_full_range_ylim = 1;   
     
 elseif  (which_movie == 81) % '190823_198-117_198_TEST_MC_2'

    count_clusters = 1;
    bPAC_clusters = [39];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    
    non_bPAC_clusters_inner = [24 32 36];
    non_bPAC_clusters_outer = [];
    %non_bPAC_clusters_inner = [34 36 47 48 50];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    

     
do_full_range_ylim = 0;
do_shift_signals_to_zero_first_pulse = 1; % 0 - no , 1 - yes
     
 elseif  (which_movie == 91) % '190910_198-117_198_TEST_MC'
     
    count_clusters = 1;
    bPAC_clusters = [32];
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [20 29 35 38 41];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)

    bPAC_that_are_non_bPAC = [29];    
    for iii_change = 1:length(bPAC_that_are_non_bPAC)
    bPAC_NUCLEUS_time_mapped_t0(bPAC_that_are_non_bPAC(iii_change),:) = 1;    
    end;    
    non_bPAC_that_are_bPAC = [];    
    for iii_change = 1:length(non_bPAC_that_are_bPAC)
    bPAC_NUCLEUS_time_mapped_t0(non_bPAC_that_are_bPAC(iii_change),:) = 0;    
    end;    
    
    
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

 elseif  (which_movie == 93) % '190912_198-117_198_TEST_MC'

    count_clusters = 1;
    bPAC_clusters = [4 26 28; 43 0 0];
    size_bPAC_clusters = [3;1];

    non_bPAC_clusters_inner = [20 22 27 30 35 38 39; 33 36 41 47 48 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7;5];
    
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)

    bPAC_that_are_non_bPAC = [];    
    for iii_change = 1:length(bPAC_that_are_non_bPAC)
    bPAC_NUCLEUS_time_mapped_t0(bPAC_that_are_non_bPAC(iii_change),:) = 1;    
    end;    
    non_bPAC_that_are_bPAC = [];    
    for iii_change = 1:length(non_bPAC_that_are_bPAC)
    bPAC_NUCLEUS_time_mapped_t0(non_bPAC_that_are_bPAC(iii_change),:) = 0;    
    end;    
    
    
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

    do_full_range_ylim = 1;
     
     
 elseif  (which_movie == 94) % '190912_198-117_198_TEST_MC_2'

    count_clusters = 1;
    bPAC_clusters = [31];
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [20 26 33 38 40];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)

    bPAC_that_are_non_bPAC = [];    
    for iii_change = 1:length(bPAC_that_are_non_bPAC)
    bPAC_NUCLEUS_time_mapped_t0(bPAC_that_are_non_bPAC(iii_change),:) = 1;    
    end;    
    non_bPAC_that_are_bPAC = [];    
    for iii_change = 1:length(non_bPAC_that_are_bPAC)
    bPAC_NUCLEUS_time_mapped_t0(non_bPAC_that_are_bPAC(iii_change),:) = 0;    
    end;    
    
    
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

    do_full_range_ylim = 1;
     
     
 elseif  (which_movie == 140) % '191213_198-117_198_MC_p23'
     
    count_clusters = 0;
    bPAC_clusters = [24;59;63];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1;1];

    non_bPAC_clusters_inner = [8 14 15 16 21 28 29 36; 53 57 58 72 0 0 0 0; 56 64 65 0 0 0 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [8;4;3];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;
    
 elseif  (which_movie == 141) % '191213_198-117_198_MC_p23_2'
     
    count_clusters = 0;
    bPAC_clusters = [42];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [32 38 40 46 48 54];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
do_full_range_ylim = 1;
    
 elseif  (which_movie == 142) % '191217_198-117_198_MC_p26'
     
    count_clusters = 0;
    bPAC_clusters = [28];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    %non_bPAC_clusters_inner = [23 25 26 30 39 40 41];
    non_bPAC_clusters_inner = [22 23 26 30 39 40 41];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
    
do_full_range_ylim = 1;

 elseif  (which_movie == 143) % '191217_198-117_198_MC_p26_2'
     
    count_clusters = 0;
    bPAC_clusters = [29];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [24 25 26 34 35 36 40 41 44];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
    
do_full_range_ylim = 1;
    


 elseif (which_movie == 155)  %  str_movie = '200213_198-117_198_MC_H89';    
    
    count_clusters = 0;
    %bPAC_clusters = [12 15 22 23  29 37 44 34 36 41 45];
    bPAC_clusters = [12 15 23  29 37 44 34 36 41 45];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [5 17 10 20 31 26 28 33 42 46 43 30 32 35 39 40];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    

    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    
    
    do_SIGMA = 1;   % 1- do zero-shifted mean and standard deviation version, 0 - don't


    
 elseif (which_movie == 157)  %  str_movie = '200528_198-117_198';    
    
    count_clusters = 0;
    bPAC_clusters = [39 46];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [31 34 35 40 47 52 56];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    

    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    
    
    
    
    
   elseif  (which_movie == 211) % '200802_198-117_198-70_2'
     
    count_clusters = 0;
    bPAC_clusters = [47 53];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [35 36 44 45 48 52 57 60 61];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
    
do_full_range_ylim = 1;
  

   elseif  (which_movie == 234) % '200820_198-117_198-70_3'
     
    count_clusters = 0;
    bPAC_clusters = [20 26];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [9 14 15 18 24 25 28 33 36 37 42 50];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
    
do_full_range_ylim = 1;


   elseif  (which_movie == 246) % '200917_198-117_207-117_1'
     
    count_clusters = 0;
    bPAC_clusters = [50 53];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [40 44 51 52 59 60 63];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
    
do_full_range_ylim = 1;


   elseif  (which_movie == 247) % '200917_198-117_207-117_2'
     
    count_clusters = 0;
    bPAC_clusters = [58 69];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [51 52 53 65 71 75 76];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
    
do_full_range_ylim = 1;



 elseif  (which_movie == 258) % '201011_198-117_198_1_I150uM'
     
    count_clusters = 0;
    bPAC_clusters = [18 21 28 29;44 0 0 0];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [4;1];

    non_bPAC_clusters_inner = [9 10 14 15 19 24 26 33 34 35; 37 38 40 43 45 47 49 57 49 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [10;8];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


 elseif  (which_movie == 259) % '201011_198-117_198_2_I150uM'
     
    count_clusters = 0;
    bPAC_clusters = [23 0;41 43];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;2];

    non_bPAC_clusters_inner = [9 12 19 22 25 28 33 0; 33 35 38 45 48 49 50 51];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7;8];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;



 elseif  (which_movie == 260) % '201018_198-117_198_1_I100uM'
     
    count_clusters = 0;
    bPAC_clusters = [19 0;30 0; 43 50];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1;2];

    non_bPAC_clusters_inner = [9 14 15 22 27 0; 20 24 36 38 41 0;42 44 47 52 54 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5;5;5];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


 elseif  (which_movie == 261) % '201018_198-117_198_2_I100uM'
     
    count_clusters = 0;
    bPAC_clusters = [21 0;45 52; 48 0];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;2;1];

    non_bPAC_clusters_inner = [6 8 13 20 26 29 0; 37 38 47 49 53 62 0; 39 44 54 55 0 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [6;6;4];
    
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_shift_plot_single_pulse = 0;
time_begin_plot_single_pulse = 0;
time_end_plot_single_pulse = 120;

 elseif  (which_movie == 265) % '201210_198-117_207-61_4'
     
    count_clusters = 0;
    bPAC_clusters = [13 0 0 0 0;39 43 49 52 59];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;5];

    non_bPAC_clusters_inner = [8 11 16 17 23 24; 29 34 37 44 51 60];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [6;6];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

elseif  (which_movie == 266) % '201210_198-117_207-61_5_same_cells'
     
    count_clusters = 0;
    bPAC_clusters = [14 0 0 0 0;33 34 39 44 52];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;5];

    non_bPAC_clusters_inner = [6 8 10 18 19 23 24; 25 26 27 36 43 49 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7;6];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 267) % '201213_198-117_207-61_1'
     
    count_clusters = 0;
    bPAC_clusters = [8;58];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1];

    non_bPAC_clusters_inner = [1 4 10 12 17;48 51 54 59 67];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5;5];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 268) % '201213_198-117_207-61_3'
     
    count_clusters = 0;
    bPAC_clusters = [25 27 34;49 0 0];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [3;1];

    non_bPAC_clusters_inner = [19 21 22 29 31 32 36 38;32 46 55 56 58 0 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [8;5];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 269) % '201213_198-117_207-61_4'
     
    count_clusters = 0;
    bPAC_clusters = [42];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [30 31 39 40 43 46 51];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 270) % '201217_198-117_207-61_1'
     
    count_clusters = 0;
    bPAC_clusters = [9 0; 25 26];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;2];

    non_bPAC_clusters_inner = [6 8 10 11 0 0 0; 21 23 24 30 33 34 35];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [4:7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 271) % '201217_198-117_207-61_2'
     
    count_clusters = 0;
    bPAC_clusters = [40 45 50 52];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [4];

    non_bPAC_clusters_inner = [33 39 42 46 49];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 272) % '201220_198-117_MDCKII_2'
     
    count_clusters = 0;
    bPAC_clusters = [4 5 13 17];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [4];

    non_bPAC_clusters_inner = [6 7 9 10 12 14 19];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 273) % '201220_198-117_MDCKII_3'
     
    count_clusters = 0;
    bPAC_clusters = [3 4 5 6 7 8 11 13 15 16 19 20 21 24];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [13];

    non_bPAC_clusters_inner = [9 10 12 14 22];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 274) % '201220_198-117_MDCKII_4_samecells'
     
    count_clusters = 0;
    bPAC_clusters = [4 5 7 8 9 10 12 13 14 19 24];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [11];

    non_bPAC_clusters_inner = [6 11 15 17 18 21 22 29];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [8];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 275) % '201224_198-117_MDCKII_4'
     
    count_clusters = 0;
    bPAC_clusters = [8 0 0 0 0 0 0 0; 27 0 0 0 0 0 0 0;17 20 21 25 26 29 31 34];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1;8];

    non_bPAC_clusters_inner = [1 4 6 10 12 0 0 0 ;13 15 24 33 0 0 0 0;9 11 19 22 28 32 35 39];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5; 4; 8];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 276) % '201224_198-117_MDCKII_5'
     
    count_clusters = 0;
    bPAC_clusters = [13];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [10 11 14 18];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [4];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 277) % '201227_198-117_MDCKII_2'
     
    count_clusters = 0;
    bPAC_clusters = [30];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [26 29];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [2];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 278) % '201227_198-117_MDCKII_3'
     
    count_clusters = 0;
    bPAC_clusters = [23];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [22 26 27];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [3];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 279) % '201227_198-117_MDCKII_9'
     
    count_clusters = 0;
    bPAC_clusters = [17];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [11 12 15 20 21 22];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [6];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    
    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    

do_full_range_ylim = 1;


elseif  (which_movie == 280) % '201231_198-117_MDCKII_3'
     
    count_clusters = 0;
    bPAC_clusters = [8 14 15 16 17 24 25 28 29 32 33 35 36];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [13];

    non_bPAC_clusters_inner = [3 4 6 10 12 20 23 26 30 34 37 39];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [12];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 281) % '201231_198-117_MDCKII_9'
     
    count_clusters = 0;
    bPAC_clusters = [46 48;57 0];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [2;1];

    non_bPAC_clusters_inner = [38 40 43 49 51 54 55 59;47 50 52 53 63 70 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [8;6];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 282) % '210103_198-117_MDCKII_4'
     

    count_clusters = 0;
    bPAC_clusters = [22 23 26 28 29];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [5];

    non_bPAC_clusters_inner = [11 13 31 32 19 20 21 25 35 37 38];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [11];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    

    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*7.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*2.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    
    
    
do_full_range_ylim = 1;

elseif  (which_movie == 284) % '210211_198-117_MDCKII_1'
     


    count_clusters = 0;
    bPAC_clusters = [27];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [15 19 20 21 25 26 28 29 30 35];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [10];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 285) % '210211_198-117_MDCKII_2'
     


    count_clusters = 0;
    bPAC_clusters = [22; 23];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1];

    non_bPAC_clusters_inner = [16 18 20 21 27 0 0; 17 19 24 25 29 33 35];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5;7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 286) % '210211_198-117_MDCKII_3'
     


    count_clusters = 0;
    bPAC_clusters = [15];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [5 10 12 14 20 24];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [6];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 287) % '210214_198-117_MDCKII_2'
     
    count_clusters = 0;
    bPAC_clusters = [30];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [20 21 25 28 33 34 39 43];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [8];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 288) % '210221_198-117_MDCKII_4'
     
    count_clusters = 0;
    bPAC_clusters = [35];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [27 32 36 41 42];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [5];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 289) % '210221_198-117_MDCKII_5'
     
    count_clusters = 0;
    bPAC_clusters = [37];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [27 27 29 30 34 35 40 42 43 47 48];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [11];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;



elseif  (which_movie == 291) % '210304_198-117_207_1'
     
    count_clusters = 0;
    bPAC_clusters = [57];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [45 49 55 60 61 67 69 71 73];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [9];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 292) % '210304_198-117_207_2'
     
    count_clusters = 0;
    bPAC_clusters = [20 ; 65 ];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1;1];

    non_bPAC_clusters_inner = [3 4 12 14 18 24 25 38; 52 58 64 70 0 0 0 0];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [8;4];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif  (which_movie == 293) % '210304_198-117_207_3'

    count_clusters = 0;
    bPAC_clusters = [54];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [41 44 50 53 61 62 66];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;
    

elseif  (which_movie == 296) % '210314_198-117_198_1'
     

     
    count_clusters = 0;
    bPAC_clusters = [34];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [29 31];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [2];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 0;
do_shift_signals_to_zero_first_pulse = 0; % 0 - no , 1 - yes


elseif  (which_movie == 297) % '210314_198-117_198_2'
     
    count_clusters = 0;
    bPAC_clusters = [36 41 42 43 48 53 58];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [7];

    non_bPAC_clusters_inner = [26 30 31 34 37 38 40 45 50 52 54 55 62 71];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [14];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 298) % '210318_198-117_198_1'
     
    count_clusters = 0;
    bPAC_clusters = [60 51 57 67];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [4];

    non_bPAC_clusters_inner = [42 46 47 54 62 63 66 73 74];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [9];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 299) % '210318_198-117_198_2'
     
    count_clusters = 0;
    bPAC_clusters = [25 26 33 54 60 68];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [6];

    non_bPAC_clusters_inner = [16 17 18 22 24 29 32 34 45 47 58 59 69 71 79];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [15];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 300) % '210321_198-117_198_2'
     
    count_clusters = 0;
    bPAC_clusters = [54];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [1];

    non_bPAC_clusters_inner = [40 43 47 57 58 63 65 68 69];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [9];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


elseif  (which_movie == 301) % '210321_198-117_198_3'
     
    count_clusters = 0;
    bPAC_clusters = [35 42];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [2];

    non_bPAC_clusters_inner = [25 26 28 37 44 45 48];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;

elseif (which_movie == 317)  % '210727_198-117_MDCKII_1_I1000uM' 

    count_clusters = 0;
    bPAC_clusters = [16 17 21 22 23 24 25 28 32];
     %bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [9];

    non_bPAC_clusters_inner = [14 15 18 26 27 29 30 34 36];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     %non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [9];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

do_full_range_ylim = 1;


  elseif (which_movie == 399) % '050316_mwc_198_198-117_IBMX_1.5'
     
    count_clusters = 1;
    bPAC_clusters = [30 35];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    
    non_bPAC_clusters_inner = [22 24 28 39 42 43];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 2.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_begin_plot_single_pulse = 90;
time_end_plot_single_pulse = 200;
    
do_full_range_ylim = 1;    

  elseif (which_movie == 400) % '031416_mwc_198_198-117_same'
     
    count_clusters = 1;
   % bPAC_clusters = [19 26 29 39 43 47 50 54];  % new
    bPAC_clusters = [19 26 29 39 43 47 50 54];  % OLD
    
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);    
    %non_bPAC_clusters_inner = [13 16 21 28 30 36 37 40 53 57 58]; % new
    non_bPAC_clusters_inner = [13 16 21 22 25 28 30 36 37 40 55 57 61 64];  % OLD
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    %scale_Erk_channel = 0*1.0;  % for RGB image of 3 channels
    %scale_NM_channel = 5.0;  % for RGB image of 3 channels
    %scale_NM_bPAC_channel = 5.0;  % for RGB image of 3 channels

    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    
    
num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_begin_plot_single_pulse = 90;
time_end_plot_single_pulse = 200;
    
do_full_range_ylim = 1;    

do_BF_channel = 0;
    scale_BF_channel = 10.00;  % for RGB image of 3 channels
   
     
 elseif (which_movie == 401) % '160902_198_198-117_EA'
     
    count_clusters = 1;
    bPAC_clusters = [28];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);
    
    non_bPAC_clusters_inner = [37 43]; % submit
        non_bPAC_clusters_inner = [ 16 22 23 29 30]; % submit
    non_bPAC_clusters_outer = [];
    %non_bPAC_clusters_outer = [ 10 15 24 25 34 42 43];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels

num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_begin_plot_single_pulse = 0;
time_end_plot_single_pulse = 120;
%time_begin_plot_single_pulse = 90;
%time_end_plot_single_pulse = 200;


do_full_range_ylim = 1;    

do_BF_channel = 0;  % when making images: 0-no (use ERK-KTR), 1-yes (use BF) 
    scale_BF_channel = 1.00;  % for RGB image of 3 channels


 elseif (which_movie == 402) % '160905_198_198-117_JP'
     
    count_clusters = 1;
    bPAC_clusters = [36 46 49 51 55; 61 0 0 0 0];
    % bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [5;1];
    %bPAC_clusters = [36 46 49 51 55];
    %size_bPAC_clusters = [5];
    
    non_bPAC_clusters_inner = [ 31 32 40 41 52 68 59; 45 47 53 58 64 66 0];
    %non_bPAC_clusters_inner = [ 31 32 40 41 52 68 59];
    non_bPAC_clusters_outer = [];
    %non_bPAC_clusters_outer = [ 10 15 24 25 34 42 43];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     % non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [7;6];
    %size_non_bPAC_clusters = [7];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*5.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels

num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_begin_plot_single_pulse = 90;
time_end_plot_single_pulse = 200;
    
do_full_range_ylim = 1;    

do_BF_channel = 0;  % when making images: 0-no (use ERK-KTR), 1-yes (use BF) 
    scale_BF_channel = 1.00;  % for RGB image of 3 channels

    
    
 elseif which_movie == 410  % '042216_mwc_198_198-117_CBX_1' where CBX is carbonoxolone
     
     
    count_clusters = 1;
    bPAC_clusters = [10 15 18 21 22 25 29 35 36 40 45];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = [11];
    
    non_bPAC_clusters_inner = [2 6 11 14 17 19 24 26 27 31 32 33 44];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [13];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    fac_all_channels = 2.0;
    scale_Erk_channel = fac_all_channels*3.0;  % for RGB image of 3 channels
    scale_NM_channel = fac_all_channels*1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = fac_all_channels*1.0;  % for RGB image of 3 channels

num_plot_single_pulse = 1;  % allows to zoom in on a single pulse to plot and make an .eps for 
time_begin_plot_single_pulse = 90;
time_end_plot_single_pulse = 200;
    
do_full_range_ylim = 1;    

do_BF_channel = 0;  % when making images: 0-no (use ERK-KTR), 1-yes (use BF) 
    scale_BF_channel = 1.00;  % for RGB image of 3 channels
    
do_SIGMA = 1;   % 1- do zero-shifted mean and standard deviation version, 0 - don't
    
    
    
elseif (which_movie == 79) % '190822_198-117_198_TEST_MC_BrA_2';    

    count_clusters = 1;
    bPAC_clusters = [49];
     bPAC_clusters = sort(bPAC_clusters);
    size_bPAC_clusters = length(bPAC_clusters);

    non_bPAC_clusters_inner = [41 44 45 51 56 57 46];
    non_bPAC_clusters_outer = [];
    non_bPAC_clusters = [non_bPAC_clusters_inner non_bPAC_clusters_outer];
     non_bPAC_clusters = sort(non_bPAC_clusters);
    size_non_bPAC_clusters = [length(non_bPAC_clusters)];
    
    bPAC_clusters_location = 0*bPAC_clusters + 1;  %  (0 - inner, 1 - outer)
    
    scale_Erk_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
    
elseif (which_movie == -1)
end;
  
