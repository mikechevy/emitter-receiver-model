
                 x_coord_min = 380;
                 x_coord_max = 550;
                 y_coord_min = 800;
                 y_coord_max = 940;
                 
                 %x_coord_min = 1;
                 %x_coord_max = xLength;
                 %y_coord_min = 1;
                 %y_coord_max = yLength;

%index_group = [];               
ii_count = 0;
index_group = [];
for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
    end;
end;
                 

for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)

 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
M_marker_threshold_TEST = 0*M_marker_threshold;

 for jjj = 1:length(index_group);
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_DAPI_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end;

figure(2)
imagesc(M_marker_threshold_TEST)
title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr)));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
       
            if (idx_map > 0)
              %text(mean_y_tot_DAPI(idx_map)-sqrt(var_y_tot_DAPI(idx_map)),mean_x_tot_DAPI(idx_map)-0*sqrt(var_x_tot_DAPI(idx_map)),strcat('t',num2str(which_frame-1),':',num2str(idx_map),', t0:',num2str(idx)));                    
              text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('t0:',num2str(idx)));                    
            end;        
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

    
end;  % end of  'for kkk = 1:length(which_frames)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plot the signals of the cells within the box
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    num_plots_max = 3;
    ii_figure_count = 1;
    ii_plot_count = 0;
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
     figure(1000+ii_figure_count)  
     title('nuclear FITC signal');
     subplot(num_plots_max,1,ii_plot_count+1) 
     plot(which_frames,nuclear_FITC_tot_time_mapped_t0(idx,:));
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');

     figure(2000+ii_figure_count)  
     title('nuclear CY3 signal');
     subplot(num_plots_max,1,ii_plot_count+1) 
     plot(which_frames,nuclear_CY3_tot_time_mapped_t0(idx,:));
     ylabel(strcat('cell:',num2str(idx)));
     xlabel('number of frames');
     
     
     ii_plot_count = ii_plot_count+1;
     if (ii_plot_count == num_plots_max)
         ii_figure_count = ii_figure_count+1;
         ii_plot_count = 0;
     end;
         
    end    



