function [mean_x_tot,mean_y_tot,var_x_tot,var_y_tot,cov_xy_tot,box_coords,num_pixels_tot,num_nuclei,M_marker_threshold,M_marker_id_threshold,M_marker_threshold_FILL,Cell_marker_FILL,threshold] = determine_nuclear_locations_adaptive_recursive(M_marker,which_frame,xLength,yLength, nucleus_min_pixels,M_FITC,M_CY3,do_threshold_fac_adjust)

global numFr;
global ii_xcorr;
global ii_physical_distance;
global length_per_pixel;
global fac_std_nuclear_size;
global num_throwout_max;
global num_throwout;


   max_max_M_marker = max(max(M_marker));
   min_min_M_marker = min(min(M_marker));
   M_marker_NORMALIZED = double(M_marker-min_min_M_marker)/double(max_max_M_marker-min_min_M_marker);
         %set the image boundaroes to zero
      M_marker_NORMALIZED(1:xLength,yLength:yLength) = 0;
      M_marker_NORMALIZED(1:xLength,1:1) = 0;
      M_marker_NORMALIZED(xLength:xLength,1:yLength) = 0;
      M_marker_NORMALIZED(1:1,1:yLength) = 0;
      

   
  do_threshold_matrix = 1;  %  1 - yes, 0 - no
  if  (do_threshold_matrix == 0)
    %  Standard method once we get it working
    threshold = determine_object_threshold(M_marker_NORMALIZED,xLength,yLength)    
    M_marker_threshold = im2bw(M_marker_NORMALIZED,threshold);   % convert to binary image
  elseif  (do_threshold_matrix == 1)
    threshold_matrix = determine_object_threshold_matrix(M_marker_NORMALIZED,xLength,yLength,do_threshold_fac_adjust);
    M_marker_threshold = im2bw(max(M_marker_NORMALIZED,threshold_matrix)-threshold_matrix,0);
    threshold = mean(mean(threshold_matrix));
  end;  
    
    M_marker_threshold_TEST = 0*M_marker_threshold;

    %  very fast segmentation (07/15/15,  MIKE maybe try this out later)
    M_marker_threshold_FILL = bwareaopen(M_marker_threshold, nucleus_min_pixels);  % removie 
    M_marker_threshold_FILL = imfill(M_marker_threshold_FILL,'holes');    
    Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    num_nuclei = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));
    M_marker_id_threshold = 0*M_marker_threshold;     
    for idx = 1:num_nuclei
       M_marker_id_threshold(Cell_marker_FILL.PixelIdxList{idx}) = idx;
    end;
  
    
      
num_nuclei
 
num_pixels_tot = zeros(num_nuclei,1);
nuclear_outliers = zeros(num_nuclei,1);
box_coords = zeros(num_nuclei,4);
        box_coords(:,1) = xLength+1;  %x_min
        box_coords(:,2) = 0;  %x_max
        box_coords(:,3) = yLength+1;  %y_min
        box_coords(:,4) = 0;  %y_max
        
for ii = 1:xLength    
    for jj = 1:yLength
         val_dummy = M_marker_id_threshold(ii,jj);
        if (val_dummy > 0)
            num_pixels_tot(val_dummy) = num_pixels_tot(val_dummy) + 1;            
            if (box_coords(val_dummy,1) > ii)
                box_coords(val_dummy,1) = ii;
            end;
            if (box_coords(val_dummy,2) < ii)
                box_coords(val_dummy,2) = ii;
            end;
            if (box_coords(val_dummy,3) > jj)
                box_coords(val_dummy,3) = jj;
            end;
            if (box_coords(val_dummy,4) < jj)
                box_coords(val_dummy,4) = jj;
            end;
        end;
    end;
end;



  %Determine mean and stanard deviation of nuclear sizes, throwing out the
  % clusters that were'nt thresholded properly.  The variable 'num_throwout' is set in
  % set_globals
 
  %  Throws out a small percentage of outliers, HEURISTIC
  num_throwout = min(num_throwout_max,floor(num_nuclei/4));
  num_pixels_tot_sort = sort(num_pixels_tot);
  mean_pix = mean(num_pixels_tot_sort(1:num_nuclei-num_throwout));
  std_pix =  std(num_pixels_tot_sort(1:num_nuclei-num_throwout));
                
  num_pixels_max =    mean_pix + fac_std_nuclear_size*std_pix





               do_plot_boxes = 1; % 1 - yes, 0 - no
               if (do_plot_boxes == 1)
                   
      
                 [N_pix,X_pix] = hist(num_pixels_tot,round(num_nuclei/10));
                figure(111)
                imagesc(M_marker_threshold_FILL);
                title('nucleus outliers');
                          for which_nucleus = 1:num_nuclei
                            if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
                                 nuclear_outliers(which_nucleus) = 1;
                                x_coord_min = box_coords(which_nucleus,1);
                                x_coord_max = box_coords(which_nucleus,2);
                                y_coord_min = box_coords(which_nucleus,3);
                                y_coord_max = box_coords(which_nucleus,4); 
                            rectangle('Position', [y_coord_min,x_coord_min,...
                                 y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                                       'EdgeColor', 'm');
                             text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
                            end;
                          end;
                  figure(112)
                  close(112);
                  figure(112)
                  hold on;
                  plot(X_pix,N_pix);
                  plot([mean_pix mean_pix],[0 max(N_pix)],'k--');
                  plot([mean_pix+std_pix mean_pix+std_pix],[0 max(N_pix)],'k--');
                  plot([mean_pix-std_pix mean_pix-std_pix],[0 max(N_pix)],'k--');
                  xlabel('number of pixes');
                  ylabel('p(pixesl');
                  title('distribution of nuclear size');
                  hold off;
                    sum(nuclear_outliers)
                    num_nuclei
                  %pause;
               end;


num_nuclei_pre_separate = num_nuclei;
box_coords_pre_separate = box_coords;
num_pixels_tot_pre_separate = num_pixels_tot;    


  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  setup parameters for criteria of determinering of nucleus needs to be
  %  tested for being a cluster of nuclei.  The parameter 'num_throwout' is
  %  set in 'set_globals.m'
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  num_pixels_tot_sort = sort(num_pixels_tot);
  mean_pix = mean(num_pixels_tot_sort(1:num_nuclei-num_throwout));
  std_pix =  std(num_pixels_tot_sort(1:num_nuclei-num_throwout));

               if (num_pixels_max < 0)
                std_pix = mean_pix/4;
                num_pixels_max =    mean_pix + fac_std_nuclear_size*std_pix
               end;
  
  
  
M_marker_threshold_out = 0*M_marker_threshold_FILL;
M_marker_threshold_TEST = 0*M_marker_threshold_TEST;
M_marker_TEST = 0*M_marker;

for which_nucleus = 1:num_nuclei

    
if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
    
    
                 x_coord_min = box_coords(which_nucleus,1);
                 x_coord_max = box_coords(which_nucleus,2);
                 y_coord_min = box_coords(which_nucleus,3);
                 y_coord_max = box_coords(which_nucleus,4); 
    
       M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = 0;
       M_marker_threshold_TEST(Cell_marker_FILL.PixelIdxList{which_nucleus}) = 1;      
       M_marker_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = M_marker(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*int16(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max));
       
  if  (do_threshold_matrix == 1)  % get threshold in the center of the box
    threshold = threshold_matrix(floor((box_coords(which_nucleus,1)+box_coords(which_nucleus,2))/2),floor((box_coords(which_nucleus,3)+box_coords(which_nucleus,4))/2));
  end;
  
M_marker_threshold_out(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = 0;
M_marker_threshold_out(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = separateTouchingNuclei_recursive_local(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max),M_marker_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max),box_coords(which_nucleus,:),threshold, nucleus_min_pixels,mean_pix,std_pix,min_min_M_marker,max_max_M_marker);

%verifyTouchingNuclei() %Use FITC and CY3 signals to verify that the separated touching nuclei, are individual nuclei

%update M_marker_threshold_FILL
%M_marker_threshold_FILL = M_marker_threshold_FILL - M_marker_threshold_TEST;
%M_marker_threshold_FILL = M_marker_threshold_FILL + M_marker_threshold_out;
M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) - M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max);
M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = M_marker_threshold_FILL(x_coord_min:x_coord_max,y_coord_min:y_coord_max) + M_marker_threshold_out(x_coord_min:x_coord_max,y_coord_min:y_coord_max);

                 do_plot_boxes_out = 0; % 1 - yes, 0 - no
                if (do_plot_boxes_out == 1)
                 figure(1111)
                 imagesc(M_marker_threshold_out); 
                 xlim([box_coords(which_nucleus,3) box_coords(which_nucleus,4)]);
                 ylim([box_coords(which_nucleus,1) box_coords(which_nucleus,2)]);
                 title('separated nuclei');
                           for which_nucleus_out = 1:num_nuclei_out
                                 x_coord_min = box_coords_out(which_nucleus_out,1);
                                 x_coord_max = box_coords_out(which_nucleus_out,2);
                                 y_coord_min = box_coords_out(which_nucleus_out,3);
                                 y_coord_max = box_coords_out(which_nucleus_out,4); 
                             rectangle('Position', [y_coord_min,x_coord_min,...
                                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                                        'EdgeColor', 'm');
                              text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus_out));
                           end;
                 figure(1112)
                 imagesc(M_marker_threshold_TEST);
                 xlim([box_coords(which_nucleus,3) box_coords(which_nucleus,4)]);
                 ylim([box_coords(which_nucleus,1) box_coords(which_nucleus,2)]);
                      pause
                 end;  % END OF:  if (do_plot_boxes_out == 1)

end; % END OF  if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
            
end;  % END OF:   for ii_nuclei = 1:num_nuclei


% update the Cell structure
M_marker_threshold_FILL = imfill(M_marker_threshold_FILL,'holes');    
Cell_marker_FILL = bwconncomp(M_marker_threshold_FILL);
    num_nuclei = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));
    M_marker_id_threshold = 0*M_marker_threshold;     
    for idx = 1:num_nuclei
       M_marker_id_threshold(Cell_marker_FILL.PixelIdxList{idx}) = idx;
    end;


mean_x_tot = zeros(num_nuclei,1);
mean_y_tot = zeros(num_nuclei,1);
var_x_tot = zeros(num_nuclei,1);
var_y_tot = zeros(num_nuclei,1);
cov_xy_tot = zeros(num_nuclei,1);
num_pixels_tot = zeros(num_nuclei,1);
nuclear_outliers = zeros(num_nuclei,1);
box_coords = zeros(num_nuclei,4);
        box_coords(:,1) = xLength+1;  %x_min
        box_coords(:,2) = 0;  %x_max
        box_coords(:,3) = yLength+1;  %y_min
        box_coords(:,4) = 0;  %y_max
   
        
for ii = 1:xLength    
    for jj = 1:yLength
         val_dummy = M_marker_id_threshold(ii,jj);
        if (val_dummy > 0)
            mean_x_tot(val_dummy) = mean_x_tot(val_dummy) + ii;
            mean_y_tot(val_dummy) = mean_y_tot(val_dummy) + jj;
            var_x_tot(val_dummy) = var_x_tot(val_dummy) + ii*ii;
            var_y_tot(val_dummy) = var_y_tot(val_dummy) + jj*jj;
            cov_xy_tot(val_dummy) = cov_xy_tot(val_dummy) + ii*jj;
            num_pixels_tot(val_dummy) = num_pixels_tot(val_dummy) + 1;            
            if (box_coords(val_dummy,1) > ii)
                box_coords(val_dummy,1) = ii;
            end;
            if (box_coords(val_dummy,2) < ii)
                box_coords(val_dummy,2) = ii;
            end;
            if (box_coords(val_dummy,3) > jj)
                box_coords(val_dummy,3) = jj;
            end;
            if (box_coords(val_dummy,4) < jj)
                box_coords(val_dummy,4) = jj;
            end;
        end;
    end;
end;

for ii = 1:num_nuclei
    mean_x_tot(ii) = mean_x_tot(ii)/num_pixels_tot(ii); 
    mean_y_tot(ii) = mean_y_tot(ii)/num_pixels_tot(ii); 
    var_x_tot(ii) = var_x_tot(ii)/num_pixels_tot(ii) - power(mean_x_tot(ii),2); 
    var_y_tot(ii) = var_y_tot(ii)/num_pixels_tot(ii) - power(mean_y_tot(ii),2); 
    cov_xy_tot(ii) = cov_xy_tot(ii)/num_pixels_tot(ii) - power(mean_x_tot(ii)*mean_y_tot(ii),1); 
end;


 do_plot_boxes = 0; % 1 - yes, 0 - no
if (do_plot_boxes == 1)
 figure(113)
 imagesc(M_marker_threshold_FILL);
 title('after functionSeparateNuclei');
           for which_nucleus = 1:num_nuclei_pre_separate
             if (num_pixels_tot_pre_separate(which_nucleus) > mean_pix + std_pix) 
                  nuclear_outliers(which_nucleus) = 1;
                 x_coord_min = box_coords_pre_separate(which_nucleus,1);
                 x_coord_max = box_coords_pre_separate(which_nucleus,2);
                 y_coord_min = box_coords_pre_separate(which_nucleus,3);
                 y_coord_max = box_coords_pre_separate(which_nucleus,4); 
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));
             end;
           end;
  mean_pix = mean(num_pixels_tot)
  std_pix =  std(num_pixels_tot);
  [N_pix,X_pix] = hist(num_pixels_tot,round(num_nuclei/10));
   figure(114)
   close(114);
   figure(114)
   hold on;
   plot(X_pix,N_pix);
   plot([mean_pix mean_pix],[0 max(N_pix)],'k--');
   plot([mean_pix+std_pix mean_pix+std_pix],[0 max(N_pix)],'k--');
   plot([mean_pix-std_pix mean_pix-std_pix],[0 max(N_pix)],'k--');
   xlabel('number of pixes');
   ylabel('p(pixesl');
   title('distribution of nuclear size after functionSeparateNuclei');
   hold off;           
    pause
end; % END OF: if (do_plot_boxes == 1)

num_nuclei_final = num_nuclei

%plot_thresholded_images
            %pause
             
  
    
