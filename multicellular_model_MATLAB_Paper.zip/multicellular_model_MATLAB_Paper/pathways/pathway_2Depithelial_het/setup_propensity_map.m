
%  INDEX MAP OF REACTIONS
%   1 - * -> reaction products
%   2 - S_j -> reaction products
%   3 - S_j + S_k -> reaction products (j~=k)
%   4 - 2 S_j -> reaction products
%   5 - S_i + S_j + S_k -> reaction products (i~=j~=k)
%   6 - S_j + 2 S_k -> (j~=k)
%   7 - 3 S_j
%   12 - (S_j0-S_j) -> reaction products, difference between inital value and current
%   13 - (S_j0-S_j)/2 -> reaction products, difference between inital value and current (dimer version)
%   20 - (S_k0/(S_k0+S_i))^2  2 S_j  - competition theory UPR, module 1
%   30 - S_i^n/(a0 + S_i^n)  - gene regulation function #1 (Hill function) Activation
%   31 - (S_i0-S_i)^2/(a0 + a1*(S_i0-S_i) + (S_i0-S_i)^2)  - gene regulation function #2
%   32 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #3, cooperativity: independent
%   33 - S_i*S_j/(a0 + a1*S_i +a2*S_j + S_i*S_j)  - gene regulation function #4, cooperativity: causal
%   34 -  gene regulation function, activator or repressor, depending on constants
%   40 - decay of species 1 due to species 2 (activation) dependent decay rate
%   41 - decay of species 1 due to species 2 (repression) dependent decay rate
%   50 - min((S_i0-S_i)/2, S_j)  - minimum of the two quantities represents the rate limiting step



num_prop_deriv1 = zeros(num_reactions,1);    
prop_deriv1_map = zeros(num_reactions,20);    

num_prop_deriv2 = zeros(num_reactions,1);    
prop_deriv2_map = zeros(num_reactions,20);    
    
for jj = 1:num_reactions
        
     if (reaction_type(jj)==1)  
%           reaction_constant(jj) = c_mu(jj);  % propensity
              % reaction_constant_dxi(jj,1) = 0; 
                 num_prop_deriv1(jj,1) = 0;    
                 prop_deriv1_map(jj,1) = 0;   % necessary for the mapping 
              % reaction_constant_dxi_dxj(jj,1) = 0; 
                 num_prop_deriv2(jj,1) = 0;    
                 prop_deriv2_map(jj,1) = 0;    
     elseif (reaction_type(jj)==2)
%            reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1));  % propensity
               % reaction_constant_dxi(jj,1) = c_mu(jj);  w.r.t. species 1;
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
               % reaction_constant_dxi_dxj(jj,1) = 0; 
                 num_prop_deriv2(jj,1) = 0;    
                 prop_deriv2_map(jj,1) = 0;    
     elseif (reaction_type(jj)==3)
%            reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2));  % propensity
%               reaction_constant_dxi(jj,1) = c_mu(jj)*x(reaction_molecules(jj,2));  w.r.t. species 1 
%               reaction_constant_dxi(jj,2) = c_mu(jj)*x(reaction_molecules(jj,1));  w.r.t. species 2 
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
%               reaction_constant_dxi_dxj(jj,1) = c_mu(jj);  w.r.t. species 1,2
                 num_prop_deriv2(jj,1) = 1;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,2);    
     elseif (reaction_type(jj)==4) 
%            reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*(x(reaction_molecules(jj,1))-1)/2;   % propensity
%               reaction_constant_dxi(jj,1) = c_mu(jj)*(x(reaction_molecules(jj,1))-1/2); w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
%               reaction_constant_dxi_dxj(jj,1) = c_mu(jj);  w.r.t. species 1,1
                 num_prop_deriv2(jj,1) = 1;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
     elseif (reaction_type(jj)==5)
%            reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))*x(reaction_molecules(jj,3));   % propensity
%               reaction_constant_dxi(jj,1) = c_mu(jj)*x(reaction_molecules(jj,2))*x(reaction_molecules(jj,3)); w.r.t. species 1 
%               reaction_constant_dxi(jj,2) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,3)); w.r.t. species 2 
%               reaction_constant_dxi(jj,3) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)); w.r.t. species 3
                 num_prop_deriv1(jj,1) = 3;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
                 prop_deriv1_map(jj,3) = reaction_molecules(jj,3);    
%               reaction_constant_dxi_dxj(jj,1) = c_mu(jj)*x(reaction_molecules(jj,3)); w.r.t. species 1,2
%               reaction_constant_dxi_dxj(jj,2) = c_mu(jj)*x(reaction_molecules(jj,2)); w.r.t. species 1,3
%               reaction_constant_dxi_dxj(jj,3) = c_mu(jj)*x(reaction_molecules(jj,1)); w.r.t. species 2,3
                 num_prop_deriv2(jj,1) = 3;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,3) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,4) = reaction_molecules(jj,3);    
                 prop_deriv2_map(jj,5) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,6) = reaction_molecules(jj,3);    
     elseif (reaction_type(jj)==6)
%            reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))*(x(reaction_molecules(jj,2))-1)/2;   % propensity
%               reaction_constant_dxi(jj,1) = c_mu(jj)*x(reaction_molecules(jj,2))*(x(reaction_molecules(jj,2))-1)/2;  w.r.t. species 1
%               reaction_constant_dxi(jj,2) = c_mu(jj)*x(reaction_molecules(jj,1))*(x(reaction_molecules(jj,2))-1/2);  w.r.t. species 2
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
%               reaction_constant_dxi_dxj(jj,1) = c_mu(jj)*(x(reaction_molecules(jj,2))-1/2);  w.r.t. species 1,2
%               reaction_constant_dxi_dxj(jj,2) = c_mu(jj)*x(reaction_molecules(jj,1));  w.r.t. species 2,2
                 num_prop_deriv2(jj,1) = 2;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,3) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,4) = reaction_molecules(jj,2);    
     elseif (reaction_type(jj)==7)
%            reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*(x(reaction_molecules(jj,1))-1)*(x(reaction_molecules(jj,1))-2)/6;   % propensity
%               reaction_constant_dxi(jj,1) = c_mu(jj)*(3*power(x(reaction_molecules(jj,1)),2) - 6*power(x(reaction_molecules(jj,1)),1) + 2)/6;   w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
%               reaction_constant_dxi_dxj(jj,1) = c_mu(jj)*(6*power(x(reaction_molecules(jj,1)),2) - 6)/6;  w.r.t. species 1,1 
                 num_prop_deriv2(jj,1) = 1;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
     elseif (reaction_type(jj)==12) % c_mu * (x_ref(species1)-x(species1))
%            reaction_constant(jj) = c_mu(jj)*(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)));   % propensity
%               reaction_constant_dxi(jj,1) = -c_mu(jj); % w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
%               reaction_constant_dxi_dxj(jj,1) = 0; 
                 num_prop_deriv2(jj,1) = 0;    
                 prop_deriv2_map(jj,1) = 0;    
     elseif (reaction_type(jj)==13) % c_mu * (x_ref(species1)-x(species1))/2  
%            reaction_constant(jj) = c_mu(jj)*(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2;   % propensity
%               reaction_constant_dxi(jj,1) = -c_mu(jj)/2; 
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
%               reaction_constant_dxi_dxj(jj,1) = 0; 
                 num_prop_deriv2(jj,1) = 0;    
                 prop_deriv2_map(jj,1) = 0;    
     elseif (reaction_type(jj)==20)
%            reaction_constant(jj) = c_mu(jj)*power(x_ref(reaction_molecules(jj,1))/(x_ref(reaction_molecules(jj,1))+kappa(jj)*x(reaction_molecules(jj,1))),2)*x(reaction_molecules(jj,2))*(x(reaction_molecules(jj,2))-1)/2; 
             %  w.r.t. species 1
             %  w.r.t. species 2
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
             %  w.r.t. species 1,1
             %  w.r.t. species 1,2
             %  w.r.t. species 2,2
                 num_prop_deriv2(jj,1) = 3;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
     elseif (reaction_type(jj)==30)
%%              reaction_constant(jj) = c_mu(jj)*power(x(reaction_molecules(jj,1)),n_hill(jj))/(k_hill(jj) + power(x(reaction_molecules(jj,1)),n_hill(jj)));
             %  w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
             %  w.r.t. species 1,1
                 num_prop_deriv2(jj,1) = 1;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
     elseif (reaction_type(jj)==31)  
%%              reaction_constant(jj) = c_mu(jj)*power(k_hill(jj),n_hill(jj))/(k_hill(jj) + power(x(reaction_molecules(jj,1)),n_hill(jj)));
             %  w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
             %  w.r.t. species 1,1
                 num_prop_deriv2(jj,1) = 1;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
     elseif (reaction_type(jj)==32)  % cooperativity-independent
%              reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))/(a_0(jj) + a_1(jj)*x(reaction_molecules(jj,1)) + a_2(jj)*x(reaction_molecules(jj,2)) + x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)));  % propensity
             %  w.r.t. species 1
             %  w.r.t. species 2 
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
             %  w.r.t. species 1,1
             %  w.r.t. species 1,2
             %  w.r.t. species 2,2
                 num_prop_deriv2(jj,1) = 3;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,3) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,4) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,5) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,6) = reaction_molecules(jj,2);    
     elseif (reaction_type(jj)==33)  % cooperativity-causal
%              reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2))/(a_0(jj) + a_1(jj)*x(reaction_molecules(jj,1)) + x(reaction_molecules(jj,1))*x(reaction_molecules(jj,2)));  % propensity
             %  w.r.t. species 1
             %  w.r.t. species 2 
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
             %  w.r.t. species 1,1
             %  w.r.t. species 1,2
             %  w.r.t. species 2,2
                 num_prop_deriv2(jj,1) = 3;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,3) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,4) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,5) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,6) = reaction_molecules(jj,2);    
     elseif (reaction_type(jj)==34)  % hill function from David's paper on two-entangled feedback loop motifs
% R_star = activate_R*R_tot*power(s/K_R_s,h_s)/(1 + power(s/K_R_s,h_s)) + (1-activate_R)*R_tot/(1 + power(s/K_R_s,h_s));
%A_E = eps_E + activate_E*(1-eps_E)*power(R_star/K_E,h_E)/(1+power(R_star/K_E,h_E)) + (1-activate_E)*(1-eps_E)/(1+power(R_star/K_E,h_E));
   %    c_mu = eps_E;
   %    a_0 = K_R_s;
   %    a_1 = h_s;
   %    a_2 = activate_R;
   %    a_3 = R_tot;
   %    a_4 = K_E;
   %    a_5 = h_E;
   %    a_6 = activate_E;
%              dummy1 = power(x(reaction_molecules(jj,1))/a_0(jj),a_1(jj));
%              dummy_star = ( a_2(jj)*a_3(jj)*dummy1 + (1-a_2(jj))*a_3(jj) ) / (1+dummy1);
%              dummy2 = power(dummy_star/a_4(jj),a_5(jj));
%              reaction_constant(jj) = a_7(jj)*( c_mu(jj) + (1-c_mu(jj))*( a_6(jj)*dummy2 + (1-a_6(jj)) ) / (1+dummy2) );  % propensity
             %  w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
             %  w.r.t. species 1,1
                 num_prop_deriv2(jj,1) = 1;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);    

     elseif (reaction_type(jj)==39)  %  uses: x_ref(species1)-x(species1)
%              reaction_constant(jj) = c_mu(jj)*power(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)),2)/(a_0(jj) + a_1(jj)*(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1))) + power(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)),2));  % propensity
             %  w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);
             %  w.r.t. species 1,1
                 num_prop_deriv2(jj,1) = 1;
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);

     elseif (reaction_type(jj)==40)
%%              reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(x(reaction_molecules(jj,2)),n_hill(jj))/(k_hill(jj) + power(x(reaction_molecules(jj,2)),n_hill(jj)));
             %  w.r.t. species 1
             %  w.r.t. species 2
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
             %  w.r.t. species 1,2
             %  w.r.t. species 2,2
                 num_prop_deriv2(jj,1) = 2;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,3) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,4) = reaction_molecules(jj,2);    
     elseif (reaction_type(jj)==41)  
%%              reaction_constant(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(k_hill(jj),n_hill(jj))/(k_hill(jj) + power(x(reaction_molecules(jj,2)),n_hill(jj)));
             %  w.r.t. species 1
             %  w.r.t. species 2
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
             %  w.r.t. species 1,2
             %  w.r.t. species 2,2
                 num_prop_deriv2(jj,1) = 2;    
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,3) = reaction_molecules(jj,2);    
                 prop_deriv2_map(jj,4) = reaction_molecules(jj,2);    
     elseif (reaction_type(jj)==50)   %  c_mu * min( (x_ref(species1)-x(species1))/2, x(species2) )*(a_0_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )/(a_1_eff + power(eta_0_eff*x(species3)+eta_1_eff*x(species4),n_eff) )
%              reaction_constant(jj) = c_mu(jj)*min(abs(x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2,abs(x(reaction_molecules(jj,2))))*( a_0_eff(jj) + power(eta_0_eff(jj)*x(reaction_molecules(jj,3))+eta_1_eff(jj)*x(reaction_molecules(jj,4)),n_eff(jj)) )/( a_1_eff(jj) + power(eta_0_eff(jj)*x(reaction_molecules(jj,3))+eta_1_eff(jj)*x(reaction_molecules(jj,4)),n_eff(jj)) );  % propensity
     elseif (reaction_type(jj)==51)   %  c_mu * min( (x_ref(species1)-x(species1))/2-x(species2), x(species3) )
%              reaction_constant(jj) = c_mu(jj)*min( abs((x_ref(reaction_molecules(jj,1))-x(reaction_molecules(jj,1)))/2-x(reaction_molecules(jj,2)) ),abs(x(reaction_molecules(jj,3))));  % propensity

     elseif (reaction_type(jj)==54) % NEW UPR Splicing function  %  c_mu * min( x(species1), x(species2) )

%              propensities(jj) = c_mu(jj)*min( abs( x(reaction_molecules(jj,1)) ),abs(x(reaction_molecules(jj,2))) );  % propensity

             %  w.r.t. species 1
             %  w.r.t. species 2
                 num_prop_deriv1(jj,1) = 2;    
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);    
                 prop_deriv1_map(jj,2) = reaction_molecules(jj,2);    
             %  w.r.t. 1,2
                 num_prop_deriv2(jj,1) = 0;    
                 prop_deriv2_map(jj,1) = 0;    

     elseif (reaction_type(jj)==57) % NEW UPR Foci decay function  %  c_mu * x(species1)*power(x_0,n) / ( power(x_0,n) + power(x(species1),n) )

          %    x_0  = a_0_eff(jj);
          %    n_0  = n_eff(jj);
          %    propensities(jj) = c_mu(jj)*x(reaction_molecules(jj,1))*power(x_0,n_0)/( power(x_0,n_0) + power(x(reaction_molecules(jj,1)),n_0) );  % propensity

             %  w.r.t. species 1
                 num_prop_deriv1(jj,1) = 1;
                 prop_deriv1_map(jj,1) = reaction_molecules(jj,1);
             %  w.r.t. species 1,1
                 num_prop_deriv2(jj,1) = 1;
                 prop_deriv2_map(jj,1) = reaction_molecules(jj,1);
                 prop_deriv2_map(jj,2) = reaction_molecules(jj,1);


     end;
        
    end;


% setup more compact 'sign_value_reaction' map

num_sign_value_map = zeros(num_reactions,1);    
sign_value_map = zeros(num_reactions,20);    
mol_sign_value_map = zeros(num_reactions,20);    
% setup the compact 'sign_value_reation' map
for ii = 1:num_reactions
  for jj = 1:num_molecules
      if (sign_value_reaction(ii,jj)~=0.0)
         num_sign_value_map(ii) = num_sign_value_map(ii)+1;
         mol_sign_value_map(ii,num_sign_value_map(ii)) = jj;
         sign_value_map(ii,num_sign_value_map(ii)) = sign_value_reaction(ii,jj);
      end;
  end;
end;
