
index_group_mapped = zeros(num_nuclei_t0,1);

for iii = 1:length(index_group)
    index_group_mapped(index_group(iii),1) = iii;
end;

if (which_pathway == 0)
    num_cells;
  mat_A_gap = zeros(num_cells,num_cells);
  mat_R_gap = zeros(num_cells,num_cells);    
    %  circular connection
  if (num_cells > 1)
    for ii = 1:num_cells
      if ii == 1
       mat_A_gap(ii,num_cells) = 1;
       mat_A_gap(ii,2) = 1;
       mat_R_gap(ii,num_cells) = 1;
       mat_R_gap(ii,2) = 1;
      elseif ii == num_cells
       mat_A_gap(ii,num_cells-1) = 1;
       mat_A_gap(ii,1) = 1;
       mat_R_gap(ii,num_cells-1) = 1;
       mat_R_gap(ii,1) = 1;
      else
       mat_A_gap(ii,ii-1) = 1;
       mat_A_gap(ii,ii+1) = 1;
       mat_R_gap(ii,ii-1) = 1;
       mat_R_gap(ii,ii+1) = 1;
      end;
    end;
  end; % if (num_cells > 1)

elseif (which_pathway == 1)    

  mat_Calcium_gap = zeros(num_cells,num_cells);
  mat_cAMP_gap = zeros(num_cells,num_cells);
  mat_Erk_paracrine = zeros(num_cells,num_cells);

 if (which_cAMP_circuit == 0)|(which_cAMP_circuit == 1)  % Andrews and current model
     
  do_new_way = 1;  % 1 - image specific connections, 0 - circular, two-neighbor connections   
   if (do_new_way == 0)   
    if (num_cells > 1)
      for ii = 1:num_cells
        if ii == 1
         mat_cAMP_gap(ii,num_cells) = 1;
         mat_cAMP_gap(ii,2) = 1;
         %mat_Calcium_gap(ii,num_cells) = 1;
         %mat_Calcium_gap(ii,2) = 1;
        elseif ii == num_cells
         mat_cAMP_gap(ii,num_cells-1) = 1;
         mat_cAMP_gap(ii,1) = 1;
         %mat_Calcium_gap(ii,num_cells-1) = 1;
         %mat_Calcium_gap(ii,1) = 1;
        else
         mat_cAMP_gap(ii,ii-1) = 1;
         mat_cAMP_gap(ii,ii+1) = 1;
         %mat_Calcium_gap(ii,ii-1) = 1;
         %mat_Calcium_gap(ii,ii+1) = 1;
        end;
      end;
    end; % if (num_cells > 1)

   elseif (do_new_way == 1)   

       if (which_modeling_case == 1)
          connection_map = [28 29]; 
             which_cell_to_plot(1) = 28;
             which_cell_to_plot(2) = 29;
       elseif (which_modeling_case == 2)
         
           connection_map = [28 29; 28 22; 28 37; 28 34; 28 30; 28 23; 24 22; 24 29; 22 29; 22 23;...
               23 19; 23 25; 25 19; 25 30; 23 30; 30 34; 34 37; 34 39; 39 37; 29 37];
               
             which_cell_to_plot(1) = 28;
             which_cell_to_plot(2) = 29;
            
                    
       elseif (which_modeling_case == 3)
           
                      connection_map = [36 31; 36 41; 36 32; 36 40; 31 32; 32 40; 40 41; 41 31];
                      
             which_cell_to_plot(1) = 36;
             which_cell_to_plot(2) = 40;
                      

       elseif (which_modeling_case == 4)
           
                      %connection_map = [36 31; 36 41; 36 32; 36 40; 31 32; 32 40; 40 41; 41 31; 31 29; 31 24; ...
                      %                  32 24; 32 26; 40 34; 40 46; 41 46; 41 49;41 48; 41 35;...% 41 44; 32 44; 41 52; ...
                      %                  29 35; 35 44; 44 48; 48 52; 52 49; 49 46; 46 51; 51 34; 34 26; 26 24; 24 29; ...
                      %                  41 29; 41 52];
                    
                      connection_map = [36 31; 36 41; 36 32; 36 40; 40 41; 41 31; 31 29; 31 24; ...
                                        40 34; 40 46; 41 46; 41 49;41 48; 41 35;...% 41 44; 32 44; 41 52; ...
                                        29 35; 35 44; 44 48; 48 52; 52 49; 49 46; 46 51; 51 34; 34 26; 26 24; 24 29; ...
                                        41 29; 41 52];
                      bPAC_NUCLEUS_time_mapped_t0(31,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(32,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(36,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(40,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(41,:) = 1;                      

                      bPAC_NUCLEUS_time_mapped_t0(46,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(49,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(51,:) = 0;                      
                      
       elseif (which_modeling_case == 5)
                                    
                      connection_map = [36 32; 40 41; 41 31; 31 29; 31 24; ...
                                        40 34; 40 46; 41 46; 41 49;41 48; 41 35;...% 41 44; 32 44; 41 52; ...
                                        29 35; 35 44; 44 48; 48 52; 52 49; 49 46; 46 51; 51 34; 34 26; 26 24; 24 29; ...
                                        41 29; 41 52];
                                    
                      %bPAC_NUCLEUS_time_mapped_t0(31,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(32,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(36,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(40,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(41,:) = 1;                      
                                                         
                      
                      bPAC_NUCLEUS_time_mapped_t0(46,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(49,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(51,:) = 0;                      
                      
             which_cell_to_plot(1) = 36;
             %which_cell_to_plot(2) = 40;
             which_cell_to_plot(2) = 34;
             
       elseif (which_modeling_case == 6)

                      connection_map = [31 41; 35 41; 36 31; 36 41; 36 32; 36 40; 31 32; 32 40; 40 41; 31 29; 31 24; ...
                                        32 24; 32 26; 40 34; 40 46; 41 46; 41 49;41 48; ...
                                        29 35; 35 44; 44 48; 48 52; 52 49; 49 46; 46 51; 51 34; 34 26; 26 24; 24 29;...
                                        31 35; 48 35; 24 23; 29 23; 29 27; 44 45; 44 58; 44 56; 48 54; 48 56;...
                                        54 63; 56 63; 52 54; 52 55; 55 68; 55 69; 49 55; 49 51; 52 63; ...
                                        27 45; 45 61; 58 61; 56 66; 26 28; 34 28; 35 27; ...
                                        55 59; 51 59; 59 65; 51 60; 59 60; 51 57; 51 50; 34 50];
           
                      
                      %bPAC_NUCLEUS_time_mapped_t0(31,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(32,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(35,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(36,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(40,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(41,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(46,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(48,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(49,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(52,:) = 1;                      

                     
                      bPAC_NUCLEUS_time_mapped_t0(36,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(40,:) = 0;                                           
                      bPAC_NUCLEUS_time_mapped_t0(46,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(49,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(51,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(55,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(61,:) = 0;                      
                      
             which_cell_to_plot(1) = 36;
             which_cell_to_plot(2) = 40;
           
       elseif (which_modeling_case == 7)
           
                                    
                      connection_map = [31 41; 35 41; 36 31; 36 41; 36 32; 36 40; 31 32; 32 40; 40 41; 31 29; 31 24; ...
                                        32 24; 32 26; 40 34; 40 46; 41 46; 41 49;41 48; ...
                                        29 35; 35 44; 44 48; 48 52; 52 49; 49 46; 46 51; 51 34; 34 26; 26 24; 24 29;...
                                        31 35; 48 35; 24 23; 29 23; 29 27; 44 45; 44 58; 44 56; 48 54; 48 56;...
                                        54 63; 56 63; 52 54; 52 55; 55 68; 55 69; 49 55; 49 51; 52 63; ...
                                        27 45; 45 61; 58 61; 56 66; 26 28; 34 28; 35 27; ...
                                        13 24; 13 26; 13 20; 6 13; 5 13; 4 13; 4 14; 4 15; 20 24;...
                                        15 20; 15 23; 20 23; 14 20; 6 28; 2 11; 3 15; 2 3;...
                                        11 23; 11 27; ...
                                        55 59; 51 59; 59 65; 51 60; 59 60; 51 57; 51 50; 34 50];
                                   
                                    
                      %bPAC_NUCLEUS_time_mapped_t0(31,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(32,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(35,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(36,:) = 1;                      
                      %bPAC_NUCLEUS_time_mapped_t0(40,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(41,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(46,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(48,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(49,:) = 1;                      
                     % bPAC_NUCLEUS_time_mapped_t0(52,:) = 1;                      

                     
                      bPAC_NUCLEUS_time_mapped_t0(36,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(40,:) = 0;                                           
                      bPAC_NUCLEUS_time_mapped_t0(46,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(49,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(51,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(55,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(61,:) = 0;                      
                      
             which_cell_to_plot(1) = 36;
             which_cell_to_plot(2) = 40;
           
       elseif (which_modeling_case == 8)
           
           
                      connection_map = [36 31; 36 41; 36 32; 36 40; 31 32; 32 40; 40 41; 41 31; 31 29; 31 24; ...
                                        32 24; 32 26; 40 34; 40 46; 41 46; 41 49;41 48; 51 55; 51 59 51 50; ...
                                        29 35; 35 44; 44 48; 48 52; 52 49; 49 46; 46 51; 51 34; 34 26; 26 24; 24 29];
                      
                      bPAC_NUCLEUS_time_mapped_t0(31,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(32,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(36,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(40,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(41,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(46,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(48,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(49,:) = 1;                      
                      bPAC_NUCLEUS_time_mapped_t0(52,:) = 1;                      
                      
                      bPAC_NUCLEUS_time_mapped_t0(51,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(55,:) = 0;                      
                      bPAC_NUCLEUS_time_mapped_t0(61,:) = 0;                      
                      
             which_cell_to_plot(1) = 36;
             which_cell_to_plot(2) = 40;
           
       end;
       
         for ii_connect = 1:length(connection_map(:,1))   
           iii =index_group_mapped(connection_map(ii_connect,1));
           jjj =index_group_mapped(connection_map(ii_connect,2));
             mat_cAMP_gap(iii,jjj) = 1;
             mat_cAMP_gap(jjj,iii) = 1;             
         end; % for ii_connect = 1:length(connection_map(:,1))   
       
    for iii = 1:num_cells
        N_coupled(iii) = sum(mat_cAMP_gap(iii,:));
    end;
         
   end;  %  if (do_new_way == 0)   


   
   
 end;

end;


%  Set coupling matrices below.  
%  1) Based on data (gap junction marker)
%  2) Simple adjacent nuclei.  We'll setup this after Christmas
%





% regnerate_


for kkk = 1:1
  which_frame = kkk
  
  
 % str_movie_processed = strcat(str_movie,'_processed')
 % file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
 % load(file_nucleus);
  
M_marker_threshold_TEST = zeros(xLength,yLength);

 for jjj = 1:num_nuclei_t0
     idx = jjj;
   M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx}'])) =   1;
 end;
     
 for jjj = 1:length(index_group)
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
        if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)
        M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   3;
        else
        M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   2;
        end;
       end;
 end;
 

end; %for kkk = 1:


figure(55)

for jjj = 1:length(size_bPAC_clusters)     
    %eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    %eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %%imshow(mat2gray(M_NM_bPAC));
    %eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    %eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %%imshow(mat2gray(M_NM));
    %%%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    %image_RGB = zeros(xLength,yLength,3);
    %image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    %image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    %imshow(image_RGB)
    imagesc(M_marker_threshold_TEST)
    
    title(strcat('bPAC cluster:',num2str(jjj)));
      for iii = 1:size_bPAC_clusters(jjj)
         idx = bPAC_clusters(jjj,iii);   
         which_frame = kkk;
          if (bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));           
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
          end;
         set(tt,'Color','w');
      end;
      
      for iii = 1:size_non_bPAC_clusters(jjj)
         idx = non_bPAC_clusters(jjj,iii);   
          if (non_bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));            
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
          end;
         set(tt,'Color','k');
      end;
      
      
end;
for iii = 1:length(index_group)
    for jjj = iii+1:length(index_group)
    
        if (mat_cAMP_gap(iii,jjj) == 1)
            idx_iii = index_group(iii)
            idx_jjj = index_group(jjj)
           tt=line([mean_y_tot_time_mapped_t0(idx_iii,which_frame) mean_y_tot_time_mapped_t0(idx_jjj,which_frame)],[mean_x_tot_time_mapped_t0(idx_iii,which_frame) mean_x_tot_time_mapped_t0(idx_jjj,which_frame)]);           
           set(tt,'Color','m');
        end;
        
    end;
end;





%pause;


