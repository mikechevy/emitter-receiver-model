% used to throwout the top 'num_throwout' values, to discuard clusters when
% calculating mean and std pixel number
num_throwout_max = 20;

% default, unless we want to look on mixtures of non-bPAC and bPAC cells
do_location_bPAC_nuclei = 0;

% USED TO DETERMIN IF pixel region is small enough to label as single nucleus: if (num_pixels_tot(which_nucleus) > mean_pix + fac_std_nuclear_size*std_pix) 
fac_std_nuclear_size = -0.5;  % if mean_pix + fac_std_nuclear_size
fac_std_nuclear_size_recursive = -.5;  % if mean_pix + fac_std_nuclear_size

% minimum size of nucleus in pixels  
nucleus_min_pixels = 200;  



%  these are handed to 'determine_nuclear_locations_adaptive_recursive' for
%  extra processing of the segmenting nuclei
do_threshold_fac_adjust = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't
do_threshold_fac_adjust_bPAC = 1;  % 1 - makes an extra adjustment in threshold, 0 - doesn't


%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;

% percentage a bPAC marked nucleus must appear over the movie, used in
% mixed_bPAC_population_analysis.m
fac_bPAC_percentage = .8;
% ratio of area of bPAC_NM to NM, used in mixed_bPAC_population_analysis.m
bPAC_NM_to_NM_ratio = 1.5;

%  bursting periods
period_burst_Ca = 25;  % seconds
period_burst_Erk = 25*60;
%  bursting thresholds
threshold_burst_Ca = 3;
threshold_burst_Erk = 10;

ii_NM_bPAC = [];


do_illumation_map_normalize = 1;  % 1 - yes, 0 - no 



%setup the array that maps the marker from a particular channel
marker_from_channel = zeros(num_different_markers,1);

if which_movie == 1  % pure MDCK+bPAC  
    str_movie = 'Pos1_new'
    numCh=3;
    numFr=120;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\img_000000000_Cy3_000.tif');
    CH1_str = 'FITC';  % Ca2+
    CH2_str = 'CY3';  % Erk
    CH3_str = 'DAPI';  % nuclear marker
    ii_CH1 = 2; % FITC
    ii_CH2 = 3;  % CY3
    ii_CH3 = 1;  % DAPI
    ii_NM = 3;  % for channel 3
       signal_channels = [ii_CH1 ii_CH2];   
       numFr_CH = [120 120 120];
    marker_from_channel(ii_Ca_marker) = 1;
    marker_from_channel(ii_bPAC_marker) = 2;
    marker_from_channel(ii_nuclear_marker) = 3;
    do_elsamad_microscope = 0;
        % time sequence parameters for movie
         tau_sample = 30; % 30 second sample period         
         time_CH1 = 0:tau_sample:(numFr-1)*tau_sample;
         time_CH2 = 0:tau_sample:(numFr-1)*tau_sample;
         time_CH3 = 0:tau_sample:(numFr-1)*tau_sample;         
%  bursting thresholds
%threshold_burst_Ca = 40;
threshold_burst_Ca = 80;
do_elsamad_microscope = 0;

elseif which_movie == 2  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '011416_bPACtest40x'
    numCh=3;
    CH1_str = 'YFP';  % Ca2+
    CH2_str = 'RFP';  % Erk
    CH3_str = 'CFP';  % nuclear marker
    numFr=379;
    numFr_import = 380;
    numCh_import = 1;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\011416_bPACtest40x.tif');    
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    marker_from_channel(ii_Ca_marker) = ii_CH1;  
    marker_from_channel(ii_Erk_marker) = ii_CH2;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH3;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 50;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
 
elseif (which_movie == 3)  % MDCK (bPAC), Erk (no fcs)

    str_movie = '020216_focused_BF'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'YFP';  % bPAC marker (no CFP recorded
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    bPAC_ledvals = [zeros(1,15) 255*ones(1,15) 0*zeros(1,15)];
    seconds_per_frame = 60;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 50;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
 
elseif which_movie == 4  % mixed MDCK and MDCK+bPAC cells
    str_movie = '020516_mwc_bPAC'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'CFP';  % bPAC marker
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 50;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

elseif which_movie == 5  % mixed MDCK and MDCK+bPAC cells
    str_movie = '020516_mwc_no_bPAC'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'CFP';  % bPAC marker
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 50;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 elseif which_movie == 6  % mixed MDCK and MDCK+bPAC cells

    str_movie = '020916_mwc_DAPI_nodrug'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'CFP';  % bPAC marker
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
    do_elsamad_microscope = 1;
    
    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

     
 elseif which_movie == 7  % mixed MDCK and MDCK+bPAC cells

    str_movie = '020916_mwc_DAPI_drug100nM'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'CFP';  % bPAC marker
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
    do_elsamad_microscope = 1;

    do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
 elseif which_movie == 8  % mixed MDCK and MDCK+bPAC cells

    str_movie = '020916_mwc_noDAPI_nodrug'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'CFP';  % bPAC marker
    CH3_str = 'CFP';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
    do_elsamad_microscope = 1;
 
 elseif which_movie == 9  % mixed MDCK and MDCK+bPAC cells

    str_movie = '020916_mwc_noDAPI_drug100nM'
    numCh=4;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'CFP';  % bPAC marker
    CH3_str = 'CFP';  % nuclear marker
    CH4_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH2;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
    do_elsamad_microscope = 1;
 
elseif which_movie == 10  % mixed MDCK and MDCK+bPAC cells
    str_movie = '021216_mwc_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
elseif which_movie ==11 % mixed MDCK and MDCK+bPAC cells
    str_movie = '021216_mwc_198-117_B'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 90;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
elseif which_movie ==12 % mixed MDCK and MDCK+bPAC cells
    str_movie = '021216_mwc_198_198-117_B'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 90;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
 
elseif which_movie == 13  % mixed MDCK and MDCK+bPAC cells
    str_movie = '021516_mwc_198_198-117_nodrug'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 90;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

elseif which_movie == 14  % mixed MDCK and MDCK+bPAC cells
    str_movie = '021516_mwc_198_198-117_100nM'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 90;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
elseif which_movie == 15  % mixed MDCK and MDCK+bPAC cells
    str_movie = '021516_mwc_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 90;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

elseif which_movie == 16  % mixed MDCK and MDCK+bPAC cells
    str_movie = '021916_nodrug_6sfor20m_2_CAT\Pos0'
    numCh=3;
    numFr=200;
    path_movie = strcat('..\multicellular_movies\',str_movie,'\img_000000000_DAPI_000.tif');
    CH1_str = 'FITC';  % Erk
    CH2_str = 'DAPI';  % 
    CH3_str = 'CFP';  % nuclear marker
    %CH4_str = 'CFP';  % bPAC marker
    %CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    %ii_CH4 = 4;
    %ii_CH5 = 5;
    ii_CH1_map = 3;
    ii_CH2_map = 1;
    ii_CH3_map = 2;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH2;
    marker_from_channel(ii_bPAC_marker) = ii_CH3;  % redundant
       signal_channels = [ii_CH1];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 0;
 
     bPAC_ledvals = [100*ones(1,120)];
    seconds_per_frame = 6;
    
    do_elsamad_microscope = 0;
        % time sequence parameters for movie
         tau_sample = 6; % 30 second sample period         
         time_CH1 = 0:tau_sample:(numFr-1)*tau_sample;
         time_CH2 = 0:tau_sample:(numFr-1)*tau_sample;
         time_CH3 = 0:tau_sample:(numFr-1)*tau_sample;  
         numFr_CH = [numFr numFr numFr];
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
 
elseif which_movie == 17  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '022316_mwc_198_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
     bPAC_ledvals = [100*ones(1,120)];
    seconds_per_frame = 60;

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

elseif which_movie == 18  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '022616_mwc_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
     bPAC_ledvals = [100*ones(1,120)];
    seconds_per_frame = 60;

elseif which_movie == 19  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '022616_mwc_198-117_2';  % num_throwout = 20
    %str_movie = '022616_mwc_198-117_2_same'  % recent processing
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
     bPAC_ledvals = [100*ones(1,120)];
    seconds_per_frame = 60;
    
elseif which_movie == 20  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '022616_mwc_198-117_3'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
     bPAC_ledvals = [100*ones(1,120)];
    seconds_per_frame = 60;

elseif which_movie == 21  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '022616_mwc_198_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
    
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
elseif which_movie == 22  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '030116_mwc_198_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 150;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
    
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

elseif which_movie == 23  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '030116_mwc_198_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
    
 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

elseif which_movie == 24  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '030116_mwc_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function
    
    
elseif which_movie == 25  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '031016_mwc_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_NM_bPAC = ii_NM;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = ii_NM
    
elseif which_movie == 26  % mixed MDCK and MDCK+bPAC cells
    
    %str_movie = '031016_mwc_198_198-117'
    str_movie = '031016_mwc_198_198-117_2'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    

elseif which_movie == 27  % mixed MDCK and MDCK+bPAC cells
    
    %str_movie = '031416_mwc_198_198-117'
    str_movie = '031416_mwc_198_198-117_same'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

    
elseif which_movie == 28  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '031416_mwc_198_198-117_connexin'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;

 do_illumation_map_normalize = 0; 
    ii_IF = ii_CH2;  % channel to base the illumination function

 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
elseif which_movie == 29  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '032216_mwc_198_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 200;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

elseif which_movie == 30  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '032216_mwc_198_198-117_connexin'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

elseif which_movie == 31  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '041216_mwc_198_198-117_carboxolone'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
    delta_xDim = 200;
    delta_yDim = 200;
    delta_xDim_step = 20;
    delta_yDim_step = 20;

    
elseif which_movie == 32  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '041216_mwc_198_198-117_18alpha'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);

    
elseif which_movie == 33  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '041216_mwc_198_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    
elseif which_movie == 34  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042216_mwc_198_198-117_caroxolene_1'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
fac_bPAC_percentage = .8;
bPAC_NM_to_NM_ratio = 1.35;


    
elseif which_movie == 35  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042216_mwc_198_198-117_caroxolene_2'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
elseif which_movie == 36  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042216_mwc_198_198-117_caroxolene_low_amp'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;
    
elseif which_movie == 37  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '160421bpac-ERKKTR-PRKACA-H89'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_Pka_marker) = ii_CH2;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;

elseif which_movie == 38  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042616_mwc_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;
        
elseif which_movie == 39  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042616_mwc_198_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;

elseif which_movie == 40  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042916_mwc_198_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
elseif which_movie == 41  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042916_mwc_198_198-117_IBMX_2'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
elseif which_movie == 42  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '042916_mwc_198_198-117_IBMX_1.3'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
    
%  adaptive threshold local dimensions
delta_xDim = 200;
delta_yDim = 200;
delta_xDim_step = 20;
delta_yDim_step = 20;
do_threshold_fac_adjust_bPAC = 0;  % 1 - makes an extra adjustment in threshold, 0 - doesn't

    
    
elseif which_movie == 43  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050316_mwc_198_198-117_IBMX_1.5'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
elseif which_movie == 44  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050316_mwc_198_198-117_IBMX_1.5_2'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;

elseif which_movie == 45  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050316_mwc_198_198-117_IBMX_1.5_3'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;

elseif which_movie == 46  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050316_mwc_198_198-117'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
elseif which_movie == 47  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050616_mwc_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;
    
elseif which_movie == 48  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050616_mwc_198_198-117_IBMX'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
elseif which_movie == 49  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '050616_mwc_198-117_IBMX_2'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 0;
    %ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    ii_NM_bPAC = ii_NM;
    
elseif which_movie == 50  % mixed MDCK and MDCK+bPAC cells
    
    str_movie = '160422mixbpac-ERKKTR-PRKACA-H89'
    numCh=5;
    CH1_str = 'YFP';  % Erk
    CH2_str = 'RFP';  % 
    CH3_str = 'DAPI';  % nuclear marker
    CH4_str = 'CFP';  % bPAC marker
    CH5_str = 'BF';  % brightfield
    ii_CH1 = 1;
    ii_CH2 = 2;
    ii_CH3 = 3;
    ii_CH4 = 4;
    ii_CH5 = 5;
    marker_from_channel(ii_Erk_marker) = ii_CH1;
    marker_from_channel(ii_Pka_marker) = ii_CH2;
    marker_from_channel(ii_nuclear_marker) = ii_CH3;
    marker_from_channel(ii_bPAC_marker) = ii_CH4;  % redundant
       signal_channels = [ii_CH1 ii_CH2];
       ii_NM = length(signal_channels)+1;
       ii_BF = numCh;;
      % minimum size of nucleus in pixels  
      nucleus_min_pixels = 100;  % 10X is used  
         %  bursting thresholds
            threshold_burst_Ca = 250;        
 do_elsamad_microscope = 1;
 
do_illumation_map_normalize = 1; 
    ii_IF = ii_CH2;  % channel to base the illumination function


 do_location_bPAC_nuclei = 1;
    ii_NM_bPAC = marker_from_channel(ii_bPAC_marker);
    %ii_NM_bPAC = ii_NM;
    
end;    





