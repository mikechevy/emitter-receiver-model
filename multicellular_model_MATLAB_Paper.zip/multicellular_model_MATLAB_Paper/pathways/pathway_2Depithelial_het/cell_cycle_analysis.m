%close all;
clear all;
pathway_str = 'pathways/pathway_information';  % path of directory relative to MAT_pic_bio

cd ../../;
set_globals_and_initialize;
set_globals_parts;
set_constants_parts;
cd(pathway_str);

global Y_info_index_cov_map;
global Y_info_index;
global scale_Y_info_index;
global X_info_index;
global Cov_mat;
global mu_vec;
global P_Y;
global P_X;
global P_Y_X;
global P_Y_X_properties;
global X;
global Y;
global Y_1;
global Y_2
global X_sequence_sample;

Y_max_scale = 1000;
Y_1_max_scale = 200;
Y_2_max_scale = 200;


         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %  which_pathway - indexes pathways to model
         %
         %
         %      0 - Biological Oscillator (Carlos)
         %      1 -  one input, one gene transcriptional network
         %      2 -  one input, one gene transcriptional network, 
         %      3 - 
         %
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         which_pathway = 1; 


do_quadratic_terms = 0; % 0-no, 1-yes  (covariance terms involving second derivative of propensities) 
do_covariances = 1;  % This is for Mike's hybrid method from the paper; 0 - do not use covariance, 1 - use covariances
num_X_input_samples = 31;



    do_cell_cycle_modulate = 1;
    
    cell_cycle_array = [0 .3 .7]; %  .01  .1 .5 1 10
    cell_cycle_array = [0]; %  .01  .1 .5 1 10


    
for  ii_array = 1:length(cell_cycle_array)
    
    fac_cell_cycle = cell_cycle_array(ii_array);
    
      file_info_str = strcat('file_info_trans_',num2str(which_pathway),'_',num2str(num_X_input_samples),'_fac_cell_cycle_',num2str(fac_cell_cycle),'.mat');   
      load(file_info_str);
   
       
          % species index
          ii_X = 1;
          ii_M_Y = 2;
          ii_Y = 3;
          ii_TF_on = 4;
          ii_TF_off = 5;
          ii_I_stress = 6;
          ii_Y_TF_on = 7;

      
             % setup some arrays
             Cov_mat = zeros(length(Y_info_index),length(Y_info_index));
             P_Y = zeros(Y_max+1,1);
             P_Y_X = zeros(Y_max+1,1);
             P_X = zeros(length(X),1);
                
          

              %P_X_sequence = 0*P_X_sequence;
              %P_X_sequence(10) = 1;
              %P_X_sequence = P_X_sequence/(P_X_sequence(10)*A_eq(10));
             
           
           
   load P_X_theory;
   for ii = 1:length(X_sequence_sample)
        
    [index_X_upper index_X_lower upper lower] = interpolate_between(X_sequence_sample,ii,X);   

    P_X_opt_theory_sample(ii) = upper*P_X_opt_theory(index_X_upper) + lower*P_X_opt_theory(index_X_lower);      
    P_X_uniform_sample(ii) = upper*P_X_uniform(index_X_upper) + lower*P_X_uniform(index_X_lower);      
    
    
   end;
           
   
   
      

           %P_X_in = P_X_opt_theory_sample;

            P_X_in = P_X_uniform_sample;
            P_X_opt = P_X_in;
           
           setup_P_Y_and_P_Y_X;         
           I_x_y_opt = calculate_mutual_information_1D(P_X_opt)
           I_x_y_theory = calculate_mutual_information_1D(P_X_opt_theory_sample)
           I_x_y_uniform = calculate_mutual_information_1D(P_X_uniform_sample)

          figure(10000)
          subplot(2,1,1)
          hold on;
          h1 = plot(X,G_n, 'r')
          set(h1,'Linewidth',2);
          subplot(2,1,2)
           hold on;
           h1 = plot(X_sequence_sample,P_X_in,'g');
            set(h1,'Linewidth',2);
           h1 = plot(X_sequence_sample,P_X_opt,'r');
            set(h1,'Linewidth',2);
           h1 = plot(X_sequence_sample,P_X_uniform_sample,'k');
            set(h1,'Linewidth',2);
           hold off
           legend(strcat('P_{in}(X), I(x,y)=',num2str(I_x_y_theory)),strcat('P_{opt}(X), I(x,y)=',num2str(I_x_y_opt)),strcat('P_{uniform}(X), I(x,y)=',num2str(I_x_y_uniform)));
           
          figure(1001)
          h1 = plot(Y,P_Y, 'r')
          
          

          
           Y_info_index(1) = ii_TF_on;
           setup_P_Y_and_P_Y_X;         
           [Y_info_index_cov_map X_info_index_cov_map] = setup_Y_and_X_cov_map(Y_info_index,X_info_index);    
           size(P_Y)
           size(P_Y_X)
           I_x_y_TF_on = calculate_mutual_information_1D(P_X_uniform_sample)
           setup_P_Y_and_P_Y_X_scale;         
           I_x_y_TF_on_scale = calculate_mutual_information_1D(P_X_uniform_sample)
          
          
           Y_info_index(1) = ii_M_Y;
           setup_P_Y_and_P_Y_X;         
           [Y_info_index_cov_map X_info_index_cov_map] = setup_Y_and_X_cov_map(Y_info_index,X_info_index);       
           I_x_y_M_Y = calculate_mutual_information_1D(P_X_uniform_sample)          
           setup_P_Y_and_P_Y_X_scale;         
           I_x_y_M_Y_scale = calculate_mutual_information_1D(P_X_uniform_sample)
          
           Y_info_index(1) = ii_Y;
           setup_P_Y_and_P_Y_X;         
           [Y_info_index_cov_map X_info_index_cov_map] = setup_Y_and_X_cov_map(Y_info_index,X_info_index);       
           
           I_x_y_Y = calculate_mutual_information_1D(P_X_uniform_sample)
           setup_P_Y_and_P_Y_X_scale;         
           I_x_y_Y_scale = calculate_mutual_information_1D(P_X_uniform_sample)
           
             %P_X_in = P_X_uniform_sample;
             %P_X_opt = fmincon('calculate_mutual_information_1D',P_X_in,A,B,A_eq,B_eq)
             %I_x_y_Y_opt = calculate_mutual_information_1D(P_X_opt)

           
          Y_info_index(1) = ii_M_Y;        
          Y_info_index(2) = ii_Y;          
          setup_P_Y_and_P_Y_X;         
          [Y_info_index_cov_map X_info_index_cov_map] = setup_Y_and_X_cov_map(Y_info_index,X_info_index);        
          I_x_y_2D = calculate_mutual_information_2D(P_X_uniform_sample)
          setup_P_Y_and_P_Y_X_scale;         
          I_x_y_2D_scale = calculate_mutual_information_2D(P_X_uniform_sample)
          
           
   for ii = 1:length(X)
        
    [index_X_upper index_X_lower upper lower] = interpolate_between(X,ii,X_sequence_sample);   

    
    P_X_opt_numerical(ii) = upper*P_X_opt(index_X_upper) + lower*P_X_opt(index_X_lower);      
   end;
           
   save(strcat('P_X_numerical_',num2str(which_pathway),'_',num2str(num_X_input_samples)), 'P_X_opt_numerical');
          
          
           
           
     tau_sequence = 30;  % minutes
     tau_sequence = 3000;  % minutes

     
     I_x_y_cell_cycle(ii_array) = -I_x_y_Y;
     I_x_y_cell_cycle_opt(ii_array) = -I_x_y_Y_opt;


     if (ii_array==1)
         P_X_opt_array = P_X_opt
     else
         P_X_opt_array = [P_X_opt_array ; P_X_opt];         
     end;
     
end;


save cell_cycle_analysis_results cell_cycle_array I_x_y_cell_cycle I_x_y_cell_cycle_opt X_sequence_sample P_X_uniform_sample P_X_opt_array;  
plot_cell_cycle_analysis_results;


