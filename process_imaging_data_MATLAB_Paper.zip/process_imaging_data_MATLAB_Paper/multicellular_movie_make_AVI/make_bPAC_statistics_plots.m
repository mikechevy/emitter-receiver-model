         %  overshoot_bPAC_pulse_cell(idx,ii);
         %  index_overshoot_bPAC_pulse_cell(idx,ii);
         %  time_overshoot_bPAC_pulse_cell(idx,ii);
         % steady_state_bPAC_pulse_cell(idx,ii);
         % ratio_overshoot_ss_bPAC_pulse_cell(idx,ii);  
         
         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  FILE for bPAC statistics
%
%  num_bPAC_pulses
%  bPAC_pulse_cell(idx,ii)
%  overshoot_bPAC_pulse_cell(idx,ii);
%  index_overshoot_bPAC_pulse_cell(idx,ii);
%  time_overshoot_bPAC_pulse_cell(idx,ii);
% steady_state_bPAC_pulse_cell(idx,ii);
% ratio_overshoot_ss_bPAC_pulse_cell(idx,ii);          
% save('bPAC_statistics_arrays','num_bPAC_pulses','bPAC_pulse_cell','overshoot_bPAC_pulse_cell','index_overshoot_bPAC_pulse_cell','index_overshoot_whole_bPAC_pulse_cell', ...
%                                   'time_overshoot_bPAC_pulse_cell','time_overshoot_whole_bPAC_pulse_cell','steady_state_bPAC_pulse_cell','ratio_overshoot_ss_bPAC_pulse_cell', ...
%                                   'num_samps_steady_state','num_samps_overshoot','num_samps_overshoot_whole');
% 
         


 %if exist('which_movie_array') == 0
  close all;
 %end;

mkdir(strcat(str_movie_processed_figures,'\statistics_plots\'));         
         
N_ratio = 10;
N_time = 10;
N_time_whole = 20;


if (ii_NM == ii_NM_bPAC)  % all emitter
    str_plot = 'b';
else
    str_plot = 'g';
end;



    do_just_first_pulse = 0;
if (do_just_first_pulse == 1)
    num_bPAC_pulses = 1;
end;

ratio_overshoot_dummy = [];
time_overshoot_dummy = [];
time_overshoot_whole_dummy = [];



ii_count = 0;

for idx = 1:num_nuclei_t0
     for ii = 1:num_bPAC_pulses     

         if (bPAC_pulse_cell(idx,ii) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)
             
             ratio_overshoot_dummy = [ratio_overshoot_dummy ratio_overshoot_ss_bPAC_pulse_cell(idx,ii)]; 
             time_overshoot_dummy = [time_overshoot_dummy time_overshoot_bPAC_pulse_cell(idx,ii)];  % minutes
             time_overshoot_whole_dummy = [time_overshoot_whole_dummy time_overshoot_whole_bPAC_pulse_cell(idx,ii)];  % minutes
             
             ii_count = ii_count+1;
             
             
         end;
  
     end;
     
     
end;


% correlated time of overshoot between two pulses in a given emitter
if (num_bPAC_pulses == 2)
    ii_count_corr = 0;
    ratio_overshoot_pulse1_dummy = [];
    time_overshoot_whole_pulse1_dummy = [];
    ratio_overshoot_pulse2_dummy = [];
    time_overshoot_whole_pulse2_dummy = [];
for idx = 1:num_nuclei_t0
    % for ii = 1:num_bPAC_pulses     

         if (max(bPAC_pulse_cell(idx,:)) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)
             
             ratio_overshoot_pulse1_dummy = [ratio_overshoot_pulse1_dummy ratio_overshoot_ss_bPAC_pulse_cell(idx,1)]; 
             time_overshoot_whole_pulse1_dummy = [time_overshoot_whole_pulse1_dummy time_overshoot_whole_bPAC_pulse_cell(idx,1)];  % minutes
             ratio_overshoot_pulse2_dummy = [ratio_overshoot_pulse2_dummy ratio_overshoot_ss_bPAC_pulse_cell(idx,2)]; 
             time_overshoot_whole_pulse2_dummy = [time_overshoot_whole_pulse2_dummy time_overshoot_whole_bPAC_pulse_cell(idx,2)];  % minutes
             
             ii_count_corr = ii_count_corr+1;
             
             
         end;
  
     %end;
     
     
end;
end;  % end of if (num_bPAC_pulses == 2)





[dist_ratio_overshoot, ratio] = hist(ratio_overshoot_dummy,N_ratio);

figure(1)
hold on;
plot(ratio, dist_ratio_overshoot,str_plot);
xlabel('overshoot to steady state ratio');
ylabel('number of cells');
title(strcat(str_movie,', number os samples: ',num2str(ii_count)));
xlim([0 max(abs(ratio))])
hold off;

[dist_time_overshoot, time_overshoot] = hist(time_overshoot_dummy,N_time);


[dist_time_overshoot_whole, time_overshoot_whole] = hist(time_overshoot_whole_dummy,N_time_whole);

figure(2)
hold on;
plot(time_overshoot_whole, dist_time_overshoot_whole,str_plot);
xlabel('time to overshoot (min.)');
ylabel('number of cells');
title(strcat(str_movie,', number os samples: ',num2str(ii_count)));
xlim([0 max(time_overshoot_whole)]);
hold off;

figure(3)
hold on;
%scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
scatter(ratio_overshoot_dummy, time_overshoot_whole_dummy,str_plot);
ylabel('time to overshoot (min.)');
%xlabel('log(overshoot to steady state ratio)');
xlabel('overshoot to steady state ratio');
title(strcat(str_movie,', number os samples: ',num2str(ii_count)));
hold off;
ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);
xlim([0 10]);


% added noise to scatter plot

time_overshoot_whole_dummy_RAND = 0*time_overshoot_whole_dummy;

for ii = 1:length(time_overshoot_whole_dummy)
    
    time_overshoot_whole_dummy_RAND(ii) = time_overshoot_whole_dummy(ii) + rand -.5; 
    
end;
location_vec = ones(length(time_overshoot_whole_dummy),1);


figure(4)
hold on;
%scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
scatter(location_vec, time_overshoot_whole_dummy_RAND,str_plot);
  ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND),std(time_overshoot_whole_dummy_RAND),'m');
  ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND),std(time_overshoot_whole_dummy_RAND)/sqrt(length(time_overshoot_whole_dummy_RAND)),'g');
  set(ss,'LineWidth',2);
    cap_width = .2;
  ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND)-std(time_overshoot_whole_dummy_RAND) mean(time_overshoot_whole_dummy_RAND)-std(time_overshoot_whole_dummy_RAND)],'m');
  set(ss,'LineWidth',2);
  ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND)+std(time_overshoot_whole_dummy_RAND) mean(time_overshoot_whole_dummy_RAND)+std(time_overshoot_whole_dummy_RAND)],'m');
  set(ss,'LineWidth',2);
  ss = scatter(location_vec(1),mean(time_overshoot_whole_dummy_RAND),'md');
  set(ss,'LineWidth',5);
  ss = scatter(location_vec(1),median(time_overshoot_whole_dummy_RAND),'yd');
  set(ss,'LineWidth',5);
ylabel('time to max (min.)');
xlabel(str_movie);
title(strcat('number of pulse samples/emitters: ',num2str(ii_count),'/',num2str(sum(bPAC_NUCLEUS_time_mapped_t0(:,1))),', median:',num2str(median(time_overshoot_whole_dummy_RAND)),',mean:',num2str(mean(time_overshoot_whole_dummy_RAND))));
hold off;
ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);
xlim([0 3]);


print('-depsc',strcat(str_movie_processed_figures,'\statistics_plots\',str_movie,'-time_to_overshoot.eps'));   


%  Make ppt of each time-to-overshoot data point showing where on the Erk Signal it was
%  extracted.



ii_count = 0;
do_PPT = 1;

cd(str_movie_processed)  % go the processed data folder of the specified movie
if (exist(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'))==2)
    do_make_ppt = input(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt exists, to you want to remake? 1-yes, 0 - no (or hit return)'));
else
    do_make_ppt = 1;
end;
cd(str_processing)  % go the processed data folder of the specified movie
   
if (do_make_ppt == 1)
%if (do_PPT == 1)
cd(str_movie_processed)  % go the processed data folder of the specified movie

for idx = 1:num_nuclei_t0
    
            if (bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)             
             figure(4);
             a1 = gca;
             f2 = figure;
             a2 = copyobj(a1,f2);
             h = gcf;
            end;
             
              if (idx==1)  % remove if file exists
              delete(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'));
              delete(strcat(str_movie,'-nuclear_Erk_signals_statistics_RECEIVERS.ppt'));
              delete(strcat(str_movie,'-nuclear_Erk_signals_statistics_ALL.ppt'));
              end;
             
     for ii = 1:num_bPAC_pulses     

         if (bPAC_pulse_cell(idx,ii) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)
             
                         
             ii_count = ii_count+1;
             
             hold on;
             if (ii==1)
              s1 = scatter(location_vec(ii_count), time_overshoot_whole_dummy_RAND(ii_count),'k');
              set(s1,'LineWidth',3);
              text(1.5,25, strcat('black: nuclei:', num2str(idx),', pulse number:',num2str(ii)));
             elseif (ii==2)
              s1 = scatter(location_vec(ii_count), time_overshoot_whole_dummy_RAND(ii_count),'c');
              set(s1,'LineWidth',3);
              text(1.5,20, strcat('cyan: nuclei:', num2str(idx),', pulse number:',num2str(ii)));
             end    
             hold off;
             
             
           
          
          %pause  % see all figures
             
         end;

         if (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)
         
              %do_PPT = 1;  % 0 - no, 1 - yes
              if (do_PPT ==1)&(ii == num_bPAC_pulses)
              % save the figures to a powerpoint slide
    
               if (exist('which_movie_array')==0)
                view_specific_Erk_cellular_response_to_bPAC_statistics;  % test here, uses idx             
                figH = figure(h);
                fig10000 = figure(10000)
                fig200 = figure(200)
                s_combine = strcat(str_movie,':nuclear Erk signals');
               saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
               saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_ALL.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
               % saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
                close(200)
                close(10000);
     
               % close duplicated scatter plot so the same figure number can
               % be reused
                close(figure(h));
               elseif (ii_round == num_rounds)
                   
                view_specific_Erk_cellular_response_to_bPAC_statistics;  % test here, uses idx             
                figH = figure(h);
                fig10000 = figure(10000)
                fig200 = figure(200)
                s_combine = strcat(str_movie,':nuclear Erk signals');
                saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
                saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_ALL.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
                % saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);

                if (num_rounds == 2)
                str_dir_dummy = pwd;
                cd(str_combined_stats_do_case);                
                   % full scatter plot of all combined data
                   figure(40)
                   hold on;
                   %scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
                   scatter(location_vec_array, time_overshoot_whole_dummy_RAND_array,str_plot);
                    ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND_array),std(time_overshoot_whole_dummy_RAND_array),'m');
                    set(ss,'LineWidth',2);
                      cap_width = .2;
                    ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND_array)-std(time_overshoot_whole_dummy_RAND_array) mean(time_overshoot_whole_dummy_RAND_array)-std(time_overshoot_whole_dummy_RAND_array)],'m');
                    set(ss,'LineWidth',2);
                    ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND_array)+std(time_overshoot_whole_dummy_RAND_array) mean(time_overshoot_whole_dummy_RAND_array)+std(time_overshoot_whole_dummy_RAND_array)],'m');
                    set(ss,'LineWidth',2);
                    ss = scatter(location_vec(1),mean(time_overshoot_whole_dummy_RAND_array),'md');
                    set(ss,'LineWidth',5);
                    ss = scatter(location_vec(1),median(time_overshoot_whole_dummy_RAND_array),'yd');
                    set(ss,'LineWidth',5);                   
                   ylabel('time to overshoot (min.)');
                   xlabel('combined movies');
                   title(strcat('combined movies, number of samples: ',num2str( sum(num_samples_array) ),', median:',num2str(median(time_overshoot_whole_dummy_RAND_array)))); 
                   hold off;
                   ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);                   
                   xlim([0 3]);
                fig40 = figure(40)
                saveppt2(strcat('combined_stats_do_case_',num2str(do_case),'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 fig40 figH], 'halign','center','title', s_combine);
                cd(str_dir_dummy)
                end;
                
                close(200)
                close(10000);
     
               % close duplicated scatter plot so the same figure number can
               % be reused
                close(figure(h));
               end;
 
               
             end; % if (do_PPT ==1)
             
         elseif (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==0)
         
              %do_PPT = 1;  % 0 - no, 1 - yes
              if (do_PPT ==1)&(ii == num_bPAC_pulses)
              % save the figures to a powerpoint slide
    
               if (exist('which_movie_array')==0)
                view_specific_Erk_cellular_response_to_bPAC_statistics;  % test here, uses idx             
                %figH = figure(h);
                fig10000 = figure(10000)
                fig200 = figure(200)
                s_combine = strcat(str_movie,':nuclear Erk signals');
               saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_RECEIVERS.ppt'),'figure',[fig10000 fig200], 'halign','center','title', s_combine);
               saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_ALL.ppt'),'figure',[fig10000 fig200], 'halign','center','title', s_combine);
               % saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
                close(200)
                close(10000);
     
               % close duplicated scatter plot so the same figure number can
               % be reused
                %close(figure(h));
               elseif (ii_round == num_rounds)
                   
                view_specific_Erk_cellular_response_to_bPAC_statistics;  % test here, uses idx             
                %figH = figure(h);
                fig10000 = figure(10000)
                fig200 = figure(200)
                s_combine = strcat(str_movie,':nuclear Erk signals');
                saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_RECEIVERS.ppt'),'figure',[fig10000 fig200], 'halign','center','title', s_combine);
                saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_ALL.ppt'),'figure',[fig10000 fig200], 'halign','center','title', s_combine);
                % saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
                
                close(200)
                close(10000);
     
               % close duplicated scatter plot so the same figure number can
               % be reused
                %close(figure(h));
               end;
 
               
             end; % if (do_PPT ==1)
             
         end; % end of 'if (sum(bPAC_pulse_cell(idx,:)) > 0)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)'
   

         
     end;  % end of 'for ii = 1:num_bPAC_pulses' 

     
     
     
end;


end; % end of 'if (do_make_ppt == 1)'




cd(str_processing);  % go back to processing code directory 'multicellular_movie_make_AVI'
%end;  % if (do_PPT == 1)





