%  load in acqdat.txt file


path_movie = strcat('..\multicellular_movies\',str_movie)

found_file_microscope = fileattrib(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'))

if (found_file_microscope == 1)  % movie has input_info.mat file
    
  load(strcat('..\multicellular_movies\',str_movie,'\input_info.mat'));
  
end;  
  
  
 % for jj = 1:numCh
 %         for kk = 1:length(measurement_order)
 %          if strcmp(eval(['CH',num2str(jj),'_str']),measurement_order(kk))==1
 %              eval(['CH',num2str(jj),'_str'])
 %              CH_to_measurement_order_map(jj) = kk;
 %              measurement_order(kk)
 %              jj
 %              kk
 %          end;
 %         end;
 %          
 %              numFr_CH(jj) = length(bPAC_ledvals);
 %         
 % end;
  


  
    
    numFr_CH = zeros(numCh,1);
    
    for jj = 1:numCh
       eval(['image_index_CH',num2str(jj),'=[];']); 
     for kk = 1:length(bPAC_ledvals)
      if(kk<10)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_00000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk<=99)&(kk>9)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_0000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk>99)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      end;  
      path_image
      found_file_image = fileattrib(path_image);
      if (found_file_image == 1)
       numFr_CH(jj) = numFr_CH(jj)+1;      
       eval(['image_index_CH',num2str(jj),'=[image_index_CH',num2str(jj),';kk];']); 
       IM = imread(path_image,'TIFF');
      end;
     end;
     
          eval(['M_CH',num2str(jj),'_total = int16(zeros(length(IM(:,1)),length(IM(1,:)),numFr_CH(',num2str(jj),')));']);
       
     for kk = 1:length(bPAC_ledvals)
      if(kk<10)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_00000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk<=99)&(kk>9)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_0000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      elseif(kk>99)
       path_image = strcat('..\multicellular_movies\',str_movie,'\img_000000',num2str(kk),'_',eval(['CH',num2str(jj),'_str']),'_p1_000.tif');
      end;  
      path_image
      found_file_image = fileattrib(path_image);
      if (found_file_image == 1)
       IM = imread(path_image,'TIFF');
        [val,kk_map] = min(abs(eval(['image_index_CH',num2str(jj)])-kk));
       eval(['M_CH',num2str(jj),'_total(:,:,kk_map) = IM(:,:);']);      
      end;
      
     end;
     
     
     eval(['numFr_CH(jj) =  length(image_index_CH',num2str(jj),');']);
    end;
    %for jj = 1:length(bPAC_ledvals)
    
xLength = length(IM(:,1))
yLength = length(IM(1,:))

    numCh_import = 1;
    numFr_NM = numFr_CH(ii_NM);

 numFr_import = sum(numFr_CH)

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  BEGIN: READ IN ACQUISITION TIMES FOR THE IMAGES
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  fids_txt = fopen(strcat('..\multicellular_movies\',str_movie,'\acqdat.txt'))
  ii_time_test = 1;
  ii_str_channel_test = 7
    
   for jj = 1:numCh     
       eval(['ii_count_CH',num2str(jj),' = 0;']);
       eval(['time_CH',num2str(jj),' = [];']);
       eval(['index_CH',num2str(jj),' = [];']);
   end;

 
 
    for ii = 1:numFr_import
       ii
     % format:  '%lf %d %lf %lf %lf %lf %s %d %d %d %s\n'
   if (do_cAMP_tests == 0)
   C = textscan(fids_txt,'%f %d %f %f %f %f %s %d %d %d %s\n')
   else
   C = textscan(fids_txt,'%f %d %f %f %f %f %s %d %s\n')
   end;
   time_test = C{ii_time_test}
   str_channel_test = C{ii_str_channel_test}
   
    for jj = 1:numCh     
     if (strcmp(str_channel_test,eval(['CH',num2str(jj),'_str']))==1)
        eval(['ii_count_CH',num2str(jj),' = ii_count_CH',num2str(jj),'+1;']);
        eval(['time_CH',num2str(jj),' = [time_CH',num2str(jj),';time_test];']);
        eval(['index_CH',num2str(jj),' = [index_CH',num2str(jj),';ii];']);
     end;
    end;

   end;
   fclose(fids_txt);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %  END: READ IN ACQUISITION TIMES FOR THE IMAGES
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%else  % older movies    

%  import_older_movies  
    
%end;





 

 

     
     
     

