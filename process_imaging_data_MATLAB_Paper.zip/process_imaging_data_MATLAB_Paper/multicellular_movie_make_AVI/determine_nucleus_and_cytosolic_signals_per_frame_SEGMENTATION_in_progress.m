%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  This function needs to be completed, but it has the basics for applying
%  the thresholding approach, binary file conversion that is used for the
%  nuclei.  Unfortunately, this one can only be used if the marker is
%  distinguisible from noise for all cells.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% To start:
num_pixels_tot_CELL = num_pixels_tot_NUCLEUS;




for ii = 1:xLength    
    for jj = 1:yLength
         val_dummy = M_marker_id_threshold(ii,jj);
        if (val_dummy > 0)
            nuclear_FITC_tot_time(val_dummy,which_frame) = nuclear_FITC_tot_time(val_dummy,which_frame) + M_FITC(ii,jj);
            nuclear_CY3_tot_time(val_dummy,which_frame) = nuclear_CY3_tot_time(val_dummy,which_frame) + M_CY3(ii,jj);
        end;
    end;
end;


% convert to average signal per pixel
for ii = 1:num_nuclei
            nuclear_FITC_tot_time(ii,which_frame) = nuclear_FITC_tot_time(ii,which_frame)/num_pixels_tot_NUCLEUS(ii);
            nuclear_CY3_tot_time(ii,which_frame) = nuclear_CY3_tot_time(ii,which_frame)/num_pixels_tot_NUCLEUS(ii);
end;


do_process_cytosolic_signals = 1;
if (do_process_cytosolic_signals == 1)
matrix_nucleus_SCRAP = 0*M_DAPI;
matrix_cytosol_SCRAP = 0*M_DAPI;
M_CELL_id_threshold_TEST = 0*M_DAPI;
M_CELL_id_threshold = 0*M_DAPI; 

box_coords_CELL = zeros(num_DAPI,4);


num_delta_phi = 20;
delta_phi_test = 2*pi/(num_delta_phi);

r_max = 200;

r_cross_section = 0:r_max;

x_boundary = zeros(num_delta_phi,1);
y_boundary = zeros(num_delta_phi,1);




      %M_FITC_threshold = 0*M_FITC;
      for idx = 1:num_nuclei_t0       
            idx_map   = index_map_tot_time_mapped_t0(idx,which_frame);          
          M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
      end;


      min_min_FITC = min(min(M_FITC));
      max_max_FITC = max(max(M_FITC));
      M_FITC_NORMALIZED = (M_FITC - min_min_FITC)/(max_max_FITC-min_min_FITC);
      M_FITC_NORMALIZED_adjusted = 0;

      M_FITC_binary = 0*M_FITC_NORMALIZED;
      
for iii = 1:num_nuclei_t0

matrix_nucleus_SCRAP = 0*matrix_cytosol_SCRAP;
matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
    
idx_map = index_map_tot_time_mapped_t0(iii,which_frame);    
    


x_coord_min = round(max(1,mean_x_tot_time_mapped_t0(iii,which_frame)-50));    
x_coord_max = round(min(xLength,mean_x_tot_time_mapped_t0(iii,which_frame)+50));        
y_coord_min = round(max(1,mean_y_tot_time_mapped_t0(iii,which_frame)-50));    
y_coord_max = round(min(yLength,mean_y_tot_time_mapped_t0(iii,which_frame)+50));    

matrix_nucleus_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
signal_nuclear_average = sum(sum(int16(M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max)).*int16(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max))))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
max_FITC_local = max(max(M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))


signal_normalized = (signal_nuclear_average - min_min_FITC)/(max_max_FITC-min_min_FITC);
threshold = .75*signal_normalized;

M_FITC_NORMALIZED_adjusted(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = min(0,M_FITC_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max)-signal_normalized);
for ii = x_coord_min:x_coord_max
 for jj = y_coord_min:y_coord_max
    
     if (M_FITC_NORMALIZED_adjusted(ii,jj) ==0 )
         M_FITC_NORMALIZED_adjusted(ii,jj) = -1e6;
         here = 1
     end;
     
 end;
end;
M_FITC_NORMALIZED_adjusted = M_FITC_NORMALIZED_adjusted + signal_normalized;

    M_FITC_binary(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_FITC_NORMALIZED(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold);   % convert to binary image
    %M_FITC_binary(x_coord_min:x_coord_max,y_coord_min:y_coord_max) = im2bw(M_FITC_NORMALIZED_adjusted(x_coord_min:x_coord_max,y_coord_min:y_coord_max),threshold);   % convert to binary image
    M_FITC_binary_FILL = bwareaopen(M_FITC_binary, nucleus_min_pixels);  % removie 
    M_FITC_binary_FILL = imfill(M_FITC_binary_FILL,'holes');    
    Cell_marker_FILL = bwconncomp(M_FITC_binary_FILL);
       %num_nuclei = length(cellfun(@numel,Cell_marker_FILL.PixelIdxList));
       %M_marker_id_threshold = 0*M_marker_threshold;     
       %for idx = 1:num_nuclei
       %  M_marker_id_threshold(Cell_marker_FILL.PixelIdxList{idx}) = idx;
       %end;

           figure(120)
           imagesc(M_FITC_binary_FILL);
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min y_coord_max]);
           ylim([x_coord_min x_coord_max]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');

           figure(121)
           imagesc(max(int16(M_FITC),int16(1.1*max_FITC_local*M_marker_threshold)));
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min y_coord_max]);
           ylim([x_coord_min x_coord_max]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');

           figure(122)
           imagesc(max(int16(M_FITC),int16(-1.1*max_FITC_local*M_marker_threshold)));
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min y_coord_max]);
           ylim([x_coord_min x_coord_max]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');
           pause;

end;
