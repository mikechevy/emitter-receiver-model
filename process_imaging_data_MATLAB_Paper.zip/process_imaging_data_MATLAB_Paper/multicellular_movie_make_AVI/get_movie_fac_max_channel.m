%if (count_clusters>0)
%    
%  size_bPAC_clusters = size_bPAC_clusters(1:count_clusters);
%  bPAC_clusters = bPAC_clusters(1:count_clusters,1:max(size_bPAC_clusters));
%    bPAC_clusters = [];
%    size_bPAC_clusters = [];
%end;
%size_non_bPAC_clusters = size_non_bPAC_clusters(1:count_clusters);
%non_bPAC_clusters = non_bPAC_clusters(1:count_clusters, 1:max(size_non_bPAC_clusters));
%non_bPAC_clusters
%size_non_bPAC_clusters
%bPAC_clusters_location = 0*bPAC_clusters;  % outside bPAC cells
%     if (num_adjacent_non_bPAC>=2)
%         bPAC_clusters_location(jjj,iii) = 1;
%     end;



fac_max_channel(ii_CH1) = .5;
fac_max_channel(ii_CH2) = .5;
fac_max_channel(ii_NM) = .3;

  
if which_movie == 47 % '190326_198-117_207-61_TEST_MC';
    
    
elseif  (which_movie == 60) % '190625_198-117_198_TEST'
     

elseif  (which_movie == 65) % '190716_198-117_198_TEST'
     
    
 elseif  (which_movie == 66) % '190726_198-117_198_TEST_MC'
     
    
 elseif  (which_movie == 68) % '190730_198-117_198_TEST_MC'

    
     
 elseif  (which_movie == 81) % '190823_198-117_198_TEST_MC_2'
     
 elseif  (which_movie == 91) % '190910_198-117_198_TEST_MC'
     

 elseif  (which_movie == 93) % '190912_198-117_198_TEST_MC'     
     
 elseif  (which_movie == 94) % '190912_198-117_198_TEST_MC_2'     
     
 elseif  (which_movie == 140) % '191213_198-117_198_MC_p23'
         
 elseif  (which_movie == 141) % '191213_198-117_198_MC_p23_2'
         
 elseif  (which_movie == 142) % '191217_198-117_198_MC_p26'
     
 elseif (which_movie == 155)  %  str_movie = '200213_198-117_198_MC_H89';    
        
     
 elseif (which_movie == 201) % '160902_198_198-117_EA'
     

elseif (which_movie == 79) % '190822_198-117_198_TEST_MC_BrA_2';    
    
elseif (which_movie == -1)
end;
  
