    time_str = 'time (seconds)';

    %close all
    

    
    
if (do_mean_or_full == 0)
 if (which_pathway == 0)  % Biological Oscillator
 time_data_sampled_dummy = time_mean/60;
 elseif (which_pathway == 1)  % bPAC/cAMP circuit   
  time_data_sampled_dummy = time_mean-5/scale_time_rates;
  if (max(time_data_sampled_dummy) > 600)
    time_data_sampled_dummy = time_data_sampled_dummy/60;  
    scale_time_data = 1;  %  - seconds, 1 - minutes, 2 = hours
    time_str = 'time (minutes)';
  end;
 end;
X_data_sampled = x_mean;
end;




for jjj = 1:length(size_bPAC_clusters)     
figure(33+jjj)
    %eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    %eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %%imshow(mat2gray(M_NM_bPAC));
    %eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    %eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %%imshow(mat2gray(M_NM));
    %%%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    %image_RGB = zeros(xLength,yLength,3);
    %image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    %image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    %imshow(image_RGB)
    imagesc(M_marker_threshold_TEST)
    
    title(strcat('bPAC cluster:',num2str(jjj)));
      for iii = 1:size_bPAC_clusters(jjj)
         idx = bPAC_clusters(jjj,iii);   
         which_frame = 1;
          if (bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx),'*'));           
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
          end;
         set(tt,'Color','w');
      end;
      for iii = 1:size_non_bPAC_clusters(jjj)
         idx = non_bPAC_clusters(jjj,iii);   
         tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
         set(tt,'Color','k');
      end;
      
        for iii = 1:length(index_group)
            for kkk = iii+1:length(index_group)
            
                if (mat_cAMP_gap(iii,kkk) == 1)
                    idx_iii = index_group(iii);
                    idx_kkk = index_group(kkk);
                   tt=line([mean_y_tot_time_mapped_t0(idx_iii,which_frame) mean_y_tot_time_mapped_t0(idx_kkk,which_frame)],[mean_x_tot_time_mapped_t0(idx_iii,which_frame) mean_x_tot_time_mapped_t0(idx_kkk,which_frame)]);           
                   set(tt,'Color','m');
                end;
        
            end;
        end;
    
end;




if (which_pathway == 0)  % Biological Oscillator

for kk = 1:num_runs

which_run = kk

% reset the sample counter
count_sampled=1;

        if (which_run == 1)

         max_which_signal = 0;
         which_signal = ii_R;

         if (do_mean_or_full == 0)
         elseif (do_mean_or_full == 1)
          sample_size_time = 60;
          index_time = 1:counts_data_final(kk)/sample_size_time:counts_data_final(kk)
          index_time = round(index_time);
         end;


     for ii = 1:num_cells
     for jj = ii+1:num_cells

             ii_count = ii*(num_cells)+jj;

          if (mat_A_gap(ii,jj) == 1)|(mat_R_gap(ii,jj)==1)
           figure(ii_count)
           subplot(3,1,1)
           hold on;
                  which_signal_dummy = ii_A;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_A),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_A),'g');
              title(strcat('cell-',num2str(ii),', cell-',num2str(jj),', A-coupling=',num2str(mat_A_gap(ii,jj)),', R-coupling=',num2str(mat_R_gap(ii,jj)) ));
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           ylabel('A(t)');
           subplot(3,1,2)
           hold on;
                  which_signal_dummy = ii_R;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_R),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_R),'g');
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           xlabel(time_str)
           ylabel('R(t)');
           subplot(3,1,3)
           hold on;
              max_signal_dummy = 1;
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_A),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_R),'g');
           hold off;
           legend('A coupling inhibitor','R coupling inhibitor');
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.5]);
           xlabel(time_str)
           ylabel('I(t)');

          end; % if (mat_A_gap(ii,jj) == 1)|(mat_R_gap(ii,jj)==1)

         max_which_signal = max(max_which_signal,max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal))))




     end; % for jj = ii+1:num_cells
     end; % for ii = 1:num_cells




end;  % for jj = 1:num_runs
end;  % for ii = 1:num_runs

elseif (which_pathway == 1)  %  bPAC/cAMP circuit

for kk = 1:num_runs

which_run = kk

% reset the sample counter
count_sampled=1;


        if (which_run == 1)

         max_which_signal = 0;
         which_signal = ii_cAMP;

         if (do_mean_or_full == 0)
         elseif (do_mean_or_full == 1)
          sample_size_time = 60;
          index_time = 1:counts_data_final(kk)/sample_size_time:counts_data_final(kk)
          index_time = round(index_time);
         end;


     for ii = 1:num_cells
     for jj = 1:num_cells

         ii_count = ii*(num_cells)+jj;
         
      if (index_group(ii) == which_cell_to_plot(1))&(index_group(jj)==which_cell_to_plot(2))       
          
          %if (mat_cAMP_gap(ii,jj) == 1)|(mat_Calcium_gap(ii,jj)==1)
           figure(ii_count)
           subplot(3,1,1)
           hold on;
                  which_signal_dummy = ii_cAMP;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_cAMP),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_cAMP),'g');
              title(strcat('cell-',num2str(ii),', cell-',num2str(jj),', cAMP-coupling=',num2str(mat_cAMP_gap(ii,jj)),', Calcium-coupling=',num2str(mat_Calcium_gap(ii,jj)) ));
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           ylabel('cAMP(t)');
           subplot(3,1,2)
           hold on;
                  which_signal_dummy = ii_PKA_on;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_PKA_on),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_PKA_on),'g');
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           xlabel(time_str)
           ylabel('PKA_on(t)');
           subplot(3,1,3)
           hold on;
              max_signal_dummy = 1;
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_cAMP_gap),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_Calcium_gap),'g');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_bPAC),'m');
           hold off;
           legend('cAMP coupling inhibitor','Calcium coupling inhibitor','bPAC');
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.5]);
           xlabel(time_str)
           ylabel('I(t)');
           
           
           figure(10*ii_count)
           subplot(3,1,1)
           hold on;
                  which_signal_dummy = ii_cAMP;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)/num_cAMP),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)/num_cAMP));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_cAMP)/num_cAMP,'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_cAMP)/num_cAMP,'g');
              title(strcat('cell-',num2str(ii),', cell-',num2str(jj),', cAMP-coupling=',num2str(mat_cAMP_gap(ii,jj)),', Calcium-coupling=',num2str(mat_Calcium_gap(ii,jj)) ));
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           ylabel('cAMP(t)');
           subplot(3,1,2)
           hold on;
                  which_signal_dummy = ii_PKA_on;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)/num_PKA),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)/num_PKA));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_PKA_on)/num_PKA,'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_PKA_on)/num_PKA,'g');
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           xlabel(time_str)
           ylabel('PKA_on(t)');
           subplot(3,1,3)
           hold on;
              max_signal_dummy = 1;
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_cAMP_gap),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_Calcium_gap),'g');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_bPAC),'m');
           hold off;
           legend('cAMP coupling inhibitor','Calcium coupling inhibitor','bPAC');
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.5]);
           xlabel(time_str)
           ylabel('I(t)');
           

           figure(100*ii_count)
           subplot(3,1,1)
           hold on;
                  which_signal_dummy = ii_ERKKTR_n;
                  which_signal_dummy = ii_ERK_off;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy),'g');
              title(strcat('cell-',num2str(ii),', cell-',num2str(jj),', cAMP-coupling=',num2str(mat_cAMP_gap(ii,jj)),', Calcium-coupling=',num2str(mat_Calcium_gap(ii,jj)) ));
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           %ylim([0 1.1*max_signal_dummy]);
           ylabel('ERKKTR_n(t)');
           subplot(3,1,2)
           hold on;
                  which_signal_dummy = ii_GJ_complex_on;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy),'g');
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           xlabel(time_str)
           ylabel('GJ_complex_on(t)');
           subplot(3,1,3)
           hold on;
              max_signal_dummy = 1;
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_cAMP_gap),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_Calcium_gap),'g');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_bPAC),'m');
           hold off;
           legend('cAMP coupling inhibitor','Calcium coupling inhibitor','bPAC');
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.5]);
           xlabel(time_str)
           ylabel('I(t)');
                     
          
           figure(1000*ii_count)
           subplot(3,1,1)
           hold on;
                  which_signal_dummy = ii_ERKKTR_n;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)/num_ERKKTR),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)/num_ERKKTR));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_ERKKTR_n)/num_ERKKTR,'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_ERKKTR_n)/num_ERKKTR,'g');
              title(strcat('cell-',num2str(ii),', cell-',num2str(jj),', cAMP-coupling=',num2str(mat_cAMP_gap(ii,jj)),', Calcium-coupling=',num2str(mat_Calcium_gap(ii,jj)) ));
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           %ylim([0 1.1*max_signal_dummy]);
           ylabel('ERKKTR_n(t)');
           subplot(3,1,2)
           hold on;
                  which_signal_dummy = ii_GJ_complex_on;
                  max_signal_dummy = max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal_dummy)/num_GJ_complex),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal_dummy)/num_GJ_complex));
              plot(time_data_sampled_dummy,X_data_sampled(:,(ii-1)*num_molecules_cell+ii_GJ_complex_on)/num_GJ_complex,'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,(jj-1)*num_molecules_cell+ii_GJ_complex_on)/num_GJ_complex,'g');
              legend(strcat('cell-',num2str(index_group(ii))),strcat('cell-',num2str(index_group(ii+1))));
           hold off;
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.1*max_signal_dummy]);
           xlabel(time_str)
           ylabel('GJ_complex_on(t)');
           subplot(3,1,3)
           hold on;
              max_signal_dummy = 1;
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_cAMP_gap),'r');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_Calcium_gap),'g');
              plot(time_data_sampled_dummy,X_data_sampled(:,ii_I_bPAC),'m');
           hold off;
           legend('cAMP coupling inhibitor','Calcium coupling inhibitor','bPAC');
           xlim([0 time_data_sampled_dummy(length(time_data_sampled_dummy))]);
           ylim([0 1.5]);
           xlabel(time_str)
           ylabel('I(t)');
           
          %end; % if (mat_cAMP_gap(ii,jj) == 1)|(mat_Calcium_gap(ii,jj)==1)
      end; % if (index_group(ii) == 28)&(index_group(jj)==29)       

          

         max_which_signal = max(max_which_signal,max(max(X_data_sampled(:,(ii-1)*num_molecules_cell+which_signal)),max(X_data_sampled(:,(jj-1)*num_molecules_cell+which_signal))))




     end; % for jj = 1:num_cells
     end; % for ii = 1:num_cells




end;  % if (which_run == )
end;  % for kk = 1:num_runs







end;



