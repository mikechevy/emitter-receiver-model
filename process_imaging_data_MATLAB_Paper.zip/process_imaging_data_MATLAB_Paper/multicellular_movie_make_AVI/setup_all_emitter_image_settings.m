%if (count_clusters>0)
%    
%  size_bPAC_clusters = size_bPAC_clusters(1:count_clusters);
%  bPAC_clusters = bPAC_clusters(1:count_clusters,1:max(size_bPAC_clusters));
%    bPAC_clusters = [];
%    size_bPAC_clusters = [];
%end;
%size_non_bPAC_clusters = size_non_bPAC_clusters(1:count_clusters);
%non_bPAC_clusters = non_bPAC_clusters(1:count_clusters, 1:max(size_non_bPAC_clusters));
%non_bPAC_clusters
%size_non_bPAC_clusters
%bPAC_clusters_location = 0*bPAC_clusters;  % outside bPAC cells
%     if (num_adjacent_non_bPAC>=2)
%         bPAC_clusters_location(jjj,iii) = 1;
%     end;

do_BF_channel = 0;  % when making images: 0-no (use ERK-KTR), 1-yes (use BF) 

do_full_range_ylim = 0;  % 1- individual plots are have their ylims adjusted based on the on signals, 0 - just their own

  
if which_movie == 105 % '191202_198-117_TEST_MC_p23'

    scale_Erk_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels
  
elseif which_movie == 109 % '191210_198-117_MC_p23_same'
    
    scale_Erk_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_channel = 1.0;  % for RGB image of 3 channels
    scale_NM_bPAC_channel = 1.0;  % for RGB image of 3 channels

   do_BF_channel = 0;
    scale_BF_channel = .750;  % for RGB image of 3 channels
    
elseif which_movie == 174 % '200621_198-117_p26'
    
elseif which_movie == 174 % '200621_198-117_p26_2_samecells'
    
elseif (which_movie == -1)

end;
  
