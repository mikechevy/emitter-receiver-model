
              
       
       if (which_pathway==0)  % Oscillator
 
        x_0_mean = 0*x_0_mean;
        x_0_mean(1:num_molecules) = y_0ss

       elseif (which_pathway==1)  
        
        
       end;
