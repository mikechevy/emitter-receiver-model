str_species = ['k' 'b' ];
str_pulse = ['r' 'g' ];

if (do_transfer_function_pulse == 0)
 time_pulse_start = 40;
 time_pulse_stop = 80;
elseif (do_transfer_function_pulse == 1)
 time_pulse_start = 15;
 time_pulse_stop = 21;
end;



[val index_pulse_start] = min(abs(time_bPAC/scale_factor_time - time_pulse_start));
[val index_pulse_stop] = min(abs(time_bPAC/scale_factor_time - time_pulse_stop));

for ii_plot = 1:length(ii_Species_to_plot_array)


if (do_ALL_bPAC == 0)  % emitter/receiver tissue   
       
pathway_str_global = pwd;
cd(pathway_str_global);
addpath(pathway_str_global);

if (do_run_specific_examples == 0)
 mkdir(strcat('image_model_runs\',str_movie_write,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('image_model_runs\',str_movie_write,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
else
 mkdir(strcat('specific_examples\',str_specific_example,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('specific_examples\',str_specific_example,'\ER\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
end;

    
    signal_average_bPAC_cluster = signal_average_bPAC_cluster_array(:,ii_plot);  
        delta_signal_average_bPAC_cluster = max(signal_average_bPAC_cluster) - min(signal_average_bPAC_cluster);
      signal_average_bPAC_cluster = (signal_average_bPAC_cluster - min(signal_average_bPAC_cluster))/delta_signal_average_bPAC_cluster;
    
    signal_average_non_bPAC_cluster = signal_average_non_bPAC_cluster_array(:,ii_plot);
      signal_average_non_bPAC_cluster = (signal_average_non_bPAC_cluster - min(signal_average_non_bPAC_cluster))/delta_signal_average_bPAC_cluster;
    signal_average_non_bPAC_cluster_inner = signal_average_non_bPAC_cluster_inner_array(:,ii_plot);
      signal_average_non_bPAC_cluster_inner = (signal_average_non_bPAC_cluster_inner - min(signal_average_non_bPAC_cluster_inner))/delta_signal_average_bPAC_cluster;
    signal_average_non_bPAC_cluster_outer = signal_average_non_bPAC_cluster_outer_array(:,ii_plot);
      signal_average_non_bPAC_cluster_outer = (signal_average_non_bPAC_cluster_outer - min(signal_average_non_bPAC_cluster_outer))/delta_signal_average_bPAC_cluster;
    
    
 figure(jjj+500)
 subplot(3,1,1)
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster,str_species(ii_plot));                
 set(ss,'LineWidth',2);
 ss = plot(time_bPAC(index_pulse_start:index_pulse_stop)/scale_factor_time,signal_average_bPAC_cluster(index_pulse_start:index_pulse_stop),str_pulse(ii_plot));                
 set(ss,'LineWidth',2);
 % if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
 %  ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster_outer,'k');                
 %  set(ss,'LineWidth',2);
 %  ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster_inner,'r');
 %  set(ss,'LineWidth',2);
 %  legend('all bPAC cells','outer bPAC cells', 'inner bPAC cells');
 % else
 %  legend('all bPAC cells');
 % end;
 set(ss,'LineWidth',2);
  if (ii_plot == 2)
   legend('cAMP','during pulse', 'ERK-KTR N/C', 'during pulse');
   text(.05*max(time_Erk)/scale_factor_time, .25, 'emitters');
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 %title(strcat('bPAC cluster:',num2str(jjj)));
    if (do_GJ2 == 1)
    title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
    else
    title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),',which GJ model=',num2str(which_GJ_model)));
    end;
   ylabel('normalized signal');
   end;

 xlim([0 max(time_Erk)/scale_factor_time]);
  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
  % ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
  % ylim([min(signal_average_bPAC_cluster) 1.1*max(signal_average_bPAC_cluster)]);
  %end;
%      sig_dummy = signal_average_bPAC_cluster;
%      ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
ylim([0 1.1]);

 hold off;
 subplot(3,1,2);
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_inner,str_species(ii_plot));
% ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster,str_species(ii_plot));
 set(ss,'LineWidth',2);
 ss = plot(time_bPAC(index_pulse_start:index_pulse_stop)/scale_factor_time,signal_average_non_bPAC_cluster_inner(index_pulse_start:index_pulse_stop),str_pulse(ii_plot));
 set(ss,'LineWidth',2);
  %if (sum(non_bPAC_clusters_location(jjj,1:size_non_bPAC_clusters(jjj))) ~= size_non_bPAC_clusters(jjj))   
  % ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_inner,str_which_GJ_model);
  % set(ss,'LineWidth',2);
  % ss = plot(time_bPAC/scale_factor_time,signal_average_non_bPAC_cluster_outer,'k');                
  % set(ss,'LineWidth',2);
  % legend('all non-bPAC cells','adjacent non-bPAC', 'separated non-bPAC cells');
  %else
  % legend('all non-bPAC cells');
  %end;
  if (ii_plot == 2)
   legend('cAMP','during pulse', 'ERK-KTR N/C','during pulse');
   text(.05*max(time_Erk)/scale_factor_time, .25, 'adj. receivers');
  end;
 set(ss,'LineWidth',2);
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_non_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 ylabel('normalized signal');
 xlim([0 max(time_Erk)/scale_factor_time]);
%  if (sum(non_bPAC_clusters_location(jjj,1:size_non_bPAC_clusters(jjj))) ~= size_non_bPAC_clusters(jjj))   
%   ylim([min([min(signal_average_non_bPAC_cluster) min(signal_average_non_bPAC_cluster_outer) min(signal_average_non_bPAC_cluster_inner)]) 1.1*max([max(signal_average_non_bPAC_cluster) max(signal_average_non_bPAC_cluster_outer) max(signal_average_non_bPAC_cluster_inner)]) ]);
%  else
%   ylim([min(signal_average_non_bPAC_cluster) max(signal_average_non_bPAC_cluster)]);
%  end;
%    sig_dummy = signal_average_bPAC_cluster;
%    sig_dummy_non_bPAC = signal_average_non_bPAC_cluster_outer;
%    delta_non_bPAC =  max(0, 1.1*(max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))- min(sig_dummy_non_bPAC)))
%    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))-delta_non_bPAC min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))-delta_non_bPAC]);
ylim([0 1.1]);
  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
   %ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
   %ylim([min(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster)]);
  %end;
 hold off;
 subplot(3,1,3)
 ylabel('bPAC');
 for ii_input_plot = 1:num_inputs_plot
 hold on;
 if (ii_input_plot == 2)&(num_inputs_plot == 3)
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
 else
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
 end;
 set(ss,'LineWidth',2);
 hold off;
 end;
 xlim([0 max(time_Erk)/scale_factor_time]);
 ylim([0 1.1]);
 ylabel('inputs');
 text(.05*max(time_Erk)/scale_factor_time, .25, str_specific_example);
 xlabel(str_time_representation);
  if (num_inputs_plot == 1)
      legend(str_input_plot1);
  elseif (num_inputs_plot == 2)
      legend(str_input_plot1,str_input_plot2);
  elseif (num_inputs_plot == 3)
      legend(str_input_plot1,str_input_plot2,str_input_plot3);
  end;
 hold off;

   subplot(3,1,2);
  %if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
  % ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
  %else
  % ylim([min(signal_average_bPAC_cluster) 1.1*max(signal_average_bPAC_cluster)]);
  %end;
    sig_dummy = signal_average_bPAC_cluster;
    sig_dummy_non_bPAC = signal_average_non_bPAC_cluster_outer;
    delta_non_bPAC =  max(0, 1.1*(max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))- min(sig_dummy_non_bPAC)))
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy))-delta_non_bPAC min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))-delta_non_bPAC]);
    
%   print('-depsc',strcat(str_Species_to_plot,'_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   print('-depsc',strcat('Compare_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   
                      if (do_PPT ==1)
                       % save the figures to a powerpoint slide

                       fig110 = figure(110+jjj)
                       fig501 = figure(500+jjj)
                       s_combine = 'average signals of bPAC and non-bPAC cells ';
   
                       saveppt2(strcat(str_Species_to_plot,'_average_signals_bPAC_cluster-',str_movie,'.ppt'),'figure',[fig110 fig501], 'halign','center','title', s_combine);
                     
                      ii_figure_count = 1;
                      
                      end; % if (do_PPT ==1)
   

cd(pathway_str_global);
                      


elseif (do_ALL_bPAC == 1)  % all emitter tissue
    
pathway_str_global = pwd;
cd(pathway_str_global);
addpath(pathway_str_global);


if (do_run_specific_examples == 0)
 if( do_transfer_function_pulse == 0)
 mkdir(strcat('image_model_runs\',str_movie_write,'\E\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('image_model_runs\',str_movie_write,'\E\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 elseif( do_transfer_function_pulse == 1)
 mkdir(strcat('image_model_runs\',str_movie_write,'\Ep\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('image_model_runs\',str_movie_write,'\Ep\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 end;
else
 if( do_transfer_function_pulse == 0)
 mkdir(strcat('specific_examples\',str_specific_example,'\E\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('specific_examples\',str_specific_example,'\E\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 elseif( do_transfer_function_pulse == 1)
 mkdir(strcat('specific_examples\',str_specific_example,'\Ep\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 cd(strcat('specific_examples\',str_specific_example,'\Ep\Reg_',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),'_I_',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),'_WM_',num2str(which_model)));
 end;    
end;


    signal_average_bPAC_cluster = signal_average_bPAC_cluster_array(:,ii_plot);  
        delta_signal_average_bPAC_cluster = max(signal_average_bPAC_cluster) - min(signal_average_bPAC_cluster);
      signal_average_bPAC_cluster = (signal_average_bPAC_cluster - min(signal_average_bPAC_cluster))/delta_signal_average_bPAC_cluster;

    
 figure(jjj+500)
 subplot(3,1,1)
 hold on;
 ss = plot(time_bPAC/scale_factor_time,signal_average_bPAC_cluster,str_species(ii_plot));                
 set(ss,'LineWidth',2);
 ss = plot(time_bPAC(index_pulse_start:index_pulse_stop)/scale_factor_time,signal_average_bPAC_cluster(index_pulse_start:index_pulse_stop),str_pulse(ii_plot));                
 set(ss,'LineWidth',2);
 
%   legend('all bPAC cells');
 set(ss,'LineWidth',2);
     %for ii = 1:num_bPAC_pulses     
     %    s_pulse = ['g' 'r'];
     % ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,signal_average_bPAC_cluster(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
     %          set(ss,'LineWidth',3);
     %end;
 %title(strcat('bPAC cluster:',num2str(jjj)));
  if (ii_plot == 2)
   legend('cAMP','during pulse', 'ERK-KTR N/C', 'during pulse');
 text(.05*max(time_Erk)/scale_factor_time, .25, 'emitters');

  %if (do_GJ2 == 1)
  %title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89)));
  %else
  %title(strcat(str_Species_to_plot,' signal, bPAC cluster:',num2str(jjj),', Reg:',num2str(fac_ac_pk),num2str(fac_c_pd),num2str(fac_pk_pd),num2str(fac_gj_pk),',I:',num2str(fac_I_bPAC), num2str(fac_I_cAMP_gap),num2str(fac_I_Calcium_gap),num2str(fac_I_IBMX),num2str(fac_I_H89),',which GJ model=',num2str(which_GJ_model)));
  %end; 
  title(str_which_case_simulation);
  end;
  
 ylabel('normalized signal');
 xlim([0 max(time_Erk)/scale_factor_time]);
 
 if do_transfer_function_pulse == 1
      do_model_fit = 0; % 1 - yes, 0 - no
      max_time_model_fit = 40;
  if do_model_fit == 1
    xlim([0 max_time_model_fit]);
  end    
 end;
  
 % if (sum(bPAC_clusters_location(jjj,1:size_bPAC_clusters(jjj))) ~= size_bPAC_clusters(jjj))   
 %  ylim([min([min(signal_average_bPAC_cluster) min(signal_average_bPAC_cluster_outer) min(signal_average_bPAC_cluster_inner)]) 1.1*max([max(signal_average_bPAC_cluster) max(signal_average_bPAC_cluster_outer) max(signal_average_bPAC_cluster_inner)]) ]);
 % else
 %  ylim([min(signal_average_bPAC_cluster) 1.1*max(signal_average_bPAC_cluster)]);
 % end;
       sig_dummy = signal_average_bPAC_cluster;
      ylim([0 1.1]);
 hold off;
 subplot(3,1,3)
 ylabel('bPAC');
 for ii_input_plot = 1:num_inputs_plot
 hold on;
 if (ii_input_plot == 2)&(num_inputs_plot == 3)
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),strcat(s_input(num_inputs_plot-ii_input_plot+1),'--'));
 else
   ss = plot(time_bPAC/scale_factor_time,X_data_sampled(:,which_inputs_plot(ii_input_plot)),s_input(num_inputs_plot-ii_input_plot+1));
 end;
 set(ss,'LineWidth',2);
 hold off;
 end;
 xlim([0 max(time_Erk)/scale_factor_time]);
  if do_transfer_function_pulse == 1
   if do_model_fit == 1
     xlim([0 max_time_model_fit]);
   end
  end;
 ylim([0 1.1]);
 ylabel('inputs');
 xlabel(str_time_representation);
 text(.05*max(time_Erk)/scale_factor_time, .25, str_specific_example);
  if (num_inputs_plot == 1)
      legend(str_input_plot1);
  elseif (num_inputs_plot == 2)
      legend(str_input_plot1,str_input_plot2); 
  elseif (num_inputs_plot == 3)
       legend(str_input_plot1,str_input_plot2,str_input_plot3);
   end;
  hold off;
%    print('-depsc',strcat(str_Species_to_plot,'_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));

   if (do_propagation_delay == 0) % 0 -default (no), 1- show specific cell results (for Reviewer 2)
    print('-depsc',strcat('Compare_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   elseif (do_propagation_delay == 1) % 0 -default (no), 1- show specific cell results (for Reviewer 2)       
    print('-depsc',strcat('Reviewer2_Compare_average_signals-cluster_',num2str(jjj),'-',str_movie,'.eps'));
   end;
cd(pathway_str_global);
                      
end;

end; % for ii_plot = 1:length(ii_Specties_to_plot_array)



                 % if (do_PPT ==1)
                          
                       cd(strcat('specific_examples\'));   
                       % save the figures to a powerpoint slide

                       fig110 = figure(111)
                       fig501 = figure(501)
                       

   
                 if (do_parameter_sweep == 0)
                      if (do_IBMX == 0)
                       if (do_ALL_bPAC == 0)
                        str_PPT = strcat(str_specific_example,'_average_signals_bPAC_cluster-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 0)
                        str_PPT = strcat(str_specific_example,'_ALL_EMITTER_average_signals_bPAC-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 1)
                        str_PPT = strcat(str_specific_example,'_ALL_EMITTER_TF_average_signals_bPAC-',str_movie,'.ppt');
                       end;
                      elseif (do_IBMX == 1)
                       if (do_ALL_bPAC == 0)
                        str_PPT = strcat(str_specific_example,'_IBMX_average_signals_bPAC_cluster-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 0)
                        str_PPT = strcat(str_specific_example,'_IBMX_ALL_EMITTER_average_signals_bPAC-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 1)
                        str_PPT = strcat(str_specific_example,'_IBMX_ALL_EMITTER_TF_average_signals_bPAC-',str_movie,'.ppt');
                       end;                          
                      end;
                        delete(str_PPT);
                      saveppt2(str_PPT,'figure',[fig501], 'halign','center','title', str_which_case_simulation);
                 elseif (do_parameter_sweep == 1)
                       s_combine = str_parameter_sweep_values;
                      if (do_IBMX == 0)
                       if (do_ALL_bPAC == 0)
                        str_PPT = strcat(str_specific_example,'_which_sweep_',num2str(which_sweep),'_average_signals_bPAC_cluster-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 0)
                        str_PPT = strcat(str_specific_example,'_which_sweep_',num2str(which_sweep),'_ALL_EMITTER_average_signals_bPAC-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 1)
                        str_PPT = strcat(str_specific_example,'_which_sweep_',num2str(which_sweep),'_ALL_EMITTER_TF_average_signals_bPAC-',str_movie,'.ppt');
                       end;
                      elseif (do_IBMX == 1)
                       if (do_ALL_bPAC == 0)
                        str_PPT = strcat(str_specific_example,'_which_sweep_',num2str(which_sweep),'_IBMX_average_signals_bPAC_cluster-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 0)
                        str_PPT = strcat(str_specific_example,'_which_sweep_',num2str(which_sweep),'_IBMX_ALL_EMITTER_average_signals_bPAC-',str_movie,'.ppt');
                       elseif (do_ALL_bPAC == 1)&(do_transfer_function_pulse == 1)
                        str_PPT = strcat(str_specific_example,'_which_sweep_',num2str(which_sweep),'_IBMX_ALL_EMITTER_TF_average_signals_bPAC-',str_movie,'.ppt');
                       end;                          
                      end;
                      if (count_parameter_sweep == 1)
                        delete(str_PPT);
                      end;
                      saveppt2(str_PPT,'figure',[fig501], 'halign','center','title', s_combine);
                 end;
                      
              %  figH = figure(h);
              %  fig10000 = figure(10000)
              %  fig200 = figure(200)
              %  s_combine = strcat(str_movie,':nuclear Erk signals');
              %  saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_EMITTERS.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
              %  saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics_ALL.ppt'),'figure',[fig10000 fig200 figH], 'halign','center','title', s_combine);
                      
                      
                     
                      ii_figure_count = 1;
                      
                       cd(pathway_str_global);
                      
                 % end; % if (do_PPT ==1)
                 %end; % if (do_parameter_sweep == 1)




