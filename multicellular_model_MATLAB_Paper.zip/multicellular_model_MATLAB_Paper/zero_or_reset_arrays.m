



    m_n_old = m_n;   % save current timestep

    % zero or reset some arrays    
    m_n = 0*m_n;
    m_jx = 0*m_jx;
    m_jy = 0*m_jy;
    m_jz = 0*m_jz;
    m_jx_abs = 0*m_jx_abs;
    m_jy_abs = 0*m_jy_abs;
    m_jz_abs = 0*m_jz_abs;
    m_cm = 0*m_cm+m_bm + NO_ID_PART;

