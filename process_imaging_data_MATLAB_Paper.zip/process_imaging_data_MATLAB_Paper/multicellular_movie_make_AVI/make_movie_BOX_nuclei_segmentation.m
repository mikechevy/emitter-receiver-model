do_make_movie = 1;  % 1 - yes, 0 - no

    % set initial values
    x_coord_min = 1;
    x_coord_max = xLength;
    y_coord_min = 1;
    y_coord_max = yLength
    fac_max = 1;

M_CH1 = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);

M_NM_segmented = zeros(xLength,yLength);
M_CM_segmented = zeros(xLength,yLength);
    
get_movie_fac_max_channel;  % gets the adjusted dynamic range of each channel from a given movie

scale_factor_time = 60;  % minutes

channel_make_movie = ii_CH1;
%channel_make_movie = ii_NM;
%channel_make_movie = ii_NM_bPAC;

%found_file_BOX = fileattrib(strcat(str_movie_processed,'\x_y_box_fac_max_segmentation.mat'))

%if (found_file_BOX == 1)
%    load(strcat(str_movie_processed,'\x_y_box_fac_max_segmentation.mat'));
%end;
    
time_Erk = time_CH1

          
which_channel = 1;    
which_frame_CH = 1;
M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(:,:,:)']))))*int16(ones(xLength,yLength));
 test_box = [];       
 
fac_max = fac_max_channel(ii_CH1);

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN:iteratively setup the range of interest
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
              rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  test_box = input('does the box size work? 1-for yes,otherwise hit return')
  
 while (length(test_box)==0)          
  x_coord_min = input(strcat('please set x_min of image (current value:',num2str(x_coord_min),'):'));
  x_coord_max = input(strcat('please set x_max of image (current value:',num2str(x_coord_max),'):'));
  y_coord_min = input(strcat('please set y_min of image (current value:',num2str(y_coord_min),'):'));
  y_coord_max = input(strcat('please set y_max of image (current value:',num2str(y_coord_max),'):'));
  %[x_coord_min x_coord_max y_coord_min y_coord_max] = input('please set range of image')
  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
              rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');
  test_box = input('does the box size work? 1-for yes,otherwise hit return.')
 end;


% test_fac_max = [];       
%  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
%              rectangle('Position', [y_coord_min,x_coord_min,...
%                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
%                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
%                      'EdgeColor', 'm');
%  test_fac_max  = input('does the intensity range work? 1-for
%  yes,otherwise hit return.')
% while (length(test_fac_max)==0)          
%  fac_max = input(strcat('please set fac_max between 0 and 1 (current value:',num2str(fac_max),'):'));
%  imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
%              rectangle('Position', [y_coord_min,x_coord_min,...
%                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
%                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
%                      'EdgeColor', 'm');
%  test_fac_max  = input('does the intensity range work? 1-for yes,otherwise hit return.')
% end;

% save(strcat(str_movie_processed,'\x_y_box_fac_max.mat'),'x_coord_min','x_coord_max','y_coord_min','y_coord_max','fac_max')

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % END: iteratively setup the range of interest
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN: FIND Nuclei within the BOX
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (length(num_nuclei_t0) > 0) 
 label_cluster_only = 0; % 1 - yes, 0 - no
if (label_cluster_only == 1)
    index_group = zeros(length(size_cluster(which_cluster)),1);
for iii = 1:size_cluster(which_cluster)
      index_group(iii) = cluster(which_cluster,iii); 
end;
else % label all cells within the box
  ii_count = 0;
index_group = [];
which_frame = 1;
 for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,which_frame) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,which_frame) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,which_frame) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,which_frame) <= y_coord_max)
      index_group = [index_group ; iii]; 
      ii_count = ii_count+1;
    end;% end;
end;
end;
end; % if (length(num_nuclei_t0) > 0) 


 
 
ii_CM_segmented = 1000;
ii_NM_segmented = 2000;
ii_CM_NM_segmented = 3000;
 
 which_channels = [signal_channels(1) ii_NM ii_CM_segmented ii_NM_segmented ii_CM_NM_segmented];

frame_direction = 1;  % start in the up direction

%for ppp = 1:length(which_channels);

for kk = 1:length(which_channels)
    
    which_channel = which_channels(kk);
      if (which_channels(kk) == ii_CM_segmented)|(which_channels(kk) == ii_NM_segmented)|(which_channels(kk) == ii_CM_NM_segmented)
          which_channel = ii_NM;
      end;
      
    which_frame_CH = 1;
    which_frame = 1;
    
           if (do_make_movie == 1)
            if (which_channels(kk) == ii_CH1)
              %filename_movie = strcat(str_movie_processed,'\CH1_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
              filename_movie = strcat(str_movie_processed,'\SEGMENTATION_CM_CH1_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channels(kk) == ii_CH2)
              %filename_movie = strcat(str_movie_processed,'\CH2_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channels(kk) == ii_NM)
              filename_movie = strcat(str_movie_processed,'\SEGMENTATION_CH_NUCLEI_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channels(kk) == ii_CM_segmented)
              filename_movie = strcat(str_movie_processed,'\SEGMENTATION_RING_CH_NUCLEI_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channels(kk) == ii_NM_segmented)
              filename_movie = strcat(str_movie_processed,'\SEGMENTATION_NUCLEI_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
              %filename_movie = strcat(str_movie_processed,'\SEGMENTATION_NUCLEI_CH_NUCLEI_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            elseif (which_channels(kk) == ii_CM_NM_segmented)
              filename_movie = strcat(str_movie_processed,'\SEGMENTATION_RING_SEGMENTATION_NUCLEI_movie_',num2str(x_coord_min),'_',num2str(x_coord_max),'_',num2str(y_coord_min),'_',num2str(y_coord_max),'_',num2str(fac_max),'_',str_movie);
            end;
          delete(strcat(filename_movie,'.avi'));
          %mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',floor(numFr_CH(ii_CH1)/20));
          mov = VideoWriter(strcat(filename_movie,'.avi'));%,'COMPRESSION','None','FPS',floor(numFr_CH(ii_CH1)/20));
          mov.FrameRate = 10;
          end;
open(mov);
    
if (which_channel == ii_CH1)|(which_channel == ii_CH2)|(which_channel == ii_NM)
 fac_max =  fac_max_channel(which_channel)
end;
    
%  if (kk > 1) 
%      
%    M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(x_coord_min:x_coord_max,y_coord_min:y_coord_max,which_frame)']))))*int16(ones(xLength,yLength));
%    fac_max = 1;
%    imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
%                rectangle('Position', [y_coord_min,x_coord_min,...
%                        y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
%                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
%                       'EdgeColor', 'm');
%      
%    test_fac_max  = input('does the intensity range work? 1-for
%    yes,otherwise hit return.')
%
%   while (length(test_fac_max)==0)          
%    fac_max = input(strcat('please set fac_max between 0 and 1 (current value:',num2str(fac_max),'):'));
%    imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
%                rectangle('Position', [y_coord_min,x_coord_min,...
%                        y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
%                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
%                       'EdgeColor', 'm');
%   test_fac_max  = input('does the intensity range work? 1-for yes,otherwise hit return.')
%   end;
%  end;
    

  

for ii = 1:numFr_CH(which_channel)

which_frame = ii;



    eval(['[val,which_frame_NM]= min(abs(time_CH',num2str(which_channel),'(which_frame)-time_CH',num2str(ii_NM),'));']);     


M_max = max(max(max(eval(['M_CH',num2str(which_channel),'_total(x_coord_min:x_coord_max,y_coord_min:y_coord_max,which_frame)']))))*int16(ones(xLength,yLength));

    ii_figure = 1000+which_channel
    %if (which_channel == channel_make_movie)
      H = figure(1000+which_channel)  
    %else
    %  figure(1000+which_channel)  
    %end;
  
    
    eval(['[val,which_frame_CH]= min(abs(time_CH',num2str(which_channel),'(which_frame)-time_CH',num2str(which_channel),'));']);     

    which_frame
    numFr_CH(which_channel)
    which_frame_CH
    

    %if (length(which_channels) == 2)|(ii_NM == ii_NM_bPAC)
      subplot(5,2,[1:8]);      
      %subplot(4,2,[1:6]);
    %elseif (length(which_channels) == 3)
    %  subplot(2,2,kk);
    %end;
      
        
  %%imagesc(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame),fac_max*M_max)']));
  if (which_channel == ii_CH1)
    % imshow(mat2gray(eval(['min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max)'])));
    eval(['M_CH1(:,:) = min(M_CH',num2str(which_channel),'_total(:,:,which_frame_CH),fac_max*M_max);']);
  elseif (which_channel == ii_CH1)
    % nothing for now
  elseif (which_channel == ii_NM) % movie of emitter/receiver nuclei
       eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(ii_NM),'(which_frame_CH)-time_CH',num2str(ii_NM_bPAC),'));']);     
       eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
       eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,which_frame);']);
  end;   
       
       M_CM_segmented = 0*M_CM_segmented;
       M_NM_segmented = 0*M_NM_segmented;

       for idx = 1:num_nuclei_t0
       
           val_merge = .3;
           
               idx_map = index_map_tot_time_mapped_t0(idx,which_frame_NM);
   
           
        M_CM_segmented(eval(['Cell_cytosol_FILL_',num2str(which_frame_NM),'.PixelIdxList{idx_map}'])) = val_merge;
        
        %% M_NM_segmented(eval(['Cell_nucleus_FILL_',num2str(which_frame_signal),'.PixelIdxList{idx_map}'])) = val_merge;
        if (which_nuclei_signal_type == 1) % shrink
         M_NM_segmented(eval(['Cell_shrink_nucleus_FILL_',num2str(which_frame_NM),'.PixelIdxList{idx_map}'])) = val_merge;
        elseif (which_nuclei_signal_type == 2) % intersect
         M_NM_segmented(eval(['Cell_intersect_nucleus_FILL_',num2str(which_frame_NM),'.PixelIdxList{idx_map}'])) = val_merge;
        elseif (which_nuclei_signal_type == 3) % circle
         M_NM_segmented(eval(['Cell_circle_nucleus_FILL_',num2str(which_frame_NM),'.PixelIdxList{idx_map}'])) = val_merge;
        end;
        
       end; % for idx = 1:num_nuclei_t0
            
       
    
       image_RGB = zeros(xLength,yLength,3);
         if (which_channels(kk) == ii_CH1)
         image_RGB(:,:,2) = .5*M_CH1(:,:)/(fac_max*(max(max(M_CH1))));
         image_RGB(:,:,3) = .5*M_CM_segmented(:,:)/max(max(M_CM_segmented));         
         elseif (which_channels(kk) == ii_NM)
         image_RGB(:,:,1) = M_NM(:,:)/(fac_max*(max(max(M_NM))));
         elseif (which_channels(kk) == ii_CM_segmented)
         image_RGB(:,:,1) = M_NM(:,:)/(fac_max*(max(max(M_NM))));
         image_RGB(:,:,3) = M_CM_segmented(:,:)/max(max(M_CM_segmented));         
         elseif (which_channels(kk) == ii_NM_segmented)
         %image_RGB(:,:,1) = .5*M_NM(:,:)/(fac_max*(max(max(M_NM))));
         image_RGB(:,:,3) = M_NM_segmented(:,:)/max(max(M_NM_segmented));         
         elseif (which_channels(kk) == ii_CM_NM_segmented)
         image_RGB(:,:,2) = M_NM_segmented(:,:)/max(max(M_NM_segmented));         
         image_RGB(:,:,3) = M_CM_segmented(:,:)/max(max(M_CM_segmented));         
         end;
       imshow(image_RGB)
  if (length(num_nuclei_t0)>0)
     hold on;                 
    for jjj = 1:length(index_group)
       idx = index_group(jjj);
       
    eval(['[val,which_frame_NM]= min(abs(time_CH',num2str(which_channel),'(which_frame)-time_CH',num2str(ii_NM),'));']);     
       
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame_NM);
       
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             %set(ll,'Color','m');

             
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),strcat(num2str(idx)));
             %tt = text(mean_y_tot_time_mapped_t0(idx,which_frame_NM),mean_x_tot_time_mapped_t0(idx,which_frame_NM),'.');
             if ii_NM == ii_NM_bPAC  % all bPAC cells
               set(tt,'Color','w');
               %set(tt,'fontsize',12);
             else
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','w');
               else
               set(tt,'Color','y');
               end;
             end;
    end;
   hold off;  
  end;   % end of 'if (length(num_nuclei_t0)>0)'
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

  
 % if (marker_from_channel(ii_Erk_marker)>0)&(ii == 1)
 %     title(strcat('Erk signal',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % elseif (marker_from_channel(ii_Ca_marker)>0)&(ii == 1)
 %     title(strcat('Erk signal',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % elseif (ii == 2)
 %     title(strcat('Nuclear marker',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % elseif (ii_NM~=ii_NM_bPAC)&(ii == 3)
 %     title(strcat('bPAC marker',', time =',num2str(time_Erk(ii)/scale_factor_time),' minutes'))
 % end;
      
  
  
      subplot(5,2,[9 10]);
      %subplot(4,2,[7 8]);
      ylabel('bPAC');
      hold on;
      plot(time_bPAC/scale_factor_time,bPAC_ledvals);
       if (which_channel == ii_CH1)
         plot([time_CH1(which_frame)/scale_factor_time time_CH1(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       elseif (which_channel == ii_CH2)
         plot([time_CH2(which_frame)/scale_factor_time time_CH2(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       elseif (which_channel == ii_CH3)
         plot([time_CH3(which_frame)/scale_factor_time time_CH3(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       elseif (which_channel == ii_CH4)
         plot([time_CH4(which_frame)/scale_factor_time time_CH4(which_frame)/scale_factor_time],[0 1.1*max(bPAC_ledvals)],'k--'); 
       end;
      hold off;
      
      xlim([0 max(time_CH1)/scale_factor_time]);
      ylim([0 1.1*max(bPAC_ledvals)]);
      xlabel('minutes');

    if (do_make_movie == 1)%&(which_channel == channel_make_movie)
    %H = gcf;
    F = getframe(H);                    
    %mov = addframe(mov,F);
    writeVideo(mov,F);
    end;
  
    if (do_make_figure == 1)%&(which_channel == channel_make_movie)    
  
       if min(abs(which_frame-which_frames_to_save))==0
           
         if kk <= length(signal_channels)
           print(strcat(str_movie_processed,'\CH',num2str(which_channel),'_',num2str(fac_max),'_',str_movie,'_which_frame',num2str(which_frame),'.eps'),'-depsc');
         elseif (which_channels(kk) == ii_NM) % movie of emitter/receiver nuclei
           print(strcat(str_movie_processed,'\CH_NUCLEI_',num2str(fac_max),'_',str_movie,'_which_frame',num2str(which_frame),'.eps'),'-depsc');
         end;
         
       end;
       
    end;
    
    
    close(ii_figure)
   
end;



  
end;

%end;  % for ppp = 1:length(which_channels);


             %mov = close(mov)
             close(mov)
