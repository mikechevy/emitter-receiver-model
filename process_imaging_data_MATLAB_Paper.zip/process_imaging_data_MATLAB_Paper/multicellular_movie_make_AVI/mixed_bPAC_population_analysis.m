
M_marker_threshold_TEST = zeros(xLength,yLength);
M_marker_threshold_TEST_bPAC = zeros(xLength,yLength);
M_marker_threshold_TEST_dummy = zeros(xLength,yLength);

% mapped bPAC nuclei to all the frames of the nuclear marker
bPAC_NUCLEUS_time_mapped_t0 = 0*x_coord_min_tot_NUCLEUS_time_mapped_t0;  
% mapped bPAC nuclei in a given bPAC nuclei measured frame
bPAC_NUCLEUS_time_mapped_t0_TEST = 0*x_coord_min_tot_NUCLEUS_time_mapped_t0(:,1:length(eval(['time_CH',num2str(ii_NM_bPAC)])));

if ii_NM == ii_NM_bPAC  % all bPAC cells
 
    bPAC_NUCLEUS_time_mapped_t0 = bPAC_NUCLEUS_time_mapped_t0 +1;  % all ones
    
else
    
for kkk = 1:length(eval(['time_CH',num2str(ii_NM_bPAC)]))
  
    eval(['[val,index_frame]= min(abs(time_CH',num2str(ii_NM_bPAC),'(kkk)-time_CH',num2str(ii_NM),'));']);     
     which_frame = index_frame;
     which_frame_bPAC = kkk;
  
  
  num_nuclei_time_bPAC(which_frame_bPAC);
  num_nuclei_time(which_frame);
  
  
  


 for jjj = 1:num_nuclei_time_bPAC(kkk)
     idx_map = jjj;
       if (idx_map > 0)
        M_marker_threshold_TEST_bPAC(eval(['Cell_nucleus_bPAC_FILL_',num2str(which_frame_bPAC),'.PixelIdxList{idx_map}'])) =   1;
       end;
                  
 end;
  
 %for jjj = 1:num_nuclei_time(kkk)
 for jjj = 1:num_nuclei_t0
     idx = jjj;
     which_nucleus = idx;
     
     M_marker_threshold_TEST = 0*M_marker_threshold_TEST;

     
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
       
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame));
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame));
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame));
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame));
       
       M_marker_threshold_TEST_dummy = M_marker_threshold_TEST+M_marker_threshold_TEST_bPAC;
       sum_TEST_dummy = sum(sum(M_marker_threshold_TEST_dummy(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/(x_coord_max-x_coord_min+1)*(y_coord_max-y_coord_min+1);
       sum_TEST = sum(sum(M_marker_threshold_TEST(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/(x_coord_max-x_coord_min+1)*(y_coord_max-y_coord_min+1);
       if (sum_TEST_dummy/sum_TEST > bPAC_NM_to_NM_ratio )  
        % the above metric corresponds to at least half the pixes are bPAC pixels as well
        bPAC_NUCLEUS_time_mapped_t0_TEST(which_nucleus,which_frame_bPAC) = 1;
        
        figure(111)
        imagesc(M_marker_threshold_TEST_dummy)
        title(strcat('which frame:',num2str(which_frame)));
            rectangle('Position', [y_coord_min,x_coord_min,...
                                   y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                                  'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                                  'EdgeColor', 'm');
        
       else
           
       end;
       
       
 end;

     M_marker_threshold_TEST = 0*M_marker_threshold_TEST;
 %for jjj = 1:num_nuclei_time(kkk)
 for jjj = 1:num_nuclei_t0
     idx = jjj;
     which_nucleus = idx;
     

     
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end; 
 
 
figure(1000)
imagesc(M_marker_threshold_TEST_bPAC);
figure(1001)
imagesc(M_marker_threshold_TEST);
 %for jjj = 1:num_nuclei_time(kkk)
 for jjj = 1:num_nuclei_t0
     idx = jjj;
     which_nucleus = idx;
       if ( bPAC_NUCLEUS_time_mapped_t0_TEST(which_nucleus,which_frame_bPAC) == 1)
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                                 set(tt,'Color','y');
       end;
 end;

figure(1002)
imagesc(M_marker_threshold_TEST_bPAC+M_marker_threshold_TEST);


%pause
which_frame 
end;
  

%  if a given nucleus has the bPAC marker most of the time, we will enforce
%  it to be a bPAC nucleus all the time
for which_nucleus = 1:num_nuclei_t0
     if  (mean(bPAC_NUCLEUS_time_mapped_t0_TEST(which_nucleus,:)) > fac_bPAC_percentage )
       bPAC_NUCLEUS_time_mapped_t0(which_nucleus,:) = 1;     
     end;
    
end;

      num_nuc_bPAC_before = sum(bPAC_NUCLEUS_time_mapped_t0(:,1))
      pause

  do_Erk_different_colors = 0;
  
  if (do_Erk_different_colors == 1)
   % if bPAC cells has a different color Erk marker
   if (marker_from_channel(ii_Erk_bPAC_marker) > 0)
      eval(['Erk_bPAC_str = CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_str']);

      num_nuc_bPAC_before = sum(bPAC_NUCLEUS_time_mapped_t0(:,1))

      
        % calculate thresholed
       Erk_RFP_none = 0;
       
      if strcmp(Erk_bPAC_str, 'RFP')==1
       for which_nucleus = 1:num_nuclei_t0
           if  (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) == 0)            
             %Erk_RFP_threshold = Erk_RFP_threshold +  eval(['mean(nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(which_nucleus,:))']);
             Erk_RFP_none = Erk_RFP_none +  eval(['mean(nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(which_nucleus,:))']);
           end;
           
       end;
           Erk_RFP_none = Erk_RFP_none/(num_nuclei_t0 - sum(bPAC_NUCLEUS_time_mapped_t0(:,1)))              
      elseif strcmp(Erk_bPAC_str, 'GFP')==1
       for which_nucleus = 1:num_nuclei_t0
           if  (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) == 1)            
             %Erk_RFP_threshold = Erk_RFP_threshold +  eval(['mean(nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(which_nucleus,:))']);
             Erk_RFP_none = Erk_RFP_none +  eval(['mean(nuclear_CH',num2str(marker_from_channel(ii_Erk_marker)),'_tot_time_mapped_t0(which_nucleus,:))']);
           end;
           
       end;
           Erk_RFP_none = Erk_RFP_none/sum(bPAC_NUCLEUS_time_mapped_t0(:,1))              
      end;
       
           lower = 4/5;
           upper = 1-lower;
           mean_average_nuclear = eval(['mean(average_nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time)'])
           Erk_RFP_threshold  =   lower*Erk_RFP + upper*mean_average_nuclear
            
           
      eval(['CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_str']);
      
       for which_nucleus = 1:num_nuclei_t0
          if strcmp(Erk_bPAC_str, 'RFP')==1
           if  (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) ~= 1)&(eval(['mean(nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(which_nucleus,:))']) > Erk_RFP_threshold)
             bPAC_NUCLEUS_time_mapped_t0(which_nucleus,:) = 1;     
           end;
          elseif strcmp(Erk_bPAC_str, 'GFP')==1
           if  (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) ~= 1)&(eval(['mean(nuclear_CH',num2str(marker_from_channel(ii_Erk_bPAC_marker)),'_tot_time_mapped_t0(which_nucleus,:))']) < Erk_RFP_threshold)
             bPAC_NUCLEUS_time_mapped_t0(which_nucleus,:) = 1;     
           end;
          end;
    
       end;    
                  
   end;
     
     
      num_nuc_bPAC_after = sum(bPAC_NUCLEUS_time_mapped_t0(:,1)) 
      pause
  end;   % if (do_Erk_different_colors == 1)

end;  % if ii_NM == ii_NM_bPAC  % all bPAC cells
  
  
save(strcat(str_movie_processed,'\bPAC_nuclei_mapped_FINAL'),'bPAC_NUCLEUS_time_mapped_t0');
  
  
  