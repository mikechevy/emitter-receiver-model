


function y_prime = moments_short(t,y)

global num_molecules;
global num_reactions;
global stochasticity;
global stochasticity_conj;
%global reaction_constant;
global propensities;
global sign_value_reaction;
global reaction_type;
global reaction_molecules;
global molecule_gene;
global c_mu;

global do_zero_order_hybrid;
global do_covariances;
global do_cov_nonlin;
global do_quadratic_terms;
global covariance_map;
global count_cov_map;
global Cov_mat;
global species_restricted;
global species_restricted_conj;

global species_cov;
global species_cov_conj;
global which_distribution;

global der_1_unr;
global der_2_unr;

global species_cov;
global species_cov_conj;

global freq_tv;
global time_constant_tv;
global c_mu_tv;
global phase_c_mu_tv;
global c_mu_0;
global do_prop_time_vary;

global time;


%  maps for the moment calculations in the hybrid code
global num_prop_deriv1;    
global prop_deriv1_map;    
global num_prop_deriv2;    
global prop_deriv2_map;    

global length_time_u_array;
global max_time;
global which_time_segment;
global which_time_segment;
global freq_tv_time_array;
global time_constant_tv_time_array;
global c_mu_tv_time_array;
global phase_c_mu_tv_time_array;
global c_mu_0_time_array;
global do_prop_time_vary_time_array;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  experimental moment data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global covariance_map_moments;
global num_cov_moments_data;
global dt_moments_data_sampled;
global time_moments_data_sampled;
global moments_data_sampled;
global include_moment_data_map;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  inputs data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global do_read_inputs_data;  % allows the input species' to be updated over time from a file or array
global time_inputs_data_sampled;
global inputs_data_sampled;
global map_inputs_data_sampled;


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  BEGIN: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 if (do_read_inputs_data == 1)  
     
  for ii = 1:length(map_inputs_data_sampled)
    [val,index_min] = min(abs(t-time_inputs_data_sampled(ii,:)));
       if (time_inputs_data_sampled(ii,index_min) > t)
           index_lower_data = index_min-1;
       else
         index_lower_data = index_min;
       end;         
     
      if (index_lower_data < length(time_inputs_data_sampled(ii,:)))
       upper_data = (t-time_inputs_data_sampled(ii,index_lower_data))/(time_inputs_data_sampled(ii,index_lower_data+1)-time_inputs_data_sampled(ii,index_lower_data));
       lower_data = 1-upper_data;
      else
       index_lower_data = length(time_inputs_data_sampled(ii,:))-1;
       upper_data = 1;
       lower_data = 1-upper_data;
      end;
      
    which_input = map_inputs_data_sampled(ii);
    y(which_input) = lower_data*inputs_data_sampled(ii,index_lower_data) + upper_data*inputs_data_sampled(ii,index_lower_data+1);
    
  end; % for ii = 1:length(map_inputs_data_sampled)
  
 end; % if (do_read_intputs_data == 1)
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  END: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


y_prime = zeros(1,length(y));





calculate_reaction_constants(y);

%  mass-action equations here, we might make this more efficient, maybe

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% BEGIN: medium way
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for ii = 1:num_molecules
        for jj = 1:num_reactions                  
         y_prime(ii) = y_prime(ii) + sign_value_reaction(jj,ii)*propensities(jj);       
        end;        
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% END: medium way
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

y_prime = y_prime';



