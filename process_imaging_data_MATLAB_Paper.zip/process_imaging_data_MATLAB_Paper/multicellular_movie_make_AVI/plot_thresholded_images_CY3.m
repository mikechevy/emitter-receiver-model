       event_x_tot = event_x_tot_CY3; 
       event_y_tot = event_y_tot_CY3;
       event_id_tot = event_id_tot_CY3; 
       event_size_tot = event_size_tot_CY3; 
       event_start_tot = event_start_tot_CY3; 
       mean_x_tot = mean_x_tot_CY3; 
       mean_y_tot = mean_y_tot_CY3; 
       var_x_tot = var_x_tot_CY3; 
       var_y_tot = var_y_tot_CY3; 
       cov_xy_tot = cov_xy_tot_CY3; 
       box_coords = box_coords_CY3; 
       num_nucleus = num_CY3; 
       M_marker_threshold = M_CY3_threshold;
       
       M_signal_threshold = M_FITC;

       which_box = num_nucleus

figure(200)
imagesc(M_marker_threshold)
hold on;
          for iii = 1:which_box
                 
                 x_coord_min = box_coords(iii,1);
                 x_coord_max = box_coords(iii,2);
                 y_coord_min = box_coords(iii,3);
                 y_coord_max = box_coords(iii,4);

             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
                    
                  M_dummy = zeros(2,2);  
                  M_dummy(1,1) = var_x_tot(iii); 
                  M_dummy(2,2) = var_y_tot(iii); 
                  M_dummy(1,2) = cov_xy_tot(iii); 
                  M_dummy(2,1) = cov_xy_tot(iii); 
                  [U_dummy L_dummy] = eig(M_dummy);
                  %angle_ellipse = angle(U_dummy(1:2));
                  angle_ellipse = angle([U_dummy(1,2); U_dummy(1:1)])+90;  % might not be correct, CORRECT THIS!!!!
              ellipse(sqrt(L_dummy(2,2)), sqrt(L_dummy(1,1)), angle_ellipse, mean_y_tot(iii), mean_x_tot(iii));   
          end;
hold off;
          
          

          
figure(201)
imagesc(max(M_marker_threshold,M_signal_threshold))
          for iii = 1:which_box
                 
                 x_coord_min = box_coords(iii,1);
                 x_coord_max = box_coords(iii,2);
                 y_coord_min = box_coords(iii,3);
                 y_coord_max = box_coords(iii,4);

             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
                    
          end;
