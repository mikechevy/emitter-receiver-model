         %  overshoot_bPAC_pulse_cell(idx,ii);
         %  index_overshoot_bPAC_pulse_cell(idx,ii);
         %  time_overshoot_bPAC_pulse_cell(idx,ii);
         % steady_state_bPAC_pulse_cell(idx,ii);
         % ratio_overshoot_ss_bPAC_pulse_cell(idx,ii);  
         
         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  FILE for bPAC statistics
%
%  num_bPAC_pulses
%  bPAC_pulse_cell(idx,ii)
%  overshoot_bPAC_pulse_cell(idx,ii);
%  index_overshoot_bPAC_pulse_cell(idx,ii);
%  time_overshoot_bPAC_pulse_cell(idx,ii);
% steady_state_bPAC_pulse_cell(idx,ii);
% ratio_overshoot_ss_bPAC_pulse_cell(idx,ii);          
% save('bPAC_statistics_arrays','num_bPAC_pulses','bPAC_pulse_cell','overshoot_bPAC_pulse_cell','index_overshoot_bPAC_pulse_cell','index_overshoot_whole_bPAC_pulse_cell', ...
%                                   'time_overshoot_bPAC_pulse_cell','time_overshoot_whole_bPAC_pulse_cell','steady_state_bPAC_pulse_cell','ratio_overshoot_ss_bPAC_pulse_cell', ...
%                                   'num_samps_steady_state','num_samps_overshoot','num_samps_overshoot_whole');
% 
         


 %if exist('which_movie_array') == 0
 % close all;
 %end;

mkdir(strcat(str_movie_processed_figures,'\statistics_plots_annotated\'));         
         
N_ratio = 10;
N_time = 10;
N_time_whole = 20;


if (ii_NM == ii_NM_bPAC)  % all emitter
    str_plot = 'b';
else
    str_plot = 'g';
end;



    do_just_first_pulse = 0;
if (do_just_first_pulse == 1)
    num_bPAC_pulses = 1;
end;

ratio_overshoot_dummy = [];
time_overshoot_dummy = [];
time_overshoot_whole_dummy = [];
time_max_to_ss_bPAC_pulse_cell_dummy = [];



ii_count = 0;

for idx = 1:num_nuclei_t0
     for ii = 1:num_bPAC_pulses     

         %if ((bPAC_pulse_cell(idx,ii) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1))
         %if ((bPAC_pulse_cell(idx,ii) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1))|((just_nuclei_not_to_use==1)&(min(abs(idx-nuclei_not_to_use))>0))
         if (min(min(abs(idx-bPAC_clusters)))==0)
             
         %%if (max(bPAC_pulse_cell(idx,:)) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1)
             
             ratio_overshoot_dummy = [ratio_overshoot_dummy ratio_overshoot_ss_bPAC_pulse_cell(idx,ii)]; 
             time_overshoot_dummy = [time_overshoot_dummy time_overshoot_bPAC_pulse_cell(idx,ii)];  % minutes
             time_overshoot_whole_dummy = [time_overshoot_whole_dummy time_overshoot_whole_bPAC_pulse_cell(idx,ii)];  % minutes
             time_max_to_ss_bPAC_pulse_cell_dummy = [time_max_to_ss_bPAC_pulse_cell_dummy time_max_to_ss_bPAC_pulse_cell(idx,ii)];
             
             ii_count = ii_count+1

         %%end;
             
         end;

     end;
     
     
end;


% correlated time of overshoot between two pulses in a given emitter
if (num_bPAC_pulses == 2)
    ii_count_corr = 0;
    ratio_overshoot_pulse1_dummy = [];
    time_overshoot_whole_pulse1_dummy = [];
    ratio_overshoot_pulse2_dummy = [];
    time_overshoot_whole_pulse2_dummy = [];
for idx = 1:num_nuclei_t0
    % for ii = 1:num_bPAC_pulses     

         if ((max(bPAC_pulse_cell(idx,:)) == 1)&(bPAC_NUCLEUS_time_mapped_t0(idx,1)==1))|(min(min(abs(idx-bPAC_clusters)))==0)
             
             ratio_overshoot_pulse1_dummy = [ratio_overshoot_pulse1_dummy ratio_overshoot_ss_bPAC_pulse_cell(idx,1)]; 
             time_overshoot_whole_pulse1_dummy = [time_overshoot_whole_pulse1_dummy time_overshoot_whole_bPAC_pulse_cell(idx,1)];  % minutes
             ratio_overshoot_pulse2_dummy = [ratio_overshoot_pulse2_dummy ratio_overshoot_ss_bPAC_pulse_cell(idx,2)]; 
             time_overshoot_whole_pulse2_dummy = [time_overshoot_whole_pulse2_dummy time_overshoot_whole_bPAC_pulse_cell(idx,2)];  % minutes
             ii_count_corr = ii_count_corr+1;
             
             
         end;
  
     %end;
     
     
end;
end;  % end of if (num_bPAC_pulses == 2)





[dist_ratio_overshoot, ratio] = hist(ratio_overshoot_dummy,N_ratio);

figure(1)
hold on;
plot(ratio, dist_ratio_overshoot,str_plot);
xlabel('overshoot to steady state ratio');
ylabel('number of cells');
title(strcat(str_movie,', number os samples: ',num2str(ii_count)));
xlim([0 max(abs(ratio))])
hold off;

[dist_time_overshoot, time_overshoot] = hist(time_overshoot_dummy,N_time);


[dist_time_overshoot_whole, time_overshoot_whole] = hist(time_overshoot_whole_dummy,N_time_whole);

figure(2)
hold on;
plot(time_overshoot_whole, dist_time_overshoot_whole,str_plot);
xlabel('time to overshoot (min.)');
ylabel('number of cells');
title(strcat(str_movie,', number os samples: ',num2str(ii_count)));
xlim([0 max(time_overshoot_whole)]);
hold off;

figure(3)
hold on;
%scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
scatter(ratio_overshoot_dummy, time_overshoot_whole_dummy,str_plot);
ylabel('time to overshoot (min.)');
%xlabel('log(overshoot to steady state ratio)');
xlabel('overshoot to steady state ratio');
title(strcat(str_movie,', number os samples: ',num2str(ii_count)));
hold off;
ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);
xlim([0 10]);


% added noise to scatter plot

time_overshoot_whole_dummy_RAND = 0*time_overshoot_whole_dummy;

for ii = 1:length(time_overshoot_whole_dummy)
    
    time_overshoot_whole_dummy_RAND(ii) = time_overshoot_whole_dummy(ii) + rand -.5; 
    
end;
location_vec = ones(length(time_overshoot_whole_dummy),1);


figure(4)
hold on;
%scatter(log(ratio_overshoot_dummy), time_overshoot_dummy,str_plot);
scatter(location_vec, time_overshoot_whole_dummy_RAND,str_plot);
  ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND),std(time_overshoot_whole_dummy_RAND),'m');
  ss = errorbar(location_vec(1),mean(time_overshoot_whole_dummy_RAND),std(time_overshoot_whole_dummy_RAND)/sqrt(length(time_overshoot_whole_dummy_RAND)),'g');
  set(ss,'LineWidth',2);
    cap_width = .2;
  ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND)-std(time_overshoot_whole_dummy_RAND) mean(time_overshoot_whole_dummy_RAND)-std(time_overshoot_whole_dummy_RAND)],'m');
  set(ss,'LineWidth',2);
  ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_overshoot_whole_dummy_RAND)+std(time_overshoot_whole_dummy_RAND) mean(time_overshoot_whole_dummy_RAND)+std(time_overshoot_whole_dummy_RAND)],'m');
  set(ss,'LineWidth',2);
  ss = scatter(location_vec(1),mean(time_overshoot_whole_dummy_RAND),'md');
  set(ss,'LineWidth',5);
  ss = scatter(location_vec(1),median(time_overshoot_whole_dummy_RAND),'yd');
  set(ss,'LineWidth',5);
ylabel('time to max (min.)');
xlabel(str_movie);
title(strcat('number of pulse samples/emitters: ',num2str(ii_count),'/',num2str(sum(size_bPAC_clusters)),', median:',num2str(median(time_overshoot_whole_dummy_RAND)),',mean:',num2str(mean(time_overshoot_whole_dummy_RAND)),',std:',num2str(std(time_overshoot_whole_dummy_RAND))));
hold off;
ylim([0 floor((max(num_samps_overshoot_whole)+9)/10)*10 ]);
xlim([0 3]);


print('-depsc',strcat(str_movie_processed_figures,'\statistics_plots_annotated\',str_movie,'-time_to_overshoot_annotated.eps'));   


location_vec = ones(length(ratio_overshoot_dummy),1);

ratio_overshoot_dummy = abs(ratio_overshoot_dummy);

figure(222)
hold on;
scatter(location_vec, abs(ratio_overshoot_dummy),str_plot);
   ss = errorbar(location_vec(1),mean(ratio_overshoot_dummy),std(ratio_overshoot_dummy),'m');
   ss = errorbar(location_vec(1),mean(ratio_overshoot_dummy),std(ratio_overshoot_dummy)/sqrt(length(ratio_overshoot_dummy)),'g');
   set(ss,'LineWidth',2);
     cap_width = .2;
   ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(ratio_overshoot_dummy)-std(ratio_overshoot_dummy) mean(ratio_overshoot_dummy)-std(ratio_overshoot_dummy)],'m');
   set(ss,'LineWidth',2);
   ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(ratio_overshoot_dummy)+std(ratio_overshoot_dummy) mean(ratio_overshoot_dummy)+std(ratio_overshoot_dummy)],'m');
   set(ss,'LineWidth',2);
   ss = scatter(location_vec(1),mean(ratio_overshoot_dummy),'md');
   set(ss,'LineWidth',5);
   ss = scatter(location_vec(1),median(ratio_overshoot_dummy),'yd');
   set(ss,'LineWidth',5);
ylabel('overshoot ratio');
xlabel(str_movie);
title(strcat('number of pulse samples/emitters: ',num2str(ii_count),'/',num2str(sum(size_bPAC_clusters)),', median:',num2str(median(ratio_overshoot_dummy)),',mean:',num2str(mean(ratio_overshoot_dummy)),',std:',num2str(std(ratio_overshoot_dummy))));
hold off;
ylim([0 max(ratio_overshoot_dummy)*1.5 ]);
ylim([0 3.5]);
xlim([0 3]);

print('-depsc',strcat(str_movie_processed_figures,'\statistics_plots_annotated\',str_movie,'-ratio_overshoot_R.eps'));   

for ii_RAND = 1:length(time_max_to_ss_bPAC_pulse_cell_dummy)     
    time_max_to_ss_bPAC_pulse_cell_dummy(ii_RAND) = time_max_to_ss_bPAC_pulse_cell_dummy(ii_RAND) + rand -.5; 
end;

location_vec = ones(length(time_max_to_ss_bPAC_pulse_cell_dummy),1);

figure(223)
hold on;
scatter(location_vec, time_max_to_ss_bPAC_pulse_cell_dummy,str_plot);
   ss = errorbar(location_vec(1),mean(time_max_to_ss_bPAC_pulse_cell_dummy),std(time_max_to_ss_bPAC_pulse_cell_dummy),'m');
   ss = errorbar(location_vec(1),mean(time_max_to_ss_bPAC_pulse_cell_dummy),std(time_max_to_ss_bPAC_pulse_cell_dummy)/sqrt(length(time_max_to_ss_bPAC_pulse_cell_dummy)),'g');
   set(ss,'LineWidth',2);
     cap_width = .2;
   ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_max_to_ss_bPAC_pulse_cell_dummy)-std(time_max_to_ss_bPAC_pulse_cell_dummy) mean(time_max_to_ss_bPAC_pulse_cell_dummy)-std(time_max_to_ss_bPAC_pulse_cell_dummy)],'m');
   set(ss,'LineWidth',2);
   ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(time_max_to_ss_bPAC_pulse_cell_dummy)+std(time_max_to_ss_bPAC_pulse_cell_dummy) mean(time_max_to_ss_bPAC_pulse_cell_dummy)+std(time_max_to_ss_bPAC_pulse_cell_dummy)],'m');
   set(ss,'LineWidth',2);
   ss = scatter(location_vec(1),mean(time_max_to_ss_bPAC_pulse_cell_dummy),'md');
   set(ss,'LineWidth',5);
   ss = scatter(location_vec(1),median(time_max_to_ss_bPAC_pulse_cell_dummy),'yd');
   set(ss,'LineWidth',5);
ylabel('time from max to ss');
xlabel(str_movie);
title(strcat('number of pulse samples/emitters: ',num2str(ii_count),'/',num2str(sum(size_bPAC_clusters)),', median:',num2str(median(time_max_to_ss_bPAC_pulse_cell_dummy)),',mean:',num2str(mean(time_max_to_ss_bPAC_pulse_cell_dummy)),',std:',num2str(std(time_max_to_ss_bPAC_pulse_cell_dummy))));
hold off;
ylim([0 40]);
xlim([0 3]);


print('-depsc',strcat(str_movie_processed_figures,'\statistics_plots_annotated\',str_movie,'-time_max_to_ss_R.eps'));   


overshoot_dynamics_dummy = time_max_to_ss_bPAC_pulse_cell_dummy-time_overshoot_whole_dummy_RAND
     location_vec = ones(length(overshoot_dynamics_dummy),1);

figure(224)
hold on;
scatter(location_vec, abs(overshoot_dynamics_dummy),str_plot);
   ss = errorbar(location_vec(1),mean(overshoot_dynamics_dummy),std(overshoot_dynamics_dummy),'m');
   ss = errorbar(location_vec(1),mean(overshoot_dynamics_dummy),std(overshoot_dynamics_dummy)/sqrt(length(overshoot_dynamics_dummy)),'g');
   set(ss,'LineWidth',2);
     cap_width = .2;
   ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(overshoot_dynamics_dummy)-std(overshoot_dynamics_dummy) mean(overshoot_dynamics_dummy)-std(overshoot_dynamics_dummy)],'m');
   set(ss,'LineWidth',2);
   ss = plot([location_vec(1)-cap_width/2 location_vec(1)+cap_width/2],[mean(overshoot_dynamics_dummy)+std(overshoot_dynamics_dummy) mean(overshoot_dynamics_dummy)+std(overshoot_dynamics_dummy)],'m');
   set(ss,'LineWidth',2);
   ss = scatter(location_vec(1),mean(overshoot_dynamics_dummy),'md');
   set(ss,'LineWidth',5);
   ss = scatter(location_vec(1),median(overshoot_dynamics_dummy),'yd');
   set(ss,'LineWidth',5);
ylabel('time-to-ss  -  time-to-max');
xlabel('combined movies');
title(strcat('number of pulse samples/emitters: ',num2str(ii_count),'/',num2str(sum(size_bPAC_clusters)),', median:',num2str(median(overshoot_dynamics_dummy)),',mean:',num2str(mean(overshoot_dynamics_dummy)),',std:',num2str(std(overshoot_dynamics_dummy))));
ylim([0 20]);
xlim([0 3]);
     
print('-depsc',strcat(str_movie_processed_figures,'\statistics_plots_annotated\',str_movie,'-overshoot_dynamics_R.eps'));   


cd(str_processing);  % go back to processing code directory 'multicellular_movie_make_AVI'
%end;  % if (do_PPT == 1)





