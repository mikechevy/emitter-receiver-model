just_nuclei_not_to_use = 0; % 1- just uses 'nuclei_not_to_use' array ,0 - also uses 'max(bPAC_pulse_cell(idx,:)) > 0' as a filter
nuclei_not_to_use = 0;  % intialize count;

do_specific_time_range = 0;  % 0- plot over full range, 1-plot over specific range

do_make_bPAC_statistics_plots_mean_std = 1; % 1-run make_bPAC_statistics_plots_mean_std, 0 - don't
factor_std_errorplot = 2; % 1- 1*std,  2 - 2*std 95 percent confidence interval, 2 - no

if which_movie == 99
  %str_movie = '191015_198-117_TEST_MC_2_H89';
    nuclei_not_to_use = [2 7 12 14 15 18 19 23 25 26 30 31 33 34 35 39 41 46 51 54 55 56 57 58 61 68 69 70 71];  %17 small hump first signal,  28 early discont. pre first pulse 
elseif (which_movie == 105)
  %str_movie = '191202_198-117_TEST_MC_p23';        
    nuclei_not_to_use = [2 8 9 10 11 13 16 17 19 21 26 31 39 41 42 49 50];  % 11 13 17 41
elseif (which_movie == 109)
  %str_movie = '191210_198-117_MC_p23_same';     
    nuclei_not_to_use = [2 3 8 10 13 15 25 26 36 44];
    nuclei_not_to_use = [2 3 8 10 13 15 25 26 35 36 41 43 44];
elseif which_movie == 154
  %str_movie = '200213_198-117_MC_H89'; 
  nuclei_not_to_use = [3 8 12 16 17 18 19 20 23 24 25 27 28 29 30 32 35 38 39];  
  just_nuclei_not_to_use = 1;
elseif which_movie == 156
  %str_movie = '200214_198-117_MC_H89'; 
  nuclei_not_to_use = [1 2 3 5 6 7 8 9 11 12 15 16 17 21 22 23 27 29 39 40 42 43 44 45 48 49 50 51 52 53 54 56 57 58 59 60 61];  
  %13 24
  just_nuclei_not_to_use = 1;  
elseif (which_movie == 174)
  %str_movie = '200621_198-117_p26'; 
    %nuclei_not_to_use = [1 10 27 39 46 48 52 69 70]; % Original Submission 17 22 (discontiuity) 40 highly sloped 59 weird
    nuclei_not_to_use = [1 10 23 27 39 46 48 52 69 70]; % REVISE 17 22 (discontiuity) 40 highly sloped 59 weird
   % nuclei_not_to_use = [1 10 17 22 27 39 40 46 48 52 59 69 70]; % 17 22 (discontiuity) 40 highly sloped 59 weird
elseif (which_movie == 175)
  %str_movie = '200621_198-117_p26_2_samecells';     
    nuclei_not_to_use = [4 6 10 26 32 34 36 37 43 44 50 56]; % 2 
elseif (which_movie == 193)
% str_movie = '200709_198-117_2';   
    %do_specific_time_range = 1;
    do_make_bPAC_statistics_plots_mean_std = 0;
elseif (which_movie == 262)
%    str_movie = '201122_198-117_1';     
    nuclei_not_to_use = [2 4 5 6 8 9 12 14 35 49 51]; % 2 
    %do_specific_time_range = 1;
    do_make_bPAC_statistics_plots_mean_std = 0;
elseif (which_movie == 263)
%    str_movie = '201122_198-117_1';     
    nuclei_not_to_use = [1 2 5 6 10 12 26 33 35 40 42]; % 2 
    %do_specific_time_range = 1;
    do_make_bPAC_statistics_plots_mean_std = 0;
elseif which_movie == 403
  %str_movie = '160922_198-117_JP'
    nuclei_not_to_use = [26 30 33 34 39 68]; 
end; 

    

if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 

do_just_nuclear_signal = 0;  % 0-ratio of nuclear to cytosol, 1-nuclear signal/min(nuclear signal);  For powerpoint stuff

  if (which_nuclei_signal_type == 1) % shrink
      str_nuclei_signal_type = 'SHRINK_';
  elseif (which_nuclei_signal_type == 2) % intersect
      str_nuclei_signal_type = 'INTERSECT_';
  elseif (which_nuclei_signal_type == 3) % circle
      str_nuclei_signal_type = 'CIRCLE_';
  end;
      
if (do_just_nuclear_signal == 1)
  str_just_nuclear = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell');
  %mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
elseif (do_just_nuclear_signal == 0)
  str_just_nuclear = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell');
  %mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
end;
  %mkdir(strcat(str_movie_processed_figures,'\cellular_signals_eps_mean_std_statistics'));
  
M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);

sig_dummy_average_bPAC_pulse_cell = zeros(1, length(time_Erk));
sig_dummy_average_bPAC_pulse_cell2 = zeros(1, length(time_Erk));
sig_dummy_variance_bPAC_pulse_cell = zeros(1, length(time_Erk));
sig_dummy_variance_bPAC_pulse_cell2 = zeros(1, length(time_Erk));
sig_dummy_average_bPAC_pulse_cell_norm = zeros(1, length(time_Erk));
sig_dummy_average_bPAC_pulse_cell2_norm = zeros(1, length(time_Erk));
sig_dummy_variance_bPAC_pulse_cell_norm = zeros(1, length(time_Erk));
sig_dummy_variance_bPAC_pulse_cell2_norm = zeros(1, length(time_Erk));
sig_dummy_average_bPAC_pulse_cell_norm_pulse2 = zeros(1, length(time_Erk));
sig_dummy_average_bPAC_pulse_cell2_norm_pulse2 = zeros(1, length(time_Erk));
sig_dummy_variance_bPAC_pulse_cell_norm_pulse2 = zeros(1, length(time_Erk));
sig_dummy_variance_bPAC_pulse_cell2_norm_pulse2 = zeros(1, length(time_Erk));
count_pulse_cell = 0;



s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
      
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);

          
          diff_bPAC_signal = diff(bPAC_ledvals);
          
%  determine pulse locations here, bPAC
             num_pulses = 0;
             num_bPAC_pulses = 0;
             index_bPAC_pulse_start = [];
             index_bPAC_pulse_stop = [];
     for ii = 1:length(diff_bPAC_signal)
         
         if (diff_bPAC_signal(ii) > 0)
             index_bPAC_pulse_start(num_bPAC_pulses+1) = ii+1; % top of pulse (rise)
             num_bPAC_pulses = num_bPAC_pulses + 1;
         elseif (diff_bPAC_signal(ii) < 0)
             index_bPAC_pulse_stop(num_bPAC_pulses) = ii; % top of pulse (decline)
         end;
             
     end;
            if length(index_bPAC_pulse_stop) < length(index_bPAC_pulse_start)
                index_bPAC_pulse_stop(num_bPAC_pulses) = length(time_bPAC); 
            end;
            
            
            
            %  this calculates the end of each step-pulse that are all but
            %  the last in a step-up sequence
            if (num_bPAC_pulses > 1)
               for ii = 1:num_bPAC_pulses -1
                if (index_bPAC_pulse_stop(ii) == 0)
                   index_bPAC_pulse_stop(ii) = index_bPAC_pulse_start(ii+1)-1;
                end;
               end;
            end;

            
% array for max cange in ERK-KTR N/C signal during pulse
Delta_ERK_KTR_pulse = zeros(num_nuclei_t0, num_bPAC_pulses);            
            

%  determine indexes of time_Erk that are within the bPAC pulse times
             index_bPAC_pulse_start_Erk = [];
             index_bPAC_pulse_stop_Erk = [];
     for ii = 1:num_bPAC_pulses
  
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_start(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_start(ii)) )
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy+1;         
          %else
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
          %end;
          index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         
          
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_stop(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_stop(ii)) )
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy;         
          %else
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy-1;          
          %end;
          index_bPAC_pulse_stop_Erk(ii) =  min(index_dummy+1,length(time_Erk));   % captures full experimental duration of pulse       

          
                    num_samps_overshoot_whole(ii) = index_bPAC_pulse_stop_Erk(ii)-index_bPAC_pulse_start_Erk(ii);  % defin3d above

          
     end;
            
          % plots average signals
          sig_dummy_nuclear_average = zeros(1, length(time_Erk));
          sig_dummy_ratio_average = sig_dummy_nuclear_average;          
          ratio_signal = zeros(num_nuclei_t0,length(time_Erk));
     
num_bPAC_pulsing_cells = 0;            
bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);
overshoot_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);
index_overshoot_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses)
index_overshoot_whole_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses)
time_overshoot_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);
time_overshoot_whole_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);
steady_state_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);
ratio_overshoot_ss_bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);
ratio_overshoot_ss_bPAC_pulse_cell_REVISE = zeros(num_nuclei_t0,num_bPAC_pulses);
index_time_max_to_ss_bPAC_pulse_cell_REVISE = zeros(num_nuclei_t0,num_bPAC_pulses);
time_max_to_ss_bPAC_pulse_cell_REVISE = zeros(num_nuclei_t0,num_bPAC_pulses);

          num_samps_overshoot = 15;
          %num_samps_overshoot_whole;  % defin3d above
          num_samps_steady_state = 10;    

cd(str_movie_processed)


for ii_round = 1:2

for idx = 1:num_nuclei_t0
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Pulse analysis 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     for ii = 1:num_bPAC_pulses     

         
         % TIME: time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,

         diff_time_Erk = diff(time_Erk)
         dt_pre_pulse = 4*60; 
         dt_pre_post = 5*60; 
         num_samps_pre = round(dt_pre_pulse/diff_time_Erk(2));
         num_samps_post = ceil(dt_pre_post/diff_time_Erk(2));
         
         %NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy);
         min_sig = min(sig_dummy);         
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig;
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)/min_sig;

          
          
          %shift_rise = 4; 
          shift_rise = 9;  % normal step response timescale (1 minute frame)
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));          
          % SETUP PULSE ANALYSIS HERE
          passed_pulse_test = 0; 

          epsilon_pulse_nucleus = .08;
          if pulse_dummy > epsilon_pulse_nucleus 
           passed_pulse_test = 1;
          end;
        else
            passed_pulse_test = 1
        end;
          
              
          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
          
         %RATIO OF NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;
          signal_dummy =  (sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig)
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)

          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          % Begin: calculate overshoot statistice
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            mean_sig_dummy_start_pre = mean(sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1));            
            if (index_bPAC_pulse_stop_Erk(ii) + num_samps_post < length(sig_dummy))
             mean_sig_dummy_end_post = mean(sig_dummy(index_bPAC_pulse_stop_Erk(ii)+1:index_bPAC_pulse_stop_Erk(ii)+num_samps_post));
            else
             mean_sig_dummy_end_post = mean_sig_dummy_start_pre;   
            end;
         
           [overshoot_dummy  index_overshoot_dummy] = max(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_start_Erk(ii)+num_samps_overshoot-1) - mean_sig_dummy_start_pre); 
           [overshoot_whole_dummy  index_overshoot_whole_dummy] = max(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_start_Erk(ii)+num_samps_overshoot_whole(ii)-1) - mean_sig_dummy_start_pre); 
           steady_state_dummy = mean(sig_dummy(index_bPAC_pulse_stop_Erk(ii)-num_samps_steady_state+1:index_bPAC_pulse_stop_Erk(ii))-mean_sig_dummy_end_post);
           %steady_state_dummy = abs(mean(sig_dummy(index_bPAC_pulse_stop_Erk(ii)-num_samps_steady_state+1:index_bPAC_pulse_stop_Erk(ii))-mean_sig_dummy_end_post));

           overshoot_bPAC_pulse_cell(idx,ii) = overshoot_dummy;
           index_overshoot_bPAC_pulse_cell(idx,ii) = index_overshoot_dummy+index_bPAC_pulse_start_Erk(ii)-1;
           index_overshoot_whole_bPAC_pulse_cell(idx,ii) = index_overshoot_whole_dummy+index_bPAC_pulse_start_Erk(ii)-1;
           time_overshoot_bPAC_pulse_cell(idx,ii) = index_overshoot_dummy;
           time_overshoot_whole_bPAC_pulse_cell(idx,ii) = index_overshoot_whole_dummy;
           steady_state_bPAC_pulse_cell(idx,ii) = steady_state_dummy;
           %ratio_overshoot_ss_bPAC_pulse_cell(idx,ii) = overshoot_dummy/steady_state_dummy;  
            ratio_overshoot = (sig_dummy(index_overshoot_whole_bPAC_pulse_cell(idx,ii)) - sig_dummy(index_bPAC_pulse_start_Erk(ii)))/(sig_dummy(index_bPAC_pulse_stop_Erk(ii)-1) - sig_dummy(index_bPAC_pulse_start_Erk(ii)));
            if (ratio_overshoot > 0)
               ratio_overshoot_ss_bPAC_pulse_cell_REVISE(idx,ii) = ratio_overshoot;  % FOR REVISIONS
            end;
            
            
                              found_one_over_exp = 0;
                for ii_check = index_overshoot_whole_bPAC_pulse_cell(idx,ii):index_bPAC_pulse_stop_Erk(ii)-1                    
                    if (found_one_over_exp == 0)                        
                      if (sig_dummy(ii_check) - (sig_dummy(index_bPAC_pulse_stop_Erk(ii)-1))) <= exp(-1)*(sig_dummy(index_overshoot_whole_bPAC_pulse_cell(idx,ii)) - (sig_dummy(index_bPAC_pulse_stop_Erk(ii)-1)))
                        index_time_max_to_ss_bPAC_pulse_cell_REVISE(idx,ii) = ii_check;
                        time_max_to_ss_bPAC_pulse_cell_REVISE(idx,ii) = (time_Erk(ii_check)-time_Erk(index_bPAC_pulse_start_Erk(ii)))/scale_factor_time + rand -.5;
                        found_one_over_exp = 1;
                      end;  
                    end;
                end;

                                                                                              
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          % End: calculate overshoot statistice
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
          
          %shift_rise = 4;  
          shift_rise = 9;  % normal step response timescale (1 minute frame)
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));
          
          epsilon_pulse_ratio = .08;
          if pulse_dummy > epsilon_pulse_ratio 
           passed_pulse_test = 1;
          end;
          % SETUP PULSE ANALYSIS HERE

          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
        else
           passed_pulse_test = 1;
        end;
          
          if (passed_pulse_test == 1)
              if (ii == 1)  %passed the first pulse only
              sig_dummy_nuclear_average = sig_dummy_nuclear_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))/double(min(nuclear_Erk_tot_time_mapped_t0_median(idx,:)));
              sig_dummy_ratio_average = sig_dummy_ratio_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));       
              ratio_signal(idx,:) = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));  
              end;
          end;
          
     end;     
    
   
     do_plot_stuff = 1; % 0 - no, 1 - yes
     if (do_plot_stuff == 1)
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Make plot of result 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     ii_plot_count = 0;
     figure(200)
     title(strcat('nuclear Erk signal (',Erk_str,')'));
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
     subplot(3,1,1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(ii_plot_count+1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig,s_pulse(ii));
               set(ss,'LineWidth',3);
     end;
     ylabel(strcat('(nuc-min(nuc))/max(nuc-min(nuc))'));
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+max(1.1*(max(sig_dummy/min_sig)-1),.1)]);

         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
           if (num_bPAC_pulses+1 == 1)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)));
           elseif (num_bPAC_pulses+1 == 2)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse'));
           elseif (num_bPAC_pulses+1 == 3)
            %lgnd = legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse 1'), strcat('signal during bPAC pulse 2'));
           end;
            %set(lgnd,'color','none');
           
       if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
           str_bPAC = ' (bPAC)';
           str_bPAC_eps = '-bPAC';
       else
           str_bPAC = ' (non-bPAC)';
           str_bPAC_eps = '-non-bPAC';
       end;
            
            
      if (num_bPAC_pulses == 1)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test =',num2str(bPAC_pulse_cell(idx,1))));
      elseif (num_bPAC_pulses == 2)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']'));
      elseif (num_bPAC_pulses == 3)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),';',num2str(bPAC_pulse_cell(idx,3)),']'));
      end;
      
     
     subplot(3,1,2) 
     hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(ii));
               set(ss,'LineWidth',3);
          % plot overshoot value and location
          if (bPAC_pulse_cell(idx,ii) == 1)
          plot(time_Erk(index_overshoot_whole_bPAC_pulse_cell(idx,ii))/scale_factor_time,sig_dummy(index_overshoot_whole_bPAC_pulse_cell(idx,ii)),'rd');
          end;
     end;
     
     ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*max((max(sig_dummy)-min(sig_dummy)),.1)]);
     xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;



          subplot(3,1,3)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          
          
          
% do_PPT = 0;  % 0 - no, 1 - yes
% if (do_PPT ==1)
%  % save the figures to a powerpoint slide
% 
% 
%   fig200 = figure(200)
%   figure(1111)
%            ylabel('bPAC');
%           plot(time_bPAC/scale_factor_time,bPAC_ledvals);
%           xlim([0 max(time_Erk)/scale_factor_time]);
%           ylim([0 1.1*max(bPAC_ledvals)]);
%           ylabel('bPAC');
%           xlabel(str_time_representation);
%   fig1111 = figure(1111);
%    s_combine = strcat(str_movie,':nuclear Erk signals');
%      if (idx==1)  % remove if file exists
%      delete(strcat(str_movie,'-nuclear_Erk_signals_statistics.ppt'));
%      end;
%      saveppt2(strcat(str_movie,'-nuclear_Erk_signals_statistics.ppt'),'figure',[fig200], 'halign','center','title', s_combine);
%      %if idx == num_nuclei_t0   
%      %movefile('nuclear_Erk_signals.ppt',strcat(str_movie_processed,'\',str_movie,'-nuclear_Erk_signals.ppt'));
%      %end;
% 
%      
% end; % if (do_PPT ==1)
%      
%           %pause
%           figure(200)
%           cd(strcat('figures-',str_movie,'\cellular_signals_eps_statistics'));          
%           print('-depsc',strcat('nuc_',num2str(idx),str_bPAC_eps,'-Erk-',str_movie,'.eps'));   
%           cd ../../;
           close(200)
% 
%            
     end; % end of 'if (do_plot_stuff == 1)'

     
     
      if ((max(bPAC_pulse_cell(idx,:)) > 0)&(min(abs(idx-nuclei_not_to_use))>0))|((just_nuclei_not_to_use==1)&(min(abs(idx-nuclei_not_to_use))>0))
           
           % regular average
           sig_dummy2 = sig_dummy;
           
           do_raw = 0; % 1-don't shift to one, 0 - do shift to 1
           if (do_raw == 0)
           sig_dummy = sig_dummy - sig_dummy(index_bPAC_pulse_start_Erk(1)) + 1;
           sig_dummy2 = sig_dummy2 - sig_dummy2(index_bPAC_pulse_start_Erk(2)) + 1;
           end;
           
           % normalized averages
           sig_dummy_dummy_norm = (sig_dummy-sig_dummy(index_bPAC_pulse_start_Erk(1)));
           sig_dummy_dummy2_norm = (sig_dummy2-sig_dummy2(index_bPAC_pulse_start_Erk(2)));
           sig_dummy_dummy_norm_pulse2 = (sig_dummy-sig_dummy(index_bPAC_pulse_start_Erk(1)));
           sig_dummy_dummy2_norm_pulse2 = (sig_dummy2-sig_dummy2(index_bPAC_pulse_start_Erk(2)));

           sig_dummy_norm = sig_dummy_dummy_norm/max(sig_dummy_dummy_norm(index_bPAC_pulse_start_Erk(1):index_bPAC_pulse_stop_Erk(1)));    % same scale (max of FIRST pulse) for both sig_dummy_norm and sig_dummy2_norm
           sig_dummy2_norm = sig_dummy_dummy2_norm/max(sig_dummy_dummy_norm(index_bPAC_pulse_start_Erk(1):index_bPAC_pulse_stop_Erk(1)));  % same scale (max of FIRST first pulse) for both sig_dummy_norm and sig_dummy2_norm
           sig_dummy_norm_pulse2 = sig_dummy_dummy_norm_pulse2/max(sig_dummy_dummy2_norm_pulse2(index_bPAC_pulse_start_Erk(2):index_bPAC_pulse_stop_Erk(2)));    % same scale (max of SECOND pulse) for both sig_dummy_norm and sig_dummy2_norm
           sig_dummy2_norm_pulse2 = sig_dummy_dummy2_norm_pulse2/max(sig_dummy_dummy2_norm_pulse2(index_bPAC_pulse_start_Erk(2):index_bPAC_pulse_stop_Erk(2)));  % same scale (max of SECOND pulse) for both sig_dummy_norm and sig_dummy2_norm

          if (ii_round == 1)
          Delta_ERK_KTR_pulse(idx,1) = max(sig_dummy_dummy_norm(index_bPAC_pulse_start_Erk(1):index_bPAC_pulse_stop_Erk(1)));
          Delta_ERK_KTR_pulse(idx,2) = max(sig_dummy_dummy2_norm_pulse2(index_bPAC_pulse_start_Erk(2):index_bPAC_pulse_stop_Erk(2)));
          end;
          
         if (ii_round == 1) 
          sig_dummy_average_bPAC_pulse_cell = sig_dummy_average_bPAC_pulse_cell + sig_dummy;
          sig_dummy_average_bPAC_pulse_cell2 = sig_dummy_average_bPAC_pulse_cell2 + sig_dummy2;
          sig_dummy_average_bPAC_pulse_cell_norm = sig_dummy_average_bPAC_pulse_cell_norm + sig_dummy_norm;
          sig_dummy_average_bPAC_pulse_cell2_norm = sig_dummy_average_bPAC_pulse_cell2_norm + sig_dummy2_norm;
          sig_dummy_average_bPAC_pulse_cell_norm_pulse2 = sig_dummy_average_bPAC_pulse_cell_norm_pulse2 + sig_dummy_norm_pulse2;
          sig_dummy_average_bPAC_pulse_cell2_norm_pulse2 = sig_dummy_average_bPAC_pulse_cell2_norm_pulse2 + sig_dummy2_norm_pulse2;
          count_pulse_cell = count_pulse_cell + 1;
         elseif (ii_round == 2) 
          sig_dummy_variance_bPAC_pulse_cell = sig_dummy_variance_bPAC_pulse_cell + (sig_dummy-sig_dummy_average_bPAC_pulse_cell).*(sig_dummy-sig_dummy_average_bPAC_pulse_cell);
          sig_dummy_variance_bPAC_pulse_cell2 = sig_dummy_variance_bPAC_pulse_cell2 + (sig_dummy2-sig_dummy_average_bPAC_pulse_cell2).*(sig_dummy2-sig_dummy_average_bPAC_pulse_cell2);
          sig_dummy_variance_bPAC_pulse_cell_norm = sig_dummy_variance_bPAC_pulse_cell_norm + (sig_dummy_norm-sig_dummy_average_bPAC_pulse_cell_norm).*(sig_dummy_norm-sig_dummy_average_bPAC_pulse_cell_norm);
          sig_dummy_variance_bPAC_pulse_cell2_norm = sig_dummy_variance_bPAC_pulse_cell2_norm + (sig_dummy2_norm-sig_dummy_average_bPAC_pulse_cell2_norm).*(sig_dummy2_norm-sig_dummy_average_bPAC_pulse_cell2_norm);
          sig_dummy_variance_bPAC_pulse_cell_norm_pulse2 = sig_dummy_variance_bPAC_pulse_cell_norm_pulse2 + (sig_dummy_norm_pulse2-sig_dummy_average_bPAC_pulse_cell_norm_pulse2).*(sig_dummy_norm_pulse2-sig_dummy_average_bPAC_pulse_cell_norm_pulse2);
          sig_dummy_variance_bPAC_pulse_cell2_norm_pulse2 = sig_dummy_variance_bPAC_pulse_cell2_norm_pulse2 + (sig_dummy2_norm_pulse2-sig_dummy_average_bPAC_pulse_cell2_norm_pulse2).*(sig_dummy2_norm_pulse2-sig_dummy_average_bPAC_pulse_cell2_norm_pulse2);
         end;
         
           % plot all signals on top of each other
           if ii_round == 1
            figure(1110)
            subplot(2,1,1)
            hold on;
            ss = plot(time_Erk/scale_factor_time,sig_dummy, s_sig(ii_plot_count+1));
            hold off;
           end;
         
      end;

      
      
     
 end; % for idx = 1:num_nuclei_t0

 
   if (ii_round == 1)
     sig_dummy_average_bPAC_pulse_cell = sig_dummy_average_bPAC_pulse_cell/count_pulse_cell;
     sig_dummy_average_bPAC_pulse_cell2 = sig_dummy_average_bPAC_pulse_cell2/count_pulse_cell;
     sig_dummy_average_bPAC_pulse_cell_norm = sig_dummy_average_bPAC_pulse_cell_norm/count_pulse_cell;
     sig_dummy_average_bPAC_pulse_cell2_norm = sig_dummy_average_bPAC_pulse_cell2_norm/count_pulse_cell;
     sig_dummy_average_bPAC_pulse_cell_norm_pulse2 = sig_dummy_average_bPAC_pulse_cell_norm_pulse2/count_pulse_cell;
     sig_dummy_average_bPAC_pulse_cell2_norm_pulse2 = sig_dummy_average_bPAC_pulse_cell2_norm_pulse2/count_pulse_cell;
   elseif (ii_round == 2)
      sig_dummy_variance_bPAC_pulse_cell = sig_dummy_variance_bPAC_pulse_cell/(count_pulse_cell-1);
      sig_dummy_variance_bPAC_pulse_cell2 = sig_dummy_variance_bPAC_pulse_cell2/(count_pulse_cell-1);
      sig_dummy_variance_bPAC_pulse_cell_norm = sig_dummy_variance_bPAC_pulse_cell_norm/(count_pulse_cell-1);
      sig_dummy_variance_bPAC_pulse_cell2_norm = sig_dummy_variance_bPAC_pulse_cell2_norm/(count_pulse_cell-1);
      sig_dummy_variance_bPAC_pulse_cell_norm_pulse2 = sig_dummy_variance_bPAC_pulse_cell_norm_pulse2/(count_pulse_cell-1);
      sig_dummy_variance_bPAC_pulse_cell2_norm_pulse2 = sig_dummy_variance_bPAC_pulse_cell2_norm_pulse2/(count_pulse_cell-1);
        do_var_pulse_specific = 1; % 1 - shift variariance for each pulse, 0-shift based on first pulse (neglects drift)
     if (do_var_pulse_specific == 0)
      sig_dummy_std_bPAC_pulse_cell = sqrt(sig_dummy_variance_bPAC_pulse_cell);
      sig_dummy_std_bPAC_pulse_cell_norm = sqrt(sig_dummy_variance_bPAC_pulse_cell_norm);
      sig_dummy_std_bPAC_pulse_cell_norm_pulse2 = sqrt(sig_dummy_variance_bPAC_pulse_cell_norm_pulse2);
     elseif (do_var_pulse_specific == 1)
         pulse1 = zeros(1,length(time_Erk));
          %pulse1(index_bPAC_pulse_start_Erk(1):index_bPAC_pulse_stop_Erk(1)) = 1;
          pulse1(1:index_bPAC_pulse_start_Erk(2)-1) = 1;
         pulse2 = zeros(1,length(time_Erk));
          %pulse2(index_bPAC_pulse_start_Erk(2):index_bPAC_pulse_stop_Erk(2)) = 1;
          pulse2(index_bPAC_pulse_start_Erk(2):length(pulse2)) = 1;
      sig_dummy_std_bPAC_pulse_cell = sqrt(sig_dummy_variance_bPAC_pulse_cell.*pulse1 + sig_dummy_variance_bPAC_pulse_cell2.*pulse2);
      sig_dummy_std_bPAC_pulse_cell_norm = sqrt(sig_dummy_variance_bPAC_pulse_cell_norm.*pulse1 + sig_dummy_variance_bPAC_pulse_cell2_norm.*pulse2);
      sig_dummy_std_bPAC_pulse_cell_norm_pulse2 = sqrt(sig_dummy_variance_bPAC_pulse_cell_norm_pulse2.*pulse1 + sig_dummy_variance_bPAC_pulse_cell2_norm_pulse2.*pulse2);
     end;
   end;
 
   
end; % for ii_round = 1:2



   figure(1110)
   subplot(2,1,1)
      %set(ss,'LineWidth',2);
         ylim([max(sig_dummy_average_bPAC_pulse_cell)+1.1*(min(sig_dummy_average_bPAC_pulse_cell)-max(sig_dummy_average_bPAC_pulse_cell)) min(sig_dummy_average_bPAC_pulse_cell)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell)-min(sig_dummy_average_bPAC_pulse_cell)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1110 = figure(1110);



do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)
    
  
  figure(1111)
  subplot(2,1,1)
  hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',2);
         ylim([max(sig_dummy_average_bPAC_pulse_cell)+1.1*(min(sig_dummy_average_bPAC_pulse_cell)-max(sig_dummy_average_bPAC_pulse_cell)) min(sig_dummy_average_bPAC_pulse_cell)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell)-min(sig_dummy_average_bPAC_pulse_cell)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
hold off;
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells)');
     if (do_raw == 0)
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics.ppt'));
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics.ppt'),'figure',[fig1111], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics.eps'));   
     elseif (do_raw == 1)
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_raw.ppt'));
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_raw.ppt'),'figure',[fig1111], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_raw.eps'));   
     end;
               
               
  figure(1112)
  subplot(2,1,1)
  hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',2);
         
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell,sig_dummy_std_bPAC_pulse_cell, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',1);         
         ylim([max(sig_dummy_average_bPAC_pulse_cell)+1.1*(min(sig_dummy_average_bPAC_pulse_cell)-max(sig_dummy_average_bPAC_pulse_cell)) min(sig_dummy_average_bPAC_pulse_cell)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell)-min(sig_dummy_average_bPAC_pulse_cell)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1112 = figure(1112);
hold off;
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD.ppt'));
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells) with error bars');
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD.ppt'),'figure',[fig1112], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD.eps'));   

  figure(1113)
  subplot(2,1,1)
  hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',2);
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm,sig_dummy_std_bPAC_pulse_cell_norm, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',1);         
         ylim([max(sig_dummy_average_bPAC_pulse_cell_norm)+1.1*(min(sig_dummy_average_bPAC_pulse_cell_norm)-max(sig_dummy_average_bPAC_pulse_cell_norm)) min(sig_dummy_average_bPAC_pulse_cell_norm)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell_norm)-min(sig_dummy_average_bPAC_pulse_cell_norm)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1113 = figure(1113);
hold off;
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM.ppt'));
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells) with error bars (normalized)');
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM.ppt'),'figure',[fig1113], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM.eps'));   

               
  figure(2113)
  subplot(2,1,1)
  hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',2);
   if (factor_std_errorplot == 1)      
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm,sig_dummy_std_bPAC_pulse_cell_norm, s_sig(ii_plot_count+1));
   elseif (factor_std_errorplot == 2)
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm,sig_dummy_std_bPAC_pulse_cell_norm*2, 'r');
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm,sig_dummy_std_bPAC_pulse_cell_norm, s_sig(ii_plot_count+1));
   end;
         set(ss,'LineWidth',1);         
         ylim([max(sig_dummy_average_bPAC_pulse_cell_norm)+1.1*(min(sig_dummy_average_bPAC_pulse_cell_norm)-max(sig_dummy_average_bPAC_pulse_cell_norm)) min(sig_dummy_average_bPAC_pulse_cell_norm)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell_norm)-min(sig_dummy_average_bPAC_pulse_cell_norm)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig2113 = figure(2113);
hold off;
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_95CI.ppt'));
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells) with error bars (normalized)');
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_95CI.ppt'),'figure',[fig2113], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_95CI.eps'));   
               
               
  figure(1114)
  subplot(2,1,1)
  hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm_pulse2, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',2);
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm_pulse2,sig_dummy_std_bPAC_pulse_cell_norm_pulse2, s_sig(ii_plot_count+1));    
        set(ss,'LineWidth',1);         
         ylim([max(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)+1.1*(min(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)-max(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)) min(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)-min(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1114 = figure(1114);
hold off;
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_PULSE2.ppt'));
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells) with error bars (normalized)');
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_PULSE2.ppt'),'figure',[fig1114], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_PULSE2.eps'));   

   
  figure(2114)
  subplot(2,1,1)
  hold on;
     ss = plot(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm_pulse2, s_sig(ii_plot_count+1));
         set(ss,'LineWidth',2);
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm_pulse2,sig_dummy_std_bPAC_pulse_cell_norm_pulse2*2, 'r');
     ss = errorbar(time_Erk/scale_factor_time,sig_dummy_average_bPAC_pulse_cell_norm_pulse2,sig_dummy_std_bPAC_pulse_cell_norm_pulse2, s_sig(ii_plot_count+1));
        set(ss,'LineWidth',1);         
         ylim([max(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)+1.1*(min(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)-max(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)) min(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)+1.1*max((max(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)-min(sig_dummy_average_bPAC_pulse_cell_norm_pulse2)),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
         ylabel('Erk-KTR (N/C)');
         title(strcat('number of cells = ',num2str(count_pulse_cell)));
  subplot(2,1,2)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig2114 = figure(2114);
hold off;
     delete(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_PULSE2_95CI.ppt'));
     s_combine = strcat(str_movie,':average Erk signals (pulsing cells) with error bars (normalized)');
     saveppt2(strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_PULSE2_95CI.ppt'),'figure',[fig2114], 'halign','center','title', s_combine);
               print('-depsc',strcat(str_movie,'-Erk_average_bPAC_pulsing_cells_mean_std_statistics_STD_NORM_PULSE2_95CI.eps'));   
   
               
end; % if (do_PPT ==1)


% generate max Delta ERK-KTR N/C amplidute versus relative Cytosolic ring
% intensity
generate_max_Delta_ERK_KTR_vs_fluor_intensity




%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    %  FILE for bPAC statistics
%    %
%    %  num_bPAC_pulses
%    %  bPAC_pulse_cell(idx,ii)
%    %  overshoot_bPAC_pulse_cell(idx,ii);
%    %  index_overshoot_bPAC_pulse_cell(idx,ii);
%    %  time_overshoot_bPAC_pulse_cell(idx,ii);
%    % steady_state_bPAC_pulse_cell(idx,ii);
%    % ratio_overshoot_ss_bPAC_pulse_cell(idx,ii);          
%    save('bPAC_statistics_arrays','num_bPAC_pulses','bPAC_pulse_cell','overshoot_bPAC_pulse_cell','index_overshoot_bPAC_pulse_cell','index_overshoot_whole_bPAC_pulse_cell', ...
%                                      'time_overshoot_bPAC_pulse_cell','time_overshoot_whole_bPAC_pulse_cell','steady_state_bPAC_pulse_cell','ratio_overshoot_ss_bPAC_pulse_cell', ...
%                                      'num_samps_steady_state','num_samps_overshoot','num_samps_overshoot_whole', 'index_bPAC_pulse_start_Erk','index_bPAC_pulse_stop_Erk');
%   


cd(str_processing);

if (do_make_bPAC_statistics_plots_mean_std == 1)
 just_nuclei_not_to_use = 1;
 load(strcat(str_movie_processed,'\bPAC_statistics_arrays'));
 ratio_overshoot_ss_bPAC_pulse_cell = ratio_overshoot_ss_bPAC_pulse_cell_REVISE;
 index_time_max_to_ss_bPAC_pulse_cell = index_time_max_to_ss_bPAC_pulse_cell_REVISE;
 time_max_to_ss_bPAC_pulse_cell = time_max_to_ss_bPAC_pulse_cell_REVISE;
 

 make_bPAC_statistics_plots_mean_std
end;   

end;   % if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)
   
