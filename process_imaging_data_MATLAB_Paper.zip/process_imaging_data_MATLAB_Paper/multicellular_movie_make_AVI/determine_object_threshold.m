function threshold = determine_object_threshold(I,xDim,yDim)


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % the method is simply an extrapolation of the noise floor at the xDIM, which should always be well below the real signal 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Sort each column into ascending order to separate noise from signal
  I_sort = sort(I);  

 
  index_min = 10;
  index_max = floor(xDim/3);
  
  slope = (mean(I_sort(index_max,:))-mean(I_sort(index_min,:)))/(index_max-index_min);
  
  threshold = mean(I_sort(index_min,:)) + slope*(xDim-index_min);

  
  
  
  %% adjust by fac_adjust
  %%fac_adjust = .15;
  fac_adjust = 0;
  threshold = threshold + fac_adjust*(max(max(I))-threshold);
  
  
   
    num_max = 10; 
  
       do_plot_sorted_image = 0;  % 1 - yes, 0 - no
   if (do_plot_sorted_image == 1) 
   for ii_rand = 1:num_max
       column_rand(ii_rand) = ceil(rand*yDim);
   figure(101)   
   subplot(2,1,1)
   hold on;
   plot(I_sort(:,column_rand(ii_rand)));
   if ii_rand == num_max
    plot([index_min xDim],[mean(I_sort(index_min,:)) threshold],'r');
   end;
   hold off;
   subplot(2,1,2)
   %hold on;
   plot(diff(I_sort(:,column_rand(ii_rand))));
   %hold off
   end;
   end;