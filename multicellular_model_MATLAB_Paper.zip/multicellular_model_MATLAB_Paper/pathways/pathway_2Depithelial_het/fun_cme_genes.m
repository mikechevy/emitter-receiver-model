function y_prime = fun_cme_genes(t,y)

global state_cme_to;
global state_cme_propensity_array;
global num_states;
global num_reactions;
global y_prime;

y_prime = 0*y_prime;

% CALCULATES THE CME CONTRIBUTIONS
for ii=1:num_states
for jj=1:num_reactions
           state_to = state_cme_to(ii,jj);

           if (state_to > 0)
            y_prime(ii) = y_prime(ii) - y(ii)*state_cme_propensity_array(ii,jj);
            y_prime(state_to) = y_prime(state_to) + y(ii)*state_cme_propensity_array(ii,jj);
           end;
end;
end;



