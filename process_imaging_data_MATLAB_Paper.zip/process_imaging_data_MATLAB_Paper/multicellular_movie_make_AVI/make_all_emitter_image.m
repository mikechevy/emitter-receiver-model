%  spatial analyze of cells and their signals within a bPAC cluster and
%  non-bPAC cells outside the cluster

length_max_bPAC = 120;


M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_Erk = zeros(xLength,yLength);
M_BF = zeros(xLength,yLength);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN: Located bPAC pulses in time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
      
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);

          
          diff_bPAC_signal = diff(bPAC_ledvals);
          


%do_median_or_mean_signal = 1; % % 0-mean, 1-median

mkdir(strcat(str_movie_processed_figures,'\all_emitter_image'));
cd(strcat(str_movie_processed_figures,'\all_emitter_image'));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calculate_averaged signtures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

kkk = 1;
which_frame = kkk;

figure(110+1)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
     if (do_BF_channel ==0)    
        eval(['M_Erk(:,:) = M_CH',num2str(marker_from_channel(ii_Erk_marker)),'_total(:,:,index_frame);']);
     elseif (do_BF_channel ==1)    
       eval(['[val,index_frame_BF]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_BF),'));']);    
        eval(['M_BF(:,:) = M_CH',num2str(ii_BF),'_total(:,:,index_frame_BF);']);
     end;
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    %imshow(mat2gray(M_NM));
    %%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = scale_NM_channel*M_NM(:,:)/max(max(M_NM));
     if (do_BF_channel ==0)    
      image_RGB(:,:,2) = scale_Erk_channel*M_Erk(:,:)/max(max(M_Erk));
     elseif (do_BF_channel ==1)    
      image_RGB(:,:,2) = scale_BF_channel*M_BF(:,:)/max(max(M_BF));
     end;
    image_RGB(:,:,3) = scale_NM_bPAC_channel*M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    
    title(strcat(str_movie,', all emitter tissue'));
      for idx = 1:num_nuclei_t0
           tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));           
         set(tt,'Color','w');
      end;
      
   set(gcf,'inverthardcopy','off')   
     if (do_BF_channel ==0)    
      print('-depsc',strcat('map-all_emitter-',str_movie,'.eps'));
     elseif (do_BF_channel ==1)    
      print('-depsc',strcat('map-all_emitter_BF','-',str_movie,'.eps'));
     end;
      

     
  
cd(str_processing);