

     matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;

     scale_factor_nucleus = 1;
     
radius_spot = 6;  % for now

for iii = 1:num_nuclei_t0

        matrix_NM_SCRAP = 0*matrix_NM_SCRAP;
        
                 x_coord_min = x_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 x_coord_max = x_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_min = y_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_max = y_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame); 
                 %x_coord_min = x_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame);
                 %x_coord_max = x_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame);
                 %y_coord_min = y_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame);
                 %y_coord_max = y_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(iii,which_frame); 
        

  for ii = x_coord_min:x_coord_max        
  for jj = y_coord_min:y_coord_max        
         %ii_scale = scale_factor_nucleus*(ii-mean_x_tot_time_mapped_t0(iii,which_frame));
         %jj_scale = scale_factor_nucleus*(jj-mean_y_tot_time_mapped_t0(iii,which_frame));
         ii_scale = scale_factor_nucleus*(ii-mean_x_tot_SHRINK_time_mapped_t0(iii,which_frame));
         jj_scale = scale_factor_nucleus*(jj-mean_y_tot_SHRINK_time_mapped_t0(iii,which_frame));
         
         if (power(ii_scale,2)+power(jj_scale,2) <= power(radius_spot,2))
          matrix_NM_SCRAP(ii,jj) = 1;
         end;
        
  end;
  end;
        
        
    binary_FILL = bwareaopen(matrix_NM_SCRAP, 0);  % remove 
    Cell_marker_FILL = bwconncomp(binary_FILL);
     idx_map = index_map_tot_time_mapped_t0(iii,which_frame);      
     eval(['Cell_circle_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_marker_FILL.PixelIdxList{1};'])
        
     
     
     matrix_nucleus_SCRAP( Cell_marker_FILL.PixelIdxList{1}) = 1;
        
end;

figure(11)
imshow(matrix_nucleus_SCRAP);

