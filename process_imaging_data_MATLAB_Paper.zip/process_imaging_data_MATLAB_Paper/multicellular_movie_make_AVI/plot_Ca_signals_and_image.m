
do_DAPI = 1;  % 1 - yes, 0 - no
do_FITC = 1;  % 1 - yes, 0 - no
do_CY3 = 1;  % 1 - yes, 0 - no

 M_marker = zeros(xLength,yLength);


for which_nucleus = 1:num_nuclei_t0
    idx = which_nucleus;

    
for kkk = 1:length(which_frames)    
  which_frame = which_frames(kkk)

                 x_coord_min = x_coord_min_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 x_coord_max = x_coord_max_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 y_coord_min = y_coord_min_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
                 y_coord_max = y_coord_max_tot_CYTOSOL_time_mapped_t0(which_nucleus,which_frame);
  
  %str_movie_processed = strcat(str_movie,'_processed')
  %file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  %load(file_nucleus);

if (which_frame == 1)|(do_continue == 1) 
figure(1)
%title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr),',nucleus:',num2str(which_nucleus)));
subplot(2,4,[1 2 5 6]);
if (marker_from_channel(ii_Ca_marker) == ii_FITC)
 M_marker(:,:) = M_FITC_total(:,:,which_frame);
elseif (marker_from_channel(ii_Ca_marker) == ii_CY3)
 M_marker(:,:) = M_CY3_total(:,:,which_frame);
end;
%imagesc(M_DAPI_threshold_FILL)
imagesc(M_marker)
                                    rectangle('Position', [y_coord_min,x_coord_min,...
                                 y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                                       'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                                       'EdgeColor', 'm');
                             text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(which_nucleus));



    
     subplot(2,4,[3 4]) 
     plot(which_frames,nuclear_Ca_tot_time_mapped_t0(idx,:)-nuclear_Ca_tot_time_mapped_t0(idx,1));
     hold on;
     plot(which_frames,nuclear_Ca_tot_time_mapped_t0(idx,:)-nuclear_Ca_tot_time_mapped_t0(idx,1));
     plot([which_frame which_frame],[min(nuclear_Ca_tot_time_mapped_t0(idx,:)-nuclear_Ca_tot_time_mapped_t0(idx,1)) max(nuclear_Ca_tot_time_mapped_t0(idx,:)-nuclear_Ca_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     legend(strcat('nucleus Ca2+,nuc:',num2str(which_nucleus)))
     xlabel('number of frames');
    xlim([0 numFr]);

    
     subplot(2,4,[7 8]) 
     plot(which_frames,cytosolic_Ca_tot_time_mapped_t0(idx,:)-cytosolic_Ca_tot_time_mapped_t0(idx,1));
     hold on;
     plot(which_frames,cytosolic_Ca_tot_time_mapped_t0(idx,:)-cytosolic_Ca_tot_time_mapped_t0(idx,1));
     plot([which_frame which_frame],[min(cytosolic_Ca_tot_time_mapped_t0(idx,:)-cytosolic_Ca_tot_time_mapped_t0(idx,1)) max(cytosolic_Ca_tot_time_mapped_t0(idx,:)-cytosolic_Ca_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     legend(strcat('cytsolic Ca2+,nuc:',num2str(which_nucleus)))
     xlabel('number of frames');
    xlim([0 numFr]);

    if (which_frame == 1)
     do_continue = input('do you want to watch this event? 1-yes, 0-no');
     if (do_continue ~=1)
         do_continue = 0;
     end;
    end;
    
end;


end;  % END OF: for kkk = 1:length(which_frames)    
end; % END OF: for which_nucleus = 1:num_nuclei_t0
    



     
              



