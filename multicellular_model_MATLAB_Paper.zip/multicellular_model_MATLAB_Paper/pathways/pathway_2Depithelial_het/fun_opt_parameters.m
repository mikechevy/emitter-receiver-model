function error = fun_opt_parameters(x)

global map_param_search;
global num_parameters_to_opt;
global c_mu;
global c_mu_0;
global map_y_error;
global y_0ss;

        for ii = 1:num_parameters_to_opt
           which_reaction = num_param_search(ii_count_params);
           c_mu(which_reaction) = x_final(ii);
           c_mu_0(which_reaction) = x_final(ii);
        end;

options = odeset('AbsTol',1e-4,'RelTol',1e-4);

cd ../../gillespie_code;
    if (do_include_moment_data == 1)
          calculate_data_driven_genes;
         [time_out, y_out] = ode15s('moments_with_data',time_moments_data,y_0ss',options);
    else
         [time_out, y_out] = ode15s('moments_unrestricted',time_moments_data,y_0ss',options);
    end;
cd ../pathways/pathway_data;

error = 0;
for kk =1:length(map_y_error)
 ii_quantity = map_y_error(kk);
 error = error + (y_out(:,ii_quantity) - moments_data_sampled(:,ii_quantity))*(y_out(:,ii_quantity) - moments_data_sampled(:,ii_quantity))';
end;
