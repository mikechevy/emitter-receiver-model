%close all;
%clear all;

set_globals;

get_movie_info_for_processing  % which_movie must already be set
str_movie = strcat('C:\Users\Mike\Desktop\Multi-cellular\multicellular_movie_processing\',str_movie);
str_movie_processed = strcat(str_movie,'_processed')
  

% load in some basic parameters
file_params = strcat(str_movie_processed,'\basic_params_for_analysis');
load(file_params);

file_track = strcat(str_movie_processed,'\track_nuclear_positions'); 
load(file_track);



which_frames = 1:numFr;


% load in the thresholded nuclei information from all frames 
%file_nucleus_tot = strcat(str_movie_processed,'\Cell_nucleus_structs_tot');
%load(file_nucleus_tot);
file_nucleus_tot_FINAL = strcat(str_movie_processed,'\Cell_nucleus_structs_tot_FINAL');
load(file_nucleus_tot_FINAL);

% load time series file foor tracking the cells
file_track_cells = strcat(str_movie_processed,'\track_cells_time_series');
load(file_track_cells);

  
 

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % BEGIN:  setup some arrays
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
 num_pixels_tot_CYTOSOL_time = zeros(num_nuclei_max, length(which_frames));
 nuclear_FITC_tot_time = zeros(num_nuclei_max, length(which_frames));
 nuclear_CY3_tot_time = zeros(num_nuclei_max, length(which_frames));
 cytosolic_FITC_tot_time = zeros(num_nuclei_max, length(which_frames));
 cytosolic_CY3_tot_time = zeros(num_nuclei_max, length(which_frames)); 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % END:  setup some arrays
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

 x_coord_min_tot_CYTOSOL_time_mapped_t0 = 0*x_coord_min_tot_NUCLEUS_time_mapped_t0;
 x_coord_max_tot_CYTOSOL_time_mapped_t0 = 0*x_coord_max_tot_NUCLEUS_time_mapped_t0;
 y_coord_min_tot_CYTOSOL_time_mapped_t0 = 0*y_coord_min_tot_NUCLEUS_time_mapped_t0;
 y_coord_max_tot_CYTOSOL_time_mapped_t0 = 0*y_coord_max_tot_NUCLEUS_time_mapped_t0;
 num_pixels_tot_CYTOSOL_time_mapped_t0 = num_pixels_tot_NUCLEUS_time_mapped_t0; 
  
 for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk)
     
  
  str_movie_processed = strcat(str_movie,'_processed')
  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus)

  
    
  num_nuclei = num_nuclei_time(which_frame); 
  num_pixels_tot_NUCLEUS = num_pixels_tot_NUCLEUS_time(1:num_nuclei,which_frame); 
  box_coords = box_coords_DAPI; 
  M_marker_threshold = M_DAPI_threshold_FILL;
  M_marker_id_threshold = M_DAPI_id_threshold;
      
  which_frame    
  %  calculated the average signals in each cell per frame
  determine_nucleus_and_cytosolic_signals_per_frame_PRACTICAL
  which_frame          
  
      %mean_x_tot_time(1:num_nuclei,which_frame) = mean_x_tot(:);
      %mean_y_tot_time(1:num_nuclei,which_frame) = mean_y_tot(:);
      %num_nuclei_time(which_frame) = num_nuclei;      
      %num_pixels_tot_CELL_time(1:num_nuclei,which_frame) = num_pixels_tot_CELL(:);
      %num_pixels_tot_NUCLEUS_time(1:num_nuclei,which_frame) = num_pixels_tot_NUCLEUS(:);

      
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %  used by 'track_cells' 
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     mean_x_tot_m1 = mean_x_tot; 
%     mean_y_tot_m1 = mean_y_tot; 
%     num_nuclei_m1 = num_nuclei; 
%     M_DAPI_m1 = M_DAPI;
%     M_FITC_m1 = M_FITC;
%     M_CY3_m1 = M_CY3;
   
   

do_plot_boxes = 0; 
if (do_plot_boxes == 1)            
which_box = num_nuclei;
figure(1)
imagesc(M_marker_threshold)
hold on;
          for iii = 1:which_box
                 
                 x_coord_min = box_coords(iii,1);
                 x_coord_max = box_coords(iii,2);
                 y_coord_min = box_coords(iii,3);
                 y_coord_max = box_coords(iii,4);

             % have to swith the x with the y coordinates for this
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
              text((y_coord_min+y_coord_max)/2,(x_coord_min+x_coord_max)/2,num2str(iii));
                    
                    
%                   M_dummy = zeros(2,2);  
%                   M_dummy(1,1) = var_x_tot(iii); 
%                   M_dummy(2,2) = var_y_tot(iii); 
%                   M_dummy(1,2) = cov_xy_tot(iii); 
%                   M_dummy(2,1) = cov_xy_tot(iii); 
%                   [U_dummy L_dummy] = eig(M_dummy);
%                   %angle_ellipse = angle(U_dummy(1:2));
%                   angle_ellipse = angle([U_dummy(1,2); U_dummy(1:1)])+90;  % might not be correct, CORRECT THIS!!!!
%               ellipse(sqrt(L_dummy(2,2)), sqrt(L_dummy(1,1)), angle_ellipse, mean_y_tot(iii), mean_x_tot(iii));   
          end;
hold off;
pause;
end; % END OF: if (do_plot_boxes == 1)            





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% write out the final nuclei-pixel array file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
file_cytosol_tot_FINAL = strcat(str_movie_processed,'\Cell_cytosol_structs_tot_FINAL');
%for kkk = 1:numFr
    which_frame = which_frames(kkk);
     if (which_frame == 1)
       save(file_cytosol_tot_FINAL,strcat('Cell_cytosol_FILL_',num2str(which_frame)));
     else
       save(file_cytosol_tot_FINAL,strcat('Cell_cytosol_FILL_',num2str(which_frame)),'-append');
     end;
%end;


    
    
    
 end;  % end of  'for kkk = 1:length(which_frames)

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% map the nuclear and cytosolic signals from each eamage
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for iii = 1:num_nuclei_t0
    ii_map = iii;  % points to the normal order for the first frame only
for kkk = 1:length(which_frames)
  which_frame = which_frames(kkk);
%    cytosolic_FITC_tot_time_mapped_t0(iii,which_frame) = cytosolic_FITC_tot_time(ii_map,which_frame);
%    cytosolic_CY3_tot_time_mapped_t0(iii,which_frame) = cytosolic_CY3_tot_time(ii_map,which_frame);
%    nuclear_FITC_tot_time_mapped_t0(iii,which_frame) = nuclear_FITC_tot_time(ii_map,which_frame);
%    nuclear_CY3_tot_time_mapped_t0(iii,which_frame) = nuclear_CY3_tot_time(ii_map,which_frame);
%    num_pixels_tot_CELL_time_mapped_t0(iii,which_frame) = num_pixels_tot_CELL_time(ii_map,which_frame);
     
    if (kkk == 1)
      index_map_tot_time_mapped_t0(iii,which_frame) = iii;  
    end;

    ii_map = index_map_forward_tot(ii_map,which_frame);  % points to the index of the properly mapped nuclues in the next frame
end;
end; 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Save processed cell signall data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
str_movie_processed = strcat(str_movie,'_processed')
file_signals = strcat(str_movie_processed,'\cellular_signals'); 
save(file_signals, 'num_pixels_tot_CYTOSOL_time','num_pixels_tot_NUCLEUS_time','nuclear_FITC_tot_time','nuclear_CY3_tot_time','cytosolic_FITC_tot_time','cytosolic_CY3_tot_time','mean_x_tot_time','mean_y_tot_time','num_nuclei_time','index_map_tot_time_mapped_t0','num_pixels_tot_NUCLEUS_time_mapped_t0','num_pixels_tot_CYTOSOL_time_mapped_t0','mean_x_tot_time_mapped_t0','mean_y_tot_time_mapped_t0','dist_map_tot_time_mapped_t0','cytosolic_FITC_tot_time_mapped_t0','cytosolic_CY3_tot_time_mapped_t0','nuclear_FITC_tot_time_mapped_t0','nuclear_CY3_tot_time_mapped_t0','num_nuclei_t0','num_mapped','num_nuclei_max','index_map_forward_tot','dist_map_forward_tot','index_map_backward_tot_f','index_map_backward_tot','dis_map_backward_tot','xLength','yLength','numFr','which_frames','x_coord_min_tot_CYTOSOL_time_mapped_t0','x_coord_max_tot_CYTOSOL_time_mapped_t0','y_coord_min_tot_CYTOSOL_time_mapped_t0','y_coord_max_tot_CYTOSOL_time_mapped_t0');
 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % write out the final nuclei-pixel array file
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% file_cytosol_tot_FINAL = strcat(str_movie_processed,'\Cell_cytosol_structs_tot_FINAL');
% for kkk = 1:numFr
%     which_frame = which_frames(kkk);
%      if (which_frame == 1)
%        save(file_cytosol_tot_FINAL,strcat('Cell_cytosol_FILL_',num2str(which_frame)));
%      else
%        save(file_cytosol_tot_FINAL,strcat('Cell_cytosol_FILL_',num2str(which_frame)),'-append');
%      end;
% end;



plot_localized_group_of_nuclei_over_time



do_calculate_threshold_value = 0;
if (do_calculate_threshold_value == 1)
   M_marker = M_DAPI;
   max_max_M_marker = max(max(M_marker));
   min_min_M_marker = min(min(M_marker));
   M_marker_NORMALIZED = double(M_marker-min_min_M_marker)/double(max_max_M_marker-min_min_M_marker);
         %set the image boundaroes to zero
      M_marker_NORMALIZED(1:xLength,yLength:yLength) = 0;
      M_marker_NORMALIZED(1:xLength,1:1) = 0;
      M_marker_NORMALIZED(xLength:xLength,1:yLength) = 0;
      M_marker_NORMALIZED(1:1,1:yLength) = 0;    
for iii = 1:num_nuclei_time(which_frame)
           matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;
           matrix_nucleus_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{iii}'])) =  1;
    nuclear_threshold_value_tot_time(iii,which_frame) = min(min(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_marker_normalized(x_coord_min:x_coord_max,y_coord_min:y_coord_max)));
    nuclear_threshold_value_tot_time(iii,which_frame) = min(min(matrix_nucleus_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{iii}'])).*M_marker_normalized(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{iii}']))));
end;
end;



