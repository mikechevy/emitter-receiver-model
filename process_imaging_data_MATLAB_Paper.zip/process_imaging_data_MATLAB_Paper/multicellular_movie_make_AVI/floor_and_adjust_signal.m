% plot time signals above/below/inside nucleus
function [Marker_signal_adjusted,Marker_signal_floor,Marker_signal,num_nucleus] = floor_signal(Marker_signal, num_nucleus, numFr, block_size,do_floor_plots)

global time_sequence_movie;

Marker_signal_floor = Marker_signal;
Marker_signal_adjusted = Marker_signal;

  for iii = 1:num_nucleus
      
      for jjj = round(block_size/2.0):block_size:numFr-round(block_size/2.0)
          Marker_signal_floor(iii,jjj) = min(Marker_signal(iii,jjj-round(block_size/2.0)+1:jjj+round(block_size/2.0)));        
      end;
      for jjj = round(block_size/2.0):block_size:numFr-round(block_size/2.0)
          
          for kkk = jjj-round(block_size/2.0)+1:jjj+round(block_size/2.0)
                 if (kkk<jjj)
                             if (jjj == round(block_size/2.0))
                                Marker_signal_floor(iii,kkk)=Marker_signal_floor(iii,jjj); 
                             else
                              lower = (block_size-(kkk-(jjj-block_size)))/block_size;
                              upper = 1-lower;
                                Marker_signal_floor(iii,kkk)= lower*Marker_signal_floor(iii,jjj-block_size)+upper*Marker_signal_floor(iii,jjj);
                             end;
                 else
                           if (jjj == numFr-round(block_size/2.0))                    
                              Marker_signal_floor(iii,kkk)=Marker_signal_floor(iii,jjj); 
                           else
                              lower = (block_size-(kkk-jjj))/block_size;
                              upper = 1-lower;
                              Marker_signal_floor(iii,kkk)= lower*Marker_signal_floor(iii,jjj)+upper*Marker_signal_floor(iii,jjj+block_size);
                           end;
                 end;                 
               %nuclear_Ca_signal_floor(iii,kkk)=nuclear_Ca_signal_floor(iii,jjj); 
          end;
              
      end;

     if do_floor_plots == 1
      figure(1)
      close(1);
      figure(1)
      hold on;
      plot(time_sequence_movie,Marker_signal(iii,:));
      plot(time_sequence_movie,Marker_signal_floor(iii,:),'g--');
      hold off;
      title(strcat('nuclues:',num2str(iii)));
      xlabel('time (seconds)');
      %ylim([400 800]);
      
      figure(2)
      subplot(2,1,1)
      plot(time_sequence_movie,Marker_signal(iii,:)-Marker_signal_floor(iii,:));
      %ylim([0 800]);
      xlabel('time (seconds)');
      subplot(2,1,2)
      do_xcorr = 0; % 1 - yes, 0 - no
      if (do_xcorr == 1)
      plot(xcorr(Marker_signal(iii,:)-Marker_signal_floor(iii,:),Marker_signal(iii,:)-Marker_signal_floor(iii,:))/numFr);
      end;
      ylabel('cross correlateion')
      %ylim();
      xlabel('time (seconds)');
      pause
      
      
%          figure(101)
%          imagesc(M_marker_threshold)
%          hold on;
%                  
%                  x_coord_min = box_coords(iii,1);
%                  x_coord_max = box_coords(iii,2);
%                  y_coord_min = box_coords(iii,3);
%                  y_coord_max = box_coords(iii,4);
% 
%              % have to swith the x with the y coordinates for this
%              rectangle('Position', [y_coord_min,x_coord_min,...
%                   y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
%                         'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
%                         'EdgeColor', 'm');
                    
     end; % end of 'if do_floor_plots == 1'
      
      
     Marker_signal_adjusted(iii,:) = Marker_signal(iii,:)-Marker_signal_floor(iii,:);
     
  end;   
