

for jjj = 1:length(index_sample_frame_Ca)

     which_sample_frame = index_sample_frame_Ca(jjj);
        if (which_sample_frame == 1)
         start_frame = 1+1;
         end_frame = 1+num_sample_sequence(1);
        else
         start_frame = 1+sum(num_sample_sequence(1:which_sample_frame-1))+1;
         end_frame = 1+sum(num_sample_sequence(1:which_sample_frame));            
        end;
    
nuclear_Ca_signal_adjusted_bursting_frame = [];

 for iii = 1:num_nuclei_t0
     
     if (bursting_nuclear_Ca_cells_per_sample_frame(iii,jjj) == 1) 
      nuclear_Ca_signal_adjusted_bursting_frame = [nuclear_Ca_signal_adjusted_bursting_frame; nuclear_Ca_signal_adjusted(iii,start_frame:end_frame)];
      index_Ca_signal_adjusted_bursting_frame(length(nuclear_Ca_signal_adjusted_bursting_frame(:,1))) = iii;
     end;
 end;
 num_nuclei_bursting_frame = sum(bursting_nuclear_Ca_cells_per_sample_frame(:,jjj));
      
ratio_xcorr = 1/1.8;  % one over the ratio of max value to next closest value  
 %ratio_xcorr = .2
[xcorr_group,size_xcorr_group] = findHotSpotsMetric(nuclear_Ca_signal_adjusted_bursting_frame,num_nuclei_bursting_frame,ratio_xcorr,ii_xcorr);

  xcorr_group_dummy = xcorr_group
  for ii = 1:length(size_xcorr_group)
   for jj = 1:size_xcorr_group(ii)
      xcorr_group(ii,jj) = index_Ca_signal_adjusted_bursting_frame(xcorr_group_dummy(ii,jj)); 
   end;
  end
  
  which_frame = 1

  %str_movie_processed = strcat(str_movie,'_processed')
  str_movie_processed = strcat('..\Movies_Processed\',str_movie,'_processed')
  file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
  load(file_nucleus);

  M_marker_threshold = M_DAPI_threshold_FILL;
  box_coords = [x_coord_min_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame) x_coord_max_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame) y_coord_min_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame) y_coord_max_tot_NUCLEUS_time_mapped_t0(1:num_nuclei_t0,which_frame)];
  mean_x_tot = mean_x_tot_time_mapped_t0(1:num_nuclei_t0,which_frame);
  mean_y_tot = mean_y_tot_time_mapped_t0(1:num_nuclei_t0,which_frame);
  
box_coords_cluster = zeros(length(size_xcorr_group),4);  
num_clusters = length(size_xcorr_group);
size_cluster = size_xcorr_group;
cluster = xcorr_group;

  box_coords_cluster(:,1) = xLength+1;
  box_coords_cluster(:,2) = 0;
  box_coords_cluster(:,3) = yLength+1;
  box_coords_cluster(:,4) = 0;

for ii = 1:length(size_xcorr_group)
ii
length(size_xcorr_group)

                 fig100 = figure(100);
                 imagesc(M_marker_threshold)
                 
                 x_coord_min_local = xLength;
                 x_coord_max_local = 1;
                 y_coord_min_local = yLength;
                 y_coord_max_local = 1;
    
    for jj = 1:size_xcorr_group(ii)
    
                 figure(100)
                 hold on;
                 x_coord_min = box_coords(xcorr_group(ii,jj),1);
                 x_coord_max = box_coords(xcorr_group(ii,jj),2);
                 y_coord_min = box_coords(xcorr_group(ii,jj),3);
                 y_coord_max = box_coords(xcorr_group(ii,jj),4);

                     x_coord_min_local = min(x_coord_min_local,x_coord_min);
                     x_coord_max_local = max(x_coord_max_local,x_coord_max);
                     y_coord_min_local = min(y_coord_min_local,y_coord_min);
                     y_coord_max_local = max(y_coord_max_local,y_coord_max);

                 
                 box_coords_cluster(ii,1) = min(box_coords_cluster(ii,1),box_coords(xcorr_group(ii,jj),1)); 
                 box_coords_cluster(ii,2) = max(box_coords_cluster(ii,2),box_coords(xcorr_group(ii,jj),2)); 
                 box_coords_cluster(ii,3) = min(box_coords_cluster(ii,3),box_coords(xcorr_group(ii,jj),3)); 
                 box_coords_cluster(ii,4) = max(box_coords_cluster(ii,4),box_coords(xcorr_group(ii,jj),4)); 
                 
                % have to swith the x with the y coordinates for this
                 rectangle('Position', [y_coord_min,x_coord_min,...
                   y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
                         'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                         'EdgeColor', 'r');
                  text(mean_y_tot(xcorr_group(ii,jj)),mean_x_tot(xcorr_group(ii,jj)),num2str(jj))
                  hold off;
        
      fig1000 = figure(1000);
      subplot(size_xcorr_group(ii),2,2*(jj-1)+1)
      hold on;
      plot(time_sequence_movie,nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),:),'g--');
      plot([time_sequence_movie(start_frame) time_sequence_movie(start_frame)],[0 max(nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),:))],'k--');
      plot([time_sequence_movie(end_frame) time_sequence_movie(end_frame)],[0 max(nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),:))],'k--');
      hold off;
      ylabel(strcat('cell ',num2str(jj)));
      ylim([0 3*threshold_burst_Ca]);
      xlim([time_sequence_movie(1) time_sequence_movie(length(time_sequence_movie))]);
      
      subplot(size_xcorr_group(ii),2,2*(jj-1)+2)
      plot(time_sequence_movie(start_frame:end_frame),nuclear_Ca_signal_adjusted(xcorr_group(ii,jj),start_frame:end_frame),'g--');
      ylabel(strcat('cell ',num2str(jj)));
      ylim([0 3*threshold_burst_Ca]);
      xlim([time_sequence_movie(start_frame) time_sequence_movie(end_frame)]);
      
      
      fig2000 = figure(2000);
      subplot(size_xcorr_group(ii),1,jj)
       if (jj ==1)
           title('cross-correlation with each surrounding cells');
       end;
       time_xcorr = -dt_sequence_movie(1)*(end_frame-start_frame+1-1):dt_sequence_movie(1):dt_sequence_movie(1)*(end_frame-start_frame+1-1);
          signal_1 = nuclear_Ca_signal_adjusted_bursting_frame(xcorr_group_dummy(ii,1),:);
          signal_2 = nuclear_Ca_signal_adjusted_bursting_frame(xcorr_group_dummy(ii,jj),:);
                xcorr_test = xcorr(signal_1-mean(signal_1),signal_2-mean(signal_2));  
                xcorr_test = xcorr_test/(sqrt(signal_1*signal_1')*sqrt(signal_2*signal_2'))
      plot(time_xcorr,xcorr_test);
      ylabel(strcat('cell ',num2str(jj)));
      xlim([min(time_xcorr),max(time_xcorr)]);
      ylim([min(1.1*min(xcorr_test),0) 1]);
      
      figBlank = figure(10000);
     %    figure(101)
     %    imagesc(M_marker_threshold)
     %    hold on;
        

    end;

       dosavePPT2=0; % 1 - saves as ppt file, 0 - no
       %pptTitle = strcat('/',str_movie_processed,'/xcorr');
       pptTitle = strcat('xcorr');
        if dosavePPT2 == 1
             save_figs_to_ppt2_xcorr
        else
            %pause;
            do_examine_local_cells = input('Do you want to examine the local cell signals? 1 - yes, 0 - no: ');
                   %do_examine_local_cells = 1;  % 1 - yes, 0 - no                   
                   if (do_examine_local_cells == 1)
                     x_coord_min_local = max(x_coord_min_local-40,1)
                     x_coord_max_local = min(x_coord_max_local+40,xLength);
                     y_coord_min_local = max(y_coord_min_local-40,1)
                     y_coord_max_local = min(y_coord_max_local+40,yLength);
                     plot_localized_group_adjusted_signals
                     pause
                   end;
                 plot_all_groups;  
        end;
       
end;

end; % END OF: for jjj = 1:length(index_sample_frame_Ca)




do_make_localized_movie = 0; % 1 - yes, 0 - no
if (do_make_localized_movie == 1)
 %  makes movies in each region that contains a cluster
 make_localized_movie_for_each_cluster

 which_cluster = 1;
 view_movie_of_cluster(which_cluster,str_movie)
end;  % end of: if (do_make_localized_movie == 1)
