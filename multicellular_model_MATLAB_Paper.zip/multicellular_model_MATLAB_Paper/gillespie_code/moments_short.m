


function y_prime = moments_short(t,y)

global num_molecules;
global num_reactions;
global stochasticity;
global stochasticity_conj;
%global reaction_constant;
global propensities;
global sign_value_reaction;
global reaction_type;
global reaction_molecules;
global molecule_gene;
global c_mu;

global do_zero_order_hybrid;
global do_covariances;
global do_cov_nonlin;
global do_quadratic_terms;
global covariance_map;
global count_cov_map;
global Cov_mat;
global species_restricted;
global species_restricted_conj;

global species_cov;
global species_cov_conj;
global which_distribution;

global der_1_unr;
global der_2_unr;

global species_cov;
global species_cov_conj;

global freq_tv;
global time_constant_tv;
global c_mu_tv;
global phase_c_mu_tv;
global c_mu_0;
global do_prop_time_vary;

global time;


%  maps for the moment calculations in the hybrid code
global num_prop_deriv1;    
global prop_deriv1_map;    
global num_prop_deriv2;    
global prop_deriv2_map;    

global length_time_u_array;
global max_time;
global which_time_segment;
global which_time_segment;
global freq_tv_time_array;
global time_constant_tv_time_array;
global c_mu_tv_time_array;
global phase_c_mu_tv_time_array;
global c_mu_0_time_array;
global do_prop_time_vary_time_array;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  experimental moment data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global covariance_map_moments;
global num_cov_moments_data;
global dt_moments_data_sampled;
global time_moments_data_sampled;
global moments_data_sampled;
global include_moment_data_map;


y_prime = zeros(1,length(y));


   if (do_covariances==1)
       Cov_mat = 0*Cov_mat;
     for ii = 1:count_cov_map
               index_1 = covariance_map(ii,1);
               index_2 = covariance_map(ii,2);
               
               Cov_mat(index_1 , index_2) = y(num_molecules+ii);  %  C_jj_ii
               Cov_mat(index_2 , index_1) = y(num_molecules+ii);  %  C_ii_jj
     end;        
   end;


y_dummy = zeros(num_molecules,1); % array used for propensity calculations
y_dummy = y(1:num_molecules);  % get necessary data into array for propensity calculation



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  inputs data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global do_read_inputs_data;  % allows the input species' to be updated over time from a file or array
global time_inputs_data_sampled;
global inputs_data_sampled;
global map_inputs_data_sampled;


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  BEGIN: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 if (do_read_inputs_data == 1)

  for ii = 1:length(map_inputs_data_sampled)
    [val,index_min] = min(abs(t-time_inputs_data_sampled(ii,:)));
       if (time_inputs_data_sampled(ii,index_min) > t)
           index_lower_data = index_min-1;
       else
         index_lower_data = index_min;
       end;

      if (index_lower_data < length(time_inputs_data_sampled(ii,:)))
       upper_data = (t-time_inputs_data_sampled(ii,index_lower_data))/(time_inputs_data_sampled(ii,index_lower_data+1)-time_inputs_data_sampled(ii,index_lower_data));
       lower_data = 1-upper_data;
      else
       index_lower_data = length(time_inputs_data_sampled(ii,:))-1;
       upper_data = 1;
       lower_data = 1-upper_data;
      end;

    which_input = map_inputs_data_sampled(ii);
    y_dummy(which_input) = lower_data*inputs_data_sampled(ii,index_lower_data) + upper_data*inputs_data_sampled(ii,index_lower_data+1);

  end; % for ii = 1:length(map_inputs_data_sampled)

 end; % if (do_read_intputs_data == 1)
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %  END: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reset both first derivative matrices for 
% unrestriced reactions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
der_1_unr = 0*der_1_unr;
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BEGIN:  SETUP SUMS AND ARRAYS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BEGIN: for jj = 1:num_reactions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for jj = 1:num_reactions
    
    sum2species_der_2_cov_unr(jj) = 0; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate first derivatives here
%    Unrestricted reactions, matrix (reaction vs. molecule)
%                      der_1_unr(j,i) da_j/dxi 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


  if (do_covariances == 1)
       for ii = 1: num_prop_deriv1(jj,1)
            index_1 = prop_deriv1_map(jj,ii);
            %if (species_restricted(index_1) == 0)  % must be w.r.t an unrestricted species
                   dummy_xi = calc_derivs1_single_analytical(y_dummy(1:num_molecules),jj,ii);
               der_1_unr(jj,index_1) = dummy_xi;  % unrestricted reactions w/ covariance, first derivative matrix
       end;    

  end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  unrestricted reaction:
%              sum2species_der_2_cov_unr(j) = Sum_i Sum_i' d^2a_j/(dxi dxi') * Cii'
%              j = jj , i = index_1 , i' = index_2
%              dummy_xi_xj = d^2 a_j/(dxi dxi')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
  if (do_covariances == 1)
       for ii = 1: num_prop_deriv2(jj,1)
            index_1 = prop_deriv2_map(jj,2*ii-1);
            index_2 = prop_deriv2_map(jj,2*ii);
            
                   dummy_xi_xj = calc_derivs2_single_analytical(y_dummy(1:num_molecules),jj,ii);
            %if (molecule_gene(index_1)==0)&(molecule_gene(index_2)==0)
              if (index_1 == index_2)  %  C_ii'/2
               sum2species_der_2_cov_unr(jj) = sum2species_der_2_cov_unr(jj) + dummy_xi_xj*Cov_mat(index_1,index_2)/2;
              else  %  C_ii'
               sum2species_der_2_cov_unr(jj) = sum2species_der_2_cov_unr(jj) + dummy_xi_xj*Cov_mat(index_1,index_2);
              end;
            %end;

       end;
  end;

  

end;  % end of 'for jj =1:num_reactions'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END: for jj = 1:num_reactions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END:  SETUP SUMS AND ARRAYS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  END OF SETUP DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



calculate_reaction_constants(y_dummy);

%  mass-action equations here, we might make this more efficient, maybe

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% BEGIN: medium way
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for ii = 1:num_molecules
        for jj = 1:num_reactions                  
         y_prime(ii) = y_prime(ii) + sign_value_reaction(jj,ii)*propensities(jj);       
        end;        
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% END: medium way
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for ii = 1:num_molecules
  y_prime(ii) = y_prime(ii) + do_quadratic_terms*sign_value_reaction(:,ii)'*sum2species_der_2_cov_unr(:);
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  BEGIN:  ALL COVARIANCE CONTRIBUTIONS BELOW
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if (do_covariances==1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Second moment (Covariance) equations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%for kk = 1:length(y_index)
%         index_dummy = y_index(kk)-num_molecules;
%  if (index_dummy>=1)
%             k = covariance_map(index_dummy,1);
%             k_prime = covariance_map(index_dummy,2);


             count_map = 1;
for kk = 1+num_molecules:count_cov_map+num_molecules              
             k = covariance_map(count_map,1);
             k_prime = covariance_map(count_map,2);
             count_map = count_map+1;



      sum_1 = 0;  %  first derivative / Covariance sums
      sum_2 = 0;  %  propensity + second derivative/Covariance  sums

      
       for jj = 1:num_reactions

            for ii = 1: num_prop_deriv1(jj,1)
               i_index = prop_deriv1_map(jj,ii);
              if (species_cov(i_index)==1)
               sum_1 = sum_1 + sign_value_reaction(jj,k)*der_1_unr(jj,i_index)*Cov_mat(i_index,k_prime);
               sum_1 = sum_1 + sign_value_reaction(jj,k_prime)*der_1_unr(jj,i_index)*Cov_mat(k,i_index);
              end;
            end;  
            
               %  1st propensity derivatives multiplying the
               %  Covariances
             %  contribution of the second line in the covariance equations
            sum_2 =  sum_2 + sign_value_reaction(jj,k)*sign_value_reaction(jj,k_prime)*( propensities(jj) + do_quadratic_terms*sum2species_der_2_cov_unr(jj) );
            %sum_error =  sum_error + sign_value_reaction(jj,k)*sign_value_reaction(jj,k_prime)*( propensities(jj));
            
                 

        end; % END:  'for jj=1:num_reactions'
           
   
        y_prime(kk) = sum_1 + sum_2;


  %end; % end of 'if (index_dummy>=1)'

end;   % end of 'if (do_covariances==1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    END: ALL COVARIANCE CONTRIBUTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end  %  end of 'if (do_covariances==1)'


y_prime = y_prime';



