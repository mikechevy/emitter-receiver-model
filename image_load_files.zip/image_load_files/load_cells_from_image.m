



% if which_movie == 0  % mixed MDCK and MDCK+bPAC cells  
%     str_movie = 'Pos0'
% elseif which_movie == 1  % pure MDCK+bPAC (Ca signaling movie used in NSF grant) 
%     str_movie = 'Pos1'
% elseif which_movie == 2  % mixed MDCK and MDCK+bPAC cells
%     str_movie = 'Pos2'  
% elseif which_movie == 3  % pure MDCK  
%     str_movie = 'Pos3'
% elseif (which_movie == 4)  % Creb reporter, no drug 
%     str_movie = 'Creb_no_drug'
% elseif (which_movie == 5)  % Creb reporter, forskolin 
%     str_movie = 'Creb_forskolin'
% elseif (which_movie == 6)  % Creb reporter, pka inhibitor 
%     str_movie = 'Creb_pka_inhibitor'
% elseif (which_movie == 7)  % Creb reporter, ibmx 
%     str_movie = 'Creb_ibmx'
% elseif (which_movie == 8)  % MDCK, Erk, Ca  (high fcs)
%     str_movie = '150626_Erk_Ca'
% elseif (which_movie == 9)  % MDCK (bPAC), Erk (no fcs)
%     str_movie = 'Erk_bPAC_passive'
% elseif (which_movie == 10)  %  MDCK,   (low fcs)
%     str_movie = '150707_MDCKI_39_117_207_highfcs'
% elseif (which_movie == 11)  %  MDCK, PKA marker (high fcs)
%     str_movie = 'Fast_cells_high_fcs'
% elseif (which_movie == 12)  %  MDCK, PKA  (low fcs)
%     str_movie = 'Fast_cells_low_fcs'
% elseif (which_movie == 13)  %  MDCK, PKA  (low fcs)
%     str_movie = 'Calcium_061215'
% elseif (which_movie == 14)  %  MDCK, PKA  (low fcs)
%     str_movie = 'Ca_Erk_noBpac_6s'
% elseif (which_movie == 15)  %  MDCK, PKA  (low fcs)
%     str_movie = 'Ca_Erk_noBpac_15s'
% elseif (which_movie == 16)  %  MDCK, PKA  (low fcs)
%     str_movie = '150820_MDCKI-198-232'
% elseif (which_movie == 17)  
%     str_movie = '198-117_6min-150min_6s-20min_6min-150min_DAPI-50ms-20_FITC-50ms_20_1'
% end;    
% 

load_from_movie = 1; % 0-no,1-yes

if (load_from_movie == 1)
    
which_movie = 1;  % pure MDCK+bPAC (Ca signaling movie used in NSF grant)

%%The function 'load_and_calculate_cellular_signals.m' from the image analsysi software calculates the boxes of
%%cells we will be interested in.  When we obtain some interesting data to model, we will eventually use this to set x_coord_min_local, x_coord_max_local, y_coord_min_local, y_coord_max_local,                      
                     x_coord_min_local = 200;
                     x_coord_max_local = 500;
                     y_coord_min_local = 200;
                     y_coord_max_local = 500;

 determine_cells_within_box;
 
 save(strcat('imagefile_',str_movie_write),'x_coord_min_local','x_coord_max_local','y_coord_min_local','y_coord_max_local','index_group', 'Cell_nucleus_FILL_1','M_marker_threshold_TEST','mean_x_tot_time_mapped_t0', 'mean_y_tot_time_mapped_t0','index_map_tot_time_mapped_t0','str_movie_write','which_frames','xLength','yLength','numFr');
 
elseif (load_from_movie == 0)
    
 %generate_cells_within_box;   
 
end;    
    

