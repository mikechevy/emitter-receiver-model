
function bursting_cells_per_frame = calculate_bursting_cells_per_sample_frame(Marker_signal,index_sample_frame,num_nuclei,numFr,threshold_burst)

global time_sequence_movie;
global sample_sequence;
global num_sample_sequence;
global tau_sample_movie;
global dt_sample_movie;


bursting_cells_per_frame = zeros(num_nuclei,length(index_sample_frame));


for iii = 1:num_nuclei
for jjj = 1:length(index_sample_frame)
  if (index_sample_frame(jjj) == 1)
     %val = max(-threshold_burst + (Marker_signal(iii,1:1+num_sample_sequence(index_sample_frame(jjj))) ... 
     %                            -Marker_signal(iii,1) ));
     val = max(-threshold_burst + Marker_signal(iii,1:1+num_sample_sequence(index_sample_frame(jjj))) ); 
  else
     %val = max(-threshold_burst + (Marker_signal(iii,1+sum(num_sample_sequence(index_sample_frame(jjj)-1))+1:1+sum(num_sample_sequence(index_sample_frame(jjj)))) ...
     %                            -Marker_signal(iii,1+sum(num_sample_sequence(index_sample_frame(jjj)-1))+1) ));      
     val = max(-threshold_burst ... 
     +Marker_signal(iii,1+sum(num_sample_sequence(index_sample_frame(jjj)-1))+1:1+sum(num_sample_sequence(index_sample_frame(jjj)))) ) ;
  end;
    if (val > 0)
       bursting_cells_per_frame(iii,jjj) = 1; 
    end;            
end;
end;

