


global do_full;
global do_particles;

global a_0;  % constants in the function f
global a_1;  % constants in the function f
global a_2;  % constants in the function f
global a_3;  % constants in the function f
global a_4;  % constants in the function f
global a_5;  % constants in the function f
global a_6;  % constants in the function f
global a_7;  % constants in the function f
global a_8;  % constants in the function f
global a_9;  % constants in the function f

global a_0_eff;  % constants in the function f_eff
global a_1_eff;  % constants in the function f_eff

global eta_0_eff;  % constants in the function f_eff
global eta_1_eff;  % constants in the function f_eff
global n_eff; % constants in the function f_eff

global do_adaptive_hybrid;
global propensity_threshold;
global propensity_threshold_min;
global stiffness_threshold;
global stiffness_init;
global min_propensity;
global ii_ref_species;

global c;  % values of the function f
global c_max; % max value of the function f

global A_er;
global V_er;
global V_nuc;
global ss_or_transient;
global kappa_k2;

global k2_0;
global solve_full_splice;
global do_full;


% molecule indexes (general)
global ii_x0;
global ii_x1;
global ii_x2;
global ii_x3;
global ii_x4;
global ii_x5;
global ii_x6;
global ii_x7;
global ii_x8;
global ii_x9;
global ii_x10;
global ii_xmax;

%  pathways 0-3
global R_tot;
global which_pathway;

%  maps for the moment calculations in the hybrid code
global num_prop_deriv1;    
global prop_deriv1_map;    
global num_prop_deriv2;    
global prop_deriv2_map;    
global der_1_r;
global der_1_unr;
global der_2_r;
global der_2_unr;
global covariance_map;
global index_of_covariance_map;
global covariance_ld_map;
global count_cov_map;
global count_cov_ld_map;
global Cov_mat;
global species_restricted;
global species_restricted_conj;
global species_cov;
global species_cov_conj;
global which_distribution;

global count_data_sampled_total;
global count_data_sampled;
global max_count_data_sampled;
global X_data_sampled;
global time_data_sampled;
global num_sampled_ssa;
global dt_sampled;
global fids_data_sampled;

global do_zero_order_hybrid;
global do_covariances;
global do_covariances_od;
global do_cov_nonlin;
global do_quadratic_terms;
global do_max_prop_var;
global do_var_prop_thres;
global do_prop_time_vary;
global do_print_debug;
global do_pathway_specific_function;
global reaction_exponent_timeseries_array;
global tau_timeseries_array;
global reaction_timeseries_distribution;
global x_timeseries_array;
global x_timeseries_max;
global int_propensity_P_nr;
global int_propensity_P_nr_start;
global sum_int_propensity_P_nr_start;
global P_nr_start;
global P_nr;
global time_P_nr;
global time_P_nr_max;
global p_r;
global time_p_r;
global dt_P_nr;
global length_time_P_nr;
global do_log_time;
global min_time_exp;
global max_time_exp;
global num_samps_per_decade;
global species_timeseries;
global reaction_timeseries;
global species_reaction_timeseries;
global reaction_species_timeseries;
global index_tau;
global index_search;
global tau_start_array;
global upper_array;
global lower_array;
global ii_lower_array;
global ii_upper_array;

global length_cdf_norm;
global x_cdf_norm_min;
global x_cdf_norm;
global cdf_norm;
global delx_cdf_norm;

global length_x_mom;
global read_rand;  
global count_rand;
global length_array_rand;
global array_rand;

global max_moment_error_dummy;
global max_moment_error_array;

global x_current;
global num_molecules;
global stochasticity;
global stochasticity_eq;
global stochasticity_conj;
global num_reactions;
%global reaction_constant;
global propensities;
global sign_value_reaction;
global reaction_type;
global reaction_molecules;
global sum_propensities;
global c_mu;
global c_mu_0;
global c_mu_tv;
global phase_c_mu_tv;
global time_tv;
global freq_tv;
global time_constant_tv;
global x_ref;
global kappa;
global passed_constants;

global length_time_u_array;
global max_time;
global total_time;
global which_time_segment;
global which_time_segment;
global freq_tv_time_array;
global time_constant_tv_time_array;
global c_mu_tv_time_array;
global phase_c_mu_tv_time_array;
global c_mu_0_time_array;
global do_prop_time_vary_time_array;

global time;

global molecule_gene;
global non_stochastic;
global log_rand_exp_tau;
global rand_exp_tau;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  experimental moment data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global covariance_map_moments;
global num_cov_moments_data;
global dt_moments_data_sampled;
global time_moments_data_sampled;
global moments_data_sampled;
global include_moment_data_map;

global map_param_search;
global map_y_error;
global num_parameters_to_opt;

global do_initial_conditions;
global done_do_initial_conditions;

global y_index;
global y_index_gene;
global y_index_t_factor;
global gene_module_index;
global num_gene_modules;
global do_gene_modules_within_ode_solver;
global do_gene_modules_qss;
global index_time_qss;
global do_moments_with_data_ode_compact;
global do_t_factor_source;
global do_rate_constants_infer;
global num_sample_points_infer;
global time_sample_infer;
global index_reaction_infer;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% input data %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global do_read_inputs_data;  % allows the input species' to be updated over time from a file or array
global time_inputs_data_sampled;
global inputs_data_sampled;
global map_inputs_data_sampled;


%  molecule indexes

ii_x0 = 1;
ii_x1 = 2;
ii_x2 = 3;
ii_x3 = 4;
ii_x4 = 5;
ii_x5 = 6;
ii_x6 = 7;
ii_x7 = 8;
ii_x8 = 9;

                                  
D_m = .031;  % micrometers^2/s,  ER lipid membrane


%  relevant areas and volumes of different parts of the cell
A_er =  ((sqrt(2)*.517)^2)*260; % surface area of the ER in micrometer^2
V_er = (A_er/2)*.031;  % volume of the ER micrometers^3
V_ner = .39;
V_cer = V_er-V_ner;
V_nuc = (4*pi/3)*(sqrt((V_ner)/(4*pi*.031)))^3;
a_er =  sqrt((A_er)/(pi)); % spatial dimenstion of ER membrane surface, one 2D membrane , i.e. a circular patch of area pi*r*r
                                  % be discontinued
A_cell = A_er;  % approximately, we can readjust this later  
a_cell = a_er;  % approximately, we can readjust this later                                    
