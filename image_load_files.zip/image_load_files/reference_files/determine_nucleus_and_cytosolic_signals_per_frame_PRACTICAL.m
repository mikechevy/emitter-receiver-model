

% To start:
num_pixels_tot_CELL = num_pixels_tot_NUCLEUS;
eval(['Cell_cytosol_FILL_',num2str(which_frame),'=Cell_nucleus_FILL_',num2str(which_frame),';']);



for ii = 1:xLength    
    for jj = 1:yLength
         val_dummy = M_marker_id_threshold(ii,jj);
        if (val_dummy > 0)
            nuclear_FITC_tot_time(val_dummy,which_frame) = nuclear_FITC_tot_time(val_dummy,which_frame) + M_FITC(ii,jj);
            nuclear_CY3_tot_time(val_dummy,which_frame) = nuclear_CY3_tot_time(val_dummy,which_frame) + M_CY3(ii,jj);
        end;
    end;
end;


% convert to average signal per pixel
for ii = 1:num_nuclei
            nuclear_FITC_tot_time(ii,which_frame) = nuclear_FITC_tot_time(ii,which_frame)/num_pixels_tot_NUCLEUS(ii);
            nuclear_CY3_tot_time(ii,which_frame) = nuclear_CY3_tot_time(ii,which_frame)/num_pixels_tot_NUCLEUS(ii);
end;



matrix_cytosol_SCRAP = 0*M_FITC;
matrix_nucleus_SCRAP = 0*M_FITC;

do_cytosol = 1; % 1 - yes, 0 - no
if (do_cytosol == 1)      
for iii = 1:num_nuclei_t0

    
idx_map = index_map_tot_time_mapped_t0(iii,which_frame);    
    
    
matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;
matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
matrix_nucleus_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
        
                 %x_coord_min = box_coords(idx_map,1);
                 %x_coord_max = box_coords(idx_map,2);
                 %y_coord_min = box_coords(idx_map,3);
                 %y_coord_max = box_coords(idx_map,4); 
                 
                 % MAKE ON FRIDAY
                 x_coord_min = x_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 x_coord_max = x_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_min = y_coord_min_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                 y_coord_max = y_coord_max_tot_NUCLEUS_time_mapped_t0(iii,which_frame); 
                 
scale_factor_nucleus = 1.2;

for ii = x_coord_min:x_coord_max
 for jj = y_coord_min:y_coord_max
    
     if (matrix_nucleus_SCRAP(ii,jj) == 1)
         ii_scale = max(2,scale_factor_nucleus*(ii-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame));
         ii_scale = min(ii_scale,xLength-1);
         jj_scale = max(2,scale_factor_nucleus*(jj-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame));
         jj_scale = min(jj_scale,yLength-1);
         matrix_cytosol_SCRAP(ceil(ii_scale),ceil(jj_scale)) = 1;
         matrix_cytosol_SCRAP(floor(ii_scale),ceil(jj_scale)) = 1;
         matrix_cytosol_SCRAP(ceil(ii_scale),floor(jj_scale)) = 1;
         matrix_cytosol_SCRAP(floor(ii_scale),floor(jj_scale)) = 1;
     end;
     
 end;
end;
        

         x_coord_min_cytosol = max(1,floor(scale_factor_nucleus*(x_coord_min-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         x_coord_max_cytosol = min(xLength,ceil(scale_factor_nucleus*(x_coord_max-mean_x_tot_time_mapped_t0(iii,which_frame)) + mean_x_tot_time_mapped_t0(iii,which_frame)));
         y_coord_min_cytosol = max(1,floor(scale_factor_nucleus*(y_coord_min-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));
         y_coord_max_cytosol = min(yLength,ceil(scale_factor_nucleus*(y_coord_max-mean_y_tot_time_mapped_t0(iii,which_frame)) + mean_y_tot_time_mapped_t0(iii,which_frame)));

                 
         
    matrix_cytosol_SCRAP = max(matrix_cytosol_SCRAP,matrix_nucleus_SCRAP);     
    %matrix_cytosol_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  0;
    binary_FILL = bwareaopen(matrix_cytosol_SCRAP-matrix_nucleus_SCRAP, 0);  % remove 
    Cell_marker_FILL = bwconncomp(binary_FILL);
    eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map} = Cell_marker_FILL.PixelIdxList{1};'])
       
         
           do_plot_iterative = 0; % 1 - yes, 0 - no        
           if (do_plot_iterative == 1)
            figure(100)
            imagesc(matrix_nucleus_SCRAP);
            %imagesc(matrix_cytosol_SCRAP);
            %imagesc(binary_FILL);
            title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
            xlim([y_coord_min_cytosol y_coord_max_cytosol]);
            ylim([x_coord_min_cytosol x_coord_max_cytosol]);
            ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
            set(ll,'Color','y');
            figure(101)
            imagesc(matrix_cytosol_SCRAP-matrix_nucleus_SCRAP);
            title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
            xlim([y_coord_min_cytosol y_coord_max_cytosol]);
            ylim([x_coord_min_cytosol x_coord_max_cytosol]);
            ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
            set(ll,'Color','y');
           figure(102)
           matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
           matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
           imagesc(matrix_cytosol_SCRAP);
           title(strcat('which nuclues:',num2str(iii),' of: ',num2str(num_nuclei_t0)));
           xlim([y_coord_min_cytosol y_coord_max_cytosol]);
           ylim([x_coord_min_cytosol x_coord_max_cytosol]);
           ll = text(mean_y_tot_time_mapped_t0(iii,which_frame),mean_x_tot_time_mapped_t0(iii,which_frame),'X');
           set(ll,'Color','y');
           %pause
           end;


           
    x_coord_min_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = x_coord_min_cytosol;
    x_coord_max_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = x_coord_max_cytosol;
    y_coord_min_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = y_coord_min_cytosol;
    y_coord_max_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = y_coord_max_cytosol; 
    num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame) = length(Cell_marker_FILL.PixelIdxList{1});           
           
           
           matrix_cytosol_SCRAP = 0*matrix_cytosol_SCRAP;
           matrix_cytosol_SCRAP(eval(['Cell_cytosol_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
    cytosolic_FITC_tot_time_mapped_t0(iii,which_frame) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol).*M_FITC(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    cytosolic_CY3_tot_time_mapped_t0(iii,which_frame) = sum(sum(matrix_cytosol_SCRAP(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol).*M_CY3(x_coord_min_cytosol:x_coord_max_cytosol,y_coord_min_cytosol:y_coord_max_cytosol)))/num_pixels_tot_CYTOSOL_time_mapped_t0(iii,which_frame);
    
           matrix_nucleus_SCRAP = 0*matrix_nucleus_SCRAP;
           matrix_nucleus_SCRAP(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =  1;
    nuclear_FITC_tot_time_mapped_t0(iii,which_frame) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_FITC(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
    nuclear_CY3_tot_time_mapped_t0(iii,which_frame) = sum(sum(matrix_nucleus_SCRAP(x_coord_min:x_coord_max,y_coord_min:y_coord_max).*M_CY3(x_coord_min:x_coord_max,y_coord_min:y_coord_max)))/num_pixels_tot_NUCLEUS_time_mapped_t0(iii,which_frame);
                      
           
           do_segmentation = 0; % 1 - yes, 0 - no        
           if (do_segmentation == 1)
               if (iii == 1)
                for idx = 1:num_nuclei_t0       
                idx_map   = index_map_tot_time_mapped_t0(idx,which_frame);          
                M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
                end;
                 min_min_FITC = min(min(M_FITC));
                 max_max_FITC = max(max(M_FITC));
                 M_FITC_NORMALIZED = (M_FITC - min_min_FITC)/(max_max_FITC-min_min_FITC);
                 M_FITC_NORMALIZED_adjusted = 0*M_FITC_NORMALIZED;
                 M_FITC_binary = 0*M_FITC_NORMALIZED;
               end;
           segment_cell_boundary      
           end;
           

end; % END OF: for iii = 1:num_nuclei_t0
end; % END OF: if (do_cytosol == 1)      




