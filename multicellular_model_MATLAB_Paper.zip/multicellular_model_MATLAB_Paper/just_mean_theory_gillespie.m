
global num_molecules;
global stochasticity;
global stochasticity_conj;
global num_reactions;
global reaction_constant;
global sign_value_reaction;
global reaction_type;
global reaction_molecules;
global c_mu;
global x_ref;
global kappa;
global passed_constants;


cd gillespie_code;






% set max number of reactions and time
max_count_reactions = 8000;  %  max number of  reactions
time_start = max_time;
max_time = max_time+t_max;


% for non-stiff systems
%[time_mean, x_mean] = ode45('mean_theory',[0 20000],x_0_mean');
% for stiff_systems
%[time_mean, x_mean] = ode23t('mean_theory',[time_start max_time],x_0_mean');


if (do_include_moment_data == 0)
  if (do_quadratic_terms == 1)|(do_covariances==0)
   %[time_mean, x_mean] = ode15s('moments_unrestricted',[time_start max_time],x_0_mean',options);    
    if (do_cell_cycle_effects == 0)
     [time_mean, x_mean] = ode15s('moments_short',[time_start max_time],x_0_mean',options);
    else
     [time_mean, x_mean] = ode15s('moments_short_lin_mean_cell_cycle',[time_start max_time],x_0_mean(1:num_volumes*num_molecules+num_volumes+1)',options);
    end;
  else  % linearized affinity assumption
   %[time_mean, x_mean] = ode15s('moments_short',[time_start max_time],x_0_mean',options);
   
   if (do_cell_cycle_effects == 0)
    [time_moments_data_sampled, moments_data_sampled] = ode15s('moments_short_lin_mean',[time_start max_time],x_0_mean(1:num_molecules)',options);
   else
    [time_moments_data_sampled, moments_data_sampled] = ode15s('moments_short_lin_mean_cell_cycle',[time_start max_time],x_0_mean(1:num_volumes*num_molecules+num_volumes+1)',options);
   end;
   
     % if (do_ramp==1)&(do_time_dependent_inputs ~= 1)  % don't let this propensity affect any variability
     %       c_mu(ii_reaction_dX_dt) = 0;  % stay at the current value of X for the rest of the pulse
     %       c_mu_0(ii_reaction_dX_dt) = 0; % stay at the current value of X for the rest of the pulse
     % end;
   
   if (do_cell_cycle_effects == 0)
    %[time_mean, cov_mean] = ode15s('moments_short_lin_cov',time_moments_data_sampled,x_0_mean(num_molecules+1:num_molecules+count_cov_map)',options);
    [time_mean, cov_mean] = ode15s('moments_short_lin_cov',[time_start max_time],x_0_mean((num_volumes*num_molecules+num_volumes+1)+1:(num_volumes*num_molecules+num_volumes+1)+count_cov_map)',options);
    [time_moments_data_sampled, moments_data_sampled] = ode15s('moments_short_lin_mean',time_mean,x_0_mean(1:num_molecules)',options);
   else
    [time_mean, cov_mean] = ode15s('moments_short_lin_cov',time_moments_data_sampled,x_0_mean((num_volumes*num_molecules+num_volumes+1)+1:(num_volumes*num_molecules+num_volumes+1)+count_cov_map)',options);
   end;
   
         if (do_load_pathway==0)
           y_ss = zeros(1,num_molecules);
           y_ss(:) = moments_data_sampled(length(time_moments_data_sampled),:);
           cov_mean_ss = zeros(1,count_cov_map);
           cov_mean_ss(:) = cov_mean(length(time_moments_data_sampled),:);
           %%%%%%% inverting for the covariances %%%%%%%%%%
           %cov_y_ss = cov_mean_ss;
           %cov_mean_ss_inv = solve_ss_lin_cov(y_ss,0*cov_y_ss)
           %dummy_cov = [cov_y_ss' cov_mean_ss_inv'] 
           %%%%%%% end of: inverting for the covariances %%%%%%%%%%
           %cov_mean_ode = cov_mean(length(time_moments_data_sampled),:);
         end;  
   
      x_mean = [moments_data_sampled cov_mean];  % combine mean and covariances
  end;

%%%%x_mean = x_mean(:,1:num_molecules);
elseif (do_include_moment_data==1)
 if (do_moments_with_data_ode_compact==0)
   [time_mean, x_mean] = ode15s('moments_with_data',time_moments_data_sampled,x_0_mean',options);
 elseif (do_moments_with_data_ode_compact==1)
     x_dummy = 0*y_index;
     for ii = 1:length(y_index) 
       x_dummy(ii)  = x_0_mean(y_index(ii));
     end;
    
    [time_mean, x_mean_dummy] = ode15s('moments_with_data_short',time_moments_data_sampled,x_dummy',options);
             x_mean = zeros(length(time_mean),num_moments+1);  % input for mass action equations
             x_mean(:,1:num_moments) = moments_data_sampled;
             
     for ii = 1:length(y_index) 
       x_mean(:,y_index(ii))  = x_mean_dummy(:,ii);
     end;

           
 end;
 %[time_mean, x_mean] = ode15s('moments_with_data',time_for_ode,x_0_mean');
end;

           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %  BEGIN: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA.
           %  THEY DON'T GET UPDATED FRPM THE ODE SOLVER ARE THEY ARE PROPERLY 
           %  SET WITHIN THE ODE SOLVER.
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           if (do_read_inputs_data == 1)

           for kk = 1:length(time_mean)
            t = time_mean(kk);
            for ii = 1:length(map_inputs_data_sampled)
              [val,index_min] = min(abs(t-time_inputs_data_sampled(ii,:)));
                 if (time_inputs_data_sampled(ii,index_min) > t)
                     index_lower_data = index_min-1;
                 else
                   index_lower_data = index_min;
                 end;

      if (index_lower_data < length(time_inputs_data_sampled(ii,:)))
                 upper_data = (t-time_inputs_data_sampled(ii,index_lower_data))/(time_inputs_data_sampled(ii,index_lower_data+1)-time_inputs_data_sampled(ii,index_lower_data));
                 lower_data = 1-upper_data;
                else
                 index_lower_data = length(time_inputs_data_sampled(ii,:))-1;
                 upper_data = 1;
                 lower_data = 1-upper_data;
                end;

              which_input = map_inputs_data_sampled(ii);
              x_mean(kk,which_input) = lower_data*inputs_data_sampled(ii,index_lower_data) + upper_data*inputs_data_sampled(ii,index_lower_data+1);


            end; % for ii = 1:length(map_inputs_data_sampled)
           end; % for kk = 1:length(time_mean)
          
           end; % if (do_read_intputs_data == 1)
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %  BEGIN: UPDATE THE INPUTS AT THE CURRENT TIME FROM THE INPUTS DATA.
           %  THEY DON'T GET UPDATED FRPM THE ODE SOLVER ARE THEY ARE PROPERLY 
           %  SET WITHIN THE ODE SOLVER.
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd ../;
