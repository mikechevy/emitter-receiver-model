

 if (do_feedback==0)&(do_half_life_ratio==0)&(do_cell_cycle_modulate==0)       
      file_info_str = strcat('data_',num2str(which_pathway),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X));
   elseif (do_feedback==1)
      file_info_str = strcat('data_',num2str(which_pathway),'_feedback_',num2str(feedback_strength),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X));
   elseif (do_half_life_ratio==1)
      file_info_str = strcat('data_',num2str(which_pathway),'_half_life_ratio_',num2str(half_life_ratio),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X));       
   elseif (do_cell_cycle_modulate==1)
     if (do_initial_condition_delta == 0)
      if( do_init_cond_delta_no_cov==0)   
       if (do_discrete_samples==0)      
       file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X));
       elseif (do_discrete_samples==1)    
        if (do_ramp == 0)   
         file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_Nds',num2str(N_discrete_samples));
        elseif (do_ramp > 0)
         file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_Nds',num2str(N_discrete_samples),'_fac_ramp',num2str(fac_ramp));
        end;
       end;
      else
       if (do_discrete_samples==0)      
        file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_nocov');
       elseif (do_discrete_samples==1)      
        if (do_ramp == 0)   
         file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_nocov','_Nds',num2str(N_discrete_samples));
        elseif (do_ramp > 0)
         file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_nocov','_Nds',num2str(N_discrete_samples),'_fac_ramp',num2str(fac_ramp));
        end;
       end;
      end;
     else
      if( do_init_cond_delta_no_cov==0)   
       file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_ic_nXs',num2str(which_X_sample));
      else
       file_info_str = strcat('data_',num2str(which_pathway),'_fac_cell_cycle_',num2str(fac_cell_cycle),'_tau_',num2str(tau_sequence),'_num_runs_',num2str(num_runs),'_num_samps_',num2str(num_X_random_samples),'_rwX_',num2str(do_random_walk_X),'_ic_nXs',num2str(which_X_sample),'_nocov');
      end;
     end;
   end;