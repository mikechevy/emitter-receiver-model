
if (do_mean_or_full==1)

if (do_ssa_raw_out == 1)

%  Output file stuff
count_data=count_data+1;  % before for matlab, after for Petsc
   X_data(count_data,:) = x_old;
   time_data(count_data) = time_old;
   propensities_partition_data(count_data,:) = propensities_mean_path;
   stochasticity_partition_data(count_data,:) = stochasticity;
     moment_error_data(count_data) = max_moment_error;
   species_restricted_data(count_data,:) = species_restricted;
      for ii = 1:count_data
      fwrite(fids_state_data,X_data(ii,:),'double');
      fwrite(fids_restricted_data,species_restricted_data(ii,:),'int');
        fwrite(fids_propensities_partition_data,propensities_partition_data(ii,:),'double');
        fwrite(fids_stochasticity_partition_data,stochasticity_partition_data(ii,:),'int');
      end;
      fwrite(fids_time_data,time_data(1:count_data),'double');
          fwrite(fids_moment_error_data,moment_error_data(1:max_count_data),'double');
      time_data_final = time_data(count_data);
      count_data_total = count_data_total +  count_data;
      count_data = 0;
      % the total number of state updates for the current run, Output file stuff
      fwrite(fids_run_data,count_data_total,'int');
      fwrite(fids_run_data,time_data_final,'double');

end;


if (do_ssa_sampled_out == 1)

          
   count_data_sampled=count_data_sampled+1;  % before for matlab, after for Petsc
   count_data_sampled_total=count_data_sampled_total+1;  % before for matlab, after for Petsc
    X_data_sampled(count_data_sampled,:) = x;  % Last Sample
             for ii=1:count_data_sampled
               fwrite(fids_data_sampled,X_data_sampled(ii,:),'double');
             end;
              count_data_sampled = 0;

end;

      fwrite(fids_run_data,count_reactions,'int');

end;  % end of 'if (do_mean_or_full==1)
