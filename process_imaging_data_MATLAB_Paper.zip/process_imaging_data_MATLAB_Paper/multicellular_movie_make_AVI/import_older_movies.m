


  fids_txt = fopen(strcat('..\multicellular_movies\',str_movie,'\acqdat.txt'))
  ii_time_test = 1;
  ii_str_channel_test = 7
    
 for jj = 1:numCh     
     eval(['ii_count_CH',num2str(jj),' = 0;']);
     eval(['time_CH',num2str(jj),' = [];']);
     eval(['index_CH',num2str(jj),' = [];']);
 end;

 
 
 
 
 for ii = 1:numFr_import
    ii
  % format:  '%lf %d %lf %lf %lf %lf %s %d %d %d %s\n'
C = textscan(fids_txt,'%f %d %f %f %f %f %s %d %d %d %s\n')
time_test = C{ii_time_test}
str_channel_test = C{ii_str_channel_test}

 for jj = 1:numCh     
  if (strcmp(str_channel_test,eval(['CH',num2str(jj),'_str']))==1)
     eval(['ii_count_CH',num2str(jj),' = ii_count_CH',num2str(jj),'+1;']);
     eval(['time_CH',num2str(jj),' = [time_CH',num2str(jj),';time_test];']);
     eval(['index_CH',num2str(jj),' = [index_CH',num2str(jj),';ii];']);
  end;
 end;

end;
fclose(fids_txt);




MD=ImportMovie(path_movie,numCh_import,numFr_import);%
 MD_mat = int16(cell2mat(MD(1,1)));   
 

 
 for jj = 1:numCh
     eval(['time_CH',num2str(jj)]);
     eval(['index_CH',num2str(jj)]);
     eval(['numFr_CH(',num2str(jj),')=length(time_CH',num2str(jj),');']);
     eval(['numFr_CH']); 
     eval(['M_CH',num2str(jj),'_total = int16(zeros(length(MD_mat(:,1)),length(MD_mat(1,:)),numFr_CH(',num2str(jj),')));']);
     eval(['size(M_CH',num2str(jj),'_total)']);
 end;
 
 
 % reset the count variables
 for jj = 1:numCh     
     eval(['ii_count_CH',num2str(jj),' = 0;']);
 end;


 for which_frame = 1:numFr_import     
     
 MD_mat = int16(cell2mat(MD(which_frame,1)));   
 
 for jj = 1:numCh     
  if (eval(['ii_count_CH',num2str(jj),'+1 <= numFr_CH(',num2str(jj),')']))
   if (eval(['index_CH',num2str(jj),'(ii_count_CH',num2str(jj),'+1) == which_frame']))      
     eval(['ii_count_CH',num2str(jj),' = ii_count_CH',num2str(jj),'+1;']);
     eval(['M_CH',num2str(jj),'_total(:,:,ii_count_CH',num2str(jj),') = MD_mat(:,:);']);
   end;
  end;
 end;
     
 end;

xLength = length(MD_mat(:,1));
yLength = length(MD_mat(1,:));
