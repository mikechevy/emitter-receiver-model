set_globals;

numTimes = 1;

dimX = 400;
dimY = 500;

matrix_nucleus = zeros(dimX,dimY);
radius_nucleus = 10;

do_load_nucleus_file = 1; % 0 - generate new matrix, 1 - load file
if (do_load_nucleus_file == 0)


 for ii_nucleus = 1:100
    
    rand_x = round(rand*dimX);
    rand_y = round(rand*dimY);
    
    
  for ii = max(1,rand_x-radius_nucleus):min(dimX,rand_x+radius_nucleus)
   for jj = max(1,rand_y-radius_nucleus):min(dimY,rand_y+radius_nucleus)
      
      if (power(ii-rand_x,2)+power(jj-rand_y,2) < power(radius_nucleus,2))
       matrix_nucleus(ii,jj) = 1;
      end;
       
   end;
  end;
 
     rand_x_tot(ii_nucleus) = rand_x;  
     rand_y_tot(ii_nucleus) = rand_y;  
       
 end; 
 
    
    save('random_nucleus_file', 'rand_x_tot', 'rand_y_tot', 'matrix_nucleus', 'radius_nucleus', 'dimX','dimY');

else
    load('random_nucleus_file');
end;

figure(1)
imagesc(matrix_nucleus)

tic
for ii_count = 1:numTimes
 [matrix_out,num_nuclei_out, box_coords_out] = findThresholdedNuclei(matrix_nucleus,dimX,dimY);
 %[matrix_out,thres_out] = edge(matrix_nucleus,'canny', .5);
 %[matrix_out,thres_out] = edge(matrix_nucleus,'sobel', .5);
 %[matrix_out,thres_out] = edge(matrix_nucleus-.1,'zerocross', .5);
 %[matrix_out] = bwperim(matrix_nucleus);
 %[matrix_out] = bwtraceboundary(matrix_nucleus);
end
toc_new = toc


 figure(111)
 imagesc(matrix_out)
           for which_nucleus = 1:num_nuclei_out
                 x_coord_min = box_coords_out(which_nucleus,1);
                 x_coord_max = box_coords_out(which_nucleus,2);
                 y_coord_min = box_coords_out(which_nucleus,3);
                 y_coord_max = box_coords_out(which_nucleus,4); 
             rectangle('Position', [y_coord_min,x_coord_min,...
                  y_coord_max-y_coord_min,x_coord_max-x_coord_min],...
                        'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                        'EdgeColor', 'm');
           end;
                 
 %pause;


mean_x_tot = zeros(num_nuclei_out,1);
mean_y_tot = zeros(num_nuclei_out,1);
var_x_tot = zeros(num_nuclei_out,1);
var_y_tot = zeros(num_nuclei_out,1);
cov_xy_tot = zeros(num_nuclei_out,1);
num_pixels_tot = zeros(num_nuclei_out,1);

for ii = 1:dimX    
    for jj = 1:dimY
         val_dummy = matrix_out(ii,jj);
        if (val_dummy > 0)
            mean_x_tot(val_dummy) = mean_x_tot(val_dummy) + ii;
            mean_y_tot(val_dummy) = mean_y_tot(val_dummy) + ii;
            var_x_tot(val_dummy) = var_x_tot(val_dummy) + ii*ii;
            var_y_tot(val_dummy) = var_y_tot(val_dummy) + jj*jj;
            cov_xy_tot(val_dummy) = cov_xy_tot(val_dummy) + ii*jj;
            num_pixels_tot(val_dummy) = num_pixels_tot(val_dummy) + 1;
        end;
    end;
end;

for ii = 1:num_nuclei_out
    mean_x_tot(ii) = mean_x_tot(ii)/num_pixels_tot(ii); 
    mean_y_tot(ii) = mean_y_tot(ii)/num_pixels_tot(ii); 
    var_x_tot(ii) = var_x_tot(ii)/num_pixels_tot(ii); 
    var_y_tot(ii) = var_y_tot(ii)/num_pixels_tot(ii); 
    cov_xy_tot(ii) = cov_xy_tot(ii)/num_pixels_tot(ii); 
end;

        
figure(2)
imagesc(matrix_out)


tic
for ii_count = 1:numTimes
test_findHotSpots_nuclei
end
toc_HotSpots = toc;


toc_new
toc_HotSpots





