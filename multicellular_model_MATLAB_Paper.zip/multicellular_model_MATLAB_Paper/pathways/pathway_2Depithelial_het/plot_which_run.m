

        figure(1000)
        subplot(2,1,1)
        hold on;
        h1 = plot(time_sampled/60-tau_sequence,X_array(which_run,:));
        set(h1,'LineWidth',2);
          if (do_cross_talk == 1)               
           h1 = plot(time_sampled/60-tau_sequence,X_R_array(which_run,:),'r');
           set(h1,'LineWidth',2);
          end;
        hold off;
        xlabel('time (minutes)');
        ylabel('X(t)');
        xlim([min(time_sampled/60-tau_sequence) max(time_sampled/60-tau_sequence)]);
        subplot(2,1,2)
        hold on;
        h1 = plot(time_sampled/60-tau_sequence,Y_array(which_run,:),'b');
        set(h1,'LineWidth',2);
        h1 = plot(time_sampled/60-tau_sequence,Y_array(which_run,:)+sqrt(Cov_Y_array(which_run,:)),'b--');
        set(h1,'LineWidth',1);
        h1 = plot(time_sampled/60-tau_sequence,Y_array(which_run,:)-sqrt(Cov_Y_array(which_run,:)),'b--');        
        set(h1,'LineWidth',1);
        hold off;   
        xlabel('time (minutes)');
        if (which_pathway==3)&(Y_info_index(1) == ii_cheY_P)
            ylabel('cheY_p(t)');            
        else
            ylabel('Y(t)');
        end;
        xlim([min(time_sampled/60-tau_sequence) max(time_sampled/60-tau_sequence)]);
