function [] = CalciumAnalysis(path, filename, numCh, numFr)
%UNTITLED Summary of this function goes here
% path ='C:\Users\JoaoPedro\Documents\UCSF\Microscopy data-large\150205-calcium-frettest\calcium-noinput_1\Pos0\img_000000000_Cy3_000.tif';
% numCh=3;
% numFr=120;
%md columns are 1-DAPI, 2-GFP, 3-RFP, 4-maskDAPI, 5-maskRFP
%todo: cell tracking
%% import data
md=ImportMovie([path, filename,'\img_000000000_Cy3_000.tif'], numCh, numFr);

%% create masks using Biosensors threshold functions
% [level, varargout] = thresholdOtsu(imageIn,varargin)
% thresholdValue = thresholdFluorescenceImage(imageIn,showPlots,noisy)
% level = thresholdRosin(imageIn,varargin)
% threshold = intensityBinnedGradientThreshold(im,binSize,sigma,smoothPar,force2D)
 for ii=1:size(md,1)
[~, md{ii,4}] = thresholdOtsu(md{ii,1},0);
[~, md{ii,5}] = thresholdOtsu(md{ii,3},0);
 end

 
 %% create individual cells from first DAPI frame
cc = bwconncomp(md{1,4}, 8);
labeled = labelmatrix(cc);
clear cc

%% identify bPAC cells
%bPAC cells express RFP
numCe=max(max(labeled));
for ii=1:numCe
    idbPAC(ii)=max(md{1,5}(labeled==ii));
end
idbPAC=find(idbPAC);

%% create masks for cytoplasm
N = 20;    % number of pixels to grow the borders
se = ones(2*N + 1, 2*N + 1);
labeled2 = imdilate(labeled,se);
labeled2=bsxfun(@minus, labeled2, labeled);
clear N se

%% measure median Ca2+ in each cell
calcium= nan(numFr, numCe);
for ii=1:numFr
    for jj=1:numCe
calcium(ii,jj)=nanmedian(md{ii,2}(labeled2==jj));
    end
end
normCa=bsxfun(@rdivide, calcium, min(calcium,[],1));
% bPACCa=normCa(:,idbPAC);
% wtCa=normCa; wtCa(:,idbPAC)=[];

%% find centroid of each nucleus
for ii=1:numCe
    [a, b]= find(labeled==ii);
x(ii)=mean(a); y(ii)=mean(b);
end
clear a b

%% save data

save (filename, 'x', 'y', 'normCa', 'idbPAC')
end

