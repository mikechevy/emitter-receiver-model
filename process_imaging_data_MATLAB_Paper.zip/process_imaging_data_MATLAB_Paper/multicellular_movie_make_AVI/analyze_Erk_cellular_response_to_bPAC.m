


if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)

do_plot_trajectory = 1; % 1 - yes, 0 - no 
do_plot_nuclei_number = 1; % 1 - yes, 0 - no 

do_just_nuclear_signal = 0;  % 0-ratio of nuclear to cytosol, 1-nuclear signal/min(nuclear signal);  For powerpoint stuff

  if (which_nuclei_signal_type == 1) % shrink
      str_nuclei_signal_type = 'SHRINK_';
  elseif (which_nuclei_signal_type == 2) % intersect
      str_nuclei_signal_type = 'INTERSECT_';
  elseif (which_nuclei_signal_type == 3) % circle
      str_nuclei_signal_type = 'CIRCLE_';
  end;
      
if (do_just_nuclear_signal == 1)
  str_just_nuclear = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'NUCLEAR_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
elseif (do_just_nuclear_signal == 0)
  str_just_nuclear = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell.ppt');
  str_just_nuclear_eps = strcat(str_nuclei_signal_type,'RATIO_local_cells_about_bPAC_cell');
  mkdir(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
end;
  mkdir(strcat(str_movie_processed_figures,'\cellular_signals_eps'));
  
M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);



s_sig = ['b' 'g' 'r'];
%  This function analyzes Erk pulses when bPAC is on
      
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);

          
          diff_bPAC_signal = diff(bPAC_ledvals);
          
%  determine pulse locations here, bPAC
             num_pulses = 0;
             num_bPAC_pulses = 0;
             index_bPAC_pulse_start = [];
             index_bPAC_pulse_stop = [];
     for ii = 1:length(diff_bPAC_signal)
         
         if (diff_bPAC_signal(ii) > 0)
             index_bPAC_pulse_start(num_bPAC_pulses+1) = ii+1; % top of pulse (rise)
             num_bPAC_pulses = num_bPAC_pulses + 1;
         elseif (diff_bPAC_signal(ii) < 0)
             index_bPAC_pulse_stop(num_bPAC_pulses) = ii; % top of pulse (decline)
         end;
             
     end;
            if length(index_bPAC_pulse_stop) < length(index_bPAC_pulse_start)
                index_bPAC_pulse_stop(num_bPAC_pulses) = length(time_bPAC); 
            end;
            
            %  this calculates the end of each step-pulse that are all but
            %  the last in a step-up sequence
            if (num_bPAC_pulses > 1)
               for ii = 1:num_bPAC_pulses -1
                if (index_bPAC_pulse_stop(ii) == 0)
                   index_bPAC_pulse_stop(ii) = index_bPAC_pulse_start(ii+1)-1;
                end;
               end;
            end;

%  determine indexes of time_Erk that are within the bPAC pulse times
             index_bPAC_pulse_start_Erk = [];
             index_bPAC_pulse_stop_Erk = [];
     for ii = 1:num_bPAC_pulses
  
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_start(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_start(ii)) )
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy+1;         
          %else
          % index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
          %end;
          index_bPAC_pulse_start_Erk(ii) =  index_dummy;          
         
          
         [val,index_dummy] = min(abs(time_bPAC(index_bPAC_pulse_stop(ii))-time_Erk))
          %if ( time_Erk(index_dummy) < time_bPAC(index_bPAC_pulse_stop(ii)) )
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy;         
          %else
          % index_bPAC_pulse_stop_Erk(ii) =  index_dummy-1;          
          %end;
          index_bPAC_pulse_stop_Erk(ii) =  min(index_dummy+1,length(time_Erk));   % captures full experimental duration of pulse       
          
          
          
     end;
            
          % plots average signals
          sig_dummy_nuclear_average = zeros(1, length(time_Erk));
          sig_dummy_ratio_average = sig_dummy_nuclear_average;          
          ratio_signal = zeros(num_nuclei_t0,length(time_Erk));
     
num_bPAC_pulsing_cells = 0;            
bPAC_pulse_cell = zeros(num_nuclei_t0,num_bPAC_pulses);

cd(str_movie_processed)

for idx = 1:num_nuclei_t0
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Pulse analysis 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     for ii = 1:num_bPAC_pulses     

         
         % TIME: time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,

         diff_time_Erk = diff(time_Erk)
         dt_pre_pulse = 4*60; 
         dt_pre_post = 5*60; 
         num_samps_pre = round(dt_pre_pulse/diff_time_Erk(2));
         num_samps_post = ceil(dt_pre_post/diff_time_Erk(2));
         
         %NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy);
         min_sig = min(sig_dummy);         
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig;
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)/min_sig;

          
          %shift_rise = 4; 
          shift_rise = 9;  % normal step response timescale (1 minute frame)
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));          
          % SETUP PULSE ANALYSIS HERE
          passed_pulse_test = 0; 

          epsilon_pulse_nucleus = .08;
          if pulse_dummy > epsilon_pulse_nucleus 
           passed_pulse_test = 1;
          end;
        else
            passed_pulse_test = 1
        end;
          
              
          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
          
         %RATIO OF NUCLEAR TO CYTOSOL
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;
          signal_dummy =  (sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig)
          signal_dummy =  sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))
          signal_dummy_pre_pulse =  sig_dummy(index_bPAC_pulse_start_Erk(ii)-num_samps_pre:index_bPAC_pulse_start_Erk(ii)-1)
         
          %shift_rise = 4;  
          shift_rise = 9;  % normal step response timescale (1 minute frame)
        if ( length(signal_dummy) > (num_samps_post+shift_rise) - (1+shift_rise) )&(do_tranfer_function==0)
          pulse_dummy = (mean(signal_dummy(1+shift_rise:num_samps_post+shift_rise))-mean(signal_dummy_pre_pulse(1:num_samps_pre)))/mean(signal_dummy_pre_pulse(1:num_samps_pre));
          
          epsilon_pulse_ratio = .08;
          if pulse_dummy > epsilon_pulse_ratio 
           passed_pulse_test = 1;
          end;
          % SETUP PULSE ANALYSIS HERE

          %%%%%%%%%%%%%%%%%%%%%%%%%
          if (passed_pulse_test == 1)
              num_bPAC_pulsing_cells = num_bPAC_pulsing_cells+1;            
              bPAC_pulse_cell(idx,ii) = 1;
          end
          %%%%%%%%%%%%%%%%%%%%%%%%%
        else
           passed_pulse_test = 1;
        end;
          
          if (passed_pulse_test == 1)
              if (ii == 1)  %passed the first pulse only
              sig_dummy_nuclear_average = sig_dummy_nuclear_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))/double(min(nuclear_Erk_tot_time_mapped_t0_median(idx,:)));
              sig_dummy_ratio_average = sig_dummy_ratio_average + double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));       
              ratio_signal(idx,:) = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));  
              end;
          end;
          
     end;     
    
   
     do_plot_stuff = 1; % 0 - no, 1 - yes
     if (do_plot_stuff == 1)
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %  Make plot of result 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     ii_plot_count = 0;
     figure(200)
     title(strcat('nuclear Erk signal (',Erk_str,')'));
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
     subplot(3,1,1) 
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(ii_plot_count+1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig,s_pulse(ii));
               set(ss,'LineWidth',3);
     end;
     ylabel(strcat('(nuc-min(nuc))/max(nuc-min(nuc))'));
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+max(1.1*(max(sig_dummy/min_sig)-1),.1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
           if (num_bPAC_pulses+1 == 1)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)));
           elseif (num_bPAC_pulses+1 == 2)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse'));
           elseif (num_bPAC_pulses+1 == 3)
            %lgnd = legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse 1'), strcat('signal during bPAC pulse 2'));
           end;
            %set(lgnd,'color','none');
           
       if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
           str_bPAC = ' (bPAC)';
           str_bPAC_eps = '-bPAC';
       else
           str_bPAC = ' (non-bPAC)';
           str_bPAC_eps = '-non-bPAC';
       end;
            
            
      if (num_bPAC_pulses == 1)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test =',num2str(bPAC_pulse_cell(idx,1))));
      elseif (num_bPAC_pulses == 2)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']'));
      elseif (num_bPAC_pulses == 3)      
       title(strcat('Nucleus-',num2str(idx),' ',str_bPAC,':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),';',num2str(bPAC_pulse_cell(idx,3)),']'));
      end;
     
     subplot(3,1,2) 
     hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(ii));
               set(ss,'LineWidth',3);
     end;
     
     ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*max((max(sig_dummy)-min(sig_dummy)),.1)]);
     hold off;




          subplot(3,1,3)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 max(1.1*max(bPAC_ledvals),1e-6)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          
          
          
do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)
 % save the figures to a powerpoint slide


  fig200 = figure(200)
  figure(1111)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 max(1.1*max(bPAC_ledvals),1e-6)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
   s_combine = strcat(str_movie,':nuclear Erk signals');
     if (idx==1)  % remove if file exists
     delete(strcat(str_movie,'-nuclear_Erk_signals.ppt'));
     end;
     saveppt2(strcat(str_movie,'-nuclear_Erk_signals.ppt'),'figure',[fig200], 'halign','center','title', s_combine);
     %if idx == num_nuclei_t0   
     %movefile('nuclear_Erk_signals.ppt',strcat(str_movie_processed,'\',str_movie,'-nuclear_Erk_signals.ppt'));
     %end;
    
end; % if (do_PPT ==1)
     
          %pause
          figure(200)
          cd(strcat('figures-',str_movie,'\cellular_signals_eps'));          
          print('-depsc',strcat('nuc_',num2str(idx),str_bPAC_eps,'-Erk-',str_movie,'.eps'));   
          cd ../../;
          close(200)
          
           
     end; % end of 'if (do_plot_stuff == 1)'
end; % for idx = 1:num_nuclei_t0




which_frame = length(eval(['time_CH',num2str(ii_NM)]));
               rect_width = 10;
figure(112)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    
    
     if (do_plot_nuclei_number == 1)
     for jjj = 1: num_nuclei_t0
         idx = jjj;
         
          y_coord_min = y_coord_min_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          y_coord_max = y_coord_max_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          x_coord_min = x_coord_min_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          x_coord_max = x_coord_max_tot_NUCLEUS_time_mapped_t0(idx,which_frame);
          %y_coord_min = y_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
          %y_coord_max = y_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
          %x_coord_min = x_coord_min_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
          %x_coord_max = x_coord_max_tot_SHRINK_NUCLEUS_time_mapped_t0(idx,which_frame);
         
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
               
                    delta_y = y_coord_max-y_coord_min+1
                    delta_x = x_coord_max-x_coord_min+1
               if (ii_NM == ii_NM_bPAC)  % all bPAC cells
               set(tt,'Color','m');
                if (bPAC_pulse_cell(jjj,1)==1)
                    rectangle('Position', [y_coord_min,x_coord_min,...
                               delta_y,delta_x],...
                              'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                   
                if (num_bPAC_pulses==2)
                if (bPAC_pulse_cell(jjj,2)==1)
                    rectangle('Position', [y_coord_min-delta_y/4,x_coord_min-delta_x/4,...
                               1.5*delta_y,1.5*delta_x],...
                              'LineWidth', 2,'LineStyle','-', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                end;
                
               elseif (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','m');
                if (bPAC_pulse_cell(jjj,1)==1)
                    rectangle('Position', [y_coord_min,x_coord_min,...
                               delta_y,delta_x],...
                              'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                if (num_bPAC_pulses==2)
                if (bPAC_pulse_cell(jjj,2)==1)
                    rectangle('Position', [y_coord_min-delta_y/4,x_coord_min-delta_x/4,...
                               1.5*delta_y,1.5*delta_x],...
                              'LineWidth', 2,'LineStyle','-', 'LineWidth', 2,...
                              'EdgeColor', 'w');
                end;
                end;

               else
               set(tt,'Color','y');
                if (bPAC_pulse_cell(jjj,1)==1)
                    rectangle('Position', [y_coord_min,x_coord_min,...
                               delta_y,delta_x],...
                              'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                              'EdgeColor', 'y');
                end;
                if (num_bPAC_pulses==2)
                if (bPAC_pulse_cell(jjj,2)==1)
                    rectangle('Position', [y_coord_min-delta_y/4,x_coord_min-delta_x/4,...
                               1.5*delta_y,1.5*delta_x],...
                              'LineWidth', 2,'LineStyle','-', 'LineWidth', 2,...
                              'EdgeColor', 'y');
                end;
                end;
                
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
                 
             %ll = line(mean_y_tot_time_mapped_t0(idx,1:index_bPAC_pulse_start_Erk(1)),mean_x_tot_time_mapped_t0(idx,1:index_bPAC_pulse_start_Erk(1)));
             %  set(ll,'Color','w');
             %ll = line(mean_y_tot_time_mapped_t0(idx,index_bPAC_pulse_start_Erk(1):which_frame),mean_x_tot_time_mapped_t0(idx,index_bPAC_pulse_start_Erk(1):which_frame));
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (ii_NM == ii_NM_bPAC)
               set(ll,'Color','m');
               elseif (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               %set(ll,'Color','w');
               set(ll,'Color','m');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
           % rectangle('Position', [y_coord_min,x_coord_min,...
           %            y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
           %           'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
           %           'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'),'interpreter','none');   
     if (num_bPAC_pulses == 1)
xlabel('dashed box - bPAC pulse respone')
elseif (num_bPAC_pulses == 2)
xlabel('dashed box - bPAC pulse 1 respone, solid box - bPAC pulse 2 respone', 'interpreter','none')
end;


     
do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)
 % save the figures to a powerpoint slide

  delete(strcat(str_movie,'-bPAC_pulsing_cells.ppt'));

  fig111 = figure(112)
  figure(1111)
           ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
  fig1111 = figure(1111);
   s_combine = 'pulsing cells induced (in)directly by bPAC';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   saveppt2(strcat(str_movie,'-bPAC_pulsing_cells.ppt'),'figure',[fig111 fig1111 fig111 fig1111], 'halign','center','title', s_combine);

    %movefile('bPAC_pulsing_cells.ppt',strcat(str_movie_processed,'\',str_movie,'-bPAC_pulsing_cells.ppt'));
    done_cells_tracked_ppt = 1;  % have made the ppt file
    
end; % if (do_PPT ==1)
     
     

cd(str_processing)






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plots of cells and their signals about a given bPAC cell
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                 
if (ii_NM==ii_NM_bPAC) % only bPAC cells
bPAC_NUCLEUS_time_mapped_t0 = ones(num_nuclei_t0,length(eval(['time_CH',num2str(ii_NM)])));
end;
bPAC_NUCLEUS_time_mapped_t0_dummy = bPAC_NUCLEUS_time_mapped_t0;

num_cells_surround_max = 9;




   cd(str_processing);
   cd(str_movie_processed);
   do_PPT  = 1;
   if (do_PPT ==1)
   delete(strcat(str_movie,'-',str_just_nuclear));
   end;
   cd(str_processing);

  
for jjj = 1:num_nuclei_t0
which_nucleus = jjj;


if (bPAC_NUCLEUS_time_mapped_t0_dummy(which_nucleus,1) == 1)

width_surround = 10;

num_cells_surround = 0;

%while (num_cells_surround <= num_cells_surround_max)&((num_cells_surround ~= sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))|(which_movie == 43))
while (num_cells_surround <= num_cells_surround_max)&(((num_cells_surround+1<sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))&(ii_NM_bPAC==ii_NM))|(ii_NM_bPAC~=ii_NM))%&((num_cells_surround ~= sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))|(which_movie == 43))

width_surround = width_surround + 1;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
    
    
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     end;
    end;
end;

num_cells_surround = ii_count;

end; % while (num_cells_surround < num_cells_surround_max)

if (num_cells_surround > num_cells_surround_max) 
width_surround = width_surround - 1;
end;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
      bPAC_NUCLEUS_time_mapped_t0_dummy(iii,:) = 0;      
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     end;
    end;
end;


which_frame = length(eval(['time_CH',num2str(ii_NM)]));
figure(110)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    
    image_RGB = zeros(xLength,yLength,3);
    image_RGB(:,:,1) = M_NM(:,:)/max(max(M_NM));
    image_RGB(:,:,3) = M_NM_bPAC(:,:)/max(max(M_NM_bPAC));
    imshow(image_RGB)
    
     if (do_plot_nuclei_number == 1)
     for idx = 1: num_nuclei_t0
              if idx == which_nucleus
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat('X:',num2str(idx)));             
              else
               tt=text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));            
              end
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(tt,'Color','w');
               else
               set(tt,'Color','y');
               end;
                            
            if (do_plot_trajectory == 1)
             if (unique_nuclei_track_time(idx) == 1) 
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
               if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
               set(ll,'Color','w');
               else
               set(ll,'Color','y');
               end;
             elseif (unique_nuclei_track_time(idx) == 0) 
             end;
            end;
     end;
     end;
            rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'r');
     title(strcat(str_movie,':magenta (bPAC cells), yellow (non-bPAC cells)'));         

num_max_plots = 3;     
ii_plot_count = 0;
ii_figure_count = 1;     
for iii = 1:length(index_group)
    idx = index_group(iii);
    
    if (bPAC_NUCLEUS_time_mapped_t0(idx,1) == 1)     
        str_bPAC = ' (bPAC)';
    else
        str_bPAC = ' (non-bPAC)';
    end;
        
     figure(200+ii_figure_count)
     %subplot(num_plots_max+1,1,ii_plot_count+1) 
    subplot(num_max_plots+1,1,ii_plot_count+1)
    if (do_just_nuclear_signal == 1)
     hold on;
         if (do_median_or_mean_signal == 0) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:));
         end;
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,(sig_dummy)/min_sig,s_sig(1));
     %ss = plot(time_Erk,nuclear_Erk_tot_time_mapped_t0(idx,:),s_sig(ii_plot_count+1));
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/min_sig,s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     
      if (num_bPAC_pulses == 1)
      text(.6*max(time_Erk)/scale_factor_time, .9*(1+1.1*(max(sig_dummy/min_sig)-1)),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      elseif (num_bPAC_pulses == 2)
      text(.6*max(time_Erk)/scale_factor_time, .9*(1+1.1*(max(sig_dummy/min_sig)-1)),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      end;
     ylim([max(sig_dummy/min_sig)+1.1*(min(sig_dummy/min_sig)-max(sig_dummy/min_sig)) 1+1.1*(max(sig_dummy/min_sig)-1)]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
           if (num_bPAC_pulses+1 == 1)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)));
           elseif (num_bPAC_pulses+1 == 2)     
            %lgnd =legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse'));
           elseif (num_bPAC_pulses+1 == 3)
            %lgnd = legend(strcat('nucleus:',num2str(idx)), strcat('signal during bPAC pulse 1'), strcat('signal during bPAC pulse 2'));
           end;
            %set(lgnd,'color','none');
     
      if (ii_plot_count+1 == 1)
        title(strcat('(nuclear Erk signal)/min(nuclear Erk signal) (',Erk_str,')'));       
      end;
            
      %if (num_bPAC_pulses == 1)      
      % title(strcat('Nucleus-',num2str(idx),':Erk signal (',Erk_str,'), passed pulse test =',num2str(bPAC_pulse_cell(idx,1))));
      %elseif (num_bPAC_pulses == 2)      
      % title(strcat('Nucleus-',num2str(idx),':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']'));
      %elseif (num_bPAC_pulses == 3)      
      % title(strcat('Nucleus-',num2str(idx),':Erk signal (',Erk_str,'), passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),';',num2str(bPAC_pulse_cell(idx,3)),']'));
      %end;
      
    elseif (do_just_nuclear_signal == 0)
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
      
      if (num_bPAC_pulses == 1)
      text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      elseif (num_bPAC_pulses == 2)
      text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      end;

    if (max(sig_dummy)~=min(sig_dummy))
    ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
    else
    ylim([max(sig_dummy)-1 max(sig_dummy)+1]);    
    end;
         %ylim([.5 2]);
         xlim([0 max(time_Erk)/scale_factor_time]);
     hold off;
     
     
      if (ii_plot_count+1 == 1)
        title(strcat('(nuclear Erk signal)/(cytosolic Erk signal) (',Erk_str,')'));       
      end;
     
     
    end;  %     if (do_just_nuclear_signal == 1)


     ii_plot_count = ii_plot_count+1;

        if (iii == length(index_group))
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('non-bPAC');
          xlabel(str_time_representation);
        elseif (ii_plot_count == num_max_plots)
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
          xlabel(str_time_representation);
          ii_figure_count = ii_figure_count+1;
          ii_plot_count = 0;
        end;

end; % for iii = 1:length(index_map)
     
do_PPT = 1;  % 0 - no, 1 - yes
if (do_PPT ==1)
 % save the figures to a powerpoint slide
 
cd(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
  fig110 = figure(110)
   %print('-depsc',strcat(str_movie_processed_figures,'\',str_just_nuclear_eps,'\map-',str_movie,'.eps'));
   set(gcf,'inverthardcopy','off')   
   print('-depsc',strcat('map-',str_movie,'.eps'));
  fig201 = figure(201)
   %print('-depsc',strcat(str_movie_processed_figures,'\',str_just_nuclear_eps,'\nuc_',num2str(idx),'_a-',str_movie,'.eps'));
   print('-depsc',strcat('nuc_',num2str(which_nucleus),'_a-',str_movie,'.eps'));
  fig202 = figure(202)
   print('-depsc',strcat('nuc_',num2str(which_nucleus),'_b-',str_movie,'.eps'));
  fig203 = figure(203)
   print('-depsc',strcat('nuc_',num2str(which_nucleus),'_c-',str_movie,'.eps'));
   s_combine = 'cells surround a given bPAC cell';
   %saveppt2(strcat('cells_tracked.ppt'),'figure',[fig111 fig1111], 'halign','center','stretch','title', s_combine);
   
   cd(str_processing);
   cd(str_movie_processed);
   saveppt2(strcat(str_movie,'-',str_just_nuclear),'figure',[fig110 fig201 fig202 fig203], 'halign','center','title', s_combine);
   close 201;
   close 202;
   close 203;
 cd(str_processing);
   
    
end; % if (do_PPT ==1)
     

%pause
          
end; %  if (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) == 1) 

    %if (jjj == num_nuclei_t0)&(do_PPT ==1)
    %cd(strcat(str_movie_processed_figures,'\',str_just_nuclear_eps));
    %movefile(str_just_nuclear,strcat(str_movie_processed,'\',str_movie,'-',str_just_nuclear));
    %cd(str_processing);
    %end;

    
    

    
end; %  for iii = 1:num_nuclei_t0





sig_dummy_nuclear_average = sig_dummy_nuclear_average/sum(bPAC_pulse_cell(:,1))
sig_dummy_ratio_average = sig_dummy_ratio_average/sum(bPAC_pulse_cell(:,1))


figure(333)
subplot(3,1,1)
ss = plot(time_Erk/scale_factor_time,sig_dummy_nuclear_average)
set(ss,'LineWidth',2);
     title('average signal of responsive cells');
     ylim([.9*min(sig_dummy_nuclear_average) 1.1*max(sig_dummy_nuclear_average)]);
     ylabel(strcat('nuc/min(nuc)'));
subplot(3,1,2)
ss = plot(time_Erk/scale_factor_time,sig_dummy_ratio_average)
set(ss,'LineWidth',2);
     ylim([.9*min(sig_dummy_ratio_average) 1.1*max(sig_dummy_ratio_average)]);
     ylabel(strcat('nuc/cyto'));
     subplot(3,1,3)
          plot(time_bPAC/scale_factor_time,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('bPAC');
     xlabel('time (minutes)');
fig333 = figure(333);
   mkdir(strcat(str_movie_processed_figures,'\average_signals_and_all'));
   cd(strcat(str_movie_processed_figures,'\average_signals_and_all'));
   %print('-depsc',strcat(str_movie_processed_figures,'\average_signals_and_all\average_signals-',str_movie,'.eps'));
   print('-depsc',strcat('average_signals-',str_movie,'.eps'));



figure(334)
imagesc(ratio_signal);
fig334 = figure(334)
title('reponse of all pulsing cells');
xlabel('frames');
ylabel('nucleus');

   %print('-depsc',strcat(str_movie_processed_figures,'\average_signals_and_all\heat_map-',str_movie,'.eps'));
   print('-depsc',strcat('heat_map-',str_movie,'.eps'));

   cd(str_processing);
   cd(str_movie_processed);
   delete(strcat(str_movie,'-average_signals_and_all.ppt'));
   saveppt2(strcat(str_movie,'-average_signals_and_all.ppt'),'figure',[fig333 fig334], 'halign','center','title', s_combine);
   %saveppt2('average_signals_and_all.ppt','figure',[fig333 fig334], 'halign','center','title', s_combine);
   %movefile('average_signals_and_all.ppt',strcat(str_movie_processed,'\',str_movie,'-average_signals_and_all.ppt'));   
   cd(str_processing);
   
   
end;   % if (which_nuclei_signal_type == 1)    % do only if SHRINK (1)
   
