
do_NM = 1;  % 1 - yes, 0 - no
do_CH1 = 1;  % 1 - yes, 0 - no
do_CH2 = 1;  % 1 - yes, 0 - no
    if (length(signal_channels)==1)
        do_CH2 = 0;
    end;


width_surround = 100;  % additional pixes in each direction about the nucleus

do_make_movie_Erk = 0;  % 1 - yes, 0 - no
 
       if (do_make_movie_Erk == 1)
          filename_movie = strcat(str_movie,'_processed\Erk_nucleus',num2str(which_nucleus),'_TEST');
          delete(strcat(filename_movie,'.avi'));
          mov = avifile(strcat(filename_movie,'.avi'),'COMPRESSION','None','FPS',2);
       end;
          
    which_frame = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+width_surround);

                 
do_track_center_of_mass = 1;  % 1 - yes, 0 - no                 
                 
                 
M_marker_threshold_TEST = zeros(xLength,yLength);
M_NM = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);
M_CH2 = zeros(xLength,yLength);
M_bPAC = zeros(xLength,yLength);

index_group = which_nucleus;





count_fast = 0;
skip_fast = 10;

%for kkk = 1:length(which_frames)
for kkk = 1:1
  which_frame = which_frames(kkk)

%   if (which_frame < numFr)
%       if (dt_sequence_movie(which_frame) < 20)&(count_fast == 0)
%           count_fast = 1;
%       elseif (dt_sequence_movie(which_frame) < 20)&(count_fast < skip_fast )
%           count_fast = count_fast+1;
%       elseif (dt_sequence_movie(which_frame) < 20)&(count_fast == skip_fast )
%           count_fast = 0;
%       elseif (dt_sequence_movie(which_frame) > 20)
%           count_fast = 1;
%       end;
%   end;      
  count_fast = 1;

          
  if (count_fast == 1)        
     if (do_track_center_of_mass == 1)                 
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)-30);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame)+30);
     end;
  
  
  if (do_load_movie_arrays == 0)   
    str_movie_processed = strcat(str_movie,'_processed')
    file_nucleus = strcat(str_movie_processed,'\nucleus_locations_frame',num2str(which_frame));
    load(file_nucleus);
  else
    M_NM(:,:) = eval(['M_CH',num2str(ii_NM),'_total(:,:,which_frame)']);
    M_CH1(:,:) = M_CH1_total(:,:,which_frame);
    if (length(signal_channels)>1)
    M_CH2(:,:) = M_CH2_total(:,:,which_frame);
    end;
    for iii = 1:numCh
        if ( strcmp(eval(['CH',num2str(iii),'_str']),'CFP')==1 )
         M_bPAC(:,:) = eval(['M_CH',num2str(iii),'_total(:,:,which_frame)']);
        end;
    end;
  end;
    
 M_marker_threshold_TEST = 0*M_marker_threshold_TEST;

 for jjj = 1:length(index_group);
     idx = index_group(jjj);
     idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       if (idx_map > 0)
       %M_marker_threshold_TEST(Cell_NM_FILL.PixelIdxList{idx_map}) = 1;         
       %M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) = M_marker_threshold(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) + 1;
       M_marker_threshold_TEST(eval(['Cell_nucleus_FILL_',num2str(which_frame),'.PixelIdxList{idx_map}'])) =   1;
       end;
 end;

figure(1)
%title(strcat('which frame:',num2str(which_frame),', total frames:',num2str(numFr),',nucleus:',num2str(which_nucleus)));
subplot(2,4,[1]);
imagesc(M_marker_threshold_TEST)
title(strcat('segmented nucleus'));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       %idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
       
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);

if (do_NM == 1)        
figure(1)
subplot(2,4,[5]);
imagesc(M_NM)
title(strcat('NM'));
   hold on;                 
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       idx_map = index_map_tot_time_mapped_t0(idx,which_frame);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');
       
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','k');
    end;
   hold off;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
    
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

  end;
    
    
end; % END OF: if (do_NM == 1)        


                  

if (do_CH2 == 1)        
figure(1)
subplot(2,4,[2]);
imagesc(M_CH2)
title(strcat('CH2'));
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');

              tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),'X');                   
              set(tt,'Color','k');
    end;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
 
     subplot(2,4,[3 4]) 
     title(strcat('nuclear CH2 signal (',CH2_str,')'));
     %plot(time_sequence_movie,nuclear_CH2_tot_time_mapped_t0(idx,:)-0*nuclear_CH2_tot_time_mapped_t0(idx,1));
     hold on;
     if (marker_from_channel(ii_Erk_marker) == ii_CH2)
     plot(time_CH2,nuclear_CH2_tot_time_mapped_t0(idx,:)./cytosolic_CH2_tot_time_mapped_t0(idx,:)-0*nuclear_CH2_tot_time_mapped_t0(idx,1));
     %plot(time_sequence_movie,nuclear_CH2_tot_time_mapped_t0(idx,:)-0*nuclear_CH2_tot_time_mapped_t0(idx,1));
     %plot([time_sequence_movie(which_frame) time_sequence_movie(which_frame)],[min(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1)) max(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1))],'k--');
     else
     plot(time_CH2,nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1));
     plot([time_CH2(which_frame) time_CH2(which_frame)],[min(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1)) max(nuclear_CH2_tot_time_mapped_t0(idx,:)-nuclear_CH2_tot_time_mapped_t0(idx,1))],'k--');
     end;
     hold off;
     if (marker_from_channel(ii_Erk_marker) == ii_CH2)
     legend(strcat('CH2 (Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH2)
     legend(strcat('CH2 (Ca2+),nuc:',num2str(which_nucleus)))
     end;
     xlabel('time (seconds)');
     xlim([0 max(time_CH2)]);
    

    
end; % END OF: if (do_CH2 == 1)        

     
     
     
if (do_CH1 == 1)        
figure(1)
subplot(2,4,[6]);
imagesc(min(M_CH1,2*max(nuclear_CH1_tot_time_mapped_t0(which_nucleus,:))))
title(strcat('CH1'));
    for jjj = 1:length(index_group);
       idx = index_group(jjj);
       
             ll = line(mean_y_tot_time_mapped_t0(idx,1:which_frame),mean_x_tot_time_mapped_t0(idx,1:which_frame));
             set(ll,'Color','m');

              tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),'X');                   
              set(tt,'Color','k');
    end;
    xlim([y_coord_min y_coord_max]);
    ylim([x_coord_min x_coord_max]);
    
     subplot(2,4,[7 8]) 
     title(strcat('nuclear CH1 signal (',CH1_str,')'));
     %plot(time_CH1,nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1));
     hold on;
     plot(time_CH1,nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1));
     plot([time_CH1(which_frame) time_CH1(which_frame)],[min(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1)) max(nuclear_CH1_tot_time_mapped_t0(idx,:)-nuclear_CH1_tot_time_mapped_t0(idx,1))],'k--');
     hold off;
     xlabel('time (seconds)');
     xlim([0 max(time_CH1)]);
     if (marker_from_channel(ii_Erk_marker) == ii_CH1)
     legend(strcat('CH1 (Erk),nuc:',num2str(which_nucleus)))
     elseif (marker_from_channel(ii_Ca_marker) == ii_CH1)
     legend(strcat('CH1 (Ca2+),nuc:',num2str(which_nucleus)))
     end;
     
     
end; % END OF: if (do_CH1 == 1)        
     

figure(3)
close 3;
figure(3)
imshow(mat2gray(M_NM));
title(strcat('NM'));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');

                  
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

  end;

  

figure(4)
close 4;
figure(4)
imshow(mat2gray(M_CH1));
title(strcat('Signal 1:',num2str(CH1_str)));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');

                  
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

  end;

figure(5)
close 5;
figure(5)
imshow(mat2gray(M_bPAC));
title(strcat('bPAC marker: CFP'));
rectangle('Position', [y_coord_min,x_coord_min,...
                       y_coord_max-y_coord_min+1,x_coord_max-x_coord_min+1],...
                      'LineWidth', 2,'LineStyle','--', 'LineWidth', 2,...
                      'EdgeColor', 'm');

                  
  for jj = 1:num_nuclei_t0
      idx = jj;
             tt = text(mean_y_tot_time_mapped_t0(idx,which_frame),mean_x_tot_time_mapped_t0(idx,which_frame),strcat(num2str(idx)));                    
             set(tt,'Color','y');

  end;

figure(6)
close 6;
figure(6)
ylabel('bPAC');
plot(time_bPAC,bPAC_ledvals);
xlim([0 max(time_Erk)]);
xlabel('time (seconds)');

    
   if (do_make_movie_Erk == 1)    
    H = gcf;
    F = getframe(H);                    
    mov = addframe(mov,F);
   end;

plot_cytosol_and_nuclear_signal    


  end;   % END OF:  if (count_fast == 1)        

end;  % end of  'for kkk = 1:length(which_frames)



   if (do_make_movie_Erk == 1)   
      mov = close(mov);
   end;
     
              



