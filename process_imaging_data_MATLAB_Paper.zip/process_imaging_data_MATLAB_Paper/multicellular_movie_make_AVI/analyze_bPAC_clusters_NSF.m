%  spatial analyze of cells and their signals within a bPAC cluster and
%  non-bPAC cells outside the cluster

         if (which_movie == 3)
         shift_time_Erk = 90;
         shift_time_bPAC = 90;
         end;


length_max_bPAC = 120;
[bPAC_groups,size_bPAC_groups] = find_bPAC_clusters([mean_x_tot_SHRINK_time_mapped_t0(:,1) mean_y_tot_SHRINK_time_mapped_t0(:,1)],num_nuclei_t0,length_max_bPAC,ii_physical_distance,bPAC_NUCLEUS_time_mapped_t0(:,1));


M_NM = zeros(xLength,yLength);
M_NM_bPAC = zeros(xLength,yLength);
M_CH1 = zeros(xLength,yLength);

M_NM_t0 = zeros(xLength,yLength);
M_NM_bPAC_t0 = zeros(xLength,yLength);
M_CH1_t0 = zeros(xLength,yLength);


% find the outer cells of each cluster.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plots of cells and their signals about a given bPAC cell
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      
matrix_bPAC = zeros(num_nuclei_t0,num_nuclei_t0);
matrix_bPAC_plus = zeros(num_nuclei_t0,num_nuclei_t0);
bPAC_clusters = zeros(num_nuclei_t0,num_nuclei_t0);


if (ii_NM==ii_NM_bPAC) % only bPAC cells
bPAC_NUCLEUS_time_mapped_t0 = ones(num_nuclei_t0,length(eval(['time_CH',num2str(ii_NM)])));
end;
bPAC_NUCLEUS_time_mapped_t0_dummy = bPAC_NUCLEUS_time_mapped_t0;

num_cells_surround_max = 6;


          
  
for jjj = 1:num_nuclei_t0
which_nucleus = jjj;

if (bPAC_NUCLEUS_time_mapped_t0_dummy(which_nucleus,1) == 1)

width_surround = 10;

num_cells_surround = 0;

while (num_cells_surround <= num_cells_surround_max)&((num_cells_surround ~= sum(bPAC_NUCLEUS_time_mapped_t0_dummy(:,1)))|(which_movie == 43))

width_surround = width_surround + 1;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
    
    
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if (ii_NM==ii_NM_bPAC)&((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     elseif (ii_NM~=ii_NM_bPAC)
      index_group = [index_group; iii]; 
      ii_count = ii_count+1;
     end;
    end;
end;

num_cells_surround = ii_count;

end; % while (num_cells_surround < num_cells_surround_max)

if (num_cells_surround > num_cells_surround_max) 
width_surround = width_surround - 1;
end;

                 which_frame_start = 1;
                 x_coord_min = max(1,x_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 x_coord_max = min(xLength,x_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 y_coord_min = max(1,y_coord_min_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)-width_surround);
                 y_coord_max = min(yLength,y_coord_max_tot_NUCLEUS_time_mapped_t0(which_nucleus,which_frame_start)+width_surround);
                 
ii_count = 0;
index_group = [];

for iii = 1:num_nuclei_t0
    if (mean_x_tot_time_mapped_t0(iii,1) >= x_coord_min)&(mean_x_tot_time_mapped_t0(iii,1) <= x_coord_max)& (mean_y_tot_time_mapped_t0(iii,1) >= y_coord_min)&(mean_y_tot_time_mapped_t0(iii,1) <= y_coord_max)
     if ((bPAC_NUCLEUS_time_mapped_t0_dummy(iii,1) == 1)) % only bPAC cells
         matrix_bPAC(which_nucleus,iii) = 1;
         matrix_bPAC(iii,which_nucleus) = 1;
         matrix_bPAC_plus(which_nucleus,iii) = 1;
         matrix_bPAC_plus(iii,which_nucleus) = 1;
     else
         matrix_bPAC_plus(which_nucleus,iii) = 1;
         %matrix_bPAC_plus(iii,which_nucleus) = 1;
     end;
    end;
end;




          
end; %  if (bPAC_NUCLEUS_time_mapped_t0(which_nucleus,1) == 1) 


    
    
end; %  for jjj = 1:num_nuclei_t0



matrix_bPAC_test = matrix_bPAC;
nnz_matrix = zeros(num_nuclei_t0,1);
nnz_matrix_next = nnz_matrix;

count_clusters = 0;


for jj = 1:num_nuclei_t0

    indexCluster = find(matrix_bPAC_test(jj,:)>0);
    
  if (length(indexCluster) > 0)  % determine the whole cluster

    nnz_matrix(jj) = 1;
      
    while (sum(abs(nnz_matrix_next-nnz_matrix))~=0)        

      indexCluster_nnz = find(nnz_matrix>0); 
%      indexCluster_nnz_next = find(nnz_matrix>0); 
        
      for kk = 1:length(indexCluster_nnz)
         row = indexCluster_nnz(kk);
        %if (nnz_matrix(row)~=1)&(nnz_matrix_next(row)~=1)
        if (nnz_matrix(row)~=nnz_matrix_next(row))
          indexCluster = find(matrix_bPAC_test(row,:)>0);
         if length(indexCluster>0)
          for mm=1:length(indexCluster)
           nnz_matrix(indexCluster(mm)) = 1;
          end;
         end;
        nnz_matrix_next(row) = 1;
        end;
      end;
                
    end;
    
          indexCluster_nnz = find(nnz_matrix>0);
          bPAC_clusters(count_clusters+1,1:length(indexCluster_nnz)) = indexCluster_nnz;
          size_bPAC_clusters(count_clusters+1) = length(indexCluster_nnz);
          count_clusters = count_clusters+1;
          for kk = 1:length(indexCluster_nnz)
            matrix_bPAC_test(indexCluster_nnz(kk),:) = 0; % remove clustered events
          end;
          
          %indexCluster_nnz
        %pause;
          nnz_matrix = 0*nnz_matrix;
          nnz_matrix_next = 0*nnz_matrix_next;
  end;
    
end;

if (count_clusters>0)
  size_bPAC_clusters = size_bPAC_clusters(1:count_clusters);
  bPAC_clusters = bPAC_clusters(1:count_clusters,1:max(size_bPAC_clusters));
  %hot_spot_clusters
  %count_clusters
  %pause
else
    bPAC_clusters = [];
    size_bPAC_clusters = [];
end;

count_dummy_max = 0;
non_bPAC_clusters = 0*matrix_bPAC;

for jjj = 1:length(size_bPAC_clusters)
count_dummy = 0;
for iii = 1:size_bPAC_clusters(jjj)
    which_nucleus_bPAC = bPAC_clusters(jjj,iii);
    for kkk = 1:num_nuclei_t0
     if (matrix_bPAC_plus(which_nucleus_bPAC,kkk)-matrix_bPAC(which_nucleus_bPAC,kkk) == 1)
        if (count_dummy == 0)
        non_bPAC_clusters(jjj,count_dummy+1) = kkk;
        count_dummy = count_dummy + 1;
        elseif (min(abs(non_bPAC_clusters(jjj,1:count_dummy) - kkk)) ~= 0)    
        non_bPAC_clusters(jjj,count_dummy+1) = kkk; 
        count_dummy = count_dummy + 1;
        end;
        count_dummy_max = max(count_dummy_max,count_dummy);
     end;
    end;
end;
size_non_bPAC_clusters(jjj) = count_dummy;
end;



         
         



size_non_bPAC_clusters = size_non_bPAC_clusters(1:count_clusters);
non_bPAC_clusters = non_bPAC_clusters(1:count_clusters, 1:max(size_non_bPAC_clusters));

non_bPAC_clusters
size_non_bPAC_clusters

bPAC_clusters_location = 0*bPAC_clusters;  % outside bPAC cells

for jjj = 1:length(size_bPAC_clusters)
for iii = 1:size_bPAC_clusters(jjj)
    which_nucleus_bPAC = bPAC_clusters(jjj,iii);
     num_adjacent_non_bPAC =    sum(matrix_bPAC_plus(which_nucleus_bPAC,:)-matrix_bPAC(which_nucleus_bPAC,:));
     if (num_adjacent_non_bPAC>=2)
         bPAC_clusters_location(jjj,iii) = 1;
     end;
end;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Calculate_averaged signtures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mkdir(strcat(str_movie_processed_figures,'\bPAC_clusters_NSF'));
cd(strcat(str_movie_processed_figures,'\bPAC_clusters_NSF'));

     delete(strcat('bPAC_cluster_bPAC_signals-',str_movie,'.ppt'));
     delete(strcat('bPAC_cluster_non_bPAC_signals-',str_movie,'.ppt'));
     delete(strcat('average_signals_bPAC_cluster-',str_movie,'.ppt'));

     
     
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
% BEGIN: Make movie here     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     

kkk = 1;
which_frame = kkk;



if (which_movie == 3)  %160902_198_198-117_EA
 which_cluster = 1;  % set by user for making figures

 jjj = which_cluster;

 fac_reduce_CH1 = .3
 fac_reduce_NM_bPAC = .7
 x_min = 100;
 x_max = 300;
 shift_y = 0;
 y_min = 100-shift_y;
 y_max = 250-shift_y;
 which_frame_CH1 = [39 49 79 88];
 which_frame_CH1 = [29+shift_time_Erk 38+shift_time_Erk 69+shift_time_Erk 78++shift_time_Erk];
  
 extra_nuclei = [16];

elseif (which_movie == 101)  %031416_mwc_198_198-117_same
    
 which_cluster = 1;  % set by user for making figures
 extra_nuclei = [42]

 jjj = which_cluster;
 fac_reduce_CH1 = .3
 fac_reduce_NM_bPAC = .7
 x_min = 245;
 x_max = 350;
 shift_y = -0;
 y_min = 200-shift_y;
 y_max = 300-shift_y;
 which_frame_CH1 = [39 49 79 88];
 
 fac_reduce_CH1 = .5
 fac_reduce_NM_bPAC = .7
 x_min = 230;
 x_max = 350;
 shift_y = 70;
 y_min = 290-shift_y;
 y_max = 390-shift_y;

end;

 
for kkk_test = 1:length(which_frame_CH1)
    kkk = which_frame_CH1(kkk_test);
figure(110+jjj)
    eval(['[val,index_frame_bPAC]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM_bPAC),'));']);     
    eval(['M_NM_bPAC(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,index_frame_bPAC);']);
    eval(['M_NM_bPAC_t0(:,:) = M_CH',num2str(ii_NM_bPAC),'_total(:,:,1);']);
    %imshow(mat2gray(M_NM_bPAC));
    eval(['[val,index_frame]= min(abs(time_CH',num2str(1),'(kkk)-time_CH',num2str(ii_NM),'));']);     
    eval(['M_NM(:,:) = M_CH',num2str(ii_NM),'_total(:,:,index_frame);']);
    eval(['M_NM_t0(:,:) = M_CH',num2str(ii_NM),'_total(:,:,1);']);
    M_CH1(:,:) = M_CH1_total(:,:,kkk);
    %M_CH1_t0(:,:) = M_CH1_total(:,:,1);
    M_CH1_t0(:,:) = M_CH1_total(:,:,kkk);
    %imshow(mat2gray(M_NM));
    %%eval(['M_NM(:,:) = M_CH',num2str(1),'_total(:,:,index_frame);']);
    image_RGB = zeros(xLength,yLength,3);
    %image_RGB(:,:,1) = M_NM(:,:)/(fac_reduce_NMmax(max(M_NM_t0(x_min:x_max,y_min:y_max))));
    image_RGB(:,:,3) = M_NM_bPAC(:,:)/(fac_reduce_NM_bPAC*max(max(M_NM_bPAC_t0(x_min:x_max,y_min:y_max))));
    image_RGB(:,:,2) = M_CH1(:,:)/(fac_reduce_CH1*max(max(M_CH1_t0(x_min:x_max,y_min:y_max))));
    %image_RGB(:,:,2) = M_CH1(:,:)/(fac_reduce_CH1*max(max(M_CH1_t0(:,:))));
    imshow(image_RGB)
    xlim([x_min x_max]);
    ylim([y_min y_max]);
    
    title(strcat('bPAC cluster:',num2str(jjj)','which frame = ',num2str(kkk)));
      for iii = 1:size_bPAC_clusters(jjj)
         idx = bPAC_clusters(jjj,iii);   
         which_frame = kkk;
          if (bPAC_clusters_location(jjj,iii) == 1)         
           tt=text(mean_y_tot_time_mapped_t0(idx,index_frame),mean_x_tot_time_mapped_t0(idx,index_frame),strcat(num2str(idx),'*'));           
          else
           tt=text(mean_y_tot_time_mapped_t0(idx,index_frame),mean_x_tot_time_mapped_t0(idx,index_frame),strcat(num2str(idx)));           
          end;
         set(tt,'Color','w');
      end;
      for iii = 1:size_non_bPAC_clusters(jjj)
         idx = non_bPAC_clusters(jjj,iii);   
         tt=text(mean_y_tot_time_mapped_t0(idx,index_frame),mean_x_tot_time_mapped_t0(idx,index_frame),strcat(num2str(idx)));            
         set(tt,'Color','y');
      end;

      for iii = 1:length(extra_nuclei)
         idx = extra_nuclei(iii);   
         tt=text(mean_y_tot_time_mapped_t0(idx,index_frame),mean_x_tot_time_mapped_t0(idx,index_frame),strcat(num2str(idx)));            
         set(tt,'Color','y');
      end;      
      
   set(gcf,'inverthardcopy','off')   
   print('-depsc',strcat('signal_group_',num2str(which_frame),'-',str_movie,'.eps'));

    pause
end;  % for kkk = 1:numFr_CH(1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
% END: Make movie here     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
     

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
% BEGIN: Plot specific nuceli signal here:     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     

if (which_movie == 3)
which_nucleus = 16
%which_nucleus = 22
%which_nucleus = 29
%which_nucleus = 28
end

num_max_plots = 3;

idx = which_nucleus;

    figure(200)
    
    subplot(num_max_plots+1,1,1)     
        if (ii_plot_count+1==1)
         title(strcat('bPAC cluster:',num2str(jjj),', bPAC cell signals'));
        end;
         hold on;
     
         if (do_median_or_mean_signal == 0) % % 0-mean, 1-median
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0(idx,:));
         elseif (do_median_or_mean_signal == 1) % % 0-mean, 1-median
         %sig_dummy = double(nuclear_Erk_tot_time_mapped_t0_median(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         sig_dummy = double(nuclear_Erk_tot_time_mapped_t0(idx,:))./double(cytosolic_Erk_tot_time_mapped_t0_median(idx,:));
         end;     
         max_sig = max(sig_dummy)
         min_sig = min(sig_dummy)
         
         
         
     %ss = plot(time_Erk/scale_factor_time,(sig_dummy-min_sig)/(max_sig-min_sig),s_sig(ii_plot_count+1));
     ss = plot(time_Erk/scale_factor_time - shift_time_Erk,sig_dummy,s_sig(1));
               set(ss,'LineWidth',2);
               set(ss,'LineWidth',2);
     for ii = 1:num_bPAC_pulses     
         s_pulse = ['g' 'r'];
     %ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time,(sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))-min_sig)/(max_sig-min_sig),s_pulse(ii));
     ss = plot(time_Erk(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii))/scale_factor_time- shift_time_Erk,sig_dummy(index_bPAC_pulse_start_Erk(ii):index_bPAC_pulse_stop_Erk(ii)),s_pulse(1));
               set(ss,'LineWidth',3);
     end;
     

     if (bPAC_clusters_location(jjj,iii) == 1)         
     ylabel([strcat('nuc:',num2str(idx),'*'), 10, str_bPAC]);
     else
     ylabel([strcat('nuc:',num2str(idx)), 10, str_bPAC]);
     end;
      
      %if (num_bPAC_pulses == 1)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = ',num2str(bPAC_pulse_cell(idx,1)))); 
      %elseif (num_bPAC_pulses == 2)
      %text(.6*max(time_Erk)/scale_factor_time, .9*(min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))),strcat('passed pulse test = [',num2str(bPAC_pulse_cell(idx,1)),';',num2str(bPAC_pulse_cell(idx,2)),']')); 
      %end;
      
    %ylim([max(sig_dummy)+1.1*(min(sig_dummy)-max(sig_dummy)) min(sig_dummy)+1.1*(max(sig_dummy)-min(sig_dummy))]);
         ylim([.7 1.35]);
         xlim([0 max(time_Erk)/scale_factor_time-shift_time_Erk]);
     hold off;
    

        
     ii_plot_count = ii_plot_count+1;
        if (iii == size_bPAC_clusters(jjj))
          subplot(num_max_plots+1,1,num_max_plots+1)
          ylabel('bPAC');
          plot(time_bPAC/scale_factor_time-shift_time_Erk,bPAC_ledvals);
          xlim([0 max(time_Erk)/scale_factor_time-shift_time_bPAC]);
          ylim([0 1.1*max(bPAC_ledvals)]);
          ylabel('non-bPAC');
          xlabel(str_time_representation);
          print('-depsc',strcat('nucleus_',num2str(idx),'-bPAC_fig_',num2str(ii_figure_count_tot),'-',str_movie,'.eps'));          
        end;



     
cd(str_processing);